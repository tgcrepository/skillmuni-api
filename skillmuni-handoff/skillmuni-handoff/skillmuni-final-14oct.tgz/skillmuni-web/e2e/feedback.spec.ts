import { test, expect } from '@playwright/test';
import { axe, logIn } from './support/helpers';

/** A-274: "How's Skillmuni treating you?" — a non-modal card, +5 XP once a month. */
test.describe('Feedback card', () => {
  test('mood → what stood out → thanks with XP; also from Profile any time', async ({ page }) => {
    await logIn(page);
    await page.goto('/home?feedback=now');
    const card = page.getByRole('dialog', { name: 'How’s Skillmuni treating you?' });
    await expect(card).toBeVisible();
    await card.getByRole('button', { name: 'Loving it' }).click();
    await expect(card.getByText('What stood out?')).toBeVisible();
    await card.locator('label.chip', { hasText: 'Job matches' }).click();
    await axe(page);
    await card.getByRole('button', { name: 'Send' }).click();
    await expect(page.getByText('Thanks, that really helps!')).toBeVisible();
    await expect(page.getByText(/\+5 XP added/)).toBeVisible();

    await page.goto('/profile');
    await page.getByRole('button', { name: 'Settings' }).click();
    await page.getByRole('menuitem', { name: 'Give feedback' }).click();
    await expect(page.getByRole('dialog', { name: 'How’s Skillmuni treating you?' })).toBeVisible();
    await page.getByRole('button', { name: 'Close feedback' }).click();
    await expect(page.getByRole('dialog', { name: 'How’s Skillmuni treating you?' })).toHaveCount(0);
  });

  test('does not pop up for a brand-new session without a success moment', async ({ page }) => {
    await logIn(page);
    await page.goto('/home');
    await page.waitForTimeout(2600);
    await expect(page.getByRole('dialog', { name: 'How’s Skillmuni treating you?' })).toHaveCount(0);
  });
});
