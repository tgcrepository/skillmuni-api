import { test, expect } from '@playwright/test';
import { axe, logIn } from './support/helpers';

test.describe('Learn: module → briefs → quiz', () => {
  test.describe.configure({ timeout: 90_000 });

  test('Brain Vita: topics, Muni’s next step, brief reader', async ({ page }) => {
    await logIn(page);
    await page.getByRole('link', { name: 'Brain Vita', exact: true }).click();
    await expect(page).toHaveURL(/\/learn\/brain-vita$/);
    await expect(page.getByRole('heading', { level: 1 })).toHaveText('Brain Vita');
    await expect(
      page.getByRole('link', { name: /^Non-Verbal Reasoning\. 1 left\./ }),
    ).toBeVisible();
    // Lobby stays the current nav item inside learning.
    await expect(page.getByRole('link', { name: 'Lobby', exact: true })).toHaveAttribute(
      'aria-current',
      'page',
    );
    await axe(page);

    await page.getByRole('link', { name: /^Non-Verbal Reasoning\./ }).click();
    await expect(page).toHaveURL(/\/learn\/brain-vita\/non-verbal-reasoning$/);
    await expect(page.getByRole('heading', { name: 'Mirror and Water Images' })).toBeVisible();
    await expect(page.getByRole('progressbar', { name: 'Briefs done' })).toHaveAttribute(
      'aria-valuetext',
      '10 done · 1 to go',
    );
    await axe(page);

    // Finished briefs collapse; expand the group and review one.
    const group = page.getByRole('button', { name: /9 briefs done/ });
    await group.click();
    await expect(group).toHaveAttribute('aria-expanded', 'true');
    await page.getByRole('button', { name: /Brief 10 Embedded Figures/ }).click();
    await expect(page.getByRole('heading', { name: 'Embedded Figures' })).toBeVisible();

    // Bookmark + feedback on the open brief.
    const card = page.getByRole('article', { name: 'Mirror and Water Images' });
    await card.getByRole('button', { name: 'Bookmark this brief' }).click();
    await expect(card.getByRole('button', { name: 'Bookmark this brief' })).toHaveAttribute(
      'aria-pressed',
      'true',
    );
    await card.getByRole('button', { name: 'Yes, helpful' }).click();
    await expect(card.getByRole('button', { name: 'Yes, helpful' })).toHaveAttribute(
      'aria-pressed',
      'true',
    );

    // Full-screen image.
    await card.getByRole('button', { name: 'View image full screen' }).click();
    await expect(page.getByRole('dialog', { name: 'Mirror and Water Images' })).toBeVisible();
    await page.keyboard.press('Escape');
    await expect(page.getByRole('dialog')).toHaveCount(0);
  });

  test('quiz: answer all, reveal, retry the miss as practice, back to briefs', async ({ page }) => {
    await logIn(page);
    await page.goto('/learn/brain-vita');
    await page.getByRole('link', { name: /Take the last quiz/ }).click();
    await expect(page).toHaveURL(/non-verbal-reasoning\/quiz$/);

    const submit = page.getByRole('button', { name: 'Submit answers' });
    await expect(submit).toHaveAttribute('aria-disabled', 'true');
    await page
      .getByRole('radio', { name: 'Top and bottom swap', exact: true })
      .check({ force: true });
    await page
      .getByRole('radio', { name: 'Top and bottom swap, left and right stay' })
      .check({ force: true });
    await expect(page.getByText('2 of 3 answered · answer all to submit')).toBeVisible();
    await axe(page);
    await page
      .getByRole('radio', { name: 'BAC, with every letter flipped sideways' })
      .check({ force: true });
    await submit.click();

    await expect(
      page.getByRole('heading', { name: 'Nice one, Yash! 2 of 3 correct' }),
    ).toBeVisible();
    // Focus moves to the results summary.
    await expect(
      page.getByRole('region', { name: 'Nice one, Yash! 2 of 3 correct' }),
    ).toBeFocused();
    await expect(page.getByText('Not quite')).toBeVisible();
    await expect(page.getByText('Your pick: Top and bottom swap')).toBeVisible();
    await axe(page);

    await page.getByRole('button', { name: 'Retry 1 wrong' }).click();
    await expect(page.getByRole('heading', { name: 'Have another go' })).toBeVisible();
    await page
      .getByRole('radio', { name: 'Left and right swap', exact: true })
      .check({ force: true });
    await page.getByRole('button', { name: 'Check' }).click();
    await expect(page.getByRole('heading', { name: 'Nailed it this time!' })).toBeVisible();
    await expect(page.getByText('Practice only · no XP')).toBeVisible();

    await page.getByRole('button', { name: 'Continue' }).click();
    await expect(page).toHaveURL(/non-verbal-reasoning$/);
    await expect(page.getByText('You did it! 2/3 correct')).toBeVisible();
    await expect(page.getByRole('link', { name: /Open the course/ })).toBeVisible();
    await axe(page);
  });

  test('module error and unknown topic states', async ({ page }) => {
    await logIn(page);
    await page.goto('/learn/brain-vita?learn=error');
    await expect(page.getByRole('alert')).toContainText('Couldn’t load this module');
    await page.goto('/learn/brain-vita/nope');
    await expect(page.getByRole('heading', { name: 'We couldn’t find that topic' })).toBeVisible();
  });
});
