import { test, expect, Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

/**
 * Locks in the 14 Oct corrections round (Skillmuni_India_Corrections.docx) so none of them slips back.
 * A new learner part-way through the quests is seeded straight into the mock backend.
 */
const AXE_TAGS = ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'];
const axe = async (page: Page) => {
  await page.waitForFunction(() =>
    document
      .getAnimations()
      .every(
        (a) => a.playState !== 'running' || a.effect?.getComputedTiming().iterations === Infinity,
      ),
  );
  expect((await new AxeBuilder({ page }).withTags(AXE_TAGS).analyze()).violations).toEqual([]);
};

async function seedNewLearner(page: Page, completed: number, partsDone: number, xp: number) {
  await page.context().addCookies([{ name: 'sm_mock_session', value: '1', url: page.url() || 'http://localhost:4200' }]);
  await page.addInitScript(
    ([c, p, x]) => {
      if (sessionStorage.getItem('__seeded')) return;
      sessionStorage.setItem('__seeded', '1');
      sessionStorage.setItem('sm_mock_persona', 'new');
      sessionStorage.setItem(
        'sm_persona_name',
        JSON.stringify({ first: 'Yash', last: 'Pohare', email: 'yash.p@gmail.com' }),
      );
      sessionStorage.setItem(
        'sm_mock_quests',
        JSON.stringify({
          progress: { completed: c, partsDone: p, xp: x, badges: c, level: 1, rank: 'Rookie', target: 400 },
          answers: { 'who-dis': { firstName: 'Yash', lastName: 'Pohare' } },
        }),
      );
    },
    [completed, partsDone, xp] as const,
  );
}

test.describe('Corrections · 14 Oct', () => {
  test.describe.configure({ timeout: 60_000 });

  test('#8 backup contact: mobile optional, +20 XP only when it is given', async ({ page }) => {
    await page.goto('/login');
    await seedNewLearner(page, 1, 1, 130);
    await page.goto('/quests/hit-me-up?part=2');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('ride-or-die');
    const next = page.getByRole('button', { name: /Next part/ });
    await expect(page.getByText('Add their mobile number to earn +20 XP')).toBeVisible();
    await expect(next).not.toContainText('+20 XP');
    await page.getByRole('textbox', { name: /mobile number/i }).fill('91234 56789');
    await expect(next).toContainText('+20 XP');
    // Typing scrolled the lineup under the sticky top bar; axe counts what sits behind a sticky
    // bar as overlapping it, so audit the step from the top of the page.
    await page.evaluate(() => window.scrollTo(0, 0));
    await axe(page);
  });

  test('#11 trophy shelf: says how to earn its XP; finishing pays only the quest bonus', async ({
    page,
  }) => {
    await page.goto('/login');
    await seedNewLearner(page, 3, 2, 370);
    await page.goto('/quests/your-flex-era?part=3');
    await expect(page.getByText('Add a certificate to earn +20 XP')).toBeVisible();
    await expect(page.getByRole('button', { name: /Reveal my card/ })).toContainText('+50 XP');
  });

  test('#12 player card reveal shows the badge earned and the level ladder', async ({ page }) => {
    await page.goto('/login');
    await seedNewLearner(page, 3, 2, 370);
    await page.goto('/quests/your-flex-era?part=3');
    await page.getByRole('button', { name: /Skip for now/ }).click();
    const reveal = page.getByRole('dialog');
    await expect(reveal.getByText('Badge earned')).toBeVisible();
    await expect(reveal.getByText(/Level 2 · Pathfinder unlocked/i)).toBeVisible();
    await expect(reveal.getByText('Pathfinder', { exact: true })).toBeVisible();
  });

  test('#32 no sound button in the top bar; sound effects switch lives in Settings', async ({
    page,
  }) => {
    await page.goto('/login');
    await seedNewLearner(page, 8, 0, 760);
    await page.goto('/profile');
    await expect(page.getByRole('heading', { name: 'My Profile' })).toBeVisible();
    await expect(page.locator('sm-audio-toggle')).toHaveCount(0);
    await page.getByRole('button', { name: 'Settings' }).click();
    const sound = page.getByRole('menuitemcheckbox', { name: /Sound effects/ });
    await expect(sound).toHaveAttribute('aria-checked', 'true');
    await expect(page.getByRole('menuitem', { name: 'Edit profile' })).toHaveCount(0);
    await sound.click();
    await page.getByRole('button', { name: 'Settings' }).click();
    await expect(page.getByRole('menuitemcheckbox', { name: /Sound effects/ })).toHaveAttribute(
      'aria-checked',
      'false',
    );
  });

  test('#13/#24 profile: one rank everywhere, level ladder, quest badges counted', async ({
    page,
  }) => {
    await page.goto('/login');
    await seedNewLearner(page, 8, 0, 760);
    await page.goto('/profile');
    await expect(page.getByText(/Pathfinder · joined/)).toBeVisible();
    await expect(page.getByText('LVL 2')).toBeVisible();
    await expect(page.getByText('400 XP').first()).toBeVisible();
    await page.goto('/stats/badges');
    await expect(page.getByText('8 of 8 earned')).toBeVisible();
    await expect(page.locator('sm-badge-medal img.art').first()).toBeVisible();
  });

  test('#22 private details Edit opens only the private fields', async ({ page }) => {
    await page.goto('/login');
    await seedNewLearner(page, 8, 0, 760);
    await page.goto('/profile');
    await page.getByRole('button', { name: 'Edit', exact: true }).click();
    const dialog = page.getByRole('dialog', { name: 'Edit private details' });
    await expect(dialog.getByRole('heading', { name: 'Gender' })).toBeVisible();
    await expect(dialog.getByRole('heading', { name: 'Your top skills' })).toHaveCount(0);
  });

  test('#31 an empty screen leads back to where you came from', async ({ page }) => {
    await page.goto('/login');
    await seedNewLearner(page, 8, 0, 760);
    await page.goto('/stats');
    await page.getByRole('link', { name: /My goals/ }).click();
    await expect(page).toHaveURL(/\/goals$/);
    await page.getByRole('button', { name: 'Go back' }).click();
    await expect(page).toHaveURL(/\/stats$/);
  });

  test('#38 the top bar stays on sub-pages on phones', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/login');
    await seedNewLearner(page, 8, 0, 760);
    await page.goto('/jobs');
    await expect(page.getByRole('link', { name: 'Skillmuni Lobby' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'My Jobs' })).toBeVisible();
  });

  test('#3 Privacy Policy opens full screen from sign-up', async ({ page }) => {
    await page.goto('/signup');
    await page.getByRole('link', { name: /Privacy Policy/ }).first().click();
    const dialog = page.getByRole('dialog', { name: 'Privacy Policy & Terms' });
    await expect(dialog).toBeVisible();
    const box = await dialog.boundingBox();
    const vw = page.viewportSize()?.width ?? 0;
    expect(Math.round(box?.width ?? 0)).toBeGreaterThanOrEqual(vw - 2);
  });
});
