import { test, expect, Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const AXE_TAGS = ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'];
const axe = async (page: Page) =>
  expect((await new AxeBuilder({ page }).withTags(AXE_TAGS).analyze()).violations).toEqual([]);

test.describe('A-289 Privacy Policy & Terms', () => {
  test('signup opens the policy over the form and keeps what was typed', async ({ page }) => {
    await page.goto('/signup');
    const first = page.getByRole('textbox', { name: /First name/ });
    await first.fill('Asha');
    await page.getByRole('link', { name: 'Privacy Policy & Terms' }).click();
    const drawer = page.getByRole('dialog', { name: 'Privacy Policy & Terms' });
    await expect(drawer.getByRole('tab', { name: 'Privacy Policy' })).toHaveAttribute(
      'aria-selected',
      'true',
    );
    await expect(drawer.getByRole('heading', { name: /User Provided Information/ })).toBeVisible();
    await expect(drawer.getByRole('link', { name: /thegamificationcompany\.com/ })).toBeVisible();
    await axe(page);
    await drawer.getByRole('tab', { name: 'Terms of Use' }).click();
    await expect(drawer.getByRole('heading', { name: /Limitations of liability/ })).toBeVisible();
    await drawer.getByRole('button', { name: 'Got it' }).click();
    await expect(drawer).toBeHidden();
    await expect(page).toHaveURL(/\/signup$/);
    // Opening the policy never ticks the consent box.
    await expect(page.getByRole('checkbox', { name: /I agree/ })).not.toBeChecked();
    await expect(first).toHaveValue('Asha');
  });

  test('/legal/terms is public and switches to /legal/privacy', async ({ page }) => {
    await page.goto('/legal/terms');
    await expect(page.getByRole('heading', { level: 1 })).toHaveText('Privacy Policy & Terms');
    await expect(page.getByRole('heading', { name: /Acceptable use/ })).toBeVisible();
    await axe(page);
    await page.getByRole('tab', { name: 'Privacy Policy' }).click();
    await expect(page).toHaveURL(/\/legal\/privacy$/);
    await page.getByRole('link', { name: /Governing Law and Jurisdiction/ }).click();
    await expect(page.getByText(/jurisdiction in Pune/)).toBeInViewport();
  });

  test('login no longer carries the SMS-rates line', async ({ page }) => {
    await page.goto('/login');
    await expect(page.getByText(/Standard SMS rates may apply/)).toHaveCount(0);
  });
});
