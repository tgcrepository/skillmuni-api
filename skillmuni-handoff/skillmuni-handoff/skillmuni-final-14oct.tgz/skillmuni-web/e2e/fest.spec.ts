import { test, expect, Page } from '@playwright/test';
import { axe, logIn } from './support/helpers';

async function openFest(page: Page, name: string): Promise<void> {
  await page.locator('sm-fest-card', { hasText: name }).getByRole('link').click();
  await expect(page.getByRole('heading', { level: 2, name })).toBeVisible();
}

test.describe('Hire Fest', () => {
  test.describe.configure({ timeout: 120_000 });

  test('switching tabs never adds history: Back from Past returns to the Launchpad (A-305)', async ({
    page,
  }) => {
    await logIn(page);
    await page.goto('/launchpad');
    await page.goto('/hire-fest');
    await page.getByRole('link', { name: /^My bookings/ }).click();
    await page.getByRole('link', { name: /^Past/ }).click();
    await expect(page).toHaveURL(/\/hire-fest\/past$/);
    await page.getByRole('button', { name: 'Back' }).first().click();
    await expect(page).toHaveURL(/\/launchpad$/);
  });

  test('H1/H2 browse, filter and fest detail', async ({ page }) => {
    await logIn(page);
    await page.goto('/hire-fest');
    await expect(page.getByRole('heading', { level: 1, name: 'Hire Fest' })).toBeVisible();
    await expect(page.locator('sm-fest-card')).toHaveCount(4);
    await axe(page);

    await page.locator('label.fchip', { hasText: 'Online' }).click();
    await expect(page.locator('sm-fest-card')).toHaveCount(1);
    await page.locator('label.fchip', { hasText: 'All' }).click();
    await expect(page.locator('sm-fest-card')).toHaveCount(4);

    await openFest(page, 'Online Hire Fest: Customer Support');
    await expect(page.getByText('Online on SkillMuni Meet')).toBeVisible();
    await expect(page.getByText('Do the 1-min test call the day before')).toBeVisible();
    await axe(page);
  });

  test('H3–H6 book two employers with clash rules, get a QR ticket', async ({ page }) => {
    await logIn(page);
    await page.goto('/hire-fest');
    await openFest(page, 'Tech & BPO Hire Fest');
    await page.getByRole('button', { name: 'Book an interview slot' }).click();

    // H3: max 2 employers; Concentrix is full.
    await expect(page.getByRole('heading', { name: 'Who do you want to meet?' })).toBeVisible();
    await page.locator('label.pick', { hasText: 'Cognizant' }).click();
    await page.locator('label.pick', { hasText: 'Teleperformance' }).click();
    await expect(page.getByRole('checkbox', { name: /HDFC Life/ })).toBeDisabled();
    await expect(page.getByText('2 employers selected')).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Next: pick times' }).click();

    // H4: picking 10:30 with Cognizant blocks clashing Teleperformance times.
    await expect(page.getByRole('heading', { name: 'Pick your times' })).toBeVisible();
    await page
      .getByRole('list', { name: 'Cognizant · Customer Support' })
      .getByRole('button', { name: /^10:30 am/ })
      .click();
    const tp = page.getByRole('list', { name: 'Teleperformance · Voice Process Exec' });
    await expect(tp.getByRole('button', { name: /^10:30 am Clashes/ })).toHaveAttribute(
      'aria-disabled',
      'true',
    );
    await expect(tp.getByRole('button', { name: /^11:00 am Clashes/ })).toHaveAttribute(
      'aria-disabled',
      'true',
    );
    await tp.getByRole('button', { name: /^12:00 pm/ }).click();
    await expect(page.getByText('2 interviews')).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Next: review' }).click();

    // H5 → H6.
    await expect(page.getByRole('heading', { name: 'Check and confirm' })).toBeVisible();
    await expect(page.getByRole('switch', { name: /WhatsApp reminder/ })).toBeChecked();
    await axe(page);
    await page.getByRole('button', { name: 'Confirm booking' }).click();
    await expect(page.getByRole('heading', { name: 'You’re booked! 🎉' })).toBeVisible();
    await expect(page.getByRole('img', { name: /Ticket QR code for booking HF-/ })).toBeVisible();
    await expect(page.getByText('Hall B, Desk 4')).toBeVisible();
    await axe(page);
  });

  test('H7/H8 bookings: ticket, cancel one interview', async ({ page }) => {
    await logIn(page);
    await page.goto('/hire-fest/bookings');
    const card = page.locator('.booking', { hasText: 'Retail & Hospitality Hire Fest' });
    await expect(card.getByText('In 22 days')).toBeVisible();
    await card.getByRole('button', { name: 'View ticket' }).click();
    await expect(card.getByRole('img', { name: /Ticket QR code/ })).toBeVisible();
    await axe(page);
    await card.getByRole('button', { name: 'Cancel' }).click();
    const dialog = page.getByRole('dialog', { name: 'Cancel your booking?' });
    await dialog.getByRole('button', { name: 'Can’t travel' }).click();
    await axe(page);
    await dialog.getByRole('button', { name: 'Cancel booking' }).click();
    await expect(page.getByRole('heading', { name: 'No bookings yet' })).toBeVisible();
  });

  test('H9 waitlist and H10 locked', async ({ page }) => {
    await logIn(page);
    await page.goto('/hire-fest');
    await openFest(page, 'Tech & BPO Hire Fest');
    await page.getByRole('button', { name: 'Book an interview slot' }).click();
    await page.locator('label.pick', { hasText: 'Concentrix' }).click();
    const wl = page.getByRole('dialog', { name: 'Join the Concentrix waitlist' });
    await expect(wl.getByText('#4')).toBeVisible();
    await axe(page);
    await wl.getByRole('button', { name: 'Join waitlist' }).click();
    await expect(page.getByText('You’re #4 on the Concentrix waitlist')).toBeVisible();

    await page.goto('/hire-fest?hf=locked');
    await openFest(page, 'Tech & BPO Hire Fest');
    await page.getByRole('button', { name: 'Book an interview slot' }).click();
    const lock = page.getByRole('dialog', { name: 'Almost there!' });
    await expect(lock.getByRole('progressbar', { name: 'Job profile done' })).toHaveAttribute(
      'aria-valuenow',
      '45',
    );
    await axe(page);
  });

  test('H12 live check-in, H13 past outcomes, H11 no fests', async ({ page }) => {
    await logIn(page);
    await page.goto('/hire-fest/bookings?hf=live');
    await expect(page.getByText('✓ Checked in 10:12')).toBeVisible();
    await expect(page.getByText('#3')).toBeVisible();
    await axe(page);

    await page.goto('/hire-fest/past');
    const row = page.locator('.out', { hasText: 'ICICI Lombard' });
    await row.locator('label', { hasText: 'Offer' }).click();
    await expect(page.getByText('Congrats! Added to My Jobs → Applied.')).toBeVisible();
    await axe(page);

    await page.goto('/hire-fest?hf=none');
    await expect(
      page.getByRole('heading', { name: 'No hire fests near you right now' }),
    ).toBeVisible();
    await expect(page.getByRole('switch', { name: /Online fests/ })).toBeChecked();
    await axe(page);
  });
});
