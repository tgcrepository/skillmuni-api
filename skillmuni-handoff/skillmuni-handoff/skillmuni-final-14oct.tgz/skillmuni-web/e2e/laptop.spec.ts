import { test, expect, Page } from '@playwright/test';
import { logIn } from './support/helpers';

/**
 * A-239 / A-240: a 1920×1080 laptop at 150% Windows scaling leaves ~1280×550 CSS px. The UI
 * scales down instead of cropping, and Muni never runs below the fold in the quests.
 */
const inView = async (page: Page, selector: string) => {
  const box = await page.locator(selector).first().boundingBox();
  const vp = page.viewportSize();
  return !!box && !!vp && box.y >= 0 && box.y + box.height <= vp.height + 1;
};

test.describe('Laptop fit', () => {
  test.beforeEach(() => test.skip(test.info().project.name !== 'desktop', 'desktop only'));
  test.describe.configure({ timeout: 60_000 });

  test('short laptop: login fits, root scales down', async ({ page }) => {
    await page.setViewportSize({ width: 1280, height: 550 });
    await page.goto('/login');
    await expect(page.getByRole('button', { name: /Send me the code/ })).toBeVisible();
    expect(await inView(page, 'button[type="submit"]')).toBe(true);
    const root = await page.evaluate(() =>
      parseFloat(getComputedStyle(document.documentElement).fontSize),
    );
    expect(root).toBeLessThan(16);
    expect(root).toBeGreaterThanOrEqual(13);
  });

  test('big laptop keeps the design size', async ({ page }) => {
    await page.setViewportSize({ width: 1536, height: 740 });
    await page.goto('/login');
    const root = await page.evaluate(() =>
      parseFloat(getComputedStyle(document.documentElement).fontSize),
    );
    expect(root).toBe(16);
  });

  test('quest rail: Muni stays inside the viewport while the card scrolls', async ({ page }) => {
    await logIn(page);
    await page.setViewportSize({ width: 1536, height: 730 });
    await page.goto('/quests/who-dis');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('call you?');
    await page.mouse.wheel(0, 400);
    expect(await inView(page, '.rail sm-muni-character img')).toBe(true);
  });
});
