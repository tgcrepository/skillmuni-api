import { test, expect, Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const AXE_TAGS = ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'];
const axe = async (page: Page) => {
  await page.waitForFunction(() =>
    document
      .getAnimations()
      .every(
        (a) => a.playState !== 'running' || a.effect?.getComputedTiming().iterations === Infinity,
      ),
  );
  expect((await new AxeBuilder({ page }).withTags(AXE_TAGS).analyze()).violations).toEqual([]);
};

async function logIn(page: Page) {
  await page.goto('/login');
  await page.getByRole('textbox', { name: 'Mobile number' }).fill('98765 43210');
  await page.getByRole('button', { name: /Send me the code/ }).click();
  await expect(page.getByRole('dialog', { name: 'Enter the 6-digit code' })).toBeVisible();
  await page.keyboard.type('123456');
  await expect(page).toHaveURL(/\/home$/);
}

test.describe('Lobby (Home v2)', () => {
  test.describe.configure({ timeout: 60_000 });

  test('login lands on the Lobby with greeting, resume, pathways and knooks', async ({ page }) => {
    await logIn(page);
    await expect(page.getByRole('heading', { level: 1 })).toContainText(
      /Good (morning|afternoon|evening),/,
    );
    await expect(page.getByRole('heading', { name: 'Pick up where you left off' })).toBeVisible();
    await expect(page.getByRole('progressbar', { name: 'Module progress' })).toHaveAttribute(
      'aria-valuenow',
      '99',
    );
    await expect(page.getByRole('link', { name: /Career Launchpad/ })).toBeVisible();
    await expect(page.getByRole('link', { name: 'Brain Vita', exact: true })).toBeVisible();
    // Lobby is the current page in the nav.
    await expect(page.getByRole('link', { name: 'Lobby', exact: true })).toHaveAttribute(
      'aria-current',
      'page',
    );
    await axe(page);
  });

  test('knooks show six; Show more opens every module; nav reaches the placeholders', async ({
    page,
  }) => {
    await logIn(page);
    // A-255: the Lobby shows up to six; the knook screen shows all of them.
    await expect(page.getByRole('link', { name: 'Surgical Strike' }).first()).toBeAttached();
    await expect(page.getByRole('link', { name: 'Money Smart' })).toHaveCount(0);
    await page.getByRole('link', { name: 'Show all modules in Skill Knook' }).click();
    await expect(page).toHaveURL(/\/knooks\/skill$/);
    await expect(page.getByRole('heading', { level: 1, name: 'Skill Knook' })).toBeVisible();
    await expect(page.getByText('10 modules')).toBeVisible();
    await expect(page.getByRole('link', { name: 'Money Smart' })).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await expect(page).toHaveURL(/\/home$/);
    await page.getByRole('link', { name: 'Show all modules in Course Knook' }).click();
    await expect(page.getByRole('link', { name: 'Digital Basics' })).toBeVisible();
    await page.goto('/home');

    // Rewards store is still a placeholder (A-172).
    await page
      .getByRole('link', { name: /^Rewards/ })
      .filter({ visible: true })
      .first()
      .click();
    await expect(page).toHaveURL(/\/rewards$/);
    await expect(
      page.getByRole('heading', { name: 'Rewards is on its way' }).first(),
    ).toBeVisible();
    await axe(page);
    await page.getByRole('link', { name: 'Back to the Lobby' }).click();
    await expect(page).toHaveURL(/\/home$/);
  });

  test('avatar menu: My profile and Log out; Muni asks before logging out (corrections #40)', async ({
    page,
  }) => {
    await logIn(page);
    await page.getByRole('button', { name: /^Account menu,/ }).click();
    await page.getByRole('menuitem', { name: 'My profile' }).click();
    await expect(page).toHaveURL(/\/profile$/);
    await page.getByRole('button', { name: /^Account menu,/ }).click();
    await page.getByRole('menuitem', { name: 'Log out' }).click();
    const bye = page.getByRole('dialog', { name: /Leaving so soon/ });
    await expect(bye.getByRole('button', { name: 'Stay and keep going' })).toBeVisible();
    await axe(page);
    // Staying keeps you here.
    await bye.getByRole('button', { name: 'Stay and keep going' }).click();
    await expect(bye).toHaveCount(0);
    await expect(page).toHaveURL(/\/profile$/);
    await page.getByRole('button', { name: 'Settings' }).click();
    await page.getByRole('menuitem', { name: 'Log out' }).click();
    await page.getByRole('dialog', { name: /Leaving so soon/ }).getByRole('button', { name: 'Log out anyway' }).click();
    await expect(page).toHaveURL(/\/login/);
  });

  test('error state retries', async ({ page }) => {
    await logIn(page);
    await page.goto('/home?home=error');
    await expect(page.getByRole('alert')).toContainText('Couldn’t load your Lobby');
    await axe(page);
  });
});
