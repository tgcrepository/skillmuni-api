import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test.describe('foundation smoke', () => {
  test('token preview renders with Figma values and is axe-clean', async ({ page }) => {
    await page.goto('/_dev/tokens');
    await expect(page.getByRole('heading', { level: 1, name: 'Design tokens' })).toBeVisible();

    const textPrimary = await page.evaluate(() =>
      getComputedStyle(document.documentElement).getPropertyValue('--sm-ref-color-ink-50').trim(),
    );
    expect(textPrimary).toBe('#f5f7ff');

    const results = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag22aa'])
      .analyze();
    expect(results.violations).toEqual([]);
  });

  test('body uses Poppins from the token stack', async ({ page }) => {
    await page.goto('/_dev/tokens');
    const family = await page.evaluate(() => getComputedStyle(document.body).fontFamily);
    expect(family).toContain('Poppins');
  });
});
