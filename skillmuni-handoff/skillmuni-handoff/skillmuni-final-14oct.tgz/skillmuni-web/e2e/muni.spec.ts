import { test, expect } from '@playwright/test';
import { axe, logIn } from './support/helpers';

test.describe('Muni chat', () => {
  test.describe.configure({ timeout: 90_000 });

  test('welcome → profile with masked reveal → chip → Esc returns focus', async ({ page }) => {
    await logIn(page);
    const launcher = page.getByRole('button', { name: /^Chat with Muni/ });
    await expect(launcher).toHaveAccessibleName('Chat with Muni, 2 new');
    await launcher.click();

    const dialog = page.getByRole('dialog', { name: 'Muni' });
    await expect(dialog).toBeVisible();
    await expect(dialog.getByText('Heyyy Yash 👋')).toBeVisible();
    await expect(dialog.getByRole('textbox', { name: 'Message Muni' })).toBeFocused();
    await axe(page);

    await dialog.getByRole('textbox', { name: 'Message Muni' }).fill('Show my profile');
    await page.keyboard.press('Enter');
    await expect(dialog.getByText('Yash Pohare')).toBeVisible();
    // Private bits arrive masked; the eye fetches the real value.
    await expect(dialog.getByText('y••••@thegamification.com')).toBeVisible();
    await dialog.getByRole('button', { name: 'Show Email' }).click();
    await expect(dialog.getByText('yash.pohare@thegamification.com')).toBeVisible();
    await expect(dialog.getByRole('button', { name: 'Hide Email' })).toBeVisible();
    await axe(page);

    const chips = dialog.getByRole('group', { name: 'Follow-ups' });
    await expect(chips.getByRole('button')).toHaveCount(3);
    await chips.getByRole('button', { name: 'My XP & rank' }).click();
    await expect(dialog.getByRole('link', { name: 'Open the Arena' })).toBeVisible();
    // Only the newest reply keeps chips.
    await expect(dialog.getByRole('group', { name: 'Follow-ups' })).toHaveCount(1);

    await dialog.getByRole('button', { name: 'Good answer' }).last().click();
    await expect(dialog.getByRole('button', { name: 'Good answer' }).last()).toHaveAttribute(
      'aria-pressed',
      'true',
    );

    await page.keyboard.press('Escape');
    await expect(dialog).toHaveCount(0);
    await expect(launcher).toBeFocused();
    // Opening clears the unread badge.
    await expect(launcher).toHaveAccessibleName('Chat with Muni');
  });

  test('topic tile, history and a failed reply with retry', async ({ page }) => {
    await logIn(page);
    await page.goto('/home?muni=error');
    await page.getByRole('button', { name: /^Chat with Muni/ }).click();
    const dialog = page.getByRole('dialog', { name: 'Muni' });

    await dialog.getByRole('button', { name: /^Jobs/ }).click();
    await expect(
      dialog.getByText('Oops, I lost my train of thought. Try that again?'),
    ).toBeVisible();
    await expect(dialog.getByRole('button', { name: 'Try again' })).toBeVisible();

    await dialog.getByRole('button', { name: 'Chat history' }).click();
    await expect(dialog.getByRole('heading', { name: 'Past chats' })).toBeVisible();
    await dialog.getByRole('button', { name: /^My XP & rank/ }).click();
    await expect(dialog.getByText('You’re #3 this week with 41 XP. Keep going!')).toBeVisible();
    await axe(page);

    await dialog.getByRole('button', { name: 'Close Muni' }).click();
    await expect(dialog).toHaveCount(0);
  });
});
