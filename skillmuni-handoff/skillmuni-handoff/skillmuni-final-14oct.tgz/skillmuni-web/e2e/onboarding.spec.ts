import { test, expect, Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { deflateSync } from 'node:zlib';

const AXE_TAGS = ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'];
/** Audit the settled UI: wait for entry animations (looping decoration aside) to finish first. */
const axe = async (page: Page) => {
  await page.waitForFunction(() =>
    document
      .getAnimations()
      .every(
        (a) => a.playState !== 'running' || a.effect?.getComputedTiming().iterations === Infinity,
      ),
  );
  expect((await new AxeBuilder({ page }).withTags(AXE_TAGS).analyze()).violations).toEqual([]);
};

async function logIn(page: Page) {
  await page.goto('/login');
  await page.getByRole('textbox', { name: 'Mobile number' }).fill('98765 43210');
  await page.getByRole('button', { name: /Send me the code/ }).click();
  await expect(page.getByRole('dialog', { name: 'Enter the 6-digit code' })).toBeVisible();
  await page.keyboard.type('123456');
  await expect(page).toHaveURL(/\/home$/);
  await page.goto('/welcome-back');
}

const cv = (name: string) => ({
  name,
  mimeType: 'application/pdf',
  buffer: Buffer.from('%PDF-1.4 mock'),
});

test.describe('6c Entry: E1 → E2 → E3 → E4', () => {
  // Long journeys through the dev server; 30 s is tight when workers run in parallel.
  test.describe.configure({ timeout: 60_000 });
  test.beforeEach(async ({ page }) => logIn(page));

  test('upload a CV, watch Muni read it, land on the summary', async ({ page }) => {
    await page.goto('/start');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('glow-up era');
    await axe(page);
    await page.getByRole('button', { name: /Let’s gooo/ }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('whole vibe');
    await page.locator('input[type=file]').setInputFiles(cv('Nkosazana_Dlamini_CV.pdf'));
    await expect(page.getByText('Tick the box so Muni can read your CV')).toBeVisible();
    await page.getByRole('checkbox', { name: /I agree to Skillmuni reading my CV/ }).check();
    await axe(page);
    await page.getByRole('button', { name: /Upload & let's go/ }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('reading your CV');
    await axe(page);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('hired vibes', {
      timeout: 15_000,
    });
    await expect(page.getByText('Found a suburb only — add your postal code')).toBeVisible();
    await axe(page);
  });

  test('a locked PDF opens the S3 sheet and "Choose another file" returns to E2', async ({
    page,
  }) => {
    await page.goto('/onboarding/cv');
    await page.locator('input[type=file]').setInputFiles(cv('locked_cv.pdf'));
    await page.getByRole('checkbox', { name: /I agree to Skillmuni reading my CV/ }).check();
    await page.getByRole('button', { name: /Upload & let's go/ }).click();
    const sheet = page.getByRole('dialog', { name: 'This PDF is locked' });
    await expect(sheet).toBeVisible({ timeout: 10_000 });
    await axe(page);
    await sheet.getByRole('button', { name: 'Choose another file' }).click();
    await expect(page).toHaveURL(/\/onboarding\/cv$/);
  });
});

test.describe('6d Quest 1 · Who Dis?', () => {
  // Long journeys through the dev server; 30 s is tight when workers run in parallel.
  test.describe.configure({ timeout: 150_000 });
  test.beforeEach(async ({ page }) => logIn(page));

  test('three parts, XP toasts, badge modal, then Hit Me Up unlocks', async ({ page }) => {
    await page.getByRole('button', { name: /Start Who Dis\?/ }).click();
    await expect(page).toHaveURL(/\/quests\/who-dis/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('call you?');
    await axe(page);

    await page.getByRole('textbox', { name: 'Last name' }).fill('Verma');
    await page.getByRole('button', { name: /Next part/ }).click();
    await expect(page.getByText('Your name locked in')).toBeVisible();
    await expect(page).toHaveURL(/part=2/);

    // A-272: India links the ID through DigiLocker — no number field, last 4 only.
    await expect(page.getByRole('textbox', { name: /Government ID/ })).toHaveCount(0);
    await page.getByRole('button', { name: 'Open the birthday picker' }).click();
    const picker = page.getByRole('dialog', { name: 'When’s your birthday?' });
    await expect(picker).toContainText('Pick your birth year to start');
    await axe(page);
    await picker.getByRole('button', { name: '1990s' }).click();
    await picker.getByRole('button', { name: '1998', exact: true }).click();
    await expect(picker).toContainText(/turning \d+ this year/);
    await picker.getByRole('button', { name: 'April' }).click();
    await picker.getByRole('button', { name: '12 April 1998' }).click();
    await axe(page);
    await picker.getByRole('button', { name: 'That’s my birthday' }).click();
    await expect(page.getByRole('textbox', { name: 'Birthday' })).toHaveValue('12 / 04 / 1998');
    await expect(page.getByRole('textbox', { name: 'Age' })).toHaveValue(/we did the maths/);
    await axe(page);

    await page.getByRole('button', { name: 'Link with DigiLocker' }).click();
    const digi = page.getByRole('dialog', { name: 'Share your ID from DigiLocker' });
    await expect(digi).toContainText('Never the full number or a copy');
    await axe(page);
    await digi.getByRole('button', { name: 'Approve (test)' }).click();
    await expect(page.getByText('Aadhaar XXXX XXXX 4821')).toBeVisible();
    // The verified birthday from DigiLocker replaces the picked one.
    await expect(page.getByRole('textbox', { name: 'Birthday' })).toHaveValue('14 / 05 / 2003');

    // Step back to part 1 from the stepper, then forward again.
    await page.getByRole('button', { name: /Your name.*go back and edit/ }).click();
    await expect(page).toHaveURL(/part=1/);
    await expect(page.getByRole('textbox', { name: 'Last name' })).toHaveValue('Verma');
    await page.getByRole('button', { name: /Next part/ }).click();
    await expect(page).toHaveURL(/part=2/);
    await expect(page.getByRole('textbox', { name: 'Birthday' })).toHaveValue('14 / 05 / 2003');
    await page.getByRole('button', { name: /Next part/ }).click();
    await expect(page).toHaveURL(/part=3/);

    await page.getByRole('button', { name: /Lock it in/ }).click();
    await expect(page.getByText('Pick your home language')).toBeVisible();
    // A-243: every language, plus "I'll describe it myself" with a text box.
    const home = page.getByRole('radiogroup', { name: /home language/ });
    await page.getByRole('button', { name: /more$/ }).first().click();
    await expect(home.locator('label.chip', { hasText: 'Maithili' })).toBeVisible();
    await home.locator('label.chip', { hasText: 'Another language' }).click();
    await pick(page, /Pick your language/, 'Swahili');
    await home.locator('label.chip', { hasText: 'I’ll describe it myself' }).click();
    await page
      .getByRole('textbox', { name: /Your home language/ })
      .fill('Hindi and Bhojpuri at home');
    await axe(page);
    await home.locator('label.chip', { hasText: 'Hindi' }).first().click();
    await page.locator('label.chip', { hasText: 'Yes' }).click();
    await expect(page.getByText('What kind? Pick all that apply')).toBeVisible();
    await page.locator('label.chip', { hasText: 'Hearing' }).click();
    await axe(page);
    await page.getByRole('button', { name: /Lock it in/ }).click();

    const modal = page.getByRole('dialog');
    await expect(modal).toContainText('Badge unlocked');
    await axe(page);
    await modal.getByRole('button', { name: /Let’s gooo/ }).click();
    await expect(page).toHaveURL(/\/quests\/hit-me-up/);
  });

  test('typing autosaves; a reload resumes with the answer kept (A-241)', async ({ page }) => {
    await page.goto('/quests/who-dis');
    await page.getByRole('textbox', { name: 'Last name' }).fill('Verma');
    await expect(page.getByRole('status').filter({ hasText: 'Progress saved' })).toBeAttached();
    await page.reload();
    await expect(page.getByRole('textbox', { name: 'Last name' })).toHaveValue('Verma');
  });

  test('Save & exit saves, signs out to login; logging back in keeps the answer (A-252)', async ({
    page,
  }) => {
    await page.goto('/quests/who-dis');
    await page.getByRole('textbox', { name: 'Last name' }).fill('Verma');
    await page.getByRole('button', { name: /Save (&|and) exit/ }).click();
    await expect(page).toHaveURL(/\/login/);
    await expect(page.getByText(/Progress saved\. Log in anytime/)).toBeVisible();
    await logIn(page);
    await page.goto('/quests/who-dis');
    await expect(page.getByRole('textbox', { name: 'Last name' })).toHaveValue('Verma');
  });

  test('XP starts at 0: +20 a step, +50 to finish (A-249)', async ({ page }, info) => {
    const full = info.project.name === 'desktop'; // tablet/phone HUDs are compact
    // A brand-new account: the sample learner already has XP from elsewhere on the one ledger (A-316).
    await page.addInitScript(() => {
      if (sessionStorage.getItem('__fresh')) return;
      sessionStorage.setItem('__fresh', '1');
      sessionStorage.setItem('sm_mock_persona', 'new');
    });
    await page.goto('/quests/who-dis');
    if (full) await expect(page.getByText(/^0 \/ 760 XP/).first()).toBeAttached();
    await expect(page.getByRole('button', { name: /Next part/ })).toContainText('+20 XP');
    await page.getByRole('textbox', { name: 'Last name' }).fill('Verma');
    await page.getByRole('button', { name: /Next part/ }).click();
    await expect(page.getByText(/\+20 XP · Your name locked in/)).toBeVisible();
    if (full) await expect(page.getByText(/^20 \/ 760 XP/).first()).toBeAttached();
  });
});

/** A-272: link the ID through the DigiLocker test dialog; the verified birthday comes with it. */
async function linkDigiLocker(page: Page) {
  await page.getByRole('button', { name: 'Link with DigiLocker' }).click();
  await page.getByRole('button', { name: 'Approve (test)' }).click();
  await expect(page.getByText(/XXXX XXXX 4821/)).toBeVisible();
}

async function finishQuest1(page: Page) {
  await page.getByRole('button', { name: /Start Who Dis\?/ }).click();
  await page.getByRole('textbox', { name: 'Last name' }).fill('Verma');
  await page.getByRole('button', { name: /Next part/ }).click();
  await linkDigiLocker(page);
  await page.getByRole('button', { name: /Next part/ }).click();
  await page.locator('label.chip', { hasText: 'Hindi' }).click();
  await page.getByRole('button', { name: /Lock it in/ }).click();
  await page
    .getByRole('dialog')
    .getByRole('button', { name: /Let’s gooo/ })
    .click();
  await expect(page).toHaveURL(/\/quests\/hit-me-up/);
}

test.describe('6d Quest 2 · Hit Me Up', () => {
  // Long journeys through the dev server; 30 s is tight when workers run in parallel.
  test.describe.configure({ timeout: 60_000 });
  test.beforeEach(async ({ page }) => logIn(page));

  test('verify number, skip backup, PIN fills the address, badge', async ({ page }) => {
    await finishQuest1(page);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Drop your digits');
    await expect(page.getByText('Verified')).toBeVisible();
    await axe(page);

    await page.getByRole('textbox', { name: 'Email' }).fill('yash@gmial.com');
    await expect(page.getByText('Did you mean yash@gmail.com?')).toBeVisible();
    await page.getByRole('button', { name: 'Yes, fix it' }).click();
    await page.getByRole('button', { name: /Next part/ }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('ride-or-die?');
    await axe(page);
    await page.getByRole('button', { name: 'Skip for now' }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('good stuff?');
    await page.getByRole('textbox', { name: /PIN code/ }).fill('560038');
    await expect(page.getByRole('textbox', { name: /City/ })).toHaveValue('Bengaluru');
    await page.getByRole('combobox', { name: /Area/ }).click();
    await page.getByRole('option', { name: 'Indiranagar' }).click();
    await page.getByRole('textbox', { name: /Flat/ }).fill('Flat 402, Sai Residency');
    await axe(page);
    await page.getByRole('button', { name: /Lock it in/ }).click();
    await expect(page.getByRole('dialog')).toContainText('Badge unlocked');
  });

  test('a new number must be verified before moving on', async ({ page }) => {
    await finishQuest1(page);
    await page.getByRole('textbox', { name: 'Mobile number' }).fill('91234 56789');
    await expect(page.getByText('Verify your number first').first()).toBeVisible();
    await page.getByRole('button', { name: 'Get OTP' }).click();
    const dialog = page.getByRole('dialog', { name: 'Enter the 6-digit code' });
    await expect(dialog).toBeVisible();
    await page.keyboard.type('123456');
    await expect(page.getByText('Verified')).toBeVisible();
  });
});

async function finishQuest2(page: Page) {
  await finishQuest1(page);
  await page.getByRole('button', { name: /Next part/ }).click();
  await page.getByRole('button', { name: 'Skip for now' }).click();
  await page.getByRole('textbox', { name: /PIN code/ }).fill('560038');
  await expect(page.getByRole('textbox', { name: /City/ })).toHaveValue('Bengaluru');
  await page.getByRole('combobox', { name: /Area/ }).click();
  await page.getByRole('option', { name: 'Indiranagar' }).click();
  await page.getByRole('textbox', { name: /Flat/ }).fill('Flat 402, Sai Residency');
  await page.getByRole('button', { name: /Lock it in/ }).click();
  await page
    .getByRole('dialog')
    .getByRole('button', { name: /Let’s gooo/ })
    .click();
  await expect(page).toHaveURL(/\/quests\/big-brain-stuff/);
}

async function pick(page: Page, field: RegExp, option: string) {
  await page.getByRole('combobox', { name: field }).click();
  const search = page.getByRole('combobox', { name: 'Search options' });
  const searchable = await search
    .waitFor({ timeout: 1000 })
    .then(() => true)
    .catch(() => false);
  if (searchable) await search.fill(option);
  await page.getByRole('option', { name: option, exact: true }).click();
}

test.describe('6d Quest 3 · Big Brain Stuff', () => {
  test.describe.configure({ timeout: 90_000 });
  test.beforeEach(async ({ page }) => logIn(page));

  test('degree details, add and undo a 12th on the timeline, badge', async ({ page }) => {
    await finishQuest2(page);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('highest level');
    await page.getByRole('button', { name: /Next part/ }).click();
    await expect(page.getByText('Pick your highest level')).toBeVisible();
    await page.locator('label.card', { hasText: 'Graduate' }).first().click();
    await axe(page);
    await page.getByRole('button', { name: /Next part/ }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('Tell us about your');
    await pick(page, /^Degree/, 'B.Tech / B.E.');
    await pick(page, /Branch/, 'Computer Science');
    await pick(page, /College/, 'RV College of Engineering, Bengaluru');
    await pick(page, /Year of passing/, '2021');
    await page.getByRole('textbox', { name: 'Score' }).fill('12');
    await page.getByRole('button', { name: /Next part/ }).click();
    await expect(page.getByText('CGPA is out of 10')).toBeVisible();
    await page.getByRole('textbox', { name: 'Score' }).fill('8.2');
    await axe(page);
    await page.getByRole('button', { name: /Next part/ }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('timeline');
    await expect(page.getByText('B.Tech / B.E. · Computer Science')).toBeVisible();
    await expect(page.getByText('Only your highest level is here')).toBeVisible();
    await page.getByRole('button', { name: /Add your 12th/ }).click();
    await page.getByRole('button', { name: /Save 12th/ }).click();
    await expect(page.getByText('Needed to match you right').first()).toBeVisible();
    await pick(page, /Board/, 'CBSE');
    await pick(page, /Stream/, 'Science (PCM)');
    await page.getByRole('textbox', { name: /School/ }).fill('Delhi Public School, Bengaluru');
    await pick(page, /Year of passing/, '2017');
    await page.getByRole('textbox', { name: /Percentage/ }).fill('88');
    await axe(page);
    await page.getByRole('button', { name: /^Save 12th$/ }).click();
    await expect(page.getByText('CBSE · Science (PCM)')).toBeVisible();
    await expect(page.getByRole('button', { name: /Add your 12th/ })).toHaveCount(0);

    await page.getByRole('button', { name: 'Remove CBSE · Science (PCM)' }).click();
    await expect(page.getByRole('group', { name: /^Remove your 12th/ })).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Remove', exact: true }).click();
    await expect(page.getByText('CBSE · Science (PCM)')).toHaveCount(0);
    await page.getByRole('button', { name: 'Undo' }).click();
    await expect(page.getByText('CBSE · Science (PCM)')).toBeVisible();

    // A-244: "Add education" adds another qualification (repeatable).
    await page.getByRole('button', { name: 'Add education' }).click();
    await pick(page, /^Level/, 'Diploma');
    await pick(page, /Degree or qualification/, 'Diploma in Computer Applications');
    await page.getByRole('textbox', { name: /Institute/ }).fill('NIIT Bengaluru');
    await pick(page, /Year of passing/, '2019');
    await axe(page);
    await page.getByRole('button', { name: /^Save education$/ }).click();
    await expect(page.getByText('Diploma in Computer Applications')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Add education' })).toBeVisible();

    await page.getByRole('button', { name: /Lock it in/ }).click();
    await expect(page.getByRole('dialog')).toContainText('Badge unlocked');
  });

  test('“No formal education” finishes the quest straight away', async ({ page }) => {
    await finishQuest2(page);
    await page.locator('label.card', { hasText: 'No formal education' }).click();
    await page.getByRole('button', { name: /Lock it in/ }).click();
    await expect(page.getByRole('dialog')).toContainText('Badge unlocked');
  });
});

async function finishQuest3(page: Page) {
  await finishQuest2(page);
  await page.locator('label.card', { hasText: 'No formal education' }).click();
  await page.getByRole('button', { name: /Lock it in/ }).click();
  await page
    .getByRole('dialog')
    .getByRole('button', { name: /Let’s gooo/ })
    .click();
  await expect(page).toHaveURL(/\/quests\/your-flex-era/);
}

async function addSkill(
  page: Page,
  name: string,
  level: 'Just started' | 'Getting there' | 'Confident',
) {
  await page.getByRole('checkbox', { name: new RegExp(`^${name},`) }).click();
  await page.getByRole('radio', { name: new RegExp(level) }).click();
  await expect(
    page.getByRole('checkbox', { name: new RegExp(`^${name},.*in deck, level`) }),
  ).toBeVisible();
}

test.describe('6d Quest 4 · Your Flex Era', () => {
  test.describe.configure({ timeout: 120_000 });
  test.beforeEach(async ({ page }) => logIn(page));

  test('skill deck, passport, a verified trophy, Player Card reveal', async ({ page }) => {
    await finishQuest3(page);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('skill deck');
    await expect(page.getByText('Add 3 more skills').first()).toBeVisible();

    await addSkill(page, 'Verbal communication', 'Getting there');
    await addSkill(page, 'Microsoft Excel', 'Confident');
    await page.getByRole('searchbox', { name: 'Search skills' }).fill('pyth');
    // A-245: search runs on ESCO; the attribution line no longer names it (corrections #10).
    await expect(page.getByText('1 result for “pyth”')).toBeVisible();
    await expect(page.getByText(/standard global skills list/)).toBeVisible();
    await addSkill(page, 'Python', 'Confident');
    await axe(page);

    await page.getByRole('searchbox', { name: 'Search skills' }).fill('rangoli art');
    await page.getByRole('button', { name: 'Add “rangoli art” as my skill' }).click();
    await expect(page.getByRole('dialog', { name: 'rangoli art' })).toBeVisible();
    await page.keyboard.press('Escape');
    await expect(page.getByRole('dialog', { name: 'rangoli art' })).toHaveCount(0);
    await expect(page.getByText('Set rangoli art’s level to continue').first()).toBeVisible();
    await page.getByRole('button', { name: 'Remove rangoli art' }).click();
    await page.getByRole('button', { name: 'Undo' }).click();
    await page.getByRole('button', { name: 'Remove rangoli art' }).click();

    // Data 3 and Tech 3 tie (within 10%) → All-Rounder (Figma §8).
    await expect(page.getByRole('group', { name: 'Your Player Card' }).first()).toContainText(
      'All-Rounder',
    );
    await page.getByRole('button', { name: /Next part/ }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('passport');
    await expect(page.getByText('Mother tongue', { exact: true })).toBeVisible();
    await page.getByRole('button', { name: 'Add a language' }).click();
    await pick(page, /Add a language/, 'English');
    await page.getByRole('button', { name: /Next part/ }).click();
    await expect(page.getByText('Pick a level for English.')).toBeVisible();
    await page
      .locator('.stamp', { hasText: 'English' })
      .locator('label.chip', { hasText: 'Fluent' })
      .click();
    await axe(page);
    await page.getByRole('button', { name: /Next part/ }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('trophy shelf');
    await page.getByRole('button', { name: /Add a trophy/ }).click();
    const dialog = page.getByRole('dialog', { name: 'Add a trophy' });
    await expect(dialog).toBeVisible();
    await pick(page, /Certificate name/, 'Google Data Analytics Professional');
    await expect(dialog.getByText('Auto-filled')).toBeVisible();
    await dialog
      .getByRole('textbox', { name: /Credential link/ })
      .fill('coursera.org/verify/8KX2QZ7M');
    await dialog.getByRole('textbox', { name: /Credential ID/ }).click();
    await expect(dialog.getByText(/Verified tick unlocked/)).toBeVisible();
    await axe(page);
    await dialog.getByRole('button', { name: 'Put it on the shelf' }).click();
    await expect(
      page.locator('.trophy', { hasText: 'Google Data Analytics Professional' }),
    ).toContainText('Verified');

    await page.getByRole('button', { name: /Reveal my card/ }).click();
    const reveal = page.getByRole('dialog', { name: /Meet/ });
    await expect(reveal).toBeVisible();
    await expect(reveal.getByRole('group', { name: 'Your Player Card' })).toContainText('Python');
    await axe(page);
    await reveal.getByRole('button', { name: /Next: Work Lore/ }).click();
    await expect(page).toHaveURL(/\/quests\/work-lore/);
  });
});

async function finishQuest4(page: Page) {
  await finishQuest3(page);
  await addSkill(page, 'Verbal communication', 'Getting there');
  await addSkill(page, 'Microsoft Excel', 'Confident');
  await addSkill(page, 'Customer service', 'Confident');
  await page.getByRole('button', { name: /Next part/ }).click();
  await expect(page.getByRole('heading', { level: 1 })).toContainText('passport');
  await page.getByRole('button', { name: /Next part/ }).click();
  await expect(page.getByRole('heading', { level: 1 })).toContainText('trophy shelf');
  await page.getByRole('button', { name: 'Skip for now' }).click();
  await page
    .getByRole('dialog', { name: /Meet/ })
    .getByRole('button', { name: /Next: Work Lore/ })
    .click();
  await expect(page).toHaveURL(/\/quests\/work-lore/);
}

test.describe('6d Quest 5 · Work Lore', () => {
  test.describe.configure({ timeout: 240_000 });
  test.beforeEach(async ({ page }) => logIn(page));

  test('types, a chapter, the timeline with an overlap, delete + undo, level up', async ({
    page,
  }) => {
    await finishQuest4(page);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('work lore');
    await page.getByRole('button', { name: /Next part/ }).click();
    await expect(page.getByText('Pick at least one type')).toBeVisible();
    await page.locator('label.card', { hasText: 'Internship' }).click();
    await page.locator('label.card', { hasText: 'Freelance / gigs' }).click();
    await axe(page);
    await page.getByRole('button', { name: /Next part/ }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('Chapter 1');
    await page.getByRole('button', { name: /Save chapters/ }).click();
    await expect(
      page.getByRole('alert').filter({ hasText: /things to fix before saving/ }),
    ).toBeFocused();
    await page.getByRole('radio', { name: 'Internship' }).click();
    await pick(page, /Your role/, 'Data Analyst Intern');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Data Analyst Intern');
    await expect(page.getByText(/Draft saved · just now/)).toBeVisible();

    // Leaving a half-filled chapter asks first; the draft comes back.
    await page.getByRole('button', { name: 'Go back' }).first().click();
    const leave = page.getByRole('dialog', { name: 'Leave without saving this chapter?' });
    await expect(leave).toContainText('You’ve filled 2 fields.');
    await axe(page);
    await page.keyboard.press('Escape');
    await expect(leave).toBeHidden();
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Data Analyst Intern');
    await page.getByRole('button', { name: 'Go back' }).first().click();
    await leave.getByRole('button', { name: 'Save draft' }).click();
    await expect(page.getByRole('heading', { level: 1 })).toContainText('work lore');
    await page.getByRole('button', { name: /Next part/ }).click();
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Data Analyst Intern');

    await pick(page, /Company or client/, 'Swiggy');
    const started = page.getByRole('group', { name: /Started/ });
    await started.getByRole('combobox', { name: 'Month' }).click();
    await page.getByRole('option', { name: 'Mar', exact: true }).click();
    await started.getByRole('combobox', { name: 'Year' }).click();
    await page.getByRole('combobox', { name: 'Search options' }).fill('2025');
    await page.getByRole('option', { name: '2025', exact: true }).click();
    await page.getByRole('switch', { name: /I still work here/ }).click();
    await page.getByRole('radio', { name: 'Hybrid' }).click();
    await page.getByRole('button', { name: 'A number you moved' }).click();
    await page.keyboard.type('report time from 2 days to 3 hours.');
    await page.getByRole('button', { name: '+ Add a skill not in your deck' }).click();
    await pick(page, /Add a skill/, 'Tableau');
    await expect(page.getByText('Tableau added. It joins your deck when you save.')).toBeVisible();
    await expect(page.locator('label.chip', { hasText: 'Tableau' })).toHaveClass(/is-selected/);
    await axe(page);

    // A-246: two kinds picked → a tab each, with its own form. The filled one is ticked.
    await expect(page.getByRole('tab', { name: '✓ Internship' })).toBeVisible();
    await page.getByRole('tab', { name: 'Freelance / gigs' }).click();
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Chapter 2');
    await pick(page, /Your role/, 'Freelance Graphic Designer');
    await expect(page.getByRole('combobox', { name: /Company or client/ })).toContainText(
      'Self-employed',
    );
    const form = page.getByRole('tabpanel', { name: 'Freelance / gigs' });
    await form
      .getByRole('group', { name: /Started/ })
      .getByRole('combobox', { name: 'Month' })
      .click();
    await page.getByRole('option', { name: 'Jun', exact: true }).click();
    await form
      .getByRole('group', { name: /Started/ })
      .getByRole('combobox', { name: 'Year' })
      .click();
    await page.getByRole('combobox', { name: 'Search options' }).fill('2024');
    await page.getByRole('option', { name: '2024', exact: true }).click();
    await form
      .getByRole('group', { name: /Ended/ })
      .getByRole('combobox', { name: 'Month' })
      .click();
    await page.getByRole('option', { name: /^Sept?$/ }).click();
    await form
      .getByRole('group', { name: /Ended/ })
      .getByRole('combobox', { name: 'Year' })
      .click();
    await page.getByRole('combobox', { name: 'Search options' }).fill('2025');
    await page.getByRole('option', { name: '2025', exact: true }).click();
    await axe(page);
    await page.getByRole('button', { name: /Save chapters/ }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('timeline');
    await expect(page.locator('.chapter', { hasText: 'Data Analyst Intern' })).toContainText('Now');
    await expect(page.locator('.chapter', { hasText: 'Freelance Graphic Designer' })).toBeVisible();

    await expect(page.getByText(/overlap by/)).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Delete Freelance Graphic Designer' }).click();
    await page.getByRole('button', { name: 'Delete', exact: true }).click();
    await expect(page.locator('.chapter', { hasText: 'Freelance Graphic Designer' })).toHaveCount(
      0,
    );
    await page.getByRole('button', { name: 'Undo' }).click();
    await expect(page.locator('.chapter', { hasText: 'Freelance Graphic Designer' })).toBeVisible();

    await page.getByRole('button', { name: /Lock it in/ }).click();
    await expect(page.getByRole('dialog')).toContainText('Lore saved.');
  });

  test('a fresher can finish from part 1', async ({ page }) => {
    await finishQuest4(page);
    await page.locator('label.card', { hasText: 'Not yet, I’m a fresher' }).click();
    await expect(page.getByRole('heading', { level: 1 })).toContainText('starts here');
    await page.getByRole('button', { name: /Finish quest/ }).click();
    await expect(page.getByRole('dialog')).toContainText('Lore saved.');
  });
});

async function finishQuest5(page: Page) {
  await finishQuest4(page);
  await page.locator('label.card', { hasText: 'Not yet, I’m a fresher' }).click();
  await page.getByRole('button', { name: /Finish quest/ }).click();
  await page
    .getByRole('dialog')
    .getByRole('button', { name: /Let’s gooo/ })
    .click();
  await expect(page).toHaveURL(/\/quests\/pick-your-arc/);
}

test.describe('6d Quests 6–8 and My Matches', () => {
  test.describe.configure({ timeout: 300_000 });
  test.beforeEach(async ({ page }) => logIn(page));

  test('arc, receipts, vibe check, send it, accept an interview and apply', async ({ page }) => {
    await finishQuest5(page);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('next arc?');
    await page.getByRole('button', { name: /Finish quest/ }).click();
    await expect(page.getByText('Employers filter by this, pick one')).toBeVisible();
    await page.locator('label.chip', { hasText: 'Full-time job' }).click();
    await page.locator('label.chip', { hasText: 'Customer support executive' }).click();
    await expect(page.locator('label.chip', { hasText: /Near .* within 25 km/ })).toHaveClass(
      /is-selected/,
    );
    await page.locator('label.chip', { hasText: 'Immediate joiner' }).click();
    await axe(page);
    await page.getByRole('button', { name: /Finish quest/ }).click();
    await page
      .getByRole('dialog')
      .getByRole('button', { name: /Let’s gooo/ })
      .click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('receipts');
    await expect(page.getByText('to add')).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: /Finish quest/ }).click();
    await page
      .getByRole('dialog')
      .getByRole('button', { name: /Let’s gooo/ })
      .click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('One last');
    await expect(page.getByText(/You already match 14 open jobs/)).toBeVisible();
    await expect(page.locator('li.row', { hasText: 'Pick Your Arc' })).toContainText(
      'Full-time job',
    );
    // A-287: no retention switch on Vibe Check.
    await expect(page.getByRole('switch', { name: /Keep my profile for 12 months/ })).toHaveCount(0);
    await axe(page);
    await page.getByRole('button', { name: /Send it/ }).click();

    const registered = page.getByRole('dialog');
    await expect(registered).toContainText('officially registered');
    await expect(registered).toContainText('Got a programme or project code?');
    await axe(page);
    await registered.getByRole('button', { name: /Take me home/ }).click();
    await expect(page).toHaveURL(/\/home$/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText(
      /Good (morning|afternoon|evening),/,
    );
    // Registered: no "finish your quests" banner on the Lobby.
    await expect(page.getByRole('link', { name: 'Continue quests' })).toHaveCount(0);
    await axe(page);
    await page.goto('/matches');
    await expect(page.getByRole('heading', { level: 1 })).toHaveText('My Matches');
    const invited = page.locator('sm-job-card', { hasText: 'Interview invite' }).first();
    await expect(invited).toBeVisible();
    await axe(page);
    await invited.getByRole('button', { name: 'Accept' }).click();
    await page.getByRole('button', { name: 'Accept interview' }).click();
    await expect(page.getByText('Interview accepted. Details sent to you by SMS.')).toBeVisible();

    const shortlisted = page.locator('sm-job-card', { hasText: 'Back Office Executive' });
    await expect(shortlisted).toContainText('Shortlisted by employer');
    await shortlisted.getByRole('button', { name: 'Apply' }).click();
    await expect(page.getByText(/^Applied to /)).toBeVisible();
    await expect(shortlisted).toContainText('Applied');
  });
});

test.describe('My Matches states', () => {
  test.beforeEach(async ({ page }) => logIn(page));

  test('empty before publishing, and an error with retry', async ({ page }) => {
    await page.goto('/matches?matches=empty');
    await expect(page.getByText('No matches yet')).toBeVisible();
    await expect(page.getByRole('link', { name: 'Add more skills' })).toBeVisible();
    await axe(page);
    await page.goto('/matches?matches=error');
    await expect(page.getByText('Couldn’t load your matches')).toBeVisible();
    await axe(page);
  });
});

test.describe('6e Programme code bonus quest', () => {
  test.describe.configure({ timeout: 120_000 });
  test.beforeEach(async ({ page }) => logIn(page));

  test('wrong code, verify, fix scores and bank, unlock', async ({ page }) => {
    await page.goto('/programme');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('programme code');
    await expect(page.locator('#sm-quest-counter')).toHaveText('Enter your code to continue');
    await expect(page.getByRole('button', { name: /Unlock (my programme|it)/ })).toBeDisabled();
    await axe(page);

    const code = page.getByRole('textbox', { name: 'Programme / project code' });
    await code.fill('SKM-XXX-00');
    await page.getByRole('button', { name: 'Check code' }).click();
    await expect(page.getByText('We couldn’t find this code.', { exact: false })).toBeVisible();
    await axe(page);

    await code.fill('skm-mum-26-0417');
    await code.press('Enter');
    await expect(page.getByRole('heading', { name: 'Customer Support Associate' })).toBeVisible();
    await expect(page.getByText('Verified')).toBeVisible();

    await page.getByRole('textbox', { name: 'English' }).fill('72');
    await page.getByRole('textbox', { name: 'Maths' }).fill('44');
    await expect(page.getByText(/Below the 50% this programme needs/)).toBeVisible();
    await page.locator('label.chip', { hasText: 'Good' }).first().click();

    await page.getByRole('button', { name: /Unlock (my programme|it)/ }).click();
    await expect(page.locator('#sm-quest-counter')).toContainText(/to fix · 1 to check/);
    await axe(page);

    await page.getByLabel('Bank account number', { exact: true }).fill('50100123456789');
    await page.getByLabel('Re-enter account number').fill('50100123456780');
    await page.getByLabel('Re-enter account number').blur();
    await expect(page.getByText('Account numbers don’t match.')).toBeVisible();
    await page.getByLabel('Re-enter account number').fill('50100123456789');
    const ifsc = page.getByRole('textbox', { name: 'IFSC code' });
    await ifsc.fill('hdfc0000240');
    await ifsc.blur();
    await expect(page.getByText('HDFC Bank · Andheri West, Mumbai')).toBeVisible();
    await page.getByRole('checkbox', { name: /This account is in my name/ }).check();
    await expect(page.locator('#sm-quest-counter')).toHaveText('1 to check');

    await page.getByRole('button', { name: /Unlock (my programme|it)/ }).click();
    const done = page.getByRole('dialog');
    await expect(done).toContainText('Programme');
    await expect(done).toContainText('unlocked!');
    await expect(done).toContainText('••89');
    await axe(page);
    await done.getByRole('button', { name: /Take me home/ }).click();
    await expect(page).toHaveURL(/\/home$/);
  });
});

test.describe('6f Institute claim', () => {
  test.describe.configure({ timeout: 150_000 });

  test('verify, consent, validate section by section, confirmed', async ({ page }) => {
    await page.goto('/claim/psa-15-aarav');
    await expect(page.getByRole('heading', { level: 1 })).toContainText(
      'Pune Skills Academy added',
    );
    await expect(page.getByText('Aarav Mehta')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Verify & continue' })).toBeDisabled();
    await axe(page);

    const otp = page.getByRole('textbox', { name: '6-digit code' });
    await otp.fill('111111');
    await expect(page.getByText('That code didn’t match. Check it and try again.')).toBeVisible();
    await page.getByRole('button', { name: 'Wrong number?' }).click();
    await expect(page.getByText(/Ask Pune Skills Academy to update your number/)).toBeVisible();
    await axe(page);

    await otp.fill('123456');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('your call');
    await expect(page.getByRole('switch', { name: /apply to jobs for me/ })).not.toBeChecked();
    await expect(page.getByRole('switch', { name: /Share my job progress/ })).toBeChecked();
    await page.getByRole('button', { name: 'Agree & review my profile' }).click();
    await expect(page.getByText('Tick this to build your profile')).toBeVisible();
    await axe(page);
    await page.getByRole('checkbox', { name: /I agree to Skillmuni/ }).check();
    await page.getByRole('button', { name: 'Agree & review my profile' }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('Check what');
    await expect(page.getByText(/0 of 5 done/)).toBeVisible();
    await expect(page.getByText('Verified by institute ✓')).toBeHidden();
    await axe(page);
    for (const name of ['Who Dis?', 'Hit Me Up', 'Big Brain Stuff', 'Your Flex Era']) {
      await page
        .getByRole('button', { name: new RegExp(`^Looks right\\s*: ${name.replace('?', '\\?')}$`) })
        .click();
      await expect(page.locator(`[data-section] .section-head`, { hasText: name })).toContainText(
        'Confirmed',
      );
    }
    await expect(page.getByText(/4 of 5 done/)).toBeVisible();
    await expect(page.getByText(/End date missing/)).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: /^Looks right\s*: Work Lore$/ }).click();

    await expect(page.getByRole('heading', { level: 1 })).toContainText('Profile confirmed!');
    await expect(page.getByText('Left to do · about 6 minutes')).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Continue to Pick Your Arc' }).click();
    await expect(page).toHaveURL(/\/quests\/pick-your-arc$/);
  });

  test('edit a section in its quest, come back, and resume after reopening the link', async ({
    page,
  }) => {
    await page.goto('/claim/psa-15-aarav');
    await page.getByRole('textbox', { name: '6-digit code' }).fill('123456');
    await page.getByRole('checkbox', { name: /I agree to Skillmuni/ }).check();
    await page.getByRole('button', { name: 'Agree & review my profile' }).click();
    await page.getByRole('button', { name: /^Looks right\s*: Who Dis\?$/ }).click();
    await expect(page.getByText(/1 of 5 done/)).toBeVisible();

    await page.getByRole('button', { name: /^Edit\s*Hit Me Up$/ }).click();
    await expect(page).toHaveURL(/\/quests\/hit-me-up\?.*returnTo=%2Fclaim%2Fpsa-15-aarav/);
    await page.getByRole('button', { name: /Save (&|and) exit/ }).click();
    await expect(page).toHaveURL(/\/claim\/psa-15-aarav$/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Check what');
    await expect(page.getByText(/1 of 5 done/)).toBeVisible();

    await page.reload();
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Check what');
    await expect(page.getByText(/1 of 5 done/)).toBeVisible();
    await axe(page);
  });

  test('this isn’t me, keep, delete my data, and dead links', async ({ page }) => {
    await page.goto('/claim/psa-15-aarav');
    await page.getByRole('button', { name: 'This isn’t me' }).click();
    await expect(page.getByRole('heading', { level: 1 })).toContainText('this profile?');
    await expect(page.getByRole('radio', { name: 'This isn’t me' })).toBeChecked();
    await axe(page);
    await page.getByRole('button', { name: 'Keep my profile' }).click();
    await expect(page.getByRole('heading', { level: 1 })).toContainText('added');

    await page.getByRole('button', { name: 'Delete my data' }).click();
    await page.getByRole('radio', { name: /job matching right now/ }).check();
    await page.getByRole('button', { name: 'Delete my data' }).click();
    await expect(page.getByRole('heading', { name: 'Your data is deleted' })).toBeVisible();
    await axe(page);

    await page.goto('/claim/nope');
    await expect(page.getByRole('heading', { name: 'This link doesn’t work' })).toBeVisible();
    await page.goto('/claim/claimed');
    await expect(
      page.getByRole('heading', { name: 'This profile is already claimed' }),
    ).toBeVisible();
    await axe(page);
    await page.goto('/claim/expired');
    await expect(page.getByRole('heading', { name: 'This invite has expired' })).toBeVisible();
  });
});

/** Tiny PNG encoder for camera-photo fixtures: `pixel(x, y)` returns a gray level. */
function png(width: number, height: number, pixel: (x: number, y: number) => number): Buffer {
  const crcTable = Array.from({ length: 256 }, (_, n) => {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    return c >>> 0;
  });
  const crc = (buf: Buffer) => {
    let c = 0xffffffff;
    for (const b of buf) c = (crcTable[(c ^ b) & 0xff] ?? 0) ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  };
  const chunk = (type: string, data: Buffer) => {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type), data]);
    const sum = Buffer.alloc(4);
    sum.writeUInt32BE(crc(body));
    return Buffer.concat([len, body, sum]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 0; // grayscale
  const raw = Buffer.alloc((width + 1) * height);
  for (let y = 0; y < height; y++)
    for (let x = 0; x < width; x++) raw[y * (width + 1) + 1 + x] = pixel(x, y);
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw)),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

test.describe('6c+ F1 Snap each page', () => {
  test.describe.configure({ timeout: 120_000 });
  test.beforeEach(async ({ page }) => logIn(page));

  test('snaps pages, flags a blurry one, keeps it, reads the CV', async ({ page }) => {
    const sharp = png(240, 320, (x, y) => (((x >> 2) + (y >> 2)) % 2 ? 250 : 10));
    const blurry = png(240, 320, () => 128);
    await page.goto('/onboarding/cv/snap');
    await expect(page.getByRole('heading', { level: 1 })).toHaveText('Snap each page of your CV');
    await expect(page.getByRole('button', { name: /Done — read my CV/ })).toBeDisabled();
    await axe(page);

    const camera = page.locator('input[type="file"]');
    await camera.setInputFiles({ name: 'page.png', mimeType: 'image/png', buffer: sharp });
    await expect(page.getByRole('button', { name: 'Page 1, sharp' })).toBeVisible();
    await camera.setInputFiles({ name: 'page2.png', mimeType: 'image/png', buffer: blurry });
    await expect(page.getByRole('button', { name: 'Page 2, blurry' })).toBeVisible();
    await expect(page.getByText(/Page 2 looks blurry/)).toBeVisible();
    await axe(page);

    await page.getByRole('button', { name: 'Keep it anyway' }).click();
    await expect(page.getByRole('button', { name: 'Page 2, sharp' })).toBeVisible();
    await page.getByRole('button', { name: /Done — read my CV/ }).click();
    await expect(page.getByText('Tick the box so Muni can read your CV')).toBeVisible();
    await page.getByRole('checkbox', { name: /I agree to Skillmuni reading my CV/ }).check();
    await page.getByRole('button', { name: /Done — read my CV/ }).click();
    await expect(page).toHaveURL(/\/onboarding\/cv\/reading$/);
    await expect(page).toHaveURL(/\/onboarding\/cv\/summary$/, { timeout: 20_000 });
  });
});
