import { test, expect } from '@playwright/test';
import { logIn } from './support/helpers';

/** A-234: Back walks history (never pushes), so no A ↔ B loops; Up pops to a parent. */
test.describe('Back navigation', () => {
  test.describe.configure({ timeout: 60_000 });

  test('Launchpad → Hire Fest → back → Launchpad → back → Lobby (no loop)', async ({ page }) => {
    await logIn(page);
    await page.goto('/home');
    await page
      .getByRole('link', { name: /Career Launchpad/ })
      .first()
      .click();
    await expect(page).toHaveURL(/\/launchpad$/);
    await page.locator('a[href^="/hire-fest"]').first().click();
    await expect(page.getByRole('heading', { level: 1, name: 'Hire Fest' })).toBeVisible();
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await expect(page).toHaveURL(/\/launchpad$/);
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await expect(page).toHaveURL(/\/home$/);
    await page.goBack();
    await expect(page).not.toHaveURL(/\/hire-fest/);
  });

  test('Hire Fest tabs are one screen: Back leaves to Launchpad, never tab ↔ tab', async ({
    page,
  }) => {
    await logIn(page);
    await page.goto('/launchpad');
    await page.locator('a[href^="/hire-fest"]').first().click();
    await expect(page.getByRole('heading', { level: 1, name: 'Hire Fest' })).toBeVisible();
    const tab = (name: RegExp) => page.getByRole('link', { name });
    await tab(/My bookings/).first().click();
    await expect(page).toHaveURL(/\/hire-fest\/bookings$/);
    await tab(/Upcoming/).first().click();
    await expect(page).toHaveURL(/\/hire-fest$/);
    await tab(/My bookings/).first().click();
    await expect(page).toHaveURL(/\/hire-fest\/bookings$/);
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await expect(page).toHaveURL(/\/launchpad$/);
  });

  test('Profile → all badges → back returns to Profile', async ({ page }) => {
    await logIn(page);
    await page.goto('/profile');
    await page.getByRole('link', { name: /See all/ }).click();
    await expect(page).toHaveURL(/\/stats\/badges$/);
    await page.getByRole('button', { name: 'Profile' }).click();
    await expect(page).toHaveURL(/\/profile$/);
  });

  test('a deep link with no history falls back to the parent and replaces the entry', async ({
    page,
  }) => {
    await logIn(page);
    await page.goto('/hire-fest');
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await expect(page).toHaveURL(/\/launchpad$/);
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await expect(page).toHaveURL(/\/home$/);
  });

  test('editing from Job Profile opens one section; Save returns, Back goes up (A-260, A-286)', async ({
    page,
  }) => {
    await logIn(page);
    await page.goto('/job-profile');
    await page.getByRole('link', { name: 'Edit contact & visibility' }).click();
    await expect(page).toHaveURL(/\/quests\/hit-me-up\?part=1&edit=1/);
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
    await page.getByRole('button', { name: 'Save changes' }).click();
    await expect(page).toHaveURL(/\/job-profile$/);
    // A-260: Back from Job Profile goes to the Launchpad, not back into the quest.
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await expect(page).toHaveURL(/\/launchpad$/);
  });

  test('Go back on part 1 steps into the last part of the previous quest (A-293)', async ({
    page,
  }) => {
    await page.addInitScript(() => {
      if (sessionStorage.getItem('sm_mock_quests')) return;
      const progress = { completed: 2, partsDone: 0, xp: 220, badges: 2, level: 1, rank: 'Rookie', target: 400 };
      sessionStorage.setItem('sm_mock_quests', JSON.stringify({ progress, answers: {} }));
    });
    await page.context().addCookies([
      { name: 'sm_mock_session', value: '1', url: 'http://localhost:4200' },
    ]);
    await page.goto('/quests/big-brain-stuff?part=1');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('highest level');
    await page.getByRole('button', { name: 'Go back' }).click();
    await expect(page).toHaveURL(/\/quests\/hit-me-up\?part=3$/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('good stuff');
  });

  test('full-screen toggle sits bottom-right', async ({ page }, info) => {
    test.skip(info.project.name === 'mobile', 'hidden on phones');
    await page.goto('/home');
    const fs = page.getByRole('button', { name: 'Full screen' });
    await expect(fs).toBeVisible();
    const box = await fs.boundingBox();
    const vp = page.viewportSize();
    expect(
      box && vp && box.x + box.width > vp.width - 80 && box.y + box.height > vp.height - 80,
    ).toBe(true);
  });
});
