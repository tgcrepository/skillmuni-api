import { test, expect } from '@playwright/test';
import { axe, logIn } from './support/helpers';

test.describe('Profile v2 · Player ID', () => {
  test.describe.configure({ timeout: 90_000 });

  test.beforeEach(async ({ page }) => {
    await logIn(page);
    await page.goto('/profile');
    await expect(page.getByRole('heading', { level: 1, name: 'My Profile' })).toBeVisible();
  });

  test('player card, strength checklist, showcase and masked private details', async ({ page }) => {
    await expect(page.getByRole('heading', { name: 'Yash Pohare' })).toBeVisible();
    await expect(page.getByText('529 / 800 XP')).toBeVisible();
    await expect(page.getByText('271 to Level 3')).toBeVisible();
    await expect(page.getByText('Level up your profile · +15 XP left')).toBeVisible();
    await expect(page.getByRole('img', { name: 'Profile 60% complete' })).toBeVisible();
    await expect(page.getByText('First Steps')).toBeVisible();
    await axe(page);

    // Private details stay masked until the eye is tapped.
    const mobile = page.getByRole('button', { name: 'Show Mobile number' });
    await expect(page.getByText('•••••• 0697')).toBeVisible();
    await mobile.click();
    await expect(page.getByText('+91 98765 40697')).toBeVisible();
    await page.getByRole('button', { name: 'Hide Mobile number' }).click();
    await expect(page.getByText('•••••• 0697')).toBeVisible();
  });

  test('edit: add top skills for +10 XP, then the task is done', async ({ page }) => {
    await page.getByRole('button', { name: /^Add your top skills/ }).click();
    const dialog = page.getByRole('dialog', { name: 'Edit your top skills' });
    await expect(dialog.getByRole('heading', { name: 'Your top skills' })).toBeVisible();
    await expect(dialog.getByText('+10 XP')).toHaveCount(0);
    await dialog.getByRole('checkbox', { name: 'Communication' }).check({ force: true });
    await dialog.getByRole('checkbox', { name: 'MS Excel' }).check({ force: true });
    await expect(dialog.getByText('2 of 5 picked')).toBeVisible();
    await expect(dialog.getByText('+10 XP')).toBeVisible();
    await axe(page);
    await dialog.getByRole('button', { name: 'Save changes' }).click();

    await expect(dialog).toHaveCount(0);
    await expect(page.getByText('Profile updated')).toBeVisible();
    await expect(page.getByText('539 / 800 XP')).toBeVisible();
    await expect(page.getByText('Level up your profile · +5 XP left')).toBeVisible();
    await expect(page.getByRole('button', { name: /^Add your top skills/ })).toHaveCount(0);
  });

  test('photo upload earns +5 XP; settings menu logs out', async ({ page }) => {
    await page.locator('input[type=file]').setInputFiles({
      name: 'me.png',
      mimeType: 'image/png',
      buffer: Buffer.from(
        'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=',
        'base64',
      ),
    });
    await expect(page.getByText('Looking good! Photo added')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Change your profile photo' })).toBeVisible();
    await expect(page.getByText('534 / 800 XP')).toBeVisible();

    await page.getByRole('button', { name: 'Settings' }).click();
    await page.getByRole('menuitem', { name: 'Log out' }).click();
    // Corrections #40: Muni asks first; staying is the main action.
    const bye = page.getByRole('dialog', { name: /Leaving so soon/ });
    await expect(bye.getByRole('button', { name: 'Stay and keep going' })).toBeVisible();
    await bye.getByRole('button', { name: 'Log out anyway' }).click();
    await expect(page).toHaveURL(/\/login$/);
  });

  test('error state retries', async ({ page }) => {
    await page.goto('/profile?profile=error');
    await expect(page.getByRole('heading', { name: 'Couldn’t load your profile' })).toBeVisible();
    await axe(page);
  });
});
