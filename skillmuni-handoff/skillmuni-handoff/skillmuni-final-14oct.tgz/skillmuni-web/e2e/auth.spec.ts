import { test, expect, Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const AXE_TAGS = ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'];
const axe = async (page: Page) =>
  expect((await new AxeBuilder({ page }).withTags(AXE_TAGS).analyze()).violations).toEqual([]);

test.describe('6a Auth', () => {
  test('E0 → L1: wrong code, then the right one, lands on the homescreen', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveURL(/\/login$/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Welcome back, legend');
    await axe(page);

    await page.getByRole('button', { name: /Send me the code/ }).click();
    await expect(page.getByText('Pop in your mobile number')).toBeVisible();

    await page.getByRole('textbox', { name: 'Mobile number' }).fill('98765 43210');
    await page.getByRole('button', { name: /Send me the code/ }).click();
    const dialog = page.getByRole('dialog', { name: 'Enter the 6-digit code' });
    await expect(dialog).toContainText('Sent to +91 98765 43210');
    await axe(page);

    await page.keyboard.type('111111');
    await expect(dialog).toContainText('That code didn’t match. Check it and try again.');
    await page.keyboard.type('123456');

    await expect(page).toHaveURL(/\/home$/);
    // A-276: no "finish your quests" banner — the Lobby is only reached after the quests.
    await expect(page.getByRole('heading', { name: 'Pick up where you left off' })).toBeVisible();
    await axe(page);
  });

  test('E0b email: a code to the inbox, no password, then home', async ({ page }) => {
    await page.goto('/login');
    await page.getByRole('radio', { name: 'Email' }).check({ force: true });
    await expect(page.getByLabel('Password')).toHaveCount(0);
    await page.getByRole('textbox', { name: 'Email' }).fill('yash.p@gmail.com');
    await page.getByRole('button', { name: /Send me the code/ }).click();
    const dialog = page.getByRole('dialog', { name: 'Enter the 6-digit code' });
    await expect(dialog).toContainText('Sent to ya•••@gmail.com');
    await axe(page);
    await page.keyboard.type('123456');
    await expect(page).toHaveURL(/\/home$/);
  });

  test('A-308: an unregistered mobile or email is sent to sign-up, not a code', async ({ page }) => {
    await page.goto('/login');
    await page.getByRole('textbox', { name: 'Mobile number' }).fill('91234 56789');
    await page.getByRole('button', { name: /Send me the code/ }).click();
    await expect(page).toHaveURL(/\/signup$/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Start your glow-up');
    await expect(page.getByText(/No account for \+91 91234 56789 yet/)).toBeVisible();
    await axe(page);

    await page.getByRole('link', { name: 'Try another login' }).click();
    await page.getByRole('radio', { name: 'Email' }).check({ force: true });
    await page.getByRole('textbox', { name: 'Email' }).fill('new.face@example.com');
    await page.getByRole('button', { name: /Send me the code/ }).click();
    await expect(page).toHaveURL(/\/signup$/);
    await expect(page.getByRole('textbox', { name: 'Email' })).toHaveValue('new.face@example.com');
    await expect(page.getByText(/No account for new.face@example.com yet/)).toBeVisible();
  });

  test('FP1 → FP2 forgot password still works from its link', async ({ page }) => {
    await page.goto('/login/forgot');
    await expect(page.getByRole('heading', { level: 1 })).toHaveText('Forgot your password?');
    await page.getByRole('textbox', { name: 'Email' }).fill('yash.p@gmail.com');
    await page.getByRole('button', { name: /Send reset link/ }).click();
    await expect(page.getByRole('heading', { level: 1 })).toHaveText('Check your inbox');
    await axe(page);
  });

  test('R1 needs a session', async ({ page }) => {
    await page.goto('/welcome-back');
    await expect(page).toHaveURL(/\/login\?returnUrl=%2Fwelcome-back/);
  });
});

test.describe('6b Sign up', () => {
  test('SU4 errors → SU3 taken → VE2 wrong code → VE4 → quests', async ({ page }) => {
    await page.goto('/login');
    await page.getByRole('link', { name: 'Join the squad' }).click();
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Start your glow-up');
    await axe(page);

    await page.getByRole('button', { name: /Create my account/ }).click();
    await expect(page.getByText('Tick this to continue.')).toBeVisible();
    await axe(page);

    await page.getByRole('textbox', { name: 'First name' }).fill('Yash');
    await page.getByRole('textbox', { name: 'Last name' }).fill('Verma');
    await page.getByRole('textbox', { name: 'Email' }).fill('yash.verma@gmail.com');
    await page.getByLabel('Password', { exact: true }).fill('abc12345!');
    await page.getByRole('checkbox').check();
    await page.getByRole('button', { name: /Create my account/ }).click();
    await expect(page.getByText('Already in the squad.')).toBeVisible();

    await page.getByRole('textbox', { name: 'Email' }).fill('yash.new@gmail.com');
    await page.getByRole('button', { name: /Create my account/ }).click();
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Verify your email');
    await page.keyboard.type('111111');
    await expect(page.getByText('That code doesn’t match. Check it and try again.')).toBeVisible();
    await axe(page);
    await page.keyboard.type('123456');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('You’re in, Yash!');
    await axe(page);
    await page.getByRole('button', { name: /Let’s gooo/ }).click();
    await expect(page).toHaveURL(/\/start$/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('glow-up era');
    await axe(page);
  });
});
