import { test, expect, Page } from '@playwright/test';
import { axe, logIn } from './support/helpers';

const isDesktop = (page: Page) => (page.viewportSize()?.width ?? 0) >= 1200;
const isMobile = (page: Page) => (page.viewportSize()?.width ?? 0) < 768;

test.describe('My Jobs', () => {
  test.describe.configure({ timeout: 90_000 });

  test('J1/J2: tabs with counts, list, job detail', async ({ page }) => {
    await logIn(page);
    await page.goto('/jobs');
    await expect(page.getByRole('heading', { level: 1, name: 'My Jobs' })).toBeVisible();
    const tabs = page.getByRole('navigation', { name: 'My Jobs sections' });
    await expect(tabs.getByRole('link', { name: /Available Jobs\s*128/ })).toHaveAttribute(
      'aria-current',
      'page',
    );
    await expect(tabs.getByRole('link', { name: /Job Invitations\s*2 new/ })).toBeVisible();
    await expect(page.getByText(/jobs in Pune and Remote/)).toBeVisible();
    await axe(page);

    const first = page.locator('sm-job-card').first().getByRole('link');
    const title = (await first.textContent())?.trim() ?? '';
    await first.click();
    if (isDesktop(page)) {
      await expect(
        page.locator('sm-job-detail').getByRole('heading', { level: 2, name: title }),
      ).toBeVisible();
    } else {
      await expect(page).toHaveURL(/\/jobs\/view\/job-/);
      await expect(page.getByRole('heading', { level: 1, name: 'Job details' })).toBeVisible();
      await expect(page.getByRole('heading', { level: 2, name: title })).toBeVisible();
    }
    await expect(page.getByRole('heading', { name: 'About the role' })).toBeVisible();
    await axe(page);
  });

  test('J3/J5/J6: quick filter with counts, pills, no results with suggestions', async ({
    page,
  }) => {
    test.skip(isMobile(page), 'Sector quick chip is covered on desktop and tablet');
    await logIn(page);
    await page.goto('/jobs');
    await page.getByRole('button', { name: /^Sector/ }).click();
    const pop = page.getByRole('dialog', { name: 'Sector' });
    await expect(pop.getByRole('checkbox', { name: /BPO \/ Contact centre/ })).toBeVisible();
    await axe(page);
    await pop.locator('sm-checkbox', { hasText: 'BPO' }).locator('label').click();
    await expect(pop.getByText('Showing roles in BPO / Contact centre.')).toBeVisible();
    const show = pop.getByRole('button', { name: /^Show \d+ jobs$/ });
    const n = Number((await show.textContent())?.match(/\d+/)?.[0]);
    await show.click();
    await expect(page.getByRole('status').getByText(`${n} jobs`, { exact: true })).toBeVisible();
    await expect(
      page.getByRole('button', { name: /BPO \/ Contact centre.*remove filter/ }),
    ).toBeVisible();

    // Search for something that doesn't exist alongside the filter → J6.
    await page
      .getByRole('searchbox', { name: 'Search job title, company or skill' })
      .fill('astronaut');
    await page.getByRole('button', { name: 'Search', exact: true }).click();
    await expect(page.getByRole('heading', { name: /No jobs match all 1 filters/ })).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Clear all filters' }).click();
    await expect(page.locator('sm-job-card').first()).toBeVisible();
  });

  test('J4 all filters: dependent location and live Show N', async ({ page }) => {
    await logIn(page);
    await page.goto('/jobs');
    await page.getByRole('button', { name: /^(All filters|Filters)/ }).click();
    const dialog = page.getByRole('dialog', { name: 'All filters' });
    await dialog.getByRole('combobox', { name: 'State' }).selectOption('Karnataka');
    await expect(dialog.getByRole('button', { name: /^Bengaluru/ })).toBeVisible();
    await expect(dialog.getByRole('button', { name: /^Pune/ })).toHaveCount(0);
    await dialog.getByRole('button', { name: /^Bengaluru/ }).click();
    await expect(dialog.getByRole('button', { name: /^Show \d+ jobs$/ })).toBeVisible();
    await axe(page);
    await dialog.getByRole('button', { name: /^Show \d+ jobs$/ }).click();
    await expect(dialog).toHaveCount(0);
    await expect(page.getByRole('button', { name: /Bengaluru.*remove filter/ })).toBeVisible();
  });

  test('J14/J15 apply: validation, submit, applied state', async ({ page }) => {
    await logIn(page);
    await page.goto(isDesktop(page) ? '/jobs?job=job-6' : '/jobs/view/job-6');
    await page.getByRole('button', { name: 'Apply now' }).first().click();
    const dialog = page.getByRole('dialog', { name: 'Apply to Front Desk Associate' });
    await expect(dialog.getByRole('radio', { name: /Yash_Pohare_CV_2026\.pdf/ })).toBeChecked();
    await dialog.getByRole('button', { name: 'Submit application' }).click();
    await expect(dialog.getByText('Answer this to apply').first()).toBeVisible();
    await axe(page);
    await dialog.getByRole('radio', { name: 'Yes' }).check({ force: true });
    await dialog.getByRole('textbox', { name: 'When can you join?' }).fill('Immediately');
    await dialog.getByRole('button', { name: 'Submit application' }).click();
    await expect(dialog).toHaveCount(0);
    await expect(page.getByText('Application sent to Taj Hotels.', { exact: false })).toBeVisible();
    await expect(page.getByRole('button', { name: /Applied on/ })).toBeDisabled();
  });

  test('J9/J10 invitations: decline with a reason', async ({ page }) => {
    await logIn(page);
    await page.goto('/jobs/invitations');
    await expect(page.getByText('2 new · 4 total')).toBeVisible();
    await page.locator('sm-job-card').filter({ hasText: 'Rahul K.' }).getByRole('link').click();
    await expect(page.getByText('Interview invite · 10 Oct, 11:00 AM').last()).toBeVisible();
    await expect(page.getByRole('button', { name: 'Suggest another time' })).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Decline' }).click();
    const dialog = page.getByRole('dialog', { name: 'Decline this invitation?' });
    await dialog.getByText('Pay is too low').click();
    await expect(dialog.getByRole('radio', { name: 'Pay is too low' })).toBeChecked();
    await axe(page);
    await dialog.getByRole('button', { name: 'Decline invitation' }).click();
    await expect(page.getByText('You declined this invitation.')).toBeVisible();
  });

  test('J12/J13 applied: timeline and withdraw', async ({ page }) => {
    await logIn(page);
    await page.goto('/jobs/applied');
    await expect(page.getByText('5 applications · 1 interview coming up')).toBeVisible();
    await page
      .locator('sm-job-card')
      .filter({ hasText: 'Interview · 12 Oct' })
      .getByRole('link')
      .click();
    await expect(page.getByRole('heading', { name: 'Application status' })).toBeVisible();
    await expect(page.getByText('Video interview · 30 min')).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Withdraw application' }).click();
    const dialog = page.getByRole('dialog', { name: 'Withdraw your application?' });
    await expect(dialog.getByText('Your interview on 12 Oct will be cancelled.')).toBeVisible();
    await dialog.getByRole('button', { name: 'Withdraw', exact: true }).click();
    await expect(page.getByText('Withdrawn', { exact: true }).first()).toBeVisible();
  });

  test('J8 never locked (A-261), J16–J19 empty, J21 error', async ({ page }) => {
    await logIn(page);
    await page.goto('/jobs/matching?jobs=locked');
    await expect(page.getByRole('link', { name: /Profile 45%/ })).toBeVisible();
    await expect(page.getByRole('heading', { name: /Finish your job profile/ })).toHaveCount(0);
    await axe(page);

    for (const [path, heading] of [
      ['/jobs/matching?jobs=empty', 'No matching jobs yet'],
      ['/jobs/invitations?jobs=empty', 'No invitations yet'],
      ['/jobs/bookmarked?jobs=empty', 'No saved jobs'],
      ['/jobs/applied?jobs=empty', 'No applications yet'],
    ] as const) {
      await page.goto(path);
      await expect(page.getByRole('heading', { name: heading })).toBeVisible();
    }
    await axe(page);

    await page.goto('/jobs?jobs=error');
    await expect(page.getByRole('heading', { name: 'Couldn’t load jobs' })).toBeVisible();
    await axe(page);
  });
});
