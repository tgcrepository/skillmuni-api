import { test, expect } from '@playwright/test';
import { axe, logIn } from './support/helpers';

test.describe('My Job Profile', () => {
  test.describe.configure({ timeout: 90_000 });

  test('P1 Living CV: strength, sections, edit links go to the source quest', async ({ page }) => {
    await logIn(page);
    await page.goto('/job-profile');
    await expect(page.getByRole('heading', { level: 1, name: 'My Job Profile' })).toBeVisible();
    // A-262: 15 of 18 quest steps filled.
    await expect(page.getByRole('progressbar', { name: 'Profile strength' })).toHaveAttribute(
      'aria-valuenow',
      '83',
    );
    const byQuest = page.getByRole('region', { name: 'Built from your quests' });
    await expect(byQuest.getByText('Left: Backup contact')).toBeVisible();
    await expect(byQuest.getByRole('link', { name: 'Fill Hit Me Up' })).toHaveAttribute(
      'href',
      /\/quests\/hit-me-up\?part=2/,
    );
    await expect(page.getByRole('heading', { name: 'Your CV is ready to send' })).toBeVisible();
    await expect(page.getByText('Customer Service Intern')).toBeVisible();
    await expect(page.getByRole('link', { name: /Tally basics.*Set level/ })).toBeVisible();
    await axe(page);

    const workEdit = page.getByRole('link', { name: 'Edit Work lore' });
    await expect(workEdit).toHaveAttribute('href', /\/quests\/work-lore\?part=1/);
  });

  test('Edit a section: opens just that part, filled in, Save returns (A-286)', async ({ page }) => {
    await logIn(page);
    await page.goto('/job-profile');
    await page.getByRole('link', { name: 'Edit Skill deck' }).click();
    await expect(page).toHaveURL(/\/quests\/your-flex-era\?part=1&edit=1/);
    await expect(page.getByText(/Editing · Your Flex Era · Skill deck/)).toBeVisible();
    await expect(page.getByRole('checkbox', { name: /^Customer service,.*in deck/ }).first()).toBeVisible();
    await page.getByRole('button', { name: 'Save changes' }).click();
    await expect(page).toHaveURL(/\/job-profile$/);
    await expect(page.getByText('Skill deck saved. Your profile is up to date.')).toBeVisible();

    await page.getByRole('link', { name: 'Edit What I’m looking for' }).click();
    await expect(page.getByText(/Editing · Pick Your Arc/)).toBeVisible();
    await page.getByRole('button', { name: 'Cancel' }).first().click();
    await expect(page).toHaveURL(/\/job-profile$/);
  });

  test('P4 share sheet: hide contact and cycle expiry', async ({ page }) => {
    await logIn(page);
    await page.goto('/job-profile');
    await page.getByRole('button', { name: 'Share', exact: true }).click();
    const dialog = page.getByRole('dialog', { name: 'Share your CV' });
    await expect(dialog.getByText('skillmuni.app/cv/yash-7q4')).toBeVisible();
    await expect(dialog.getByRole('switch')).toBeChecked();
    await dialog.getByRole('button', { name: /30 days/ }).click();
    await expect(dialog.getByRole('button', { name: /90 days/ })).toBeVisible();
    await axe(page);
    await dialog.getByRole('button', { name: 'Done' }).click();
    await expect(dialog).toHaveCount(0);
  });

  test('P5 newer CV: review changes, add them, profile updates', async ({ page }) => {
    await logIn(page);
    await page.goto('/job-profile');
    await expect(page.getByText('Customer Service Intern')).toBeVisible();
    await page.locator('input[type=file]').setInputFiles({
      name: 'cv.pdf',
      mimeType: 'application/pdf',
      buffer: Buffer.from('%PDF-1.4'),
    });
    const dialog = page.getByRole('dialog', { name: 'We found 4 updates in your new CV' });
    await expect(dialog).toBeVisible({ timeout: 10_000 });
    await axe(page);
    await dialog.getByRole('button', { name: 'Add 3 updates' }).click();
    await expect(dialog).toHaveCount(0);
    await expect(page.getByText('Customer Support Executive')).toBeVisible();
    await expect(page.getByText('Freshdesk')).toBeVisible();
  });

  test('P5 wrong file type is refused', async ({ page }) => {
    await logIn(page);
    await page.goto('/job-profile');
    await expect(page.getByText('Customer Service Intern')).toBeVisible();
    await page.locator('input[type=file]').setInputFiles({
      name: 'cv.png',
      mimeType: 'image/png',
      buffer: Buffer.from('x'),
    });
    await expect(page.getByText('Use a PDF or Word file up to 5 MB.')).toBeVisible();
  });

  test('P6 sections to finish and P7 fresher', async ({ page }) => {
    await logIn(page);
    await page.goto('/job-profile?jp=finish');
    const finish = page.getByRole('dialog', { name: '2 quick quests to unlock your CV' });
    await expect(finish).toBeVisible();
    await axe(page);
    await finish.getByRole('button', { name: 'Later' }).click();
    await expect(finish).toHaveCount(0);

    await page.goto('/job-profile?jp=fresher');
    await expect(
      page.getByRole('heading', { name: 'Your fresher CV is ready to send' }),
    ).toBeVisible();
    await expect(page.getByText('Customer Service Intern')).toHaveCount(0);
    await axe(page);
  });

  test('P3 employer view hides edits, private rows and contact', async ({ page }) => {
    await logIn(page);
    await page.goto('/job-profile');
    await page.getByRole('link', { name: 'Employer view' }).click();
    await expect(page).toHaveURL(/\/job-profile\/employer$/);
    await expect(
      page.getByRole('heading', { name: 'You’re seeing what employers see' }),
    ).toBeVisible();
    await expect(page.getByRole('link', { name: /^Edit/ })).toHaveCount(0);
    await expect(page.getByText('Expected pay')).toHaveCount(0);
    await expect(page.getByText('Teleperformance internship letter')).toHaveCount(0);
    await expect(page.getByText('Shared after you apply')).toHaveCount(2);
    await axe(page);
    await page.getByRole('link', { name: 'Back to editing' }).click();
    await expect(page).toHaveURL(/\/job-profile$/);
  });

  test('P2 CV preview: switch template and toggles, settings persist', async ({ page }) => {
    await logIn(page);
    await page.goto('/job-profile/cv');
    await expect(page.getByRole('heading', { level: 1, name: 'Preview my CV' })).toBeVisible();
    const doc = page.locator('sm-cv-document');
    await expect(doc).toHaveClass(/cv--creative/);
    await page.getByRole('radio', { name: /Classic/ }).click();
    await expect(doc).toHaveClass(/cv--classic/);
    await expect(doc.getByText('₹3 – 4.5 LPA')).toHaveCount(0);
    await page.getByRole('switch', { name: 'Show expected salary' }).click();
    await expect(doc.getByText('₹3 – 4.5 LPA')).toBeVisible();
    await axe(page);
    await page.reload();
    await expect(page.locator('sm-cv-document')).toHaveClass(/cv--classic/);
  });

  test('error state offers retry', async ({ page }) => {
    await logIn(page);
    await page.goto('/job-profile?jp=error');
    await expect(
      page.getByRole('heading', { name: 'Couldn’t load your job profile' }),
    ).toBeVisible();
    await axe(page);
  });
});
