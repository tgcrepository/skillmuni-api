import { test, expect } from '@playwright/test';
import { axe, logIn } from './support/helpers';

test.describe('The Arena (Leaderboard v2)', () => {
  test.describe.configure({ timeout: 60_000 });

  test('podium, your spot, rank-up toast, filters and the pinned row', async ({ page }) => {
    await logIn(page);
    await page.getByRole('link', { name: 'Arena', exact: true }).click();
    await expect(page).toHaveURL(/\/arena$/);
    await expect(page.getByRole('heading', { level: 1 })).toHaveText('Who’s cooking?');
    await expect(page.getByRole('heading', { name: 'Top 3 this week' })).toBeVisible();
    await expect(page.getByText('115 XP to steal the crown')).toBeVisible();
    await expect(page.getByRole('status').filter({ hasText: 'Rank up!' })).toBeVisible();
    await page.getByRole('button', { name: 'Dismiss' }).click();
    await axe(page);

    await page.getByRole('button', { name: 'All time' }).click();
    await expect(page.getByRole('button', { name: 'All time' })).toHaveAttribute(
      'aria-pressed',
      'true',
    );
    await expect(page.getByRole('heading', { name: 'Top 3 of all time' })).toBeVisible();
    // You're #12: pinned under the list.
    await expect(page.getByRole('button', { name: /^Rank 12, Yash \(you\)/ })).toBeVisible();
    await expect(page.getByText('Promotion zone ends here · 947 XP to get in')).toBeVisible();
  });

  test('player peek: cheer, undo, Esc returns focus', async ({ page }) => {
    await logIn(page);
    await page.goto('/arena');
    const row = page.getByRole('button', { name: /^Rank 4, Priya Deshmukh/ });
    await row.click();
    const peek = page.getByRole('dialog', { name: 'Priya Deshmukh' });
    await expect(peek).toContainText('#4 · Rookie · Lvl 1');
    await axe(page);
    await peek.getByRole('button', { name: 'Cheer' }).click();
    await expect(peek.getByRole('button', { name: /Cheered · 13/ })).toHaveAttribute(
      'aria-pressed',
      'true',
    );
    await peek.getByRole('button', { name: /Cheered/ }).click();
    await expect(peek.getByRole('button', { name: 'Cheer' })).toBeVisible();
    await page.keyboard.press('Escape');
    await expect(peek).toHaveCount(0);
    await expect(row).toBeFocused();
  });

  test('empty week and error states', async ({ page }) => {
    await logIn(page);
    await page.goto('/arena?arena=empty');
    await expect(page.getByRole('heading', { name: 'The Arena is wide open' })).toBeVisible();
    // A-271: try the crown on; Muni reacts.
    await page.getByRole('button', { name: 'Try the crown on' }).click();
    await expect(page.getByRole('button', { name: 'Looks good on you!' })).toHaveAttribute(
      'aria-pressed',
      'true',
    );
    await expect(page.getByText(/Told you it fits/)).toBeVisible();
    await axe(page);
    await page.goto('/arena?arena=error');
    await expect(page.getByRole('alert')).toContainText('Couldn’t load the Arena');
  });

  test('standings strip slides in, in rank order, once the podium scrolls away (A-301)', async ({
    page,
  }) => {
    await page.setViewportSize({ width: 1366, height: 560 });
    await logIn(page);
    await page.goto('/arena');
    await expect(page.getByRole('heading', { name: 'Top 3 this week' })).toBeVisible();
    const dock = page.locator('.strip-dock');
    await expect(dock).not.toHaveClass(/is-shown/);
    await page.evaluate(() => scrollTo(0, document.documentElement.scrollHeight));
    await expect(dock).toHaveClass(/is-shown/);
    await expect(dock.locator('.strip-name')).toHaveText(['Ananya Iyer', 'You', 'Kabir Nair']);
    await page.evaluate(() => scrollTo(0, 0));
    await expect(dock).not.toHaveClass(/is-shown/);
    await axe(page);
  });
});
