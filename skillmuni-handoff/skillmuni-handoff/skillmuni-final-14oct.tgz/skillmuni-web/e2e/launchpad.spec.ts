import { test, expect } from '@playwright/test';
import { axe, logIn } from './support/helpers';

test.describe('Career Launchpad', () => {
  test.describe.configure({ timeout: 90_000 });

  test('L1 returning: readiness, one primary CTA, sectors and search', async ({ page }) => {
    await logIn(page);
    await page.getByRole('link', { name: /Career Launchpad/ }).click();
    await expect(page).toHaveURL(/\/launchpad$/);
    // A-306: missions follow real activity: assessment taken, applied, fest booked; profile at 83%.
    await expect(page.getByText('Level 3 · Almost in orbit')).toBeVisible();
    await expect(page.getByRole('progressbar', { name: 'Launch readiness' })).toHaveAttribute(
      'aria-valuenow',
      '86',
    );
    await expect(page.getByText('The Connector')).toBeVisible();
    await expect(page.getByText('5 new matches')).toBeVisible();
    await axe(page);

    // Best fit first; "View all" opens every sector with search.
    await expect(page.getByRole('link', { name: 'BPO, 24 jobs, Best fit' })).toBeVisible();
    await page.getByRole('button', { name: 'View all 14' }).click();
    const dialog = page.getByRole('dialog', { name: 'All sectors' });
    await expect(dialog.getByRole('link')).toHaveCount(14);
    await dialog.getByRole('searchbox', { name: 'Search sectors' }).fill('bank');
    await expect(dialog.getByRole('link')).toHaveCount(1);
    await dialog.getByRole('searchbox', { name: 'Search sectors' }).fill('Aviation');
    await expect(dialog.getByText('No sector called “Aviation”')).toBeVisible();
    await axe(page);
    await dialog.getByRole('button', { name: 'Clear search' }).last().click();
    await expect(dialog.getByRole('link')).toHaveCount(14);
    await dialog.getByRole('radio', { name: 'A–Z' }).check({ force: true });
    await expect(dialog.getByRole('link').first()).toHaveAccessibleName(/^Banking/);
    await page.keyboard.press('Escape');
    await expect(dialog).toHaveCount(0);
  });

  test('L2 new learner: assessment is the next mission, My Jobs open (A-261)', async ({ page }) => {
    await logIn(page);
    await page.goto('/launchpad?launch=new');
    await expect(page.getByText('Level 0 · On the launchpad')).toBeVisible();
    await expect(page.getByText('Unlocks at 60% profile')).toHaveCount(0);
    await expect(page.getByRole('link', { name: /Explore jobs/ })).toBeVisible();
    // A-262: no "Start profile" — the profile is built from the quests, shown quest by quest.
    await expect(page.getByRole('link', { name: /Start profile/ })).toHaveCount(0);
    await expect(page.getByText(/Built from your quests/)).toBeVisible();
    await expect(page.getByRole('link', { name: /Start assessment/ })).toBeVisible();
    await axe(page);
  });

  test('L3–L6: paused, launched, no fest, jobs failed', async ({ page }) => {
    await logIn(page);
    await page.goto('/launchpad?launch=paused');
    await expect(
      page.getByText('Paused at question 14 of 36. Your answers are saved.'),
    ).toBeVisible();
    await expect(page.getByRole('link', { name: /^Resume/ })).toBeVisible();

    await page.goto('/launchpad?launch=done');
    await expect(page.getByText('Level 4 · Launched!')).toBeVisible();
    await expect(page.getByText('2 interviews')).toBeVisible();
    await expect(page.getByRole('link', { name: 'View my slot' })).toBeVisible();

    await page.goto('/launchpad?launch=nofest');
    await expect(page.getByText('No fests scheduled yet')).toBeVisible();
    await page.getByRole('button', { name: 'Turn on fest alerts' }).click();
    await expect(page.getByText('Done! We’ll ping you when a fest drops.')).toBeVisible();

    await page.goto('/launchpad?launch=jobs-error');
    await expect(page.getByRole('alert')).toContainText('Couldn’t load your jobs');
    // The rest of the page still works.
    await expect(page.getByRole('link', { name: /See what’s left/ })).toBeVisible();
    await axe(page);
  });
});
