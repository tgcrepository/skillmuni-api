import { expect, Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const AXE_TAGS = ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'];

/** Audit the settled UI: wait for entry animations (looping decoration aside) to finish first. */
export async function axe(page: Page): Promise<void> {
  await page.waitForFunction(() =>
    document
      .getAnimations()
      .every(
        (a) => a.playState !== 'running' || a.effect?.getComputedTiming().iterations === Infinity,
      ),
  );
  // A toast that starts leaving mid-scan is half transparent; it is on its way out, not content.
  const scan = await new AxeBuilder({ page }).withTags(AXE_TAGS).exclude('.toast-out').analyze();
  expect(scan.violations).toEqual([]);
}

/** Mobile login with the mock code; lands on the Lobby. */
export async function logIn(page: Page): Promise<void> {
  await page.goto('/login');
  await page.getByRole('textbox', { name: 'Mobile number' }).fill('98765 43210');
  await page.getByRole('button', { name: /Send me the code/ }).click();
  await expect(page.getByRole('dialog', { name: 'Enter the 6-digit code' })).toBeVisible();
  await page.keyboard.type('123456');
  await expect(page).toHaveURL(/\/home$/);
}
