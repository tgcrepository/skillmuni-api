import { test, expect } from '@playwright/test';
import { axe, logIn } from './support/helpers';

test.describe('My Stats dashboard', () => {
  test.describe.configure({ timeout: 90_000 });

  test('Rewards → Learning → Assessments', async ({ page }) => {
    await logIn(page);
    await page.goto('/stats');
    await expect(page.getByRole('heading', { name: 'Yash Pohare' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Today’s quests' })).toBeVisible();
    await expect(page.getByText('48 XP to pass Aarav (#11)')).toBeVisible();
    await expect(page.getByRole('link', { name: 'My Stats', exact: true }).first()).toHaveAttribute(
      'aria-current',
      'page',
    );
    await axe(page);

    await page.goto('/stats/learning');
    await expect(page.getByRole('heading', { name: 'International Opportunities' })).toBeVisible();
    await expect(page.getByText('0 days left')).toBeVisible();
    await page.getByRole('button', { name: 'Brain-Vita, 98.86%' }).click();
    await expect(page.getByRole('heading', { level: 3, name: 'Brain-Vita' })).toBeVisible();
    await page.getByRole('button', { name: /^Not started/ }).click();
    await page.getByRole('button', { name: 'Show all 17 quests' }).click();
    await expect(page.getByRole('button', { name: 'Tally for Beginners, 0%' })).toBeVisible();
    await axe(page);

    await page.goto('/stats/assessments');
    await expect(page.getByRole('heading', { name: 'Digital Skills' })).toBeVisible();
    await expect(page.getByText('Entrepreneurial Mindset · 59%')).toBeVisible();
    await page.getByRole('button', { name: 'Risk & Adaptability, Advanced, 86%' }).click();
    await expect(page.getByRole('heading', { name: 'Risk & Adaptability' })).toBeVisible();
    await axe(page);
  });

  test('assessments empty state and error retry', async ({ page }) => {
    await logIn(page);
    await page.goto('/stats/assessments?stats=empty');
    await expect(page.getByRole('heading', { name: 'Your skill cards are waiting' })).toBeVisible();
    await expect(page.getByRole('link', { name: /Start your first assessment/ })).toBeVisible();
    await axe(page);
    await page.goto('/stats?stats=error');
    await expect(page.getByRole('heading', { name: 'Couldn’t load your stats' })).toBeVisible();
  });

  test('quest badges land in the library as quests are finished (A-292)', async ({ page }) => {
    await page.addInitScript(() => {
      if (sessionStorage.getItem('sm_mock_quests')) return;
      const progress = { completed: 2, partsDone: 1, xp: 240, badges: 2, level: 1, rank: 'Rookie', target: 400 };
      sessionStorage.setItem('sm_mock_quests', JSON.stringify({ progress, answers: {} }));
    });
    await page.context().addCookies([
      { name: 'sm_mock_session', value: '1', url: 'http://localhost:4200' },
    ]);
    await page.goto('/stats/badges');
    await expect(page.getByRole('button', { name: /^Main Character Badge, earned/ })).toBeVisible();
    await expect(page.getByRole('button', { name: /^Link Up Badge, earned/ })).toBeVisible();
    await expect(page.getByRole('button', { name: /^Big Brain Badge/ })).not.toHaveAccessibleName(
      /earned/,
    );
  });

  test('My Badges: filter, detail, pin to showcase', async ({ page }) => {
    await logIn(page);
    await page.goto('/stats/badges');
    await expect(page.getByRole('heading', { level: 1, name: 'My Badges' })).toBeVisible();
    // A-292: every profile quest has its badge in the library.
    await expect(page.getByRole('heading', { name: /Profile quests/ })).toBeVisible();
    await page.getByRole('button', { name: 'Earned · 2' }).click();
    await page.getByRole('button', { name: /^Quiz Starter, earned/ }).click();

    // Desktop shows the detail panel; tablet and mobile open it in a dialog.
    const desktop = (page.viewportSize()?.width ?? 0) >= 1280;
    const scope = desktop
      ? page.getByRole('complementary', { name: 'Badge details' })
      : page.getByRole('dialog');
    await expect(scope.getByRole('heading', { name: 'Quiz Starter' })).toBeVisible();
    await scope.getByRole('button', { name: 'Unpin from showcase' }).click();
    await expect(page.getByText('Quiz Starter left your showcase')).toBeVisible();
    await expect(scope.getByRole('button', { name: 'Pin to showcase' })).toBeVisible();
    await axe(page);
  });
});
