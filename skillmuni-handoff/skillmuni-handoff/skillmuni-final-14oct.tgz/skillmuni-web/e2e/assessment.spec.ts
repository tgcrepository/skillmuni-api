import { test, expect, Page } from '@playwright/test';
import { axe, logIn } from './support/helpers';

/** Answer `n` pairs with the number keys (cycling 1–4), waiting for each board to settle. */
async function answer(page: Page, n: number, from = 1): Promise<void> {
  for (let i = 0; i < n; i++) {
    await expect(page.getByText(`Pair ${from + i} of 36`, { exact: true })).toBeVisible();
    await page.keyboard.press(String((i % 4) + 1));
  }
}

test.describe('Career Assessment · Muni’s Balance', () => {
  test.describe.configure({ timeout: 120_000 });

  test('B1 → B3/B4: intro, pick with keys and taps, undo, skip', async ({ page }) => {
    await logIn(page);
    await page.goto('/assessments/career?ca=new');
    await expect(
      page.getByRole('heading', { name: 'What really drives you at work?' }),
    ).toBeVisible();
    await axe(page);

    await page.getByRole('button', { name: 'Why 36 pairs?' }).click();
    const why = page.getByRole('dialog', { name: 'Why 36 pairs?' });
    await expect(why).toBeVisible();
    await why.getByRole('button', { name: 'Got it' }).click();

    await page.getByRole('button', { name: /Let’s play/ }).click();
    await expect(page.getByText('Pair 1 of 36', { exact: true })).toBeVisible();
    const group = page.getByRole('radiogroup', { name: 'Which feels more like you?' });
    await expect(group.getByRole('radio')).toHaveCount(4);
    await axe(page);

    // Tap "Lean This": the radio checks, Muni reacts, then Undo puts it back.
    await group.getByRole('radio', { name: 'Lean This' }).check({ force: true });
    await expect(group.getByRole('radio', { name: 'Lean This' })).toBeChecked();
    await expect(page.locator('sm-seesaw').getByText('Leaning This. Noted! ⚖️')).toBeVisible();
    await page.getByRole('button', { name: 'Undo' }).click();
    await expect(group.getByRole('radio', { name: 'Lean This' })).not.toBeChecked();
    await expect(page.getByText('Pair 1 of 36', { exact: true })).toBeVisible();

    // Key 4 = All in That; the next pair slides in.
    await page.keyboard.press('4');
    await expect(page.getByText('Pair 2 of 36', { exact: true })).toBeVisible();

    // Skip for now moves on at once.
    await page.getByRole('button', { name: 'Skip for now' }).click();
    await expect(page.getByText('Pair 3 of 36', { exact: true })).toBeVisible();
  });

  test('B5 island cleared earns +25 XP (reduced motion)', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await logIn(page);
    await page.goto('/assessments/career?ca=new');
    await page.getByRole('button', { name: /Let’s play/ }).click();
    await answer(page, 9);
    await expect(page.getByRole('heading', { name: 'Vibe Check: conquered! 🎉' })).toBeVisible();
    await expect(page.getByText('27 pairs to go')).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Sail to Island 2' }).click();
    await expect(page.getByText('Pair 10 of 36', { exact: true })).toBeVisible();
  });

  test('B2 resume and B6 save & exit', async ({ page }) => {
    await logIn(page);
    await page.goto('/assessments/career?ca=resume');
    await expect(page.getByRole('heading', { name: 'Island 2 · Main Character' })).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: 'Resume at pair 14' }).click();
    await expect(page.getByText('Pair 14 of 36', { exact: true })).toBeVisible();

    await page.getByRole('button', { name: 'Save & exit' }).click();
    const dialog = page.getByRole('dialog', { name: 'Take a break?' });
    await expect(dialog.getByText('pick up at pair 14 on Main Character')).toBeVisible();
    await axe(page);
    await dialog.getByRole('button', { name: 'Save & exit' }).click();
    await expect(page).toHaveURL(/\/launchpad$/);
  });

  test('B7 final check → S4 calculating → B8 the jars open → S1', async ({ page }) => {
    await logIn(page);
    await page.goto('/assessments/career?ca=final');
    await page.getByRole('button', { name: 'Finish up' }).click();
    await expect(page.getByRole('heading', { name: '34 of 36 balanced' })).toBeVisible();
    await expect(page.getByRole('button', { name: 'Open my jars' })).toBeDisabled();
    await axe(page);

    for (const n of [12, 27]) {
      await page.getByRole('button', { name: `Answer pair ${n}` }).click();
      await expect(page.getByText(`Pair ${n} of 36`, { exact: true })).toBeVisible();
      await page.keyboard.press('1');
      await expect(page.getByRole('button', { name: 'Open my jars' })).toBeVisible();
    }
    await page.getByRole('button', { name: 'Open my jars' }).click();
    await expect(page.getByRole('heading', { name: 'Reading your 108 coins…' })).toBeVisible();
    await expect(page.getByText('Your archetype', { exact: true })).toBeVisible({
      timeout: 10_000,
    });
    await expect(page.getByText('+100 XP · Mission complete')).toBeVisible();
    await axe(page);

    await page.getByRole('link', { name: 'See my full results' }).click();
    await expect(page).toHaveURL(/\/assessments\/career\/report$/);
    await expect(page.getByRole('heading', { name: 'Your Career Drivers' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Your top 3 drivers' })).toBeVisible();

    // A-306: the result shows up on Profile and the Launchpad straight away.
    await page.goto('/profile');
    // Corrections #21: the archetype is a showcase card that links to the full results.
    const arch = page.getByRole('link', { name: /Your career archetype/ });
    await expect(arch).toContainText(/The /);
    await arch.click();
    await expect(page).toHaveURL(/\/assessments\/career\/report$/);
    // Corrections #19: Back from the results returns to where they were opened from.
    await page.getByRole('button', { name: 'Back', exact: true }).click();
    await expect(page).toHaveURL(/\/profile$/);
    await page.goto('/launchpad');
    await expect(page.getByRole('link', { name: 'View report' })).toBeVisible();
  });

  test('S3 offline submit keeps answers and retries when back online', async ({
    page,
    context,
  }) => {
    await logIn(page);
    await page.goto('/assessments/career?ca=final');
    await page.getByRole('button', { name: 'Finish up' }).click();
    for (const n of [12, 27]) {
      await page.getByRole('button', { name: `Answer pair ${n}` }).click();
      await page.keyboard.press('3');
      await expect(page.getByRole('button', { name: 'Open my jars' })).toBeVisible();
    }
    await context.setOffline(true);
    await page.getByRole('button', { name: 'Open my jars' }).click();
    await expect(page.getByRole('heading', { name: 'You’re offline' })).toBeVisible({
      timeout: 10_000,
    });
    await expect(page.getByText('✓ 36/36 answers saved on this device')).toBeVisible();
    await axe(page);
    await context.setOffline(false);
    await expect(page.getByText('Your archetype', { exact: true })).toBeVisible({
      timeout: 10_000,
    });
  });

  test('S1 results: compare, breakdown details, S2 retake', async ({ page }) => {
    await logIn(page);
    await page.goto('/assessments/career/report?ca=done');
    await expect(page.getByRole('heading', { name: 'The Creative Pathfinder' })).toBeVisible();
    await expect(page.getByText('▲ 2 since last time')).toBeVisible();
    await axe(page);

    await page.getByRole('button', { name: 'Compare with attempt 2' }).click();
    await expect(page.getByRole('button', { name: 'Hide attempt 2' })).toHaveAttribute(
      'aria-pressed',
      'true',
    );

    const security = page.getByRole('button', { name: /Security/ });
    await security.click();
    await expect(security).toHaveAttribute('aria-expanded', 'true');
    await expect(page.getByText('Mid-range for you', { exact: false })).toBeVisible();
    await axe(page);

    await page.getByRole('button', { name: 'Retake' }).click();
    const dialog = page.getByRole('dialog', { name: 'Retake the assessment?' });
    await expect(dialog.getByText('Retakes don’t earn XP again', { exact: false })).toBeVisible();
    await axe(page);
    await dialog.getByRole('button', { name: 'Retake now' }).click();
    await expect(page).toHaveURL(/\/assessments\/career$/);
    await expect(page.getByText('🔁 Retake · no XP')).toBeVisible();
  });

  test('load error offers retry', async ({ page }) => {
    await logIn(page);
    await page.goto('/assessments/career?ca=error');
    await expect(page.getByRole('heading', { name: 'Couldn’t load the assessment' })).toBeVisible();
    await axe(page);
  });
});
