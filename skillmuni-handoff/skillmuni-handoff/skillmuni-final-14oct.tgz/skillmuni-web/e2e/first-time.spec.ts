import { test, expect, Page } from '@playwright/test';
import { axe, logIn } from './support/helpers';

/** A-232 / A-233: "Join the squad" → a brand-new learner; logging in → the returning learner. */
async function register(page: Page) {
  await page.goto('/signup');
  await page.getByRole('textbox', { name: 'First name' }).fill('Priya');
  await page.getByRole('textbox', { name: 'Last name' }).fill('Nair');
  await page.getByRole('textbox', { name: 'Email' }).fill('priya.nair@example.com');
  await page.getByLabel('Password', { exact: true }).fill('abc12345!');
  await page.getByRole('checkbox').check();
  await page.getByRole('button', { name: /Create my account/ }).click();
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Verify your email');
  await page.keyboard.type('123456');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('You’re in, Priya!');
}

test.describe('First-time vs returning learner', () => {
  test.describe.configure({ timeout: 60_000 });

  test('fixed country code; Google sign-in routes new → quests, existing → Lobby', async ({
    page,
  }) => {
    await page.goto('/login');
    await expect(page.getByRole('combobox', { name: 'Country code' })).toHaveCount(0);
    await expect(page.getByText('+91')).toBeVisible();
    await page.getByRole('button', { name: /Continue with Google/ }).click();
    await page.getByRole('button', { name: /Yash Pohare/ }).click();
    await expect(page).toHaveURL(/\/home$/);
    // Signed in, Sign up sends you to the Lobby (BR-07)…
    await page.goto('/signup');
    await expect(page).toHaveURL(/\/home$/);

    // …so sign out (a fresh browser) before signing up as someone new.
    await page.context().clearCookies();
    await page.goto('/signup');
    await page.getByRole('button', { name: /Sign up with Google/ }).click();
    await page.getByRole('button', { name: /Ananya Rao/ }).click();
    await expect(page).toHaveURL(/\/start$/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('glow-up era');
  });

  test('a new account sees first moves and empty histories', async ({ page }) => {
    await register(page);
    await page.goto('/home');
    await expect(page.getByRole('heading', { name: 'Your first moves' })).toBeVisible();
    await expect(page.getByRole('link', { name: /Discover your Career Drivers/ })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Pick up where you left off' })).toHaveCount(0);
    await axe(page);

    await page.goto('/jobs/applied');
    await expect(page.getByText('No applications yet')).toBeVisible();
    await page.goto('/hire-fest/bookings');
    await expect(page.getByText('No bookings yet')).toBeVisible();
    await page.goto('/assessments/career');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Career Assessment');
    await expect(page.getByRole('button', { name: /Let’s play/ })).toBeVisible();
  });

  test('first moves: My Jobs ticks step 3; all three pay a +50 XP bonus (A-266)', async ({ page }) => {
    await register(page);
    await page.goto('/home');
    await expect(page.getByText('Start your first learning module')).toBeVisible();
    await expect(page.getByText(/Finish all 3 for a/)).toBeVisible();
    await page.getByRole('link', { name: /See jobs that fit you/ }).click();
    await expect(page).toHaveURL(/\/jobs\/matching/);
    await page.goto('/home');
    await expect(page.getByRole('link', { name: /See jobs that fit you\s*, done/ })).toBeVisible();
    await expect(page.getByText('1 of 3 done')).toBeVisible();

    await page.goto('/home?first=done');
    await expect(page.getByText(/All 3 moves done/)).toBeVisible();
    await axe(page);
    await page.getByRole('button', { name: /Collect \+50 XP/ }).click();
    await expect(page.getByText('First-moves bonus collected. Flying start!')).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Your first moves' })).toHaveCount(0);
  });

  test('logging in shows the returning learner', async ({ page }) => {
    await logIn(page);
    await expect(page.getByRole('heading', { name: 'Pick up where you left off' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Your first moves' })).toHaveCount(0);
  });
});
