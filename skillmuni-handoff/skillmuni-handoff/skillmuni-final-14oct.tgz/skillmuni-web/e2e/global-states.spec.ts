import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const AXE_TAGS = ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'];

test.describe('Phase 5 global states', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/_dev/states');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('call you?');
  });

  test('OF1: offline banner, answers queue, and replay with a toast when back online', async ({
    page,
    context,
  }) => {
    await context.setOffline(true);
    const status = page.locator('sm-offline-banner [role="status"]');
    await expect(status).toContainText('You’re offline');

    await page.getByRole('button', { name: /Next part/ }).click();
    await expect(status).toContainText('We’ll save your answers when you’re back');
    await expect(page.getByText('Saved on this device')).toBeVisible();
    // Let the offline banner and header transitions settle before measuring contrast.
    await page.waitForFunction(() =>
      document
        .getAnimations()
        .every((a) => a.playState !== 'running' || a.effect?.getComputedTiming().iterations === Infinity),
    );
    expect((await new AxeBuilder({ page }).withTags(AXE_TAGS).analyze()).violations).toEqual([]);

    await context.setOffline(false);
    await expect(page.getByText('Back online. Your answers are saved.')).toBeVisible();
    await expect(status).toBeEmpty();
  });

  test('SE1: session expiry is critical and returns to login with the return URL', async ({
    page,
  }) => {
    await page.getByRole('button', { name: 'Expire session' }).click();
    const dialog = page.getByRole('dialog', { name: 'You’ve been logged out' });
    await expect(dialog).toBeVisible();
    await expect(dialog).toContainText('carry on from Who Dis?');

    await page.keyboard.press('Escape');
    await expect(dialog).toBeVisible();
    expect((await new AxeBuilder({ page }).withTags(AXE_TAGS).analyze()).violations).toEqual([]);

    await dialog.getByRole('button', { name: 'Log in again' }).click();
    await expect(page).toHaveURL(/\/login\?returnUrl=%2F_dev%2Fstates/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Welcome back');
  });

  test('PM1: camera primer offers a file upload fallback', async ({ page }) => {
    await page.getByRole('button', { name: 'Camera primer' }).click();
    const dialog = page.getByRole('dialog', { name: 'Snap your CV with the camera?' });
    await expect(dialog).toBeVisible();
    expect((await new AxeBuilder({ page }).withTags(AXE_TAGS).analyze()).violations).toEqual([]);
    await dialog.getByRole('button', { name: 'Upload a file instead' }).click();
    await expect(page.getByText('Primer result: fallback')).toBeVisible();
  });
});
