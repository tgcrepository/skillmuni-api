import { defineConfig, devices } from '@playwright/test';

/** E2E runs against the dev server with the MSW mock backend. */
export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: !!process.env['CI'],
  retries: process.env['CI'] ? 2 : 0,
  reporter: [['list'], ['html', { open: 'never' }]],
  // The dev server is slow under parallel workers; give assertions room before failing.
  expect: { timeout: 10_000 },
  use: {
    baseURL: 'http://localhost:4200',
    trace: 'retain-on-failure',
    // Optional: point at a locally installed Chromium when the Playwright CDN is unavailable.
    ...(process.env['PW_CHROMIUM_PATH']
      ? {
          launchOptions: {
            executablePath: process.env['PW_CHROMIUM_PATH'],
            args: ['--no-sandbox'],
          },
        }
      : {}),
  },
  projects: [
    {
      name: 'desktop',
      use: { ...devices['Desktop Chrome'], viewport: { width: 1728, height: 1117 } },
    },
    {
      name: 'tablet',
      use: { ...devices['Desktop Chrome'], viewport: { width: 834, height: 1194 }, hasTouch: true },
    },
    { name: 'mobile', use: { ...devices['Pixel 7'], viewport: { width: 390, height: 844 } } },
  ],
  webServer: {
    command: 'npm start -- --port 4200',
    url: 'http://localhost:4200',
    reuseExistingServer: !process.env['CI'],
    timeout: 180_000,
  },
});
