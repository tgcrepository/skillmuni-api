import { chromium } from '@playwright/test';
const S = process.argv[2];
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
for (const [name, w, h] of [['desktop', 1536, 864], ['mobile', 390, 844]]) {
  const p = await b.newPage({ viewport: { width: w, height: h } });
  await p.goto('http://localhost:4200/login');
  await p.waitForTimeout(1200);
  await p.screenshot({ path: `${S}/v-login-${name}.png` });
  await p.getByRole('textbox', { name: 'Mobile number' }).fill('98765 43210');
  await p.getByRole('button', { name: /Send me the code/ }).click();
  await p.getByRole('dialog').waitFor();
  await p.keyboard.type('123456');
  await p.waitForURL(/home/);
  await p.waitForTimeout(1000);
  await p.screenshot({ path: `${S}/v-home-${name}.png` });
  await p.goto('http://localhost:4200/quests/who-dis?part=2');
  await p.waitForTimeout(1500);
  await p.screenshot({ path: `${S}/v-q1-${name}.png` });
  await p.close();
}
await b.close();
