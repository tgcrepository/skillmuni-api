# Skillmuni Web

Angular 22 front end for Skillmuni registration, quests, My Matches, programme code and institute claim.
Figma source of truth: `Skillmuni-India` → page **Screens – Reviewed**.

## Requirements

Node **24** (or ≥ 22.22.3) · npm 10.

## Scripts

| Command             | What it does                                                                     |
| ------------------- | -------------------------------------------------------------------------------- |
| `npm start`         | Dev server with the MSW mock API (`/_dev/tokens` shows every token)              |
| `npm run tokens`    | Regenerate CSS tokens from `tokens/source/*.json` (runs before start/build/test) |
| `npm run verify`    | Format check → ESLint + Stylelint → type-check → unit tests → production build   |
| `npm run e2e`       | Playwright at 1728 / 834 / 390 with axe checks                                   |
| `npm run storybook` | Component workbench (a11y addon fails on violations)                             |
| `npm run test:a11y` | Builds Storybook and runs axe (WCAG 2.2 AA) on every story                       |

## Try it (mock API)

| Where                                                                                   | How                                                                                                                                                        |
| --------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `/login`                                                                                | Mobile **or email**, code **123456** (000000 = expired, anything else = wrong) → `/home`                                                                   |
| `/home`                                                                                 | The Lobby (Home v2). Add `?home=empty` (new learner) or `?home=error`                                                                                      |
| `/arena`                                                                                | Leaderboard. `?arena=empty` / `?arena=error`. "All time" shows the pinned "you" row                                                                        |
| Muni (bottom-right on any learner page)                                                 | Chat drawer. Try "Show my profile" (eye reveals email), the topic tiles, chips, history. `?muni=error` fails replies                                       |
| `/profile`                                                                              | Player ID. Eye reveals private details; Edit adds skills (+10 XP); upload a photo (+5 XP). `?profile=error` / `?profile=new`                               |
| `/stats`                                                                                | My Stats: Rewards · `/stats/learning` · `/stats/assessments` (`?stats=empty` for the empty state, `?stats=error`). `/stats/badges` = My Badges (pin/unpin) |
| `/launchpad`                                                                            | Career Launchpad. `?launch=new` · `paused` · `done` · `nofest` · `jobs-error` · `loading` · `error`. View all opens every sector with search               |
| `/job-profile` · `/job-profile/cv` · `/job-profile/employer`                            | My Job Profile (Living CV), CV preview and download, employer view. `?jp=fresher` · `finish` · `error`                                                     |
| `/assessments/career` · `/assessments/career/report`                                    | Career Assessment (Muni’s Balance) and Your Career Drivers. `?ca=new` · `resume` · `final` · `done` · `error`; go offline before “Open my jars” for S3     |
| `/jobs` · `/jobs/matching` · `/jobs/invitations` · `/jobs/bookmarked` · `/jobs/applied` | My Jobs v2. `?jobs=locked` (J8) · `empty` (J16–J19) · `error` (J21) · `slow` (J20)                                                                         |
| `/hire-fest` · `/hire-fest/bookings` · `/hire-fest/past`                                | Hire Fest v2: browse, book 2 employers in 3 steps, QR ticket, bookings, live day, past offers. `?hf=locked` · `none` · `live` · `error`                    |
| `/learn/brain-vita`                                                                     | Module → `/learn/brain-vita/non-verbal-reasoning` (briefs) → `…/quiz`. Correct answers: the second option. `?learn=error`                                  |
| `/learn/digital-basics/digital-workplace-essentials/quiz`                               | The Figma quiz copy (QZ1–QZ5)                                                                                                                              |
| `/quests/who-dis` … `/quests/vibe-check`                                                | Quests 1–8; Vibe Check "Send it" opens the Registered modal                                                                                                |
| `/matches`                                                                              | My Matches (add `?matches=empty` or `?matches=error` for those states)                                                                                     |
| `/programme`                                                                            | Bonus quest. Code **SKM-MUM-26-0417** (IN) / **SKM-JHB-26-0102** (ZA), IFSC **HDFC0000240**                                                                |
| `/claim/psa-15-aarav`                                                                   | Institute claim V1–V5, code **123456**. `/claim/claimed`, `/claim/expired`, `/claim/anything` show the dead-link states                                    |

## Structure

```
src/app/
  core/        app-wide services (theme, api clients, auth, config)
  shared/ui/   design-system components (one per folder, each with spec + story)
  features/    lazy-loaded slices (auth, onboarding, quests, matches, programme, claim, home, arena, learn)
src/mocks/     MSW handlers, one file per feature
src/styles/    generated tokens, typography utilities, media-query mixins
tokens/source/ Figma exports (primitives, semantic, styles) + extensions (motion, layout, z)
tools/tokens/  token build script
docs/          Phase 1 audit and ASSUMPTIONS.md
```

## Components (`src/app/shared/ui`)

Icon · Button · Icon Button · Text Link · Tag · Pill · Checkbox · Switch · Radio group · Chip group ·
Field · Input · OTP · Status Icon · Select (searchable menu) · Banner · Toast (service + host) ·
Segmented Control · Tabs · Progress Bar. Each has a spec and a Storybook story; `npm run test:a11y`
runs axe on every story.

## Token rules

- Components use **semantic** tokens only: `var(--sm-color-…)`, `var(--sm-space-…)`, `var(--sm-font-…)`, `var(--sm-motion-…)`.
- `--sm-ref-*` are primitives — never referenced in components.
- Stylelint blocks hex, `rgb()`, `px`, `ms` and raw values for colour, radius, gap, font, shadow and z-index.
- Breakpoints: `@use 'mq'` → `mq.tablet-up`, `mq.desktop-up`, `mq.below-tablet`.
- Tenants re-brand at runtime with `TenantThemeService.apply()`; alpha tints follow via `color-mix()`.
- Anything not in Figma goes in `docs/ASSUMPTIONS.md` before it is built.
