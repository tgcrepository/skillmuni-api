// @ts-check
const eslint = require('@eslint/js');
const { defineConfig } = require('eslint/config');
const tseslint = require('typescript-eslint');
const angular = require('angular-eslint');
const prettier = require('eslint-config-prettier');

module.exports = defineConfig([
  {
    ignores: [
      'dist/**',
      'storybook-static/**',
      'public/mockServiceWorker.js',
      '.angular/**',
      'src/index.html',
    ],
  },
  {
    files: ['**/*.ts'],
    extends: [
      eslint.configs.recommended,
      tseslint.configs.strict,
      tseslint.configs.stylistic,
      angular.configs.tsRecommended,
      prettier,
    ],
    processor: angular.processInlineTemplates,
    rules: {
      '@angular-eslint/directive-selector': [
        'error',
        { type: 'attribute', prefix: 'sm', style: 'camelCase' },
      ],
      '@angular-eslint/component-selector': [
        'error',
        { type: ['element', 'attribute'], prefix: 'sm', style: 'kebab-case' },
      ],
      '@angular-eslint/no-host-metadata-property': 'off',
      '@angular-eslint/prefer-signals': 'error',
      '@angular-eslint/prefer-output-emitter-ref': 'error',
      '@typescript-eslint/no-explicit-any': 'error',
      // output<void>() is the idiomatic Angular event with no payload.
      '@typescript-eslint/no-invalid-void-type': 'off',
      '@typescript-eslint/no-extraneous-class': ['error', { allowWithDecorator: true }],
      '@typescript-eslint/explicit-member-accessibility': ['error', { accessibility: 'no-public' }],
      'no-console': ['error', { allow: ['error', 'warn'] }],
    },
  },
  {
    files: ['**/*.spec.ts'],
    rules: { '@typescript-eslint/no-non-null-assertion': 'off' },
  },
  {
    files: ['**/*.html'],
    extends: [angular.configs.templateRecommended, angular.configs.templateAccessibility],
    rules: {
      '@angular-eslint/template/prefer-control-flow': 'error',
      // Icon Button gets its accessible name from the required `label` input.
      '@angular-eslint/template/elements-content': ['error', { allowList: ['label'] }],
      '@angular-eslint/template/prefer-self-closing-tags': 'error',
      '@angular-eslint/template/no-inline-styles': ['error', { allowBindToStyle: true }],
      '@angular-eslint/template/i18n': [
        'error',
        { checkId: true, checkText: true, checkAttributes: false, requireDescription: false },
      ],
    },
  },
  {
    // Test hosts, Storybook demos and dev-only routes are fixtures, not shipped UI copy.
    files: ['**/*.spec.ts/*.html', '**/*.stories.ts/*.html', 'src/app/features/dev/**/*.html'],
    rules: {
      '@angular-eslint/template/i18n': 'off',
      '@angular-eslint/template/no-inline-styles': 'off',
    },
  },
]);
