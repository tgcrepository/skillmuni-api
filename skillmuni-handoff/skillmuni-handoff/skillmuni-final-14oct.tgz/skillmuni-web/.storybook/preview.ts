import type { Preview } from '@storybook/angular-vite';
import '@angular/localize/init';
import '@fontsource/poppins/400.css';
import '@fontsource/poppins/500.css';
import '@fontsource/poppins/600.css';
import '@fontsource/poppins/700.css';
import '@fontsource/caveat/700.css';
import '@angular/cdk/overlay-prebuilt.css';
import '../src/styles/tokens/tokens.generated.css';
import '../src/styles/tokens/typography.generated.css';
import '../src/styles.scss';

const preview: Preview = {
  parameters: {
    layout: 'centered',
    backgrounds: { disable: true },
    a11y: { test: 'error' },
    viewport: {
      options: {
        mobile: { name: 'Mobile 390', styles: { width: '390px', height: '844px' } },
        tablet: { name: 'Tablet 834', styles: { width: '834px', height: '1194px' } },
        desktop: { name: 'Desktop 1728', styles: { width: '1728px', height: '1117px' } },
      },
    },
    controls: { matchers: { color: /(background|color)$/i, date: /Date$/i } },
  },
};

export default preview;
