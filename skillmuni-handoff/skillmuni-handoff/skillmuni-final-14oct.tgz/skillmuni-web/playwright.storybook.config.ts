import { defineConfig, devices } from '@playwright/test';

/** Accessibility sweep over every Storybook story. Build Storybook first (npm run build-storybook). */
export default defineConfig({
  testDir: './e2e-storybook',
  fullyParallel: true,
  reporter: [['list']],
  use: {
    baseURL: 'http://localhost:6006',
    ...(process.env['PW_CHROMIUM_PATH']
      ? {
          launchOptions: {
            executablePath: process.env['PW_CHROMIUM_PATH'],
            args: ['--no-sandbox'],
          },
        }
      : {}),
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'npx http-server storybook-static -p 6006 -s',
    url: 'http://localhost:6006',
    reuseExistingServer: !process.env['CI'],
  },
});
