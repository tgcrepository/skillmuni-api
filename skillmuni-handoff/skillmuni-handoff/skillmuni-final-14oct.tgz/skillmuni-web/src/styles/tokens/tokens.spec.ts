import manifest from './tokens.manifest.json';
import semantic from '../../../tokens/source/semantic.json';
import styles from '../../../tokens/source/styles.json';

const slug = (p: string) => p.replace(/\//g, '-').replace(/_/g, '-').toLowerCase();
const has = (token: string) => manifest.tokens.includes(token);

describe('generated design tokens', () => {
  it('includes every Figma Theme, Dimension and Responsive variable', () => {
    const groups = [semantic.Theme, semantic.Dimension, semantic.Responsive] as Record<
      string,
      unknown
    >[];
    const missing = groups
      .flatMap((g) => Object.keys(g))
      .filter((k) => !k.startsWith('$'))
      .map((k) => `--sm-${slug(k)}`)
      .filter((t) => !has(t));
    expect(missing).toEqual([]);
  });

  it('matches the code syntax Figma already emits', () => {
    expect(has('--sm-color-text-primary')).toBe(true);
    expect(has('--sm-space-400')).toBe(true);
  });

  it('has a font composite for every Figma text style', () => {
    const missing = Object.keys(styles.text).filter((k) => !has(`--sm-font-${k}`));
    expect(missing).toEqual([]);
  });

  it('defines motion, focus and layering tokens', () => {
    for (const t of [
      '--sm-motion-duration-micro',
      '--sm-motion-duration-standard',
      '--sm-motion-duration-page',
      '--sm-motion-easing-standard',
      '--sm-shadow-focus-ring-offset',
      '--sm-z-modal',
      '--sm-layout-shell-rail-width',
    ]) {
      expect(has(t)).toBe(true);
    }
  });
});
