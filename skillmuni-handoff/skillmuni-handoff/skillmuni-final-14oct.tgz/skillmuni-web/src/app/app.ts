import { FeedbackCard } from './shared/feedback/feedback-card';
import { XpFxLayer } from './shared/ui/xp-fx/xp-fx-layer';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FullscreenToggle } from './shared/shell/fullscreen-toggle';
import { OfflineBanner } from './shared/shell/offline-banner';
import { ToastHost } from './shared/ui/toast/toast-host';

@Component({
  selector: 'sm-root',
  imports: [RouterOutlet, FullscreenToggle, OfflineBanner, ToastHost, XpFxLayer, FeedbackCard],
  template: `
    <router-outlet />
    <sm-offline-banner />
    <sm-toast-host />
    <sm-fullscreen-toggle />
    <sm-feedback-card />
    <sm-xp-fx-layer />
  `,
  host: { class: 'sm-app' },
})
export class App {}
