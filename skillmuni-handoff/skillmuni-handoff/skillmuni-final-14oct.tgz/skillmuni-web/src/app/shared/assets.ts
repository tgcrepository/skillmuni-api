/**
 * Raster artwork exported from Figma (see public/assets/README.md).
 * Tenants can override the logo at runtime via TenantTheme.logoUrl.
 */
export const ASSETS = {
  muniCharacter: 'assets/muni/muni-character.png',
  muniAvatar: 'assets/muni/muni-avatar.png',
  /** Large face crop (192 px) for circles bigger than 56 (corrections #39). */
  muniFace: 'assets/muni/muni-face.webp',
  /** 3D bulb for quizzes (corrections #20). */
  quizBulb: 'assets/learn/quiz-bulb.webp',
  /** Seesaw poses (A-247): arms crossed in the middle, leaning and pointing to either side. */
  muniPose: {
    center: 'assets/muni/muni-pose-center.webp',
    left: 'assets/muni/muni-pose-lean-left.webp',
    right: 'assets/muni/muni-pose-lean-right.webp',
  },
  /** Reward currencies (A-278): XP = orange thunder, coins = gold coin, credits = graduation cap. */
  currency: {
    xp: 'assets/currency/xp.webp',
    coin: 'assets/currency/coin.webp',
    credit: 'assets/currency/credit.webp',
  },
  logo: 'assets/brand/logo.webp',
  loginBackground: 'assets/brand/login-bg.jpg',
  quest: (n: number) => `assets/quests/quest-${n}.png`,
} as const;
