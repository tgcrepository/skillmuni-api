import { Component, inject, viewChild } from '@angular/core';
import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Button } from '../ui/button/button';
import { Icon } from '../ui/icon/icon';
import { SmDialog } from '../ui/overlay/dialog';

export interface DigiSimData {
  readonly docLabel: string;
}

/**
 * Stand-in for DigiLocker's own consent screen while no DigiLocker partner id is configured
 * (A-272). Deliberately plain and labelled "test mode" — it never imitates DigiLocker's sign-in.
 * In production the learner is sent to DigiLocker, signs in there and approves sharing.
 */
@Component({
  selector: 'sm-digilocker-simulator',
  imports: [Button, Icon, SmDialog],
  template: `
    <sm-dialog [title]="title" [subtitle]="subtitle">
      <p class="lead" i18n="@@digi.simLead">With your OK, Skillmuni receives only:</p>
      <ul class="list">
        <li><sm-icon name="check" size="sm" /><ng-container i18n="@@digi.getName">Your name</ng-container></li>
        <li><sm-icon name="check" size="sm" /><ng-container i18n="@@digi.getDob">Your date of birth</ng-container></li>
        <li>
          <sm-icon name="check" size="sm" />
          <ng-container i18n="@@digi.getLast4">The last 4 characters of your {{ data.docLabel }}</ng-container>
        </li>
        <li class="never">
          <sm-icon name="x" size="sm" />
          <ng-container i18n="@@digi.never">Never the full number or a copy of the document</ng-container>
        </li>
      </ul>
      <div smDialogActions class="actions">
        <button sm-button variant="secondary" type="button" (click)="dialog().close()" i18n="@@ui.cancel">
          Cancel
        </button>
        <button sm-button type="button" (click)="dialog().close('test-ok')" i18n="@@digi.simApprove">
          Approve (test)
        </button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .lead {
      margin: 0 0 var(--sm-space-300);
      color: var(--sm-color-text-body);
      font: var(--sm-font-body-sm);
    }

    .list {
      display: grid;
      gap: var(--sm-space-200);
      margin: 0;
      padding: 0;
      list-style: none;

      li {
        display: flex;
        align-items: center;
        gap: var(--sm-space-200);
        color: var(--sm-color-text-heading);
        font: var(--sm-font-body-sm-semibold);
      }

      sm-icon {
        flex: none;
        color: var(--sm-color-feedback-success-icon);
      }

      .never sm-icon {
        color: var(--sm-color-feedback-error-text);
      }
    }

    .actions {
      display: flex;
      flex-wrap: wrap;
      justify-content: flex-end;
      gap: var(--sm-space-300);
    }
  `,
})
export class DigiLockerSimulator {
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly data = inject<DigiSimData>(DIALOG_DATA);
  protected readonly title = $localize`:@@digi.simTitle:Share your ID from DigiLocker`;
  protected readonly subtitle = $localize`:@@digi.simSub:Test mode: DigiLocker isn’t connected for this workspace yet. In the live app you sign in on DigiLocker and approve there.`;
}
