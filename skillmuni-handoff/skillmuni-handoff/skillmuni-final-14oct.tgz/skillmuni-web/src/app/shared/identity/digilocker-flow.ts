import { DOCUMENT } from '@angular/common';
import { Service, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { DigiDoc, IDENTITY_API, LinkedId } from '../../core/identity/identity.api';
import { OverlayService } from '../ui/overlay/overlay.service';
import { DigiLockerSimulator, DigiSimData } from './digilocker-simulator';

/**
 * Link a government ID through DigiLocker (A-272). Live: the server returns DigiLocker's consent
 * URL and the learner approves on DigiLocker; the callback completes the link server-side.
 * Without a partner id (dev, demos) a clearly labelled test dialog stands in.
 */
@Service()
export class DigiLockerFlow {
  private readonly api = inject(IDENTITY_API);
  private readonly overlay = inject(OverlayService);
  private readonly doc = inject(DOCUMENT);

  /** Resolves the masked record, or null if the learner cancelled (or left for DigiLocker). */
  async link(doc: DigiDoc, docLabel: string): Promise<LinkedId | null> {
    if (!environment.digilockerClientId) {
      const ref = this.overlay.adaptive<DigiLockerSimulator, DigiSimData, string>(
        DigiLockerSimulator,
        { data: { docLabel }, size: 'sm' },
      );
      const code = await firstValueFrom(ref.closed);
      if (!code) return null;
      return firstValueFrom(this.api.link(doc, code));
    }
    const { authorizeUrl } = await firstValueFrom(this.api.start(doc));
    this.doc.defaultView?.location.assign(authorizeUrl);
    return null;
  }

  unlink(): Promise<void> {
    return firstValueFrom(this.api.unlink());
  }
}
