import {
  Component,
  ElementRef,
  PLATFORM_ID,
  computed,
  effect,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { NgOptimizedImage, isPlatformBrowser } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { Viewport } from '../../core/layout/viewport';
import { MuniSuggestion, MuniTopic } from '../../core/muni/muni.api';
import { ASSETS } from '../assets';
import { Icon } from '../ui/icon/icon';
import { MuniAvatar } from '../ui/muni/muni-avatar';
import { ToastService } from '../ui/toast/toast.service';
import { ChatMessage, MuniChat } from './muni-chat.service';
import { Typewriter } from '../ui/muni/typewriter';
import { Currency } from '../ui/currency/currency';

interface Shortcut {
  readonly cmd: string;
  readonly ask: string;
}

interface SpeechRecognitionLike {
  lang: string;
  interimResults: boolean;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
}

/**
 * Muni chat drawer (Figma D1 180:5917 welcome · D2 181:6025 conversation · M1/M2 mobile).
 * Rich cards, short bubbles, ≤ 3 follow-up chips, typing state, timestamps, 👍 👎 copy, history,
 * attach CV, voice (when the browser supports it) and "/" shortcuts. Private profile fields stay masked
 * until the eye is tapped (re-fetched from the server, never kept in history).
 */
@Component({
  selector: 'sm-muni-chat-panel',
  imports: [Currency, Icon, MuniAvatar, NgOptimizedImage, RouterLink, Typewriter],
  templateUrl: './muni-chat-panel.html',
  styleUrl: './muni-chat-panel.scss',
  host: { class: 'sm-muni-chat', '[class.is-mobile]': 'viewport.isMobile()' },
})
export class MuniChatPanel {
  protected readonly chat = inject(MuniChat);
  protected readonly viewport = inject(Viewport);
  private readonly router = inject(Router);
  private readonly toast = inject(ToastService);
  private readonly browser = isPlatformBrowser(inject(PLATFORM_ID));

  protected readonly character = ASSETS.muniCharacter;
  protected readonly expandLabel = $localize`:@@muni.expand:Expand chat`;
  protected readonly shrinkLabel = $localize`:@@muni.shrink:Shrink chat`;
  protected readonly showLabel = $localize`:@@muni.show:Show`;
  protected readonly hideLabel = $localize`:@@muni.hide:Hide`;
  protected readonly draft = signal('');
  protected readonly revealed = signal<Readonly<Record<string, string>>>({});
  protected readonly listening = signal(false);
  private readonly log = viewChild<ElementRef<HTMLElement>>('log');
  private readonly input = viewChild<ElementRef<HTMLTextAreaElement>>('input');
  private recognition: SpeechRecognitionLike | null = null;

  protected readonly canListen =
    this.browser &&
    typeof window !== 'undefined' &&
    ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window);

  protected readonly shortcuts: readonly Shortcut[] = [
    { cmd: '/jobs', ask: 'Jobs for me' },
    { cmd: '/learn', ask: 'Continue my quest' },
    { cmd: '/rank', ask: 'My XP & rank' },
    { cmd: '/profile', ask: 'Show my profile' },
    { cmd: '/archetype', ask: 'My career archetype' },
  ];
  protected readonly matches = computed(() => {
    const d = this.draft();
    return d.startsWith('/')
      ? this.shortcuts.filter((s) => s.cmd.startsWith(d.split(' ')[0] ?? ''))
      : [];
  });

  protected readonly started = computed(() => this.chat.messages().length > 0);
  protected readonly todayLabel = computed(() => {
    const first = this.chat.messages()[0];
    return first ? $localize`:@@muni.today:Today · ${first.time}:time:` : '';
  });

  constructor() {
    // Keep the newest message in view.
    effect(() => {
      this.chat.messages();
      this.chat.typing();
      const el = this.log()?.nativeElement;
      if (el) queueMicrotask(() => el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' }));
    });
  }

  protected send(): void {
    const text = this.draft().trim();
    if (!text) return;
    const shortcut = this.matches()[0];
    this.draft.set('');
    void this.chat.ask(shortcut ? shortcut.ask : text);
  }

  protected onKey(e: KeyboardEvent): void {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      this.send();
    }
  }

  protected useShortcut(s: Shortcut): void {
    this.draft.set('');
    void this.chat.ask(s.ask);
    this.input()?.nativeElement.focus();
  }

  protected pickTopic(t: MuniTopic): void {
    void this.chat.ask(t.label, t.id);
  }

  protected act(s: MuniSuggestion): void {
    if (s.link) {
      this.go(s.link);
      return;
    }
    void this.chat.ask(s.intent ?? s.title);
  }

  protected go(url: string): void {
    this.chat.close();
    void this.router.navigateByUrl(url);
  }

  protected async peek(field: 'email' | 'mobile'): Promise<void> {
    if (this.revealed()[field]) {
      this.revealed.update((r) => ({ ...r, [field]: '' }));
      return;
    }
    try {
      const value = await this.chat.reveal(field);
      this.revealed.update((r) => ({ ...r, [field]: value }));
    } catch {
      this.toast.show($localize`:@@muni.revealFail:Couldn’t show that right now.`, {
        tone: 'error',
      });
    }
  }

  protected meText(m: ChatMessage): string {
    const b = m.blocks[0];
    return b?.kind === 'text' ? b.text : '';
  }

  protected fieldValue(key: string, masked: string): string {
    return this.revealed()[key] || masked;
  }

  protected async copy(m: ChatMessage): Promise<void> {
    const text = m.blocks
      .map((b) => (b.kind === 'text' ? b.text : ''))
      .filter(Boolean)
      .join('\n');
    try {
      await navigator.clipboard.writeText(text);
      this.toast.show($localize`:@@muni.copied:Copied`);
    } catch {
      this.toast.show($localize`:@@muni.copyFail:Couldn’t copy that.`, { tone: 'error' });
    }
  }

  protected attach(e: Event): void {
    const file = (e.target as HTMLInputElement).files?.[0];
    (e.target as HTMLInputElement).value = '';
    if (!file) return;
    void this.chat.ask(`📎 ${file.name}`, 'cv');
  }

  protected toggleVoice(): void {
    if (!this.canListen) return;
    if (this.listening()) {
      this.recognition?.stop();
      return;
    }
    const w = window as unknown as Record<string, new () => SpeechRecognitionLike>;
    const Ctor = w['SpeechRecognition'] ?? w['webkitSpeechRecognition'];
    if (!Ctor) return;
    const r = new Ctor();
    r.lang = document.documentElement.lang || 'en-IN';
    r.interimResults = false;
    r.onresult = (ev) => {
      const said = ev.results[0]?.[0]?.transcript ?? '';
      this.draft.set(said);
    };
    r.onend = () => this.listening.set(false);
    this.recognition = r;
    this.listening.set(true);
    r.start();
  }
}
