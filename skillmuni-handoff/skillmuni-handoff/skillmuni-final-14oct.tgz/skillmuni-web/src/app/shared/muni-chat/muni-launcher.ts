import { Component, OnInit, computed, inject } from '@angular/core';
import { MuniAvatar } from '../ui/muni/muni-avatar';
import { MuniChat } from './muni-chat.service';

/**
 * Muni chat entry in the top bar, next to the profile button (A-235; was the Figma D0 182:6251
 * floating launcher). Unread badge on the button; the once-per-session proactive nudge arrives as a
 * toast with an "Ask Muni" action, so it never covers page buttons under the bar (A-256).
 * Opens the chat drawer; focus comes back here when it closes.
 */
@Component({
  selector: 'sm-muni-launcher',
  imports: [MuniAvatar],
  template: `
    <button
      type="button"
      class="launcher"
      [attr.aria-label]="label()"
      aria-haspopup="dialog"
      [attr.aria-expanded]="chat.isOpen()"
      (click)="chat.open()"
    >
      <sm-muni-avatar [size]="40" />
      @if (chat.unread()) {
        <span class="badge" aria-hidden="true">{{ chat.unread() }}</span>
      }
    </button>

  `,
  styleUrl: './muni-launcher.scss',
  host: { class: 'sm-muni-launcher' },
})
export class MuniLauncher implements OnInit {
  protected readonly chat = inject(MuniChat);

  protected readonly label = computed(() =>
    this.chat.unread()
      ? $localize`:@@muni.launcherUnread:Chat with Muni, ${this.chat.unread()}:n: new`
      : $localize`:@@muni.launcher:Chat with Muni`,
  );


  ngOnInit(): void {
    void this.chat.init();
  }
}
