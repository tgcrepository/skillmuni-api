import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { Subject, of, throwError } from 'rxjs';
import { MUNI_API, MuniApi, MuniReply } from '../../core/muni/muni.api';
import { MuniChat } from './muni-chat.service';

const reply = (chips: string[]): MuniReply => ({
  blocks: [{ kind: 'text', text: 'hi' }],
  chips,
});

function setup(ask: MuniApi['ask'], url = '/home') {
  sessionStorage.clear();
  const api: MuniApi = {
    welcome: () =>
      of({
        firstName: 'Yash',
        intro: '',
        suggestions: [],
        topics: [],
        unread: 2,
        nudge: { title: 'n', body: 'b' },
      }),
    ask,
    reveal: () => of({ value: 'real@x.com' }),
    rate: vi.fn(() => of(undefined)),
    history: () => of([]),
  };
  TestBed.configureTestingModule({
    providers: [
      { provide: MUNI_API, useValue: api },
      { provide: Router, useValue: { url, events: new Subject<unknown>() } },
    ],
  });
  return { chat: TestBed.inject(MuniChat), api };
}

describe('MuniChat', () => {
  it('shows the nudge once per session', async () => {
    const { chat } = setup(() => of(reply([])));
    await chat.init();
    expect(chat.nudge()?.title).toBe('n');
    expect(chat.unread()).toBe(2);
    expect(sessionStorage.getItem('sm_muni_nudged')).toBe('1');
  });

  it('keeps the nudge for the Lobby only', async () => {
    sessionStorage.removeItem('sm_muni_nudged');
    const { chat } = setup(() => of(reply([])), '/arena');
    await chat.init();
    expect(chat.nudge()).toBeNull();
  });

  it('caps chips at 3 and clears earlier chips once the user moves on', async () => {
    const { chat } = setup(() => of(reply(['a', 'b', 'c', 'd'])));
    await chat.ask('hello');
    expect(chat.messages().map((m) => m.from)).toEqual(['me', 'muni']);
    expect(chat.messages()[1]?.chips).toEqual(['a', 'b', 'c']);

    await chat.ask('a');
    const muni = chat.messages().filter((m) => m.from === 'muni');
    expect(muni[0]?.chips).toEqual([]);
    expect(muni[1]?.chips).toEqual(['a', 'b', 'c']);
  });

  it('ignores empty input', async () => {
    const ask = vi.fn(() => of(reply([])));
    const { chat } = setup(ask);
    await chat.ask('   ');
    expect(ask).not.toHaveBeenCalled();
    expect(chat.messages()).toEqual([]);
  });

  it('shows a retryable failure and retries without repeating the user bubble', async () => {
    let fail = true;
    const { chat } = setup(() => (fail ? throwError(() => new Error('503')) : of(reply([]))));
    await chat.ask('jobs');
    const failed = chat.messages()[1];
    expect(failed?.failed).toBe('jobs');
    expect(chat.typing()).toBe(false);

    fail = false;
    if (failed) chat.retry(failed);
    await vi.waitFor(() => expect(chat.messages().length).toBe(2));
    expect(chat.messages().map((m) => m.from)).toEqual(['me', 'muni']);
    expect(chat.messages()[1]?.failed).toBeUndefined();
  });

  it('toggles ratings and asks the server for masked values', async () => {
    const { chat, api } = setup(() => of(reply([])));
    await chat.ask('hi');
    const m = chat.messages()[1];
    if (!m) throw new Error('no reply');
    chat.rate(m, true);
    expect(chat.messages()[1]?.rating).toBe(true);
    const rated = chat.messages()[1];
    if (rated) chat.rate(rated, true);
    expect(chat.messages()[1]?.rating).toBeNull();
    expect(api.rate).toHaveBeenLastCalledWith(m.id, null);
    expect(await chat.reveal('email')).toBe('real@x.com');
  });
});
