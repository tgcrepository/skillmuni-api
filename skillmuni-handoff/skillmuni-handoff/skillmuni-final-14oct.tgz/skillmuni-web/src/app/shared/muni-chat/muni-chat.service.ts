import { NavigationStart, Router } from '@angular/router';
import { Dialog } from '@angular/cdk/dialog';
import { Overlay } from '@angular/cdk/overlay';
import { Service, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { Viewport } from '../../core/layout/viewport';
import { ToastService } from '../ui/toast/toast.service';
import { MUNI_API, MuniBlock, MuniHistoryItem, MuniWelcome } from '../../core/muni/muni.api';

export interface ChatMessage {
  readonly id: string;
  readonly from: 'me' | 'muni';
  readonly blocks: readonly MuniBlock[];
  readonly chips: readonly string[];
  /** "7:06 pm" */
  readonly time: string;
  readonly rating: boolean | null;
  /** Failed send: the text to retry. */
  readonly failed?: string;
}

const NUDGE_MS = 6000;
const NUDGE_KEY = 'sm_muni_nudged';

let seq = 0;
const nextId = () => `m${++seq}`;

function clock(): string {
  return new Date()
    .toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
    .toLowerCase();
}

/**
 * Muni chat state (Figma Muni Chat v2 179:5915) shared by the launcher and the drawer.
 * Desktop/tablet: 440 px drawer with a light scrim (expandable). Mobile: full screen.
 * Esc closes and focus returns to the launcher (CDK Dialog restoreFocus).
 */
@Service()
export class MuniChat {
  private readonly api = inject(MUNI_API);
  private readonly dialog = inject(Dialog);
  private readonly overlay = inject(Overlay);
  private readonly viewport = inject(Viewport);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);

  readonly welcome = signal<MuniWelcome | null>(null);
  readonly messages = signal<readonly ChatMessage[]>([]);
  readonly typing = signal(false);
  readonly expanded = signal(false);
  readonly view = signal<'chat' | 'history'>('chat');
  readonly history = signal<readonly MuniHistoryItem[] | null>(null);
  readonly unread = signal(0);
  readonly nudge = signal<{ title: string; body: string } | null>(null);
  readonly isOpen = signal(false);

  private ref: {
    close(): void;
    addPanelClass(c: string): unknown;
    removePanelClass(c: string): unknown;
  } | null = null;
  private nudgeTimer: ReturnType<typeof setTimeout> | undefined;
  private loaded = false;

  /**
   * Loads the welcome once. The proactive nudge shows once per session for 6 s, and only on the
   * Lobby, where it's relevant — never over another screen's title or main button (corrections sweep).
   */
  async init(): Promise<void> {
    if (!this.loaded) {
      this.loaded = true;
      try {
        const w = await firstValueFrom(this.api.welcome());
        this.welcome.set(w);
        this.unread.set(w.unread);
      } catch {
        this.loaded = false;
        return;
      }
    }
    this.tryNudge();
  }

  private tryNudge(): void {
    const w = this.welcome();
    if (!w?.nudge || this.nudgedThisSession()) return;
    if (!this.router.url.split(/[?#]/)[0]?.startsWith('/home')) return;
    this.nudge.set(w.nudge);
    this.markNudged();
    this.nudgeTimer = setTimeout(() => this.nudge.set(null), NUDGE_MS);
    // Raised here, once, not by each launcher instance: shells re-create on navigation (A-288).
    const id = this.toast.show(`${w.nudge.title} · ${w.nudge.body}`, {
      tone: 'success',
      duration: NUDGE_MS,
      action: { label: $localize`:@@muni.nudgeOpen:Ask Muni`, run: () => void this.open() },
    });
    // The nudge belongs to the Lobby: leaving it takes the toast away so it never covers another screen.
    const sub = this.router.events.subscribe((e) => {
      if (!(e instanceof NavigationStart)) return;
      sub.unsubscribe();
      this.toast.dismiss(id);
      clearTimeout(this.nudgeTimer);
      this.nudge.set(null);
    });
    setTimeout(() => sub.unsubscribe(), NUDGE_MS);
  }

  async open(): Promise<void> {
    if (this.ref) return;
    clearTimeout(this.nudgeTimer);
    this.nudge.set(null);
    this.unread.set(0);
    const { MuniChatPanel } = await import('./muni-chat-panel');
    const mobile = this.viewport.isMobile();
    const ref = this.dialog.open(MuniChatPanel, {
      ariaLabelledBy: 'muni-title',
      ariaModal: true,
      autoFocus: 'textarea',
      restoreFocus: true,
      hasBackdrop: true,
      backdropClass: 'sm-muni-scrim',
      panelClass: ['sm-muni-pane', mobile ? 'is-full' : 'is-drawer'],
      positionStrategy: this.overlay.position().global().end('0').top('0'),
      width: mobile ? '100vw' : undefined,
      height: '100dvh',
      maxWidth: '100vw',
    });
    this.ref = ref;
    this.isOpen.set(true);
    ref.backdropClick.subscribe(() => this.close());
    ref.closed.subscribe(() => {
      this.ref = null;
      this.isOpen.set(false);
      this.expanded.set(false);
      this.view.set('chat');
    });
    void this.init();
  }

  close(): void {
    this.ref?.close();
  }

  toggleExpanded(): void {
    const next = !this.expanded();
    this.expanded.set(next);
    if (next) this.ref?.addPanelClass('is-expanded');
    else this.ref?.removePanelClass('is-expanded');
  }

  async showHistory(): Promise<void> {
    this.view.set(this.view() === 'history' ? 'chat' : 'history');
    if (this.view() === 'history' && !this.history()) {
      try {
        this.history.set(await firstValueFrom(this.api.history()));
      } catch {
        this.history.set([]);
      }
    }
  }

  /** Re-open a past chat as read-only bubbles above a fresh conversation. */
  restore(item: MuniHistoryItem): void {
    this.messages.set(
      item.messages.map((m) => ({
        id: nextId(),
        from: m.from,
        blocks: [{ kind: 'text', text: m.text }],
        chips: [],
        time: item.when,
        rating: null,
      })),
    );
    this.view.set('chat');
  }

  async ask(text: string, intent?: string, resend = false): Promise<void> {
    const clean = text.trim();
    if (!clean || this.typing()) return;
    this.view.set('chat');
    if (resend) return this.reply(clean, intent);
    // Chips are answered once: clear them from earlier Muni messages so no dead buttons stay behind.
    this.messages.update((list) => [
      ...list.map((m) => (m.chips.length ? { ...m, chips: [] } : m)),
      {
        id: nextId(),
        from: 'me',
        blocks: [{ kind: 'text', text: clean }],
        chips: [],
        time: clock(),
        rating: null,
      },
    ]);
    return this.reply(clean, intent);
  }

  private async reply(clean: string, intent?: string): Promise<void> {
    this.typing.set(true);
    try {
      const r = await firstValueFrom(
        this.api.ask(intent ? { text: clean, intent } : { text: clean }),
      );
      this.messages.update((list) => [
        ...list,
        {
          id: nextId(),
          from: 'muni',
          blocks: r.blocks,
          chips: r.chips.slice(0, 3),
          time: clock(),
          rating: null,
        },
      ]);
    } catch {
      this.messages.update((list) => [
        ...list,
        {
          id: nextId(),
          from: 'muni',
          blocks: [
            {
              kind: 'text',
              text: $localize`:@@muni.failed:Oops, I lost my train of thought. Try that again?`,
            },
          ],
          chips: [],
          time: clock(),
          rating: null,
          failed: clean,
        },
      ]);
    } finally {
      this.typing.set(false);
    }
  }

  retry(m: ChatMessage): void {
    if (!m.failed) return;
    // The user's bubble is already there; only the failed reply goes.
    this.messages.update((list) => list.filter((x) => x.id !== m.id));
    void this.ask(m.failed, undefined, true);
  }

  rate(m: ChatMessage, helpful: boolean): void {
    const value = m.rating === helpful ? null : helpful;
    this.messages.update((list) => list.map((x) => (x.id === m.id ? { ...x, rating: value } : x)));
    this.api.rate(m.id, value).subscribe({ error: () => undefined });
  }

  reveal(field: 'email' | 'mobile'): Promise<string> {
    return firstValueFrom(this.api.reveal(field)).then((r) => r.value);
  }

  private nudgedThisSession(): boolean {
    try {
      return sessionStorage.getItem(NUDGE_KEY) === '1';
    } catch {
      return false;
    }
  }

  private markNudged(): void {
    try {
      sessionStorage.setItem(NUDGE_KEY, '1');
    } catch {
      /* private mode */
    }
  }
}
