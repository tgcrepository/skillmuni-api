import { Component, ElementRef, computed, effect, inject, signal, viewChild } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { FEEDBACK_API, FeedbackMood } from '../../core/feedback/feedback.api';
import { FeedbackPrompt } from '../../core/feedback/feedback-prompt';
import { Viewport } from '../../core/layout/viewport';
import { Button } from '../ui/button/button';
import { ChipGroup, ChipOption } from '../ui/chip/chip-group';
import { Icon } from '../ui/icon/icon';
import { XpFx } from '../ui/xp-fx/xp-fx';

interface Mood {
  readonly value: FeedbackMood;
  readonly emoji: string;
  readonly label: string;
}

/**
 * "How's Skillmuni treating you?" (A-274). A small non-modal card in the corner (above the tabs on
 * phones): it never blocks the screen or steals focus. Mood → what stood out → optional note →
 * thank-you with +5 XP (once a month). When it shows is decided by FeedbackPrompt.
 */
@Component({
  selector: 'sm-feedback-card',
  imports: [Button, ChipGroup, Icon],
  template: `
    @if (prompt.open()) {
      <section
        class="card"
        [class.card--tabs]="viewport.isMobile()"
        role="dialog"
        aria-modal="false"
        aria-labelledby="fb-title"
        animate.enter="card-in"
        animate.leave="card-out"
        (keydown.escape)="dismiss()"
      >
        <button type="button" class="x" [attr.aria-label]="closeLabel" (click)="dismiss()">
          <sm-icon name="x" size="sm" />
        </button>
        @if (!done()) {
          <h2 class="title" id="fb-title" i18n="@@fb.title">How’s Skillmuni treating you?</h2>
          <div class="moods" role="group" [attr.aria-label]="moodGroup">
            @for (m of moods; track m.value) {
              <button
                type="button"
                class="mood"
                [class.is-on]="mood() === m.value"
                [attr.aria-pressed]="mood() === m.value"
                [attr.aria-label]="m.label"
                [attr.title]="m.label"
                (click)="pick(m.value)"
              >
                <span aria-hidden="true">{{ m.emoji }}</span>
              </button>
            }
          </div>
          @if (mood(); as m) {
            <div class="more" animate.enter="more-in">
              <p class="label" id="fb-tags" i18n="@@fb.stoodOut">What stood out?</p>
              <sm-chip-group
                [multiple]="true"
                order="given"
                labelledBy="fb-tags"
                [options]="m >= 4 ? goodTags : badTags"
                [value]="tags()"
                (valueChange)="tags.set($any($event) ?? [])"
              />
              <label class="label" for="fb-note" i18n="@@fb.note">Anything else? (optional)</label>
              <textarea
                #note
                id="fb-note"
                class="note"
                rows="2"
                maxlength="500"
                [value]="comment()"
                (input)="comment.set($any($event.target).value)"
              ></textarea>
              <div class="actions">
                <span class="xp" i18n="@@fb.xp">+5 XP · once a month</span>
                <button sm-button type="button" [loading]="busy()" (click)="send($event)" i18n="@@fb.send">
                  Send
                </button>
              </div>
            </div>
          }
        } @else {
          <div class="thanks" role="status">
            <span class="big" aria-hidden="true">💜</span>
            <h2 class="title" id="fb-title" i18n="@@fb.thanks">Thanks, that really helps!</h2>
            <p class="sub">
              @if (earned()) {
                <ng-container i18n="@@fb.thanksXp">+{{ earned() }} XP added. We’ll check in again in a month.</ng-container>
              } @else {
                <ng-container i18n="@@fb.thanksNoXp">Got it. We’ll check in again in a month.</ng-container>
              }
            </p>
          </div>
        }
      </section>
    }
  `,
  styleUrl: './feedback-card.scss',
})
export class FeedbackCard {
  protected readonly prompt = inject(FeedbackPrompt);
  protected readonly viewport = inject(Viewport);
  private readonly api = inject(FEEDBACK_API);
  private readonly router = inject(Router);
  private readonly xpFx = inject(XpFx);
  private readonly noteEl = viewChild<ElementRef<HTMLTextAreaElement>>('note');

  protected readonly mood = signal<FeedbackMood | null>(null);
  protected readonly tags = signal<string[]>([]);
  protected readonly comment = signal('');
  protected readonly busy = signal(false);
  protected readonly done = signal(false);
  protected readonly earned = signal(0);

  protected readonly closeLabel = $localize`:@@fb.close:Close feedback`;
  protected readonly moodGroup = $localize`:@@fb.moodGroup:Your mood`;
  protected readonly moods: readonly Mood[] = [
    { value: 1, emoji: '😫', label: $localize`:@@fb.m1:Not great` },
    { value: 2, emoji: '😕', label: $localize`:@@fb.m2:Meh` },
    { value: 3, emoji: '😐', label: $localize`:@@fb.m3:Okay` },
    { value: 4, emoji: '🙂', label: $localize`:@@fb.m4:Good` },
    { value: 5, emoji: '🤩', label: $localize`:@@fb.m5:Loving it` },
  ];
  protected readonly goodTags: readonly ChipOption[] = [
    { value: 'learning', label: $localize`:@@fb.tLearning:Learning briefs` },
    { value: 'xp', label: $localize`:@@fb.tXp:XP and badges` },
    { value: 'jobs', label: $localize`:@@fb.tJobs:Job matches` },
    { value: 'muni', label: $localize`:@@fb.tMuni:Muni` },
    { value: 'easy', label: $localize`:@@fb.tEasy:Easy to use` },
  ];
  protected readonly badTags: readonly ChipOption[] = [
    { value: 'slow', label: $localize`:@@fb.tSlow:Slow or buggy` },
    { value: 'confusing', label: $localize`:@@fb.tConfusing:Hard to find things` },
    { value: 'content', label: $localize`:@@fb.tContent:Content` },
    { value: 'jobs-few', label: $localize`:@@fb.tJobsFew:Not enough jobs` },
    { value: 'other', label: $localize`:@@fb.tOther:Something else` },
  ];
  private readonly wasOpen = computed(() => this.prompt.open());

  constructor() {
    // A fresh card every time it opens.
    effect(() => {
      if (this.wasOpen()) {
        this.mood.set(null);
        this.tags.set([]);
        this.comment.set('');
        this.done.set(false);
        this.earned.set(0);
      }
    });
  }

  protected pick(m: FeedbackMood): void {
    const prev = this.mood();
    if (prev && prev >= 4 !== m >= 4) this.tags.set([]);
    this.mood.set(m);
  }

  protected dismiss(): void {
    if (this.done()) this.prompt.close();
    else this.prompt.dismissed();
  }

  protected async send(event: Event): Promise<void> {
    const mood = this.mood();
    if (!mood || this.busy()) return;
    const origin = event.currentTarget as HTMLElement | null;
    this.busy.set(true);
    try {
      const { xp } = await firstValueFrom(
        this.api.send({
          mood,
          tags: this.tags(),
          comment: this.comment().trim(),
          screen: this.router.url.split(/[?#]/)[0] ?? '',
        }),
      );
      this.earned.set(xp);
      this.prompt.submitted();
      this.done.set(true);
      if (xp) this.xpFx.burst(xp, origin, { announce: false });
      setTimeout(() => this.prompt.close(), 3200);
    } catch {
      this.noteEl()?.nativeElement.focus();
    } finally {
      this.busy.set(false);
    }
  }
}
