import { Component } from '@angular/core';

/** Figma: App Shell → Brand Tagline (32:52). "Learn. Do. Belong." in Caveat with the Ember swoosh. */
@Component({
  selector: 'sm-brand-tagline',
  template: `
    <p class="text" i18n="@@brand.tagline">Learn.&nbsp; Do.&nbsp; Belong.</p>
    <svg class="swoosh" viewBox="-2 -2 99 14" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="sm-swoosh" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" class="stop-1" />
          <stop offset="1" class="stop-2" />
        </linearGradient>
      </defs>
      <path d="M 0 9.74 C 28.5 0.74 66.5 -2.26 95 1.74" stroke="url(#sm-swoosh)" />
    </svg>
  `,
  styleUrl: './brand-tagline.scss',
  host: { class: 'sm-brand-tagline' },
})
export class BrandTagline {}
