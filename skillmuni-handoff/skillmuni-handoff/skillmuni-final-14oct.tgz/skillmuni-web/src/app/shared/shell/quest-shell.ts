import { MARK_NEEDED } from '../ui/field/field-context';
import { DialogRef } from '@angular/cdk/dialog';
import { NgTemplateOutlet } from '@angular/common';
import { Component, TemplateRef, computed, inject, input, output, viewChild } from '@angular/core';
import { Viewport } from '../../core/layout/viewport';
import { questById } from '../../core/quests/quest-catalog';
import { MuniAvatar } from '../ui/muni/muni-avatar';
import { MuniCharacter } from '../ui/muni/muni-character';
import { MuniTip } from '../ui/muni/muni-tip';
import { SpeechBubble } from '../ui/muni/speech-bubble';
import { SmDialog } from '../ui/overlay/dialog';
import { OverlayService, requestClose } from '../ui/overlay/overlay.service';
import { LootDropCard } from '../ui/quest/loot-drop-card';
import { QuestMap, QuestMapVariant, QuestProgress } from '../ui/quest/quest-map';
import { AppHeader, HudState } from './app-header';
import { BrandTagline } from './brand-tagline';
import { PageBackground } from './page-background';

export interface QuestLoot {
  readonly badge: string;
  /** Long form for the desktop rail, e.g. "+50 XP, and the Hit Me Up quest unlocks". */
  readonly reward: string;
  /** Short form for compact cards, e.g. "+50 XP · unlocks Hit Me Up". */
  readonly rewardShort: string;
  /** 0–100 */
  readonly progress: number;
}

/**
 * The quest-flow page frame. Figma: Q1 desktop (200:11572), tablet (200:12629), mobile (200:13165).
 *
 * Desktop ≥ 1280: header · [quest map rail | quest card | loot card + Muni bubble + Muni] · tagline / powered-by.
 * Tablet: header · lineup strip · Muni row (Muni, bubble, compact loot) · card with pinned bottom bar.
 * Mobile: header with back · compact lineup + "See all" (full map in a sheet) · Muni tip · card · compact loot.
 *
 * Project the Quest Card as content. Landmarks: banner, navigation (map), main, complementary (rail), contentinfo.
 */
@Component({
  providers: [{ provide: MARK_NEEDED, useValue: true }],
  selector: 'sm-quest-shell',
  imports: [
    AppHeader,
    PageBackground,
    BrandTagline,
    QuestMap,
    LootDropCard,
    SpeechBubble,
    MuniAvatar,
    MuniCharacter,
    MuniTip,
    SmDialog,
    NgTemplateOutlet,
  ],
  templateUrl: './quest-shell.html',
  styleUrl: './quest-shell.scss',
  host: {
    class: 'sm-quest-shell',
    '[attr.data-size]': 'viewport.size()',
    '[class.is-bonus]': '!showMap()',
  },
})
export class QuestShell {
  protected readonly viewport = inject(Viewport);
  private readonly overlay = inject(OverlayService);

  readonly quest = input.required<number>();
  readonly progress = input.required<QuestProgress>();
  readonly hud = input<HudState | null>(null);
  /** Autosave status for the header (A-241). */
  readonly saveState = input<'idle' | 'saving' | 'saved'>('idle');
  /** "Save & back to Job Profile" when a quest was opened to edit (A-252); default "Save & exit". */
  readonly exitLabel = input('');
  readonly loot = input.required<QuestLoot>();
  /** What Muni says right now (bubble on desktop/tablet, tip on mobile). */
  readonly muni = input.required<string>();
  /** Caveat exclamation for celebrate moments, e.g. "Slay, Yash!" */
  readonly muniExclamation = input('');
  /**
   * Replaces the loot card (e.g. Q4's live Player Card, Figma 200:24911). Rendered in the desktop rail, and
   * after the quest card on tablet / mobile.
   */
  readonly reward = input<TemplateRef<unknown> | null>(null);
  /** Bonus quests (programme code, Figma P1–P5) have no quest lineup: card + rail only. */
  readonly showMap = input(true);
  /** Header override for screens outside the 8 quests (e.g. the Programme bonus quest). */
  readonly heading = input('');
  readonly headingSub = input('');

  readonly back = output<void>();
  readonly exit = output<void>();
  readonly openQuest = output<number>();

  private readonly mapSheet = viewChild.required<TemplateRef<unknown>>('mapSheet');
  private sheetRef: DialogRef<unknown, unknown> | null = null;

  protected readonly meta = computed(() => questById(this.quest()));
  protected readonly title = computed(() => this.heading() || (this.meta()?.name ?? ''));
  protected readonly subtitle = computed(
    () =>
      this.headingSub() ||
      (this.heading() ? '' : $localize`:@@shell.questOf:Quest ${this.quest()}:n: of ${8}:total:`),
  );
  protected readonly mapVariant = computed<QuestMapVariant>(() => {
    const size = this.viewport.size();
    return size === 'desktop' ? 'rail' : size === 'tablet' ? 'strip' : 'compact';
  });

  protected openMap(): void {
    this.sheetRef = this.overlay.sheet(this.mapSheet(), {
      ariaLabel: $localize`:@@shell.allQuests:All quests`,
    });
    this.sheetRef.closed.subscribe(() => (this.sheetRef = null));
  }

  protected choose(id: number): void {
    if (this.sheetRef) requestClose(this.sheetRef);
    this.openQuest.emit(id);
  }
}
