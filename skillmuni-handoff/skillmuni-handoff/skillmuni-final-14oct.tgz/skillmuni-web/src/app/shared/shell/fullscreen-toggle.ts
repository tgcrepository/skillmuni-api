import { DOCUMENT } from '@angular/common';
import { Component, DestroyRef, ElementRef, computed, inject, signal } from '@angular/core';
import { Viewport } from '../../core/layout/viewport';
import { Icon } from '../ui/icon/icon';

/**
 * Full-screen toggle, bottom-right on every screen (A-237). Rendered once at the app root so it
 * never moves between pages. Hidden where the browser can't go full screen (iPhone Safari) and on
 * phones, where it would cover the bottom tabs and sticky action bars.
 */
@Component({
  selector: 'sm-fullscreen-toggle',
  imports: [Icon],
  template: `
    @if (available()) {
      <button
        type="button"
        class="fs"
        [attr.aria-label]="label()"
        [attr.title]="label()"
        [attr.aria-pressed]="on()"
        [style.translate]="lift() ? '0 ' + -lift() + 'px' : null"
        (click)="toggle()"
      >
        <sm-icon [name]="on() ? 'minimize' : 'maximize'" size="sm" />
      </button>
    }
  `,
  styles: `
    :host {
      position: fixed;
      inset-block-end: var(--sm-space-400);
      inset-inline-end: var(--sm-space-400);
      z-index: var(--sm-z-sticky);
    }

    .fs {
      display: grid;
      place-items: center;
      inline-size: var(--sm-size-touch-min);
      block-size: var(--sm-size-touch-min);
      padding: 0;
      border: var(--sm-stroke-sm) solid var(--sm-color-border-default);
      border-radius: var(--sm-radius-full);
      background: var(--sm-color-surface-panel-muted);
      color: var(--sm-color-icon-default);
      box-shadow: var(--sm-shadow-elevation-panel);
      backdrop-filter: var(--sm-backdrop-elevation-panel);
      cursor: pointer;
      transition-property: transform, translate, border-color;
      transition-duration: var(--sm-motion-duration-fast);
      transition-timing-function: var(--sm-motion-easing-standard);
    }

    .fs:hover,
    .fs:focus-visible {
      border-color: var(--sm-color-border-brand);
      transform: scale(1.06);
    }

    .fs:focus-visible {
      box-shadow: var(--sm-shadow-focus-ring-offset);
      outline: none;
    }

    @media (prefers-reduced-motion: reduce) {
      .fs:hover,
      .fs:focus-visible {
        transform: none;
      }
    }

    @media print {
      :host {
        display: none;
      }
    }
  `,
})
export class FullscreenToggle {
  private readonly doc = inject(DOCUMENT);
  private readonly viewport = inject(Viewport);

  protected readonly on = signal(!!this.doc.fullscreenElement);
  private readonly supported = !!this.doc.fullscreenEnabled;
  protected readonly available = computed(() => this.supported && !this.viewport.isMobile());

  protected readonly label = computed(() =>
    this.on()
      ? $localize`:@@fullscreen.exit:Exit full screen`
      : $localize`:@@fullscreen.enter:Full screen`,
  );

  /**
   * Pixels to rise so a pinned bottom bar (quest footer, Apply bar, quiz actions…) is never
   * covered. Found by looking under the corner for a fixed/sticky ancestor, so no page has to opt in.
   */
  protected readonly lift = signal(0);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;

  private measure(): void {
    const win = this.doc.defaultView;
    if (!win || !this.available()) return;
    const size = this.host.firstElementChild?.getBoundingClientRect();
    const inset = 16;
    const x = win.innerWidth - inset - (size?.width ?? 44) / 2;
    const y = win.innerHeight - inset - (size?.height ?? 44) / 2;
    let lift = 0;
    for (const el of this.doc.elementsFromPoint(x, y)) {
      if (this.host.contains(el) || el === this.doc.body || el === this.doc.documentElement)
        continue;
      for (let n: Element | null = el; n && n !== this.doc.body; n = n.parentElement) {
        const pos = win.getComputedStyle(n).position;
        if (pos === 'fixed' || pos === 'sticky') {
          const top = n.getBoundingClientRect().top;
          if (top > win.innerHeight / 2) lift = Math.max(lift, Math.ceil(win.innerHeight - top));
          break;
        }
      }
    }
    if (lift !== this.lift()) this.lift.set(lift);
  }

  constructor() {
    const sync = () => this.on.set(!!this.doc.fullscreenElement);
    this.doc.addEventListener('fullscreenchange', sync);
    let frame = 0;
    const schedule = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => this.measure());
    };
    const win = this.doc.defaultView;
    win?.addEventListener('scroll', schedule, { passive: true, capture: true });
    win?.addEventListener('resize', schedule, { passive: true });
    const mo = new MutationObserver(schedule);
    mo.observe(this.doc.body, { childList: true, subtree: true });
    inject(DestroyRef).onDestroy(() => {
      this.doc.removeEventListener('fullscreenchange', sync);
      win?.removeEventListener('scroll', schedule, { capture: true });
      win?.removeEventListener('resize', schedule);
      mo.disconnect();
      cancelAnimationFrame(frame);
    });
  }

  protected async toggle(): Promise<void> {
    try {
      if (this.doc.fullscreenElement) await this.doc.exitFullscreen();
      else await this.doc.documentElement.requestFullscreen({ navigationUI: 'hide' });
    } catch {
      /* blocked by the browser or an iframe policy: nothing to do */
    }
  }
}
