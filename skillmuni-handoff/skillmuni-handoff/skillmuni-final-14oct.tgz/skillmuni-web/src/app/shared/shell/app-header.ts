import { NgOptimizedImage } from '@angular/common';
import {
  Component,
  booleanAttribute,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { Icon } from '../ui/icon/icon';
import { IconButton } from '../ui/icon-button/icon-button';
import { XpHud } from '../ui/hud/xp-hud';
import { Viewport } from '../../core/layout/viewport';
import { TenantThemeService } from '../../core/theme/tenant-theme';
import { ASSETS } from '../assets';
import { TOTAL_XP } from '../../core/quests/quest-catalog';

export interface HudState {
  readonly level: number;
  readonly rank: string;
  readonly xp: number;
  readonly target: number;
}

/**
 * Figma: App Shell → App Header (32:121). Floating glass bar.
 * Desktop: logo · title with Ember underline · XP HUD (full) · Save & exit.
 * Tablet: same with the medium HUD. Mobile: back · title + "Quest N of 8" · compact HUD · Save & exit.
 * Save & exit (Figma 200:44079): no confirmation — autosave, go to Welcome back, toast. The parent handles `exit`.
 */
@Component({
  selector: 'sm-app-header',
  imports: [Icon, IconButton, XpHud, NgOptimizedImage],
  templateUrl: './app-header.html',
  styleUrl: './app-header.scss',
  host: { class: 'sm-app-header', '[class]': '"sm-app-header sm-app-header--" + viewport.size()' },
})
export class AppHeader {
  protected readonly viewport = inject(Viewport);
  private readonly tenant = inject(TenantThemeService);

  readonly title = input.required<string>();
  /** Mobile sub-line, e.g. "Quest 1 of 8". */
  readonly subtitle = input('');
  readonly hud = input<HudState | null>(null);
  /** A-264: the quest HUD bar runs over all the registration XP. */
  protected readonly journey = TOTAL_XP;
  readonly showBack = input(true, { transform: booleanAttribute });
  readonly showExit = input(true, { transform: booleanAttribute });
  /** Autosave status next to Save & exit (A-241). */
  readonly saveState = input<'idle' | 'saving' | 'saved'>('idle');
  /** Replaces "Save & exit" when the quest returns to a platform screen (A-252). */
  readonly exitLabel = input('');
  protected readonly saveExitLabel = $localize`:@@header.saveExit:Save and exit`;
  readonly back = output<void>();
  readonly exit = output<void>();

  protected readonly logo = computed(() => this.tenant.active()?.logoUrl ?? ASSETS.logo);
  protected readonly logoAlt = computed(() => this.tenant.active()?.name ?? 'Skillmuni');
  protected readonly logoMissing = signal(false);
  protected readonly hudLayout = computed(() =>
    this.viewport.size() === 'desktop'
      ? 'full'
      : this.viewport.size() === 'tablet'
        ? 'medium'
        : 'compact',
  );
}
