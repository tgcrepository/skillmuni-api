import { Component } from '@angular/core';

/**
 * Figma: App Shell → Page Background (32:56). Canvas gradient + three ambient glows
 * (violet bottom-left, orange top-right, blue centre) + bottom wave. Fixed behind every screen; decorative.
 * Wave path copied from Figma (1728 × 180 frame), stretched to the viewport width.
 */
@Component({
  selector: 'sm-page-background',
  template: `
    <span class="glow glow--violet"></span>
    <span class="glow glow--orange"></span>
    <span class="glow glow--blue"></span>
    <svg class="wave" viewBox="0 0 1728 180" preserveAspectRatio="none" focusable="false">
      <defs>
        <linearGradient id="sm-wave-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" class="wave-stop-1" />
          <stop offset="1" class="wave-stop-2" />
        </linearGradient>
      </defs>
      <path
        class="wave-fill"
        d="M 0 50 C 420 -40 960 130 1728 0 L 1728 180 L 0 180 L 0 50 Z"
        fill="url(#sm-wave-fill)"
      />
      <path
        class="wave-line"
        d="M 0 50 C 420 -40 960 130 1728 0"
        vector-effect="non-scaling-stroke"
      />
    </svg>
  `,
  styleUrl: './page-background.scss',
  host: { 'aria-hidden': 'true', class: 'sm-page-background' },
})
export class PageBackground {}
