import { NgOptimizedImage } from '@angular/common';
import { CdkMenu, CdkMenuItem, CdkMenuTrigger } from '@angular/cdk/menu';
import {
  Component,
  Service,
  booleanAttribute,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { filter, map, startWith } from 'rxjs';
import { Auth } from '../../core/auth/auth';
import { Viewport } from '../../core/layout/viewport';
import { TenantThemeService } from '../../core/theme/tenant-theme';
import { ASSETS } from '../assets';
import { Icon } from '../ui/icon/icon';
import { IconName } from '../ui/icon/icons';
import { MuniLauncher } from '../muni-chat/muni-launcher';
import { BrandTagline } from './brand-tagline';
import { PageBackground } from './page-background';
import { LogoutFlow } from './logout-dialog';

/** Counts shown on the nav. Rewards has no count while the store is coming soon (corrections #27). */
@Service()
export class LearnerBadges {
  readonly rewardsReady = signal(0);
  readonly unread = signal(0);
}

interface NavItem {
  readonly id: 'lobby' | 'arena' | 'stats' | 'rewards';
  readonly label: string;
  readonly link: string;
  readonly icon: IconName;
  readonly iconActive: IconName;
}

/**
 * Learner app frame (Figma Home v2 185:8307 desktop · 185:8317 tablet · 62:592 mobile; components 47:1162).
 * Desktop/tablet: floating glass Top Nav — logo · Lobby · Arena · My Stats · Rewards · bell · avatar.
 * Mobile: logo · bell · avatar on top, Bottom Nav with the four destinations.
 * Selected item (Nav Item 47:1186): Ember tint + glow, filled icon, glowing 4px underline, aria-current.
 */
@Component({
  selector: 'sm-learner-shell',
  imports: [
    BrandTagline,
    CdkMenu,
    CdkMenuItem,
    CdkMenuTrigger,
    Icon,
    MuniLauncher,
    NgOptimizedImage,
    PageBackground,
    RouterLink,
  ],
  templateUrl: './learner-shell.html',
  styleUrl: './learner-shell.scss',
  host: {
    '[class]': '"sm-learner-shell sm-learner-shell--" + viewport.size()',
    '[class.no-tabs]': 'hideTabsOnMobile()',
  },
})
export class LearnerShell {
  protected readonly viewport = inject(Viewport);
  protected readonly badges = inject(LearnerBadges);
  private readonly auth = inject(Auth);
  private readonly router = inject(Router);
  private readonly tenant = inject(TenantThemeService);

  /**
   * Mobile: the page also draws its own back + title row under the top bar (Brain Vita, Brief, Quiz,
   * My Jobs). The app top bar itself always stays (corrections #38).
   */
  readonly pageHeaderOnMobile = input(false, { transform: booleanAttribute });
  /** Mobile only: hide the bottom tabs (quiz pins its own action bar). */
  readonly hideTabsOnMobile = input(false, { transform: booleanAttribute });

  protected readonly logo = computed(() => this.tenant.active()?.logoUrl ?? ASSETS.logo);
  protected readonly logoAlt = computed(() => this.tenant.active()?.name ?? 'Skillmuni');
  protected readonly logoMissing = signal(false);

  protected readonly name = computed(() => {
    const u = this.auth.user();
    return u?.firstName ?? '';
  });
  protected readonly photo = computed(() => this.auth.user()?.photoUrl ?? null);
  protected readonly initial = computed(() =>
    (this.auth.user()?.firstName ?? '').charAt(0).toUpperCase(),
  );

  /** Corrections #40: the avatar opens a menu with My profile and Log out. */
  protected readonly accountLabel = computed(
    () => $localize`:@@nav.account:Account menu, ${this.name()}:name:`,
  );
  private readonly logoutFlow = inject(LogoutFlow);
  protected logout(): void {
    void this.logoutFlow.confirm();
  }

  protected readonly items: readonly NavItem[] = [
    {
      id: 'lobby',
      label: $localize`:@@nav.lobby:Lobby`,
      link: '/home',
      icon: 'home',
      iconActive: 'home-filled',
    },
    {
      id: 'arena',
      label: $localize`:@@nav.arena:Arena`,
      link: '/arena',
      icon: 'bar-chart',
      iconActive: 'bar-chart-filled',
    },
    {
      id: 'stats',
      label: $localize`:@@nav.stats:My Stats`,
      link: '/stats',
      icon: 'layout-grid',
      iconActive: 'layout-grid',
    },
    {
      id: 'rewards',
      label: $localize`:@@nav.rewards:Rewards`,
      link: '/rewards',
      icon: 'gift',
      iconActive: 'gift',
    },
  ];

  private readonly url = toSignal(
    this.router.events.pipe(
      filter((e): e is NavigationEnd => e instanceof NavigationEnd),
      map((e) => e.urlAfterRedirects),
      startWith(this.router.url),
    ),
    { initialValue: this.router.url },
  );

  /** Lobby stays selected inside modules, briefs and quizzes (Figma learn screens). */
  protected readonly activeId = computed(() => {
    const path = (this.url() ?? '').split(/[?#]/)[0] ?? '';
    if (['/learn', '/home', '/launchpad', '/job-profile'].some((p) => path.startsWith(p)))
      return 'lobby';
    return this.items.find((i) => path.startsWith(i.link))?.id ?? null;
  });

  protected readonly onProfile = computed(() =>
    ((this.url() ?? '').split(/[?#]/)[0] ?? '').startsWith('/profile'),
  );

  protected readonly bellLabel = computed(() =>
    this.badges.unread()
      ? $localize`:@@nav.bellUnread:Notifications, ${this.badges.unread()}:count: new`
      : $localize`:@@nav.bell:Notifications`,
  );

}
