import { NgOptimizedImage } from '@angular/common';
import { Component, computed, inject, input, signal } from '@angular/core';
import { TenantThemeService } from '../../core/theme/tenant-theme';
import { ASSETS } from '../assets';

/**
 * Skillmuni (or tenant) logo. Falls back to the wordmark as text when the image is missing.
 * Size: `md` header 51 · `lg` login card 78 · `sm` mobile 32.
 */
@Component({
  selector: 'sm-brand-logo',
  imports: [NgOptimizedImage],
  template: `
    <img
      [ngSrc]="src()"
      [alt]="name()"
      width="240"
      height="77"
      [priority]="priority()"
      (error)="missing.set(true)"
      [class.is-missing]="missing()"
    />
    @if (missing()) {
      <span class="text">{{ name() }}</span>
    }
  `,
  styles: `
    :host {
      display: inline-grid;
      align-items: center;
      justify-items: center;
      block-size: var(--_h);
    }

    :host(.sm-brand-logo--sm) {
      --_h: var(--sm-size-logo-height-sm);
    }

    :host(.sm-brand-logo--md) {
      --_h: var(--sm-size-logo-height);
    }

    :host(.sm-brand-logo--lg) {
      --_h: var(--sm-size-logo-height-lg);
    }

    img,
    .text {
      grid-area: 1 / 1;
    }

    img {
      inline-size: auto;
      block-size: var(--_h);
    }

    .text {
      color: var(--sm-color-text-heading);
      font: var(--sm-font-heading-lg);
      letter-spacing: var(--sm-letter-spacing-overline);
      text-transform: uppercase;
    }
  `,
  host: { '[class]': '"sm-brand-logo sm-brand-logo--" + size()' },
})
export class BrandLogo {
  private readonly tenant = inject(TenantThemeService);
  readonly size = input<'sm' | 'md' | 'lg'>('md');
  readonly priority = input(false);
  protected readonly src = computed(() => this.tenant.active()?.logoUrl ?? ASSETS.logo);
  protected readonly name = computed(() => this.tenant.active()?.name ?? 'Skillmuni');
  protected readonly missing = signal(false);
}
