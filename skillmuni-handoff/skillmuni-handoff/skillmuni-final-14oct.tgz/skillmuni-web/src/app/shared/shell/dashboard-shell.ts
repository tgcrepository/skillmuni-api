import {
  Component,
  DestroyRef,
  ElementRef,
  afterEveryRender,
  computed,
  inject,
  input,
} from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { Viewport } from '../../core/layout/viewport';
import { AppHeader } from './app-header';
import { BrandTagline } from './brand-tagline';
import { PageBackground } from './page-background';

export interface DashboardNavItem {
  readonly label: string;
  readonly short: string;
  /** Route, or null while the screen isn't built (shown as "Soon"). */
  readonly link: string | null;
}

export interface DashboardUser {
  readonly name: string;
  readonly level: number;
  readonly rank: string;
}

/**
 * Learner dashboard frame (Figma 200:38000 desktop · 200:38316 mobile · 200:38733 tablet).
 * Desktop / tablet: header + left nav with the learner chip. Mobile: header + bottom tab bar
 * (Lobby · Matches · Quests · Learn · Me). Project the page as content.
 */
@Component({
  selector: 'sm-dashboard-shell',
  imports: [AppHeader, BrandTagline, PageBackground, RouterLink, RouterLinkActive],
  template: `
    <a class="skip" href="#sm-main" i18n="@@shell.skipMain">Skip to content</a>
    <sm-page-background />
    <sm-app-header [title]="title()" [showBack]="false" [showExit]="false" />

    <div class="layout">
      @if (!viewport.isMobile()) {
        <nav class="side" i18n-aria-label="@@dash.nav" aria-label="Dashboard">
          @if (user(); as u) {
            <div class="me">
              <span class="avatar" aria-hidden="true">{{ initials() }}</span>
              <span class="me-text">
                <span class="me-name">{{ u.name }}</span>
                <span class="me-rank" i18n="@@dash.rank">Lvl {{ u.level }} · {{ u.rank }}</span>
              </span>
            </div>
          }
          <ul class="links">
            @for (item of nav; track item.label) {
              <li>
                @if (item.link) {
                  <a
                    class="link"
                    [routerLink]="item.link"
                    routerLinkActive="is-active"
                    ariaCurrentWhenActive="page"
                    >{{ item.label }}</a
                  >
                } @else {
                  <span class="link is-soon" aria-disabled="true">
                    {{ item.label }} <span class="soon" i18n="@@dash.soon">Soon</span>
                  </span>
                }
              </li>
            }
          </ul>
        </nav>
      }
      <main id="sm-main" class="main" tabindex="-1"><ng-content /></main>
    </div>

    @if (viewport.isMobile()) {
      <nav class="tabbar" i18n-aria-label="@@dash.nav" aria-label="Dashboard">
        @for (item of tabs; track item.short) {
          @if (item.link) {
            <a
              class="tab"
              [routerLink]="item.link"
              routerLinkActive="is-active"
              ariaCurrentWhenActive="page"
            >
              <span class="dot" aria-hidden="true"></span>{{ item.short }}
            </a>
          } @else {
            <span class="tab is-soon" aria-disabled="true">
              <span class="dot" aria-hidden="true"></span>{{ item.short }}
              <span class="sm-visually-hidden" i18n="@@dash.soonSr">(coming soon)</span>
            </span>
          }
        }
      </nav>
    } @else {
      <footer class="foot">
        <sm-brand-tagline />
        <p class="powered" i18n="@@shell.powered">© Powered by The Gamification Company</p>
      </footer>
    }
  `,
  styleUrl: './dashboard-shell.scss',
  host: { class: 'sm-dashboard-shell' },
})
export class DashboardShell {
  protected readonly viewport = inject(Viewport);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;

  constructor() {
    // Toasts sit above the mobile tab bar (same contract as the quest bottom bar).
    const root = document.documentElement;
    afterEveryRender(() => {
      const bar = this.host.querySelector<HTMLElement>('.tabbar');
      root.style.setProperty('--sm-bottom-bar-height', bar ? `${bar.offsetHeight}px` : '0px');
    });
    inject(DestroyRef).onDestroy(() => root.style.removeProperty('--sm-bottom-bar-height'));
  }

  readonly title = input.required<string>();
  readonly user = input<DashboardUser | null>(null);

  protected readonly initials = computed(() =>
    (this.user()?.name ?? '')
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((w) => w.charAt(0).toUpperCase())
      .join(''),
  );

  protected readonly nav: readonly DashboardNavItem[] = [
    {
      label: $localize`:@@dash.lobby:Lobby`,
      short: $localize`:@@dash.lobby:Lobby`,
      link: '/home',
    },
    {
      label: $localize`:@@dash.matches:My Matches`,
      short: $localize`:@@dash.matchesShort:Matches`,
      link: '/matches',
    },
    { label: $localize`:@@dash.applications:Applications`, short: '', link: null },
    {
      label: $localize`:@@dash.quests:Quests`,
      short: $localize`:@@dash.quests:Quests`,
      link: '/welcome-back',
    },
    {
      label: $localize`:@@dash.learning:Learning`,
      short: $localize`:@@dash.learn:Learn`,
      link: null,
    },
    { label: $localize`:@@dash.compass:Career Compass`, short: '', link: null },
    { label: $localize`:@@dash.profile:Profile`, short: $localize`:@@dash.me:Me`, link: null },
    { label: $localize`:@@dash.settings:Settings`, short: '', link: null },
  ];
  /** Mobile tab bar: Lobby · Matches · Quests · Learn · Me (Figma MM2). */
  protected readonly tabs = this.nav.filter((n) => n.short);
}
