import { Component, computed, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Viewport, ViewportSize } from '../../core/layout/viewport';
import { QuestShell } from './quest-shell';

@Component({
  imports: [QuestShell],
  template: `
    <sm-quest-shell
      [quest]="1"
      [progress]="{ completed: 0, partsDone: 1 }"
      [loot]="{
        badge: 'Main Character Badge',
        reward: '+50 XP, and more',
        rewardShort: '+50 XP',
        progress: 10,
      }"
      muni="Hey there"
      (exit)="exits = exits + 1"
      (openQuest)="opened = $event"
    >
      <p class="card">card</p>
    </sm-quest-shell>
  `,
})
class Host {
  exits = 0;
  opened = 0;
}

function setup(size: ViewportSize) {
  const s = signal<ViewportSize>(size);
  TestBed.configureTestingModule({
    providers: [
      {
        provide: Viewport,
        useValue: {
          size: s,
          isMobile: computed(() => s() === 'mobile'),
          isDesktop: computed(() => s() === 'desktop'),
          isShort: signal(false),
        },
      },
    ],
  });
  const fixture = TestBed.createComponent(Host);
  fixture.detectChanges();
  return { fixture, el: fixture.nativeElement as HTMLElement };
}

describe('QuestShell', () => {
  afterEach(() => document.querySelector('.cdk-overlay-container')?.replaceChildren());

  it('desktop: rail map, card in main, reward rail and footer landmarks', () => {
    const { el } = setup('desktop');
    expect(el.querySelector('sm-quest-map')?.classList).toContain('is-rail');
    expect(el.querySelector('main .card')).toBeTruthy();
    expect(el.querySelector('aside sm-loot-drop-card')).toBeTruthy();
    expect(el.querySelector('footer')?.textContent).toContain('Powered by');
    expect(el.querySelector('a.skip')?.getAttribute('href')).toBe('#sm-main');
  });

  it('tablet: lineup strip and Muni row with compact loot card', () => {
    const { el } = setup('tablet');
    expect(el.querySelector('sm-quest-map')?.classList).toContain('is-strip');
    expect(el.querySelector('.muni-row sm-loot-drop-card')?.classList).toContain('is-compact');
    expect(el.querySelector('aside')).toBeNull();
  });

  it('mobile: compact lineup, Muni tip, and "See all" opens the full map in a sheet', async () => {
    const { fixture, el } = setup('mobile');
    expect(el.querySelector('sm-muni-tip')?.textContent).toContain('Hey there');
    (el.querySelector('.see-all') as HTMLButtonElement).click();
    fixture.detectChanges();
    await fixture.whenStable();
    const pane = document.querySelector('.sm-pane--sheet');
    expect(pane?.querySelector('sm-quest-map.is-rail')).toBeTruthy();
    (
      pane?.querySelector(
        'sm-quest-item button, sm-quest-item [role="button"]',
      ) as HTMLElement | null
    )?.click();
    expect(fixture.componentInstance.opened).toBe(1);
  });

  it('forwards Save and exit from the header', () => {
    const { fixture, el } = setup('desktop');
    (
      el.querySelector(
        '[aria-label="Save and exit"], button.exit, button.exit-pill',
      ) as HTMLButtonElement
    ).click();
    expect(fixture.componentInstance.exits).toBe(1);
  });
});
