import { DOCUMENT } from '@angular/common';
import { Component, effect, inject, untracked } from '@angular/core';
import { Connectivity } from '../../core/network/connectivity';
import { OfflineQueue } from '../../core/network/offline-queue';
import { Banner } from '../ui/banner/banner';
import { ToastService } from '../ui/toast/toast.service';

/**
 * Figma: State / Offline (200:30585) and OF1 (203:9253 · 203:9590 · 203:9995).
 * Floating warning banner while offline — bottom-start on desktop, above the bottom bar below desktop.
 * Inputs stay usable; saves queue (OfflineQueue). When the queue drains, a success toast confirms it.
 * Rendered once in the app root.
 */
@Component({
  selector: 'sm-offline-banner',
  imports: [Banner],
  template: `
    <div class="live" role="status">
      @if (!connectivity.online()) {
        <sm-banner tone="warning" class="banner">
          @if (queue.pending().length) {
            <ng-container i18n="@@offline.queued"
              >You’re offline. We’ll save your answers when you’re back.</ng-container
            >
          } @else {
            <ng-container i18n="@@offline.idle"
              >You’re offline. Keep going, we’ll save as soon as you’re back.</ng-container
            >
          }
        </sm-banner>
      }
    </div>
  `,
  styleUrl: './offline-banner.scss',
  host: { class: 'sm-offline-banner' },
})
export class OfflineBanner {
  protected readonly connectivity = inject(Connectivity);
  protected readonly queue = inject(OfflineQueue);
  private readonly toast = inject(ToastService);
  private readonly doc = inject(DOCUMENT);

  constructor() {
    // While the banner floats, the page gets room at the end so its last button can scroll clear of it.
    effect(() => {
      this.doc.documentElement.classList.toggle('sm-is-offline', !this.connectivity.online());
    });
    let seen = untracked(this.queue.flushed);
    effect(() => {
      const n = this.queue.flushed();
      if (n > seen) {
        seen = n;
        untracked(() =>
          this.toast.show($localize`:@@offline.synced:Back online. Your answers are saved.`),
        );
      }
    });
  }
}
