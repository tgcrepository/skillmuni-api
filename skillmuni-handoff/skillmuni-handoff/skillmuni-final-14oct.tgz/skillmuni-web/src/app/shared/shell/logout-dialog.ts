import { DialogRef } from '@angular/cdk/dialog';
import { Component, Service, computed, inject } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { Auth } from '../../core/auth/auth';
import { LADDER, levelFor } from '../../core/quests/levels';
import { QuestStore } from '../../core/quests/quest-store';
import { Button } from '../ui/button/button';
import { MuniAvatar } from '../ui/muni/muni-avatar';
import { SmDialog } from '../ui/overlay/dialog';
import { OverlayService } from '../ui/overlay/overlay.service';
import { ToastService } from '../ui/toast/toast.service';
import { Typewriter } from '../ui/muni/typewriter';

/**
 * Corrections #40: logging out asks first, with Muni making the case for staying.
 * The pitch uses the learner's real progress (XP to the next level), so it never feels canned.
 * "Stay" is the main action; "Log out anyway" is always one tap away — never a trap.
 */
@Component({
  selector: 'sm-logout-dialog',
  imports: [SmDialog, Button, MuniAvatar, Typewriter],
  template: `
    <sm-dialog centered stacked labelledBy="logout-title" [dismissible]="true">
      <div class="wrap">
        <div class="muni">
          <sm-muni-avatar [size]="96" />
          <span class="wave" aria-hidden="true">👋</span>
        </div>
        <h2 id="logout-title" class="title" i18n="@@logout.title">
          Leaving so soon, {{ name() }}?
        </h2>
        <p class="bubble" smTypewriter>{{ pitch() }}</p>
        <ul class="facts">
          <li>
            <span class="fact-value">{{ level().level }}</span>
            <span class="fact-label" i18n="@@logout.level">Level · {{ level().rank }}</span>
          </li>
          <li>
            <span class="fact-value">{{ xp() }}</span>
            <span class="fact-label" i18n="@@logout.xp">XP earned</span>
          </li>
          <li>
            <span class="fact-value">{{ toNext() || '🏆' }}</span>
            <span class="fact-label" i18n="@@logout.toNext">XP to level up</span>
          </li>
        </ul>
        <p class="safe" i18n="@@logout.safe">Your progress is saved either way.</p>
      </div>
      <div smDialogActions>
        <button
          sm-button
          type="button"
          cdkFocusInitial
          (click)="ref.close(false)"
          i18n="@@logout.stay"
        >
          Stay and keep going
        </button>
        <button
          sm-button
          variant="secondary"
          type="button"
          (click)="ref.close(true)"
          i18n="@@logout.go"
        >
          Log out anyway
        </button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .wrap {
      display: grid;
      justify-items: center;
      gap: var(--sm-space-300);
      text-align: center;
    }
    .muni {
      position: relative;
      animation: sm-logout-bob var(--sm-motion-duration-page) var(--sm-motion-easing-standard) both;
    }
    .wave {
      position: absolute;
      inset-block-end: 0;
      inset-inline-end: calc(var(--sm-space-200) * -1);
      font: var(--sm-font-heading);
      transform-origin: 70% 70%;
      animation: sm-logout-wave calc(var(--sm-motion-duration-page) * 3)
        var(--sm-motion-easing-standard) 2;
    }
    .title {
      margin: 0;
      color: var(--sm-color-text-primary);
      font: var(--sm-font-heading);
    }
    .bubble {
      position: relative;
      margin: 0;
      padding: var(--sm-space-300) var(--sm-space-400);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-brand);
      border-radius: var(--sm-radius-xl);
      background: var(--sm-color-surface-inverse);
      color: var(--sm-color-text-inverse);
      font: var(--sm-font-speech);
    }
    .facts {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: var(--sm-space-200);
      inline-size: 100%;
      margin: 0;
      padding: 0;
      list-style: none;
    }
    .facts li {
      display: grid;
      gap: var(--sm-space-50);
      padding: var(--sm-space-250) var(--sm-space-200);
      border-radius: var(--sm-radius-lg);
      background: var(--sm-color-surface-inset);
    }
    .fact-value {
      color: var(--sm-color-text-primary);
      font: var(--sm-font-title);
    }
    .fact-label {
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }
    .safe {
      margin: 0;
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }
    @keyframes sm-logout-bob {
      from {
        opacity: 0;
        transform: translateY(var(--sm-space-300)) scale(0.9);
      }
    }
    @keyframes sm-logout-wave {
      25% {
        transform: rotate(18deg);
      }
      50% {
        transform: rotate(-10deg);
      }
      75% {
        transform: rotate(14deg);
      }
    }
    @media (prefers-reduced-motion: reduce) {
      .muni,
      .wave {
        animation: none;
      }
    }
  `,
})
export class LogoutDialog {
  protected readonly ref = inject<DialogRef<boolean>>(DialogRef);
  private readonly auth = inject(Auth);
  private readonly store = inject(QuestStore);

  protected readonly name = computed(() => this.auth.user()?.firstName ?? '');
  protected readonly xp = computed(() => this.store.progress()?.xp ?? 0);
  protected readonly level = computed(() => levelFor(this.xp()));
  protected readonly toNext = computed(() => {
    const top = LADDER.at(-1)?.level ?? 1;
    return this.level().level >= top ? 0 : Math.max(0, this.level().target - this.xp());
  });
  private readonly nextRank = computed(
    () => LADDER.find((l) => l.level === this.level().level + 1)?.rank ?? '',
  );

  protected readonly pitch = computed(() => {
    const left = this.toNext();
    if (!left)
      return $localize`:@@logout.pitchTop:You’re at the top of the ladder. Stick around and defend your spot!`;
    if (left <= 120)
      return $localize`:@@logout.pitchClose:Wait, you’re only ${left}:left: XP from ${this.nextRank()}:rank:! One quick quiz and you’re there.`;
    return $localize`:@@logout.pitchFar:One more quiz? Every bit of XP gets you closer to ${this.nextRank()}:rank:, and I’ll be right here cheering.`;
  });
}

/** Opens the Muni logout check from anywhere (top-bar avatar menu, Profile → Settings). */
@Service()
export class LogoutFlow {
  private readonly overlay = inject(OverlayService);
  private readonly auth = inject(Auth);
  private readonly store = inject(QuestStore);
  private readonly router = inject(Router);
  private readonly toast = inject(ToastService);

  async confirm(): Promise<void> {
    if (!this.store.progress()) void this.store.load().catch(() => undefined);
    const ref = this.overlay.adaptive<LogoutDialog, unknown, boolean>(LogoutDialog, {
      size: 'sm',
      ariaLabel: $localize`:@@logout.aria:Log out?`,
    });
    const leave = await firstValueFrom(ref.closed);
    if (!leave) return;
    try {
      await firstValueFrom(this.auth.logout());
    } catch {
      /* signed out locally either way */
    }
    this.toast.show($localize`:@@logout.bye:Logged out. See you soon!`);
    await this.router.navigateByUrl('/login');
  }
}
