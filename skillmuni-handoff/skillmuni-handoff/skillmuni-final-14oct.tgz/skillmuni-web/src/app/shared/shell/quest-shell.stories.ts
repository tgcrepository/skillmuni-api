import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Component, inject, signal } from '@angular/core';
import { QuestCard } from '../ui/quest/quest-card';
import { Field } from '../ui/field/field';
import { Input } from '../ui/input/input';
import { Tag } from '../ui/tag/tag';
import { ToastHost } from '../ui/toast/toast-host';
import { ToastService } from '../ui/toast/toast.service';
import { QuestShell } from './quest-shell';

/** Storybook / e2e harness: Q1 part 1 inside the shell. Exit shows the Figma 200:44079 toast. */
@Component({
  selector: 'sm-quest-shell-demo',
  imports: [QuestShell, QuestCard, Field, Input, Tag, ToastHost],
  template: `
    <sm-quest-shell
      [quest]="1"
      [progress]="{ completed: 0, partsDone: 0 }"
      [hud]="{ level: 1, rank: 'Rookie', xp: 90, target: 400 }"
      [loot]="{
        badge: 'Main Character Badge',
        reward: '+50 XP, and the Hit Me Up quest unlocks',
        rewardShort: '+50 XP · unlocks Hit Me Up',
        progress: 10,
      }"
      [muni]="muni()"
      (exit)="saveAndExit()"
      (openQuest)="opened.set($event)"
    >
      <sm-quest-card
        eyebrow="Quest 1 of 8 · Who dis? · Part 1 of 3"
        xpPromise="+50 XP when you’re done"
        subtitle="Use the name on your ID, it goes on your certificates. Takes like 20 seconds, fr."
        [steps]="steps"
        counter="1 more to go"
        primaryLabel="Next part"
        primaryXp="+20 XP"
      >
        <h1 smQuestTitle>First up, what should we <em>call you?</em></h1>
        <div class="fields">
          <sm-field label="First name" status="valid" helper="Looks good"
            ><sm-input value="Nkosazana"
          /></sm-field>
          <sm-field label="Last name"><sm-input placeholder="Your last name" /></sm-field>
          <sm-field label="Nickname" helper="Your nickname in the app. Totally optional."
            ><sm-tag>Optional</sm-tag><sm-input placeholder="What your friends call you"
          /></sm-field>
        </div>
      </sm-quest-card>
    </sm-quest-shell>
    <sm-toast-host />
  `,
  styles: `
    .fields {
      display: grid;
      grid-template-columns: repeat(
        auto-fit,
        minmax(min(var(--sm-layout-shell-map-width), 100%), 1fr)
      );
      gap: var(--sm-space-600);
    }
  `,
})
class QuestShellDemo {
  private readonly toast = inject(ToastService);
  readonly opened = signal(0);
  readonly muni = signal('Hey! Let’s start with your name. Easy XP, no cap.');
  readonly steps = [
    { label: 'Your name', short: 'Name', answered: 1, total: 2 },
    { label: 'ID & birthday', short: 'ID & bday', answered: 0, total: 2, xp: '+20 XP' },
    { label: 'The tea', answered: 0, total: 3, xp: '+20 XP' },
  ];

  saveAndExit(): void {
    this.toast.show($localize`:@@shell.saved:Progress saved. Pick up anytime.`);
  }
}

const meta: Meta<QuestShellDemo> = {
  title: 'Shell/Quest Shell',
  component: QuestShellDemo,
  parameters: {
    figma: {
      node: 'Q1 desktop 200:11572 · tablet 200:12629 · mobile 200:13165 · Save & exit 200:44079',
    },
    layout: 'fullscreen',
  },
};
export default meta;

export const Desktop: StoryObj<QuestShellDemo> = { globals: { viewport: { value: 'desktop' } } };
export const Tablet: StoryObj<QuestShellDemo> = { globals: { viewport: { value: 'tablet' } } };
export const Mobile: StoryObj<QuestShellDemo> = { globals: { viewport: { value: 'mobile' } } };
