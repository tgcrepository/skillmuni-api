import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { delayed } from './delayed';

@Component({ template: '' })
class Host {
  readonly loading = signal(false);
  readonly show = delayed(this.loading);
}

describe('delayed()', () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it('only turns on after 400 ms of continuous loading', () => {
    const host = TestBed.createComponent(Host).componentInstance;
    host.loading.set(true);
    TestBed.tick();
    vi.advanceTimersByTime(399);
    expect(host.show()).toBe(false);
    vi.advanceTimersByTime(1);
    expect(host.show()).toBe(true);
    host.loading.set(false);
    TestBed.tick();
    expect(host.show()).toBe(false);
  });

  it('never flashes for fast responses', () => {
    const host = TestBed.createComponent(Host).componentInstance;
    host.loading.set(true);
    TestBed.tick();
    vi.advanceTimersByTime(200);
    host.loading.set(false);
    TestBed.tick();
    vi.advanceTimersByTime(1000);
    expect(host.show()).toBe(false);
  });
});
