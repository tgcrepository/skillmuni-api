import { StreakDay } from '../../core/arena/arena.api';

export const DAY_LETTERS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

/** "Wednesday, today, not done yet" — the accessible name of a streak-week cell (Mon-first). */
export function streakDayLabel(i: number, state: StreakDay): string {
  const day = [
    $localize`:@@day.mon:Monday`,
    $localize`:@@day.tue:Tuesday`,
    $localize`:@@day.wed:Wednesday`,
    $localize`:@@day.thu:Thursday`,
    $localize`:@@day.fri:Friday`,
    $localize`:@@day.sat:Saturday`,
    $localize`:@@day.sun:Sunday`,
  ][i];
  const s = {
    done: $localize`:@@arena.dayDone:done`,
    today: $localize`:@@arena.dayToday:today, not done yet`,
    upcoming: $localize`:@@arena.dayUpcoming:coming up`,
    missed: $localize`:@@arena.dayMissed:missed`,
  }[state];
  return `${day}, ${s}`;
}
