export interface CalendarEvent {
  readonly id: string;
  readonly title: string;
  /** ISO date (all-day) or ISO date-time. */
  readonly start: string;
  /** Minutes; ignored for all-day events. */
  readonly minutes?: number;
  readonly location?: string;
  readonly description?: string;
}

const stamp = (d: Date) =>
  d
    .toISOString()
    .replace(/[-:]/g, '')
    .replace(/\.\d{3}/, '');
const esc = (s: string) => s.replace(/[\\;,]/g, (c) => `\\${c}`).replace(/\n/g, '\\n');

/** Builds an .ics file the phone or laptop opens in its own calendar app. */
export function icsText(e: CalendarEvent): string {
  const allDay = /^\d{4}-\d{2}-\d{2}$/.test(e.start);
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Skillmuni//EN',
    'BEGIN:VEVENT',
    `UID:${e.id}@skillmuni`,
  ];
  if (allDay) {
    lines.push(`DTSTART;VALUE=DATE:${e.start.replace(/-/g, '')}`);
  } else {
    const start = new Date(e.start);
    const end = new Date(start.getTime() + (e.minutes ?? 30) * 60_000);
    lines.push(`DTSTART:${stamp(start)}`, `DTEND:${stamp(end)}`);
  }
  lines.push(`SUMMARY:${esc(e.title)}`);
  if (e.location) lines.push(`LOCATION:${esc(e.location)}`);
  if (e.description) lines.push(`DESCRIPTION:${esc(e.description)}`);
  lines.push('END:VEVENT', 'END:VCALENDAR');
  return lines.join('\r\n');
}

export function downloadIcs(e: CalendarEvent): void {
  const url = URL.createObjectURL(new Blob([icsText(e)], { type: 'text/calendar' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `${e.id}.ics`;
  a.click();
  URL.revokeObjectURL(url);
}

/**
 * Day and time as the organiser set them ("10 Oct, 11:00 AM"), read from the ISO string's own
 * offset so an IST interview reads 11:00 AM on any device (A-225).
 */
export function eventWhen(iso: string, withTime = true): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/.exec(iso);
  if (!m) return iso;
  const [, y, mo, d, h, mi] = m;
  const day = new Date(Date.UTC(Number(y), Number(mo) - 1, Number(d))).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    timeZone: 'UTC',
  });
  if (!withTime || h === undefined) return day;
  const hour = Number(h);
  const time = `${hour % 12 || 12}:${mi} ${hour < 12 ? 'AM' : 'PM'}`;
  return `${day}, ${time}`;
}
