import { Signal, effect, signal } from '@angular/core';

/** Loading UI waits this long before appearing, so fast responses never flash a skeleton (A-32). */
export const LOADING_DELAY = 400;

/**
 * True only once `source` has been true for `ms` continuously; false as soon as it turns false.
 * Call in an injection context (component field initialiser).
 */
export function delayed(source: Signal<boolean>, ms = LOADING_DELAY): Signal<boolean> {
  const out = signal(false);
  effect((onCleanup) => {
    if (!source()) {
      out.set(false);
      return;
    }
    const id = setTimeout(() => out.set(true), ms);
    onCleanup(() => clearTimeout(id));
  });
  return out.asReadonly();
}
