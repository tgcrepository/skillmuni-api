import { Component, input } from '@angular/core';
import { Icon } from '../icon/icon';

export type StatusTone = 'success' | 'error' | 'warning' | 'info';

/**
 * Figma: Inputs & Fields → Status Icon (18:22). Solid M (22px) inside inputs; tinted L (28px) in banners
 * and trust notes. Always next to text, so it is decorative (aria-hidden).
 */
@Component({
  selector: 'sm-status-icon',
  imports: [Icon],
  template: `
    @switch (tone()) {
      @case ('success') {
        <sm-icon name="check" size="inherit" />
      }
      @case ('info') {
        <span class="glyph glyph--info"></span>
      }
      @default {
        <span class="glyph glyph--alert"></span>
      }
    }
  `,
  styleUrl: './status-icon.scss',
  host: {
    'aria-hidden': 'true',
    '[class]': '"sm-status-icon sm-status-icon--" + tone() + " sm-status-icon--" + size()',
  },
})
export class StatusIcon {
  readonly tone = input<StatusTone>('success');
  readonly size = input<'m' | 'l'>('m');
}
