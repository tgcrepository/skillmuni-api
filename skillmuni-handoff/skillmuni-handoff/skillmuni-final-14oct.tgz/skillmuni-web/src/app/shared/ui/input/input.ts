import { Component, booleanAttribute, computed, inject, input, model, output } from '@angular/core';
import type { FormValueControl } from '@angular/forms/signals';
import { Icon } from '../icon/icon';
import { IconName } from '../icon/icons';
import { StatusIcon, StatusTone } from '../status-icon/status-icon';
import { FIELD_CONTEXT, FieldStatus } from '../field/field-context';
import { uniqueId } from '../internal/unique-id';

export type InputType = 'text' | 'email' | 'tel' | 'password' | 'search' | 'url' | 'number';

/**
 * Figma: Inputs & Fields → Input (18:131). Text entry only — use inside <sm-field> for label + helper.
 * Height follows layout/control/height (56 desktop/tablet, 52 mobile).
 * States: hover, focus (violet border + halo + orange caret), filled, valid, error, warning,
 * disabled (dashed — dependency not met), read-only (dashed — computed value).
 * Projected content (e.g. an Icon Button) sits at the trailing edge.
 */
@Component({
  selector: 'sm-input',
  imports: [Icon, StatusIcon],
  template: `
    @if (leadingIcon(); as icon) {
      <sm-icon class="lead" [name]="icon" size="inherit" />
    }
    <input
      [id]="id"
      [type]="type()"
      [value]="value()"
      [placeholder]="placeholder()"
      [disabled]="disabled()"
      [readOnly]="readonly()"
      [required]="isRequired()"
      [attr.name]="name() || null"
      [attr.autocomplete]="autocomplete() || null"
      [attr.inputmode]="inputmode() || null"
      [attr.maxlength]="maxLength() ?? null"
      [attr.aria-invalid]="resolvedStatus() === 'error' || null"
      [attr.aria-describedby]="describedBy() || null"
      [attr.aria-label]="ariaLabel() || null"
      (input)="onInput($event)"
      (blur)="touch.emit()"
    />
    <ng-content />
    @if (statusTone(); as tone) {
      <sm-status-icon [tone]="tone" />
    }
  `,
  styleUrl: './input.scss',
  host: {
    '[class]': '"sm-input sm-input--" + resolvedStatus()',
    '[class.is-disabled]': 'disabled()',
    '[class.is-readonly]': 'readonly()',
    '[class.is-filled]': '!!value()',
  },
})
export class Input implements FormValueControl<string> {
  private readonly field = inject(FIELD_CONTEXT, { optional: true });

  readonly value = model('');
  readonly type = input<InputType>('text');
  readonly placeholder = input('');
  readonly disabled = input(false, { transform: booleanAttribute });
  readonly readonly = input(false, { transform: booleanAttribute });
  readonly required = input(false, { transform: booleanAttribute });
  readonly invalid = input(false, { transform: booleanAttribute });
  /**
   * Bound by Signal Forms' [formField]. A required-but-empty field is "invalid" from the start; it only
   * turns red once touched (or when <sm-field> shows an error, e.g. after Next).
   */
  readonly touched = input(true);
  readonly name = input('');
  readonly autocomplete = input('');
  readonly inputmode = input<
    '' | 'text' | 'numeric' | 'tel' | 'email' | 'decimal' | 'search' | 'url'
  >('');
  readonly maxLength = input<number | undefined>(undefined);
  readonly leadingIcon = input<IconName | null>(null);
  /** Only when there is no visible <sm-field> label (e.g. inline search). */
  readonly ariaLabel = input('');
  /** Overrides the status coming from <sm-field>. */
  readonly status = input<FieldStatus | null>(null);
  readonly touch = output<void>();

  protected readonly id = this.field?.controlId ?? uniqueId('input');

  protected readonly resolvedStatus = computed<FieldStatus>(
    () =>
      this.status() ??
      (this.invalid() && this.touched() ? 'error' : (this.field?.status() ?? 'none')),
  );
  protected readonly statusTone = computed<StatusTone | null>(() => {
    const s = this.resolvedStatus();
    return s === 'none' ? null : s === 'valid' ? 'success' : s;
  });
  protected readonly describedBy = computed(() => this.field?.describedBy() ?? '');
  protected readonly isRequired = computed(
    () => this.required() || (this.field?.required() ?? false),
  );

  protected onInput(event: Event): void {
    this.value.set((event.target as HTMLInputElement).value);
  }
}
