import { Component, booleanAttribute, input, model, output } from '@angular/core';
import type { FormCheckboxControl } from '@angular/forms/signals';

/**
 * Figma: Selection Controls → Switch (16:83). 44 × 26, on = Arcane gradient.
 * Immediate on/off settings ("I still work here", "Show on Player Card").
 * Use Checkbox when the change only applies after a submit.
 * Native checkbox with role="switch".
 */
@Component({
  selector: 'sm-switch',
  template: `
    <label class="row">
      <span class="label"><ng-content /></span>
      <span class="track">
        <input
          type="checkbox"
          role="switch"
          [checked]="checked()"
          [disabled]="disabled()"
          [attr.aria-checked]="checked()"
          [attr.aria-describedby]="describedBy() || null"
          [attr.name]="name() || null"
          (change)="onChange($event)"
          (blur)="touch.emit()"
        />
        <span class="thumb" aria-hidden="true"></span>
      </span>
    </label>
  `,
  styleUrl: './switch.scss',
  host: {
    class: 'sm-switch',
    '[class.is-on]': 'checked()',
    '[class.is-disabled]': 'disabled()',
    '[class.is-label-end]': 'labelPosition() === "end"',
  },
})
export class Switch implements FormCheckboxControl {
  readonly checked = model(false);
  readonly disabled = input(false, { transform: booleanAttribute });
  readonly name = input('');
  readonly describedBy = input('');
  /** "end" puts the switch first and the label after it (Figma V2 consent list). */
  readonly labelPosition = input<'start' | 'end'>('start');
  readonly touch = output<void>();

  protected onChange(event: Event): void {
    this.checked.set((event.target as HTMLInputElement).checked);
  }
}
