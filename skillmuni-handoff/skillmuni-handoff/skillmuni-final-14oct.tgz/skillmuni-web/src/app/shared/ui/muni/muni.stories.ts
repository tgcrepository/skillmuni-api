import type { Meta, StoryObj } from '@storybook/angular-vite';
import { MuniTip } from './muni-tip';
import { MuniCharacter } from './muni-character';
import { MuniAvatar } from './muni-avatar';
import { SpeechBubble } from './speech-bubble';

const meta: Meta = {
  title: 'Composites/Muni',
  parameters: {
    figma: { node: 'Speech Bubble 28:29 · Muni Tip 28:419 · Avatar 28:4 · Character 28:2' },
    layout: 'padded',
  },
  decorators: [
    (story) => ({
      ...story(),
      moduleMetadata: { imports: [MuniTip, MuniCharacter, MuniAvatar, SpeechBubble] },
    }),
  ],
};
export default meta;

export const Bubbles: StoryObj = {
  render: () => ({
    template: `
      <div style="display:grid;grid-template-columns:repeat(2,var(--sm-layout-shell-map-width));gap:var(--sm-space-1200) var(--sm-space-1600);padding:var(--sm-space-400)">
        <sm-speech-bubble>Heyyy! Let’s start easy. What should we call you, bestie?</sm-speech-bubble>
        <sm-speech-bubble exclamation="Slay, Yash!">Heyyy! Let’s start easy. What should we call you, bestie?</sm-speech-bubble>
        <sm-speech-bubble tail="left">Heyyy! Let’s start easy. What should we call you, bestie?</sm-speech-bubble>
        <sm-speech-bubble tail="left" exclamation="Slay, Yash!">Heyyy! Let’s start easy. What should we call you, bestie?</sm-speech-bubble>
        <sm-speech-bubble tail="none">Heyyy! Let’s start easy. What should we call you, bestie?</sm-speech-bubble>
      </div>`,
  }),
};

export const TipAndCharacter: StoryObj = {
  render: () => ({
    template: `
      <div style="display:grid;gap:var(--sm-space-800);inline-size:var(--sm-layout-shell-rail-width)">
        <sm-muni-tip>Heyyy! Let’s start easy. What should we call you, bestie?</sm-muni-tip>
        <div style="display:flex;gap:var(--sm-space-400);align-items:center">
          <sm-muni-avatar [size]="32" /><sm-muni-avatar [size]="40" /><sm-muni-avatar [size]="56" />
        </div>
        <sm-muni-character />
      </div>`,
  }),
};
