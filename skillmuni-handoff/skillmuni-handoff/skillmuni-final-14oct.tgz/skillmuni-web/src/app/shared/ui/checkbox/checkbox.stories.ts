import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Checkbox } from './checkbox';
import { Switch } from '../switch/switch';
import { Radio } from '../radio/radio';
import { RadioGroup } from '../radio/radio-group';

const meta: Meta = {
  title: 'Primitives/Selection controls',
  parameters: { figma: { node: 'Checkbox 16:60 · Radio 16:70 · Switch 16:83' } },
};
export default meta;

export const Checkboxes: StoryObj = {
  render: () => ({
    template: `
      <div style="display:grid;gap:var(--sm-space-400)">
        <sm-checkbox>Make it a signature move</sm-checkbox>
        <sm-checkbox [checked]="true">I agree to Skillmuni reading my CV</sm-checkbox>
        <sm-checkbox indeterminate>Select all</sm-checkbox>
        <sm-checkbox disabled>Disabled</sm-checkbox>
        <sm-checkbox disabled [checked]="true">Disabled checked</sm-checkbox>
        <sm-checkbox invalid>Tick the box so Muni can read your CV</sm-checkbox>
      </div>`,
    moduleMetadata: { imports: [Checkbox] },
  }),
};

export const Radios: StoryObj = {
  render: () => ({
    props: { value: 'degree' },
    template: `
      <sm-radio-group [(value)]="value" ariaLabel="Highest level">
        <sm-radio value="matric">Matric (NSC)</sm-radio>
        <sm-radio value="degree">Degree</sm-radio>
        <sm-radio value="phd" disabled>PhD</sm-radio>
      </sm-radio-group>`,
    moduleMetadata: { imports: [RadioGroup, Radio] },
  }),
};

export const Switches: StoryObj = {
  render: () => ({
    template: `
      <div style="display:grid;gap:var(--sm-space-200)">
        <sm-switch>I still work here</sm-switch>
        <sm-switch [checked]="true">Show on Player Card</sm-switch>
        <sm-switch disabled>Disabled</sm-switch>
        <sm-switch disabled [checked]="true">Disabled on</sm-switch>
      </div>`,
    moduleMetadata: { imports: [Switch] },
  }),
};
