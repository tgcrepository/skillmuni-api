import { Component, input } from '@angular/core';
import { Icon } from '../icon/icon';

export type StepState = 'upcoming' | 'current' | 'done';

/** Figma: Progress & Game HUD → Step Status (24:41). 20px marker: upcoming (empty), current (Ember dot), done (green check). */
@Component({
  selector: 'sm-step-status',
  imports: [Icon],
  template: `
    @if (status() === 'done') {
      <sm-icon name="check" size="inherit" />
    } @else if (status() === 'current') {
      <span class="dot"></span>
    }
  `,
  styleUrl: './step-status.scss',
  host: { '[class]': '"sm-step-status sm-step-status--" + status()', 'aria-hidden': 'true' },
})
export class StepStatus {
  readonly status = input<StepState>('upcoming');
}
