import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ChipGroup, ChipOption } from './chip-group';

const OPTIONS: ChipOption[] = [
  { value: 'f', label: 'Female' },
  { value: 'm', label: 'Male' },
  { value: 'x', label: 'Rather not say' },
];

@Component({
  imports: [ChipGroup],
  template: `
    <sm-chip-group [options]="options" [(value)]="single" ariaLabel="Gender" />
    <sm-chip-group
      [options]="options"
      [(value)]="multi"
      multiple
      ariaLabel="Work types"
      addMoreLabel="Add more"
      (addMore)="added = added + 1"
    />
  `,
})
class Host {
  readonly options = OPTIONS;
  readonly single = signal<string | string[] | null>(null);
  readonly multi = signal<string | string[] | null>(['m']);
  added = 0;
}

describe('ChipGroup', () => {
  function setup() {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const [single, multi] = fixture.nativeElement.querySelectorAll(
      'sm-chip-group',
    ) as NodeListOf<HTMLElement>;
    return { fixture, host: fixture.componentInstance, single: single!, multi: multi! };
  }

  it('single mode is a radiogroup of radios', () => {
    const { fixture, host, single } = setup();
    expect(single.getAttribute('role')).toBe('radiogroup');
    const inputs = single.querySelectorAll('input');
    expect(inputs[0]!.type).toBe('radio');
    inputs[2]!.click();
    fixture.detectChanges();
    expect(host.single()).toBe('x');
    expect(single.querySelectorAll('.is-selected')).toHaveLength(1);
  });

  it('multi mode toggles values and keeps option order', () => {
    const { fixture, host, multi } = setup();
    expect(multi.getAttribute('role')).toBe('group');
    const inputs = multi.querySelectorAll('input');
    inputs[0]!.click();
    fixture.detectChanges();
    expect(host.multi()).toEqual(['f', 'm']);
    inputs[1]!.click();
    fixture.detectChanges();
    expect(host.multi()).toEqual(['f']);
  });

  it('emits addMore from the dashed chip', () => {
    const { fixture, host, multi } = setup();
    (multi.querySelector('.chip--add') as HTMLButtonElement).click();
    fixture.detectChanges();
    expect(host.added).toBe(1);
  });
});
