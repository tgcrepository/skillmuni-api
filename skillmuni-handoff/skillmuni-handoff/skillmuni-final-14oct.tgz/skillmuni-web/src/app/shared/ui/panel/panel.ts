import { Component, input } from '@angular/core';

export type PanelVariant = 'glass' | 'glass-muted' | 'raised' | 'inset';

/**
 * Figma: Cards & Overlays → Panel (30:49). The surface system as a container.
 * Glass = main Quest card (padding/gap/radius from layout/panel/*, tighter on mobile) ·
 * Glass Muted = side rails · Raised = opaque popovers · Inset = recessed wells inside cards.
 */
@Component({
  selector: 'sm-panel',
  template: `<ng-content />`,
  styleUrl: './panel.scss',
  host: { '[class]': '"sm-panel sm-panel--" + variant()' },
})
export class Panel {
  readonly variant = input<PanelVariant>('glass');
}
