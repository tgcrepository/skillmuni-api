import { Dialog, DialogConfig, DialogRef } from '@angular/cdk/dialog';
import { BreakpointObserver } from '@angular/cdk/layout';
import { ComponentType } from '@angular/cdk/portal';
import { InjectionToken, Service, TemplateRef, inject } from '@angular/core';

export type OverlayKind = 'modal' | 'sheet' | 'drawer';

export interface OverlayOptions<D> {
  readonly data?: D;
  /** Accessible name (id of the visible title element is wired by <sm-modal>/<sm-sheet>). */
  readonly ariaLabel?: string;
  /** Critical overlays (e.g. session expired) ignore scrim clicks and Esc. Default false. */
  readonly critical?: boolean;
  /**
   * Modal width: 'md' 640 (Quest Complete) · 'sm' 480 (confirmations) · 'lg' wide.
   * 'full': the whole screen at every size, e.g. Privacy Policy & Terms (corrections #3).
   */
  readonly size?: 'sm' | 'md' | 'lg' | 'full';
  /** What gets focus on open: a CSS selector inside the overlay, or the default first tabbable element. */
  readonly autoFocus?: string;
}

const MOBILE = '(max-width: 767.98px)';

/** Lets <sm-dialog> render as a sheet or a modal. */
export const OVERLAY_KIND = new InjectionToken<OverlayKind>('OVERLAY_KIND');

/**
 * Opens modals and bottom sheets on top of a Scrim (Figma 31:182) using Angular CDK Dialog:
 * focus is trapped and restored, the rest of the page is inert, aria-modal is set,
 * Esc and scrim click close non-critical overlays.
 * `adaptive()` follows the Figma rule: Bottom Sheet on mobile, Modal on tablet/desktop.
 */
@Service()
export class OverlayService {
  private readonly dialog = inject(Dialog);
  private readonly breakpoints = inject(BreakpointObserver);

  modal<C, D = unknown, R = unknown>(
    content: ComponentType<C> | TemplateRef<C>,
    options: OverlayOptions<D> = {},
  ): DialogRef<R, C> {
    return this.open<C, D, R>('modal', content, options);
  }

  sheet<C, D = unknown, R = unknown>(
    content: ComponentType<C> | TemplateRef<C>,
    options: OverlayOptions<D> = {},
  ): DialogRef<R, C> {
    return this.open<C, D, R>('sheet', content, options);
  }

  adaptive<C, D = unknown, R = unknown>(
    content: ComponentType<C> | TemplateRef<C>,
    options: OverlayOptions<D> = {},
  ): DialogRef<R, C> {
    return this.open<C, D, R>(this.isMobile() ? 'sheet' : 'modal', content, options);
  }

  /** Side drawer on tablet/desktop (e.g. All filters, Figma 274:24332); bottom sheet on mobile. */
  drawer<C, D = unknown, R = unknown>(
    content: ComponentType<C> | TemplateRef<C>,
    options: OverlayOptions<D> = {},
  ): DialogRef<R, C> {
    return this.open<C, D, R>(this.isMobile() ? 'sheet' : 'drawer', content, options);
  }

  /** Full-screen reading view at every size (corrections #3). Esc and the close button dismiss it. */
  fullscreen<C, D = unknown, R = unknown>(
    content: ComponentType<C> | TemplateRef<C>,
    options: OverlayOptions<D> = {},
  ): DialogRef<R, C> {
    return this.open<C, D, R>('modal', content, { ...options, size: 'full' });
  }

  isMobile(): boolean {
    return this.breakpoints.isMatched(MOBILE);
  }

  private open<C, D, R>(
    kind: OverlayKind,
    content: ComponentType<C> | TemplateRef<C>,
    options: OverlayOptions<D>,
  ): DialogRef<R, C> {
    const config: DialogConfig<D, DialogRef<R, C>> = {
      data: options.data,
      ariaLabel: options.ariaLabel ?? null,
      ariaModal: true,
      disableClose: true,
      autoFocus: options.autoFocus ?? 'first-tabbable',
      restoreFocus: true,
      hasBackdrop: true,
      backdropClass: 'sm-scrim',
      panelClass: ['sm-pane', `sm-pane--${kind}`, `sm-pane--${options.size ?? 'md'}`],
      providers: [{ provide: OVERLAY_KIND, useValue: kind }],
    };
    const ref = this.dialog.open<R, D, C>(content, config);
    if (!options.critical) {
      ref.backdropClick.subscribe(() => requestClose(ref));
      ref.keydownEvents.subscribe((e) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          requestClose(ref);
        }
      });
    }
    return ref;
  }
}

const guards = new WeakMap<object, () => boolean>();

/**
 * Ask before a dismiss (Esc, scrim, close button, drag) — e.g. "Discard this trophy?". The guard returns
 * true to allow closing. Closing with a result (Save) is never guarded.
 */
export function guardClose<R, C>(ref: DialogRef<R, C>, allow: () => boolean): void {
  guards.set(ref, allow);
}

/**
 * Plays the leave animation, then closes. Panes listen for the `sm-leaving` class.
 * Reduced-motion users get ~1ms animations, so this resolves immediately.
 */
export function requestClose<R, C>(ref: DialogRef<R, C>, result?: R): void {
  const guard = guards.get(ref);
  if (result === undefined && guard && !guard()) return;
  const pane = ref.overlayRef.overlayElement;
  if (pane.classList.contains('sm-leaving')) return;
  pane.classList.add('sm-leaving');
  ref.overlayRef.backdropElement?.classList.add('sm-leaving');
  const done = () => ref.close(result);
  // Ignore looping decoration (e.g. reveal rays): only finite leave animations are awaited.
  const animations = (
    typeof pane.getAnimations === 'function' ? pane.getAnimations({ subtree: true }) : []
  ).filter((a) => a.effect?.getComputedTiming().iterations !== Infinity);
  if (!animations.length) {
    done();
    return;
  }
  Promise.all(animations.map((a) => a.finished)).then(done, done);
}
