import type { Meta, StoryObj } from '@storybook/angular-vite';
import { applicationConfig } from '@storybook/angular-vite';
import { Component, inject, signal } from '@angular/core';
import { Connectivity } from '../../../core/network/connectivity';
import { OfflineBanner } from '../../shell/offline-banner';
import { Button } from '../button/button';
import { MuniPrompt, MuniPromptData } from '../muni-prompt/muni-prompt';
import { OverlayService } from '../overlay/overlay.service';
import { Skeleton } from '../skeleton/skeleton';
import { StateBlock } from './state-block';

@Component({
  selector: 'sm-prompts-demo',
  imports: [Button],
  template: `
    <div style="display:flex;gap:var(--sm-space-300);flex-wrap:wrap">
      <button sm-button type="button" (click)="open(se1, true)">SE1 Session expired</button>
      <button sm-button variant="secondary" type="button" (click)="open(pm1)">PM1 Camera</button>
      <button sm-button variant="secondary" type="button" (click)="open(pm2)">
        PM2 Notifications
      </button>
    </div>
  `,
})
class PromptsDemo {
  private readonly overlay = inject(OverlayService);
  readonly se1: MuniPromptData = {
    title: 'You’ve been logged out',
    body: 'For your safety we log you out after 30 minutes away. Your answers are saved — log in to carry on from Big Brain Stuff.',
    primary: 'Log in again',
    dismissible: false,
  };
  readonly pm1: MuniPromptData = {
    title: 'Snap your CV with the camera?',
    body: 'Skillmuni needs your camera to take a photo of your printed CV. We only use it to read the CV — you can delete the photo anytime.',
    primary: 'Allow camera',
    secondary: 'Upload a file instead',
  };
  readonly pm2: MuniPromptData = {
    title: 'Want a ping when Muni’s done?',
    body: 'We’ll only notify you about your CV, quests and job matches. Turn it off anytime in Settings.',
    primary: 'Turn on notifications',
    secondary: 'Not now',
  };

  open(data: MuniPromptData, critical = false): void {
    this.overlay.adaptive(MuniPrompt, { data, critical, size: 'sm' });
  }
}

const meta: Meta = {
  title: 'Patterns/Global states',
  parameters: {
    figma: {
      node: 'SE1 203:9762 · PM1 203:8534 · PM2 203:8988 · OF1 200:30585 · MM1 204:8692 · MM3 204:9085',
    },
    layout: 'padded',
  },
};
export default meta;

export const Prompts: StoryObj = {
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [PromptsDemo] } })],
  render: () => ({ template: `<sm-prompts-demo />` }),
};

export const ErrorAndEmpty: StoryObj = {
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [StateBlock, Button] } })],
  render: () => ({
    template: `
      <div style="display:grid;gap:var(--sm-space-600);max-inline-size:var(--sm-size-modal-width)">
        <sm-state-block title="Couldn’t load your matches" body="Check your connection and try again. Your profile is safe.">
          <button sm-button smStateAction type="button">Try again</button>
        </sm-state-block>
        <sm-state-block kind="empty" title="No matches yet" body="Finish your quests and Muni will start matching you with jobs." />
        <sm-state-block kind="no-permission" title="This one’s locked for now" body="Take the skills assessment to see your matches." />
      </div>`,
  }),
};

export const SkeletonCard: StoryObj = {
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [Skeleton] } })],
  render: () => ({
    template: `
      <div aria-busy="true" style="display:grid;gap:var(--sm-space-300);padding:var(--sm-space-500);max-inline-size:var(--sm-size-modal-width-sm);border:var(--sm-stroke-sm) solid var(--sm-color-border-subtle);border-radius:var(--sm-radius-4xl);background:var(--sm-color-surface-panel)">
        <span class="sm-visually-hidden">Loading your matches…</span>
        <sm-skeleton width="55%" />
        <sm-skeleton width="85%" />
        <sm-skeleton width="40%" />
        <sm-skeleton shape="pill" width="70%" />
        <sm-skeleton shape="block" />
      </div>`,
  }),
};

export const OfflineBannerStory: StoryObj = {
  name: 'Offline banner',
  decorators: [
    applicationConfig({
      providers: [{ provide: Connectivity, useValue: { online: signal(false) } }],
    }),
    (story) => ({ ...story(), moduleMetadata: { imports: [OfflineBanner] } }),
  ],
  render: () => ({
    template: `<div style="min-block-size: var(--sm-size-modal-width-sm)"><sm-offline-banner /></div>`,
  }),
};
