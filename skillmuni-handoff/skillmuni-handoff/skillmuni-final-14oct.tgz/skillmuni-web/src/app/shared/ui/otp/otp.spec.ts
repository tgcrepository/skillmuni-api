import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Otp, OtpStatus } from './otp';

@Component({
  imports: [Otp],
  template: `<sm-otp
    [(value)]="code"
    [status]="status()"
    ariaLabel="6-digit code"
    (completed)="done = $event"
  />`,
})
class Host {
  readonly code = signal('');
  readonly status = signal<OtpStatus>('none');
  done = '';
}

describe('Otp', () => {
  function setup() {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    return {
      fixture,
      host: fixture.componentInstance,
      el,
      input: el.querySelector('input') as HTMLInputElement,
    };
  }

  it('is a single one-time-code field for assistive tech and autofill', () => {
    const { el, input } = setup();
    expect(input.getAttribute('autocomplete')).toBe('one-time-code');
    expect(input.getAttribute('inputmode')).toBe('numeric');
    expect(el.querySelector('.boxes')!.getAttribute('aria-hidden')).toBe('true');
    expect(el.querySelectorAll('.box')).toHaveLength(6);
  });

  it('accepts a pasted code, strips non-digits and emits completed', () => {
    const { fixture, host, el, input } = setup();
    input.value = '12-34 56';
    input.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(host.code()).toBe('123456');
    expect(host.done).toBe('123456');
    expect([...el.querySelectorAll('.box')].map((b) => b.textContent!.trim()).join('')).toBe(
      '123456',
    );
  });

  it('reflects the error state on the host', () => {
    const { fixture, host, el, input } = setup();
    host.status.set('error');
    fixture.detectChanges();
    expect(el.querySelector('sm-otp')!.classList).toContain('sm-otp--error');
    expect(input.getAttribute('aria-invalid')).toBe('true');
  });
});
