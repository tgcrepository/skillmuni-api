import { Component, booleanAttribute, input } from '@angular/core';
import { MuniAvatar } from './muni-avatar';
import { SpeechBubble } from './speech-bubble';

/**
 * Figma: Muni → Muni Tip (28:419). Mobile/tablet placement: avatar + left-tail bubble,
 * full width above the Quest card. `live` announces message changes politely.
 */
@Component({
  selector: 'sm-muni-tip',
  imports: [MuniAvatar, SpeechBubble],
  template: `
    <sm-muni-avatar />
    <sm-speech-bubble tail="left" [exclamation]="exclamation()"><ng-content /></sm-speech-bubble>
  `,
  styles: `
    :host {
      display: flex;
      align-items: flex-start;
      gap: var(--sm-space-400);
    }

    sm-speech-bubble {
      flex: 1 1 0;
    }
  `,
  host: { class: 'sm-muni-tip', role: 'note', '[attr.aria-live]': 'live() ? "polite" : null' },
})
export class MuniTip {
  readonly exclamation = input('');
  readonly live = input(false, { transform: booleanAttribute });
}
