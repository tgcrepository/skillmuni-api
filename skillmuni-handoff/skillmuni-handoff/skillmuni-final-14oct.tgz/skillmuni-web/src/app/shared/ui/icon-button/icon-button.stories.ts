import type { Meta, StoryObj } from '@storybook/angular-vite';
import { IconButton } from './icon-button';

const meta: Meta<IconButton> = {
  title: 'Primitives/Icon Button',
  component: IconButton,
  parameters: { figma: { node: '12:223' } },
  args: { icon: 'edit', label: 'Edit', tone: 'neutral', size: 44, disabled: false },
  argTypes: {
    tone: { control: 'inline-radio', options: ['neutral', 'ghost'] },
    size: { control: 'inline-radio', options: [44, 36] },
  },
  render: (args) => ({
    props: args,
    template: `<button sm-icon-button [icon]="icon" [label]="label" [tone]="tone" [size]="size" [disabled]="disabled"></button>`,
  }),
};
export default meta;
type Story = StoryObj<IconButton>;

export const Playground: Story = {};
export const AllVariants: Story = {
  render: () => ({
    template: `
      <div style="display:grid;grid-template-columns:repeat(2,max-content);gap:var(--sm-space-600)">
        @for (s of [44, 36]; track s) {
          @for (t of ['neutral','ghost']; track t) {
            <div style="display:flex;gap:var(--sm-space-400)">
              <button sm-icon-button icon="edit" label="Edit" [tone]="$any(t)" [size]="$any(s)"></button>
              <button sm-icon-button icon="edit" label="Edit" [tone]="$any(t)" [size]="$any(s)" disabled></button>
            </div>
          }
        }
      </div>`,
    moduleMetadata: { imports: [IconButton] },
  }),
};
