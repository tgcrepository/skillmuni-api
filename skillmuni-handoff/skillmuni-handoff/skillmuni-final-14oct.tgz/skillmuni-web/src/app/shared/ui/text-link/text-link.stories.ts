import type { Meta, StoryObj } from '@storybook/angular-vite';
import { TextLink } from './text-link';

const meta: Meta<TextLink> = {
  title: 'Primitives/Text Link',
  component: TextLink,
  parameters: { figma: { node: '12:236' } },
  args: { tone: 'brand' },
  argTypes: { tone: { control: 'inline-radio', options: ['brand', 'accent'] } },
  render: (args) => ({
    props: args,
    template: `<a sm-text-link [tone]="tone" href="#">Forgot it? Happens to the best of us</a>`,
  }),
};
export default meta;
export const Playground: StoryObj<TextLink> = {};
