import { Component, DestroyRef, PLATFORM_ID, effect, inject, input, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

/**
 * Number that counts up from 0 when it first shows (Leaderboard handoff: 600 ms).
 * Screen readers get the final value straight away; reduced motion skips the animation.
 */
@Component({
  selector: 'sm-count-up',
  template: `<span aria-hidden="true">{{ shown() }}</span
    ><span class="sm-visually-hidden">{{ value() }}</span>`,
  host: { class: 'sm-count-up' },
  styles: `
    :host {
      font-variant-numeric: tabular-nums;
    }
  `,
})
export class CountUp {
  readonly value = input.required<number>();
  readonly duration = input(600);

  protected readonly shown = signal(0);
  private frame = 0;
  private readonly browser = isPlatformBrowser(inject(PLATFORM_ID));

  constructor() {
    inject(DestroyRef).onDestroy(() => cancelAnimationFrame(this.frame));
    effect(() => {
      const target = this.value();
      const reduce =
        !this.browser ||
        typeof matchMedia === 'undefined' ||
        typeof requestAnimationFrame === 'undefined' ||
        matchMedia('(prefers-reduced-motion: reduce)').matches;
      cancelAnimationFrame(this.frame);
      if (reduce || target === 0) {
        this.shown.set(target);
        return;
      }
      const from = this.shown();
      const total = this.duration();
      let start = 0;
      const step = (t: number) => {
        start ||= t;
        const p = Math.min(1, (t - start) / total);
        const eased = 1 - (1 - p) ** 3;
        this.shown.set(Math.round(from + (target - from) * eased));
        if (p < 1) this.frame = requestAnimationFrame(step);
      };
      this.frame = requestAnimationFrame(step);
    });
  }
}
