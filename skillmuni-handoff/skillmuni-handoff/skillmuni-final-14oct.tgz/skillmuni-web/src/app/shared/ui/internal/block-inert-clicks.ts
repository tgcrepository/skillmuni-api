import { DestroyRef, ElementRef, inject } from '@angular/core';

/**
 * Stops clicks on the host before any (click) listener runs while `isInert()` is true.
 * Used by controls that use aria-disabled instead of the native `disabled` attribute,
 * so they stay focusable and readable by screen readers.
 * Must be called in an injection context (field initialiser or constructor).
 */
export function blockInertClicks(isInert: () => boolean): void {
  const el = inject(ElementRef).nativeElement as HTMLElement;
  const handler = (event: Event) => {
    if (isInert()) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  };
  el.addEventListener('click', handler, { capture: true });
  inject(DestroyRef).onDestroy(() => el.removeEventListener('click', handler, { capture: true }));
}
