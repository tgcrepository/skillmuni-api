import type { Meta, StoryObj } from '@storybook/angular-vite';
import { XpHud } from './xp-hud';
import { SectionStepper } from './section-stepper';
import { SkillChip } from './skill-chip';
import { PowerMeter } from './power-meter';
import { LevelOrb } from './level-orb';
import { StepStatus } from './step-status';
import { OptionCards } from '../option-card/option-cards';

const meta: Meta = {
  title: 'Composites/Game HUD',
  parameters: {
    figma: {
      node: 'XP HUD 26:18 · Stepper 26:354 · Skill Chip 26:73 · Power Meter 24:58 · Option Card 16:202',
    },
    layout: 'padded',
  },
  decorators: [
    (story) => ({
      ...story(),
      moduleMetadata: {
        imports: [XpHud, SectionStepper, SkillChip, PowerMeter, LevelOrb, StepStatus, OptionCards],
      },
    }),
  ],
};
export default meta;

export const Hud: StoryObj = {
  render: () => ({
    props: {
      steps: [
        { label: 'Name', answered: 1, total: 2 },
        { label: 'ID & bday', answered: 0, total: 2, xp: '+20 XP' },
        { label: 'The tea', answered: 0, total: 3, xp: '+20 XP' },
      ],
    },
    template: `
      <div style="display:grid;gap:var(--sm-space-1000);max-inline-size:var(--sm-layout-shell-card-max-width)">
        <div style="display:flex;gap:var(--sm-space-1200);align-items:center">
          <sm-xp-hud [level]="1" rank="Rookie" [xp]="50" [target]="400" />
          <sm-xp-hud [level]="1" rank="Rookie" [xp]="50" [target]="400" layout="compact" />
        </div>
        <sm-section-stepper [steps]="steps" [current]="0" />
        <sm-section-stepper [steps]="steps" [current]="1" />
        <div style="display:flex;gap:var(--sm-space-300);flex-wrap:wrap">
          <sm-skill-chip skill="Communication" [level]="2" />
          <sm-skill-chip skill="Communication" kind="signature" [level]="3" />
          <sm-skill-chip skill="Communication" kind="unset" />
        </div>
        <div style="display:flex;gap:var(--sm-space-600);align-items:center">
          <sm-power-meter [level]="0" /><sm-power-meter [level]="1" /><sm-power-meter [level]="2" /><sm-power-meter [level]="3" />
          <sm-level-orb [level]="1" /><sm-level-orb [level]="2" size="m" /><sm-level-orb [level]="3" size="s" />
          <sm-step-status /><sm-step-status status="current" /><sm-step-status status="done" />
        </div>
      </div>`,
  }),
};

export const OptionCardGrid: StoryObj = {
  render: () => ({
    props: {
      items: [
        { value: 'ft', title: 'Full-time job', code: 'FT', description: '30+ hours a week' },
        { value: 'pt', title: 'Part-time', code: 'PT', description: 'Under 30 hours' },
        { value: 'in', title: 'Internship', code: 'IN', description: 'Paid or unpaid' },
        {
          value: 'gig',
          title: 'Gig / freelance',
          code: 'GG',
          description: 'Side hustles count',
          disabled: true,
        },
        {
          value: 'fresher',
          title: 'Not yet, I’m a fresher',
          description: 'Totally fine, skip ahead',
          optOut: true,
        },
      ],
      value: ['in'],
    },
    template: `<div style="max-inline-size:var(--sm-layout-shell-card-max-width)"><sm-option-cards [items]="items" [(value)]="value" ariaLabel="Work types" /></div>`,
  }),
};
