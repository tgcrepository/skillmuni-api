import type { Meta, StoryObj } from '@storybook/angular-vite';
import { ChipGroup } from './chip-group';

const options = [
  { value: 'f', label: 'Female' },
  { value: 'm', label: 'Male' },
  { value: 'nb', label: 'Non-binary' },
  { value: 'x', label: 'Rather not say' },
  { value: 'z', label: 'Unavailable', disabled: true },
];

const meta: Meta<ChipGroup> = {
  title: 'Primitives/Chip group',
  component: ChipGroup,
  parameters: { figma: { node: '16:38' } },
};
export default meta;

export const Single: StoryObj<ChipGroup> = {
  render: () => ({
    props: { options, value: 'x' },
    template: `<sm-chip-group [options]="options" [(value)]="value" ariaLabel="Gender" />`,
    moduleMetadata: { imports: [ChipGroup] },
  }),
};

export const MultipleWithAddMore: StoryObj<ChipGroup> = {
  render: () => ({
    props: { options, value: ['f', 'nb'] },
    template: `<sm-chip-group [options]="options" [(value)]="value" multiple addMoreLabel="+ Add more" ariaLabel="Work types" />`,
    moduleMetadata: { imports: [ChipGroup] },
  }),
};
