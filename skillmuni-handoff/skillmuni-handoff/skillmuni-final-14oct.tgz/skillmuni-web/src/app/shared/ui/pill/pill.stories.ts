import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Pill } from './pill';

const meta: Meta<Pill> = {
  title: 'Primitives/Pill',
  component: Pill,
  parameters: { figma: { node: '14:77' } },
};
export default meta;

export const AllVariants: StoryObj<Pill> = {
  render: () => ({
    template: `
      <div style="display:grid;gap:var(--sm-space-400)">
        @for (s of ['m','s']; track s) {
          <div style="display:flex;gap:var(--sm-space-400);align-items:center">
            @for (t of ['accent','brand','inset','success','neutral']; track t) {
              <sm-pill [tone]="$any(t)" [size]="$any(s)">+50 XP when you’re done</sm-pill>
            }
          </div>
        }
        <div style="display:flex;gap:var(--sm-space-400)">
          <sm-pill tone="brand" icon="sparkle">Speedrun</sm-pill>
          <sm-pill tone="success" dot>Live</sm-pill>
          <sm-pill tone="neutral" size="s">8 of 15</sm-pill>
        </div>
      </div>`,
    moduleMetadata: { imports: [Pill] },
  }),
};
