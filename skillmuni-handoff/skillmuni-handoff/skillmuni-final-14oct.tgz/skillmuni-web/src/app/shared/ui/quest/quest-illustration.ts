import { NgOptimizedImage } from '@angular/common';
import { signal } from '@angular/core';
import { Component, computed, input } from '@angular/core';
import { ASSETS } from '../../assets';

/**
 * Figma: Navigation → Quest Illustration (26:448). 3D quest badge art, 56 × 70, scales proportionally.
 * Decorative — the quest name is always shown as text next to it.
 */
@Component({
  imports: [NgOptimizedImage],
  selector: 'sm-quest-illustration',
  template: `<img
    [ngSrc]="src()"
    alt=""
    width="56"
    height="70"
    (error)="missing.set(true)"
    [class.is-missing]="missing()"
  />`,
  styles: `
    :host {
      display: block;
      flex: none;
      inline-size: var(--sm-size-quest-art-width);
      aspect-ratio: 56 / 70;
    }

    /* Artwork not shipped yet: keep the slot visible so the lineup still reads as 8 quests */
    :host(.is-placeholder) {
      border-radius: var(--sm-radius-lg);
      background: var(--sm-color-surface-inset-strong);
    }

    img {
      inline-size: 100%;
      block-size: 100%;
      object-fit: contain;
    }
  `,
  host: {
    class: 'sm-quest-illustration',
    'aria-hidden': 'true',
    '[class.is-placeholder]': 'missing()',
  },
})
export class QuestIllustration {
  protected readonly missing = signal(false);
  readonly quest = input.required<number>();
  protected readonly src = computed(() => ASSETS.quest(this.quest()));
}
