import { Component, inject } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { OverlayService } from './overlay.service';
import { SmDialog } from './dialog';
import { Button } from '../button/button';

@Component({
  imports: [SmDialog, Button],
  template: `
    <sm-dialog title="Who are they to you?" subtitle="Pick one. You can change it later.">
      <p>Options</p>
      <div smDialogActions><button sm-button>Done</button></div>
    </sm-dialog>
  `,
})
class Content {}

@Component({ template: '' })
class Host {
  readonly overlays = inject(OverlayService);
}

describe('OverlayService + sm-dialog', () => {
  const pane = () => document.querySelector('.cdk-overlay-pane') as HTMLElement | null;

  afterEach(() => document.querySelector('.cdk-overlay-container')?.replaceChildren());

  it('opens a labelled, modal dialog over a scrim', async () => {
    const fixture = TestBed.createComponent(Host);
    fixture.componentInstance.overlays.modal(Content);
    fixture.detectChanges();
    await fixture.whenStable();
    const dialog = document.querySelector('[role="dialog"]') as HTMLElement;
    expect(dialog.getAttribute('aria-modal')).toBe('true');
    expect(document.querySelector('.sm-scrim')).not.toBeNull();
    expect(pane()!.classList).toContain('sm-pane--modal');
    const titleId = dialog.getAttribute('aria-labelledby')!;
    expect(document.getElementById(titleId)!.textContent).toContain('Who are they to you?');
  });

  it('renders as a sheet with a grabber when opened as a sheet', async () => {
    const fixture = TestBed.createComponent(Host);
    fixture.componentInstance.overlays.sheet(Content);
    fixture.detectChanges();
    await fixture.whenStable();
    expect(pane()!.classList).toContain('sm-pane--sheet');
    expect(document.querySelector('sm-dialog')!.classList).toContain('sm-dialog--sheet');
    expect(document.querySelector('.grabber')).not.toBeNull();
  });

  it('closes on Escape unless critical', async () => {
    const fixture = TestBed.createComponent(Host);
    const ref = fixture.componentInstance.overlays.modal(Content);
    fixture.detectChanges();
    await fixture.whenStable();
    let closed = false;
    ref.closed.subscribe(() => (closed = true));
    document
      .querySelector('[role="dialog"]')!
      .dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    await new Promise((r) => setTimeout(r, 0));
    expect(closed).toBe(true);

    const critical = fixture.componentInstance.overlays.modal(Content, { critical: true });
    fixture.detectChanges();
    await fixture.whenStable();
    let criticalClosed = false;
    critical.closed.subscribe(() => (criticalClosed = true));
    document
      .querySelector('[role="dialog"]')!
      .dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    await new Promise((r) => setTimeout(r, 0));
    expect(criticalClosed).toBe(false);
  });
});
