import { Directive } from '@angular/core';
import { FIELD_CONTEXT } from './field-context';

/**
 * Detaches a control from the surrounding <sm-field> so it keeps its own id and accessible name —
 * e.g. the country-code Select sitting next to the phone Input inside one "Mobile number" field.
 */
@Directive({
  selector: '[smFieldExempt]',
  providers: [{ provide: FIELD_CONTEXT, useValue: null }],
})
export class FieldExempt {}
