import { Component, computed, input } from '@angular/core';
import { QuestIllustration } from './quest-illustration';
import { uniqueId } from '../internal/unique-id';

/**
 * Figma: Cards & Overlays → Badge Ring (29:33). Quest badge with an Ember progress arc driven by the real
 * percentage (Figma note). 100 = unlocked: solid Ember edge, warm inner, glow.
 * Geometry from Figma: outer 128, track/arc 120 with 93% inner radius, inner disc 104.
 */
@Component({
  selector: 'sm-badge-ring',
  imports: [QuestIllustration],
  template: `
    <svg viewBox="0 0 128 128" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient [id]="gradId" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" class="stop-1" />
          <stop offset="1" class="stop-2" />
        </linearGradient>
      </defs>
      <circle class="outer" cx="64" cy="64" r="63.25" />
      <circle class="track" cx="64" cy="64" r="57.9" />
      <circle
        class="arc"
        cx="64"
        cy="64"
        r="57.9"
        pathLength="100"
        [attr.stroke]="'url(#' + gradId + ')'"
        [attr.stroke-dasharray]="clamped() + ' 100'"
      />
      <circle class="inner" cx="64" cy="64" r="52" />
    </svg>
    <sm-quest-illustration [quest]="quest()" />
  `,
  styleUrl: './badge-ring.scss',
  host: {
    '[class]': '"sm-badge-ring sm-badge-ring--" + size()',
    '[class.is-unlocked]': 'clamped() >= 100',
    role: 'img',
    '[attr.aria-label]': 'label()',
  },
})
export class BadgeRing {
  readonly quest = input.required<number>();
  readonly progress = input(0);
  readonly size = input<'l' | 'm' | 's'>('l');
  readonly label = input.required<string>();

  protected readonly gradId = uniqueId('badge-grad');
  protected readonly clamped = computed(() => Math.min(100, Math.max(0, this.progress())));
}
