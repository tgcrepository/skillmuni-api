import { Component, inject } from '@angular/core';
import { XpFx } from './xp-fx';
import { Currency } from '../currency/currency';

const SPARKS = Array.from({ length: 8 }, (_, i) => i);

/** Renders XpFx bursts above everything (A-263). Decorative: the gain is announced by XpFx. */
@Component({
  selector: 'sm-xp-fx-layer',
  template: `
    @for (b of fx.bursts(); track b.id) {
      <span
        class="burst"
        [class.burst--lg]="b.size === 'lg'"
        [class.is-landing]="b.landed"
        [style.left.px]="b.x"
        [style.top.px]="b.y"
        [style.--dx.px]="b.dx"
        [style.--dy.px]="b.dy"
      >
        @for (s of sparks; track s) {
          <span class="spark" [style.--a]="s"></span>
        }
        <span class="chip"><sm-currency kind="xp" [size]="b.size === 'lg' ? 'md' : 'sm'" pop />{{ b.label }}</span>
      </span>
    }
  `,
  imports: [Currency],
  styleUrl: './xp-fx-layer.scss',
  host: { 'aria-hidden': 'true' },
})
export class XpFxLayer {
  protected readonly fx = inject(XpFx);
  protected readonly sparks = SPARKS;
}
