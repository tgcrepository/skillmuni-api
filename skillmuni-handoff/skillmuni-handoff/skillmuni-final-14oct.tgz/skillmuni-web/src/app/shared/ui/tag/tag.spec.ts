import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Tag } from './tag';
import { Pill } from '../pill/pill';

@Component({
  imports: [Tag, Pill],
  template: `
    <sm-tag tone="brand">From your CV</sm-tag>
    <sm-pill tone="success" size="s" dot icon="check">Live</sm-pill>
  `,
})
class Host {}

describe('Tag and Pill', () => {
  it('render tone and size classes with projected text', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    const tag = el.querySelector('sm-tag')!;
    const pill = el.querySelector('sm-pill')!;
    expect(tag.classList).toContain('sm-tag--brand');
    expect(tag.textContent).toContain('From your CV');
    expect(pill.classList).toContain('sm-pill--success');
    expect(pill.classList).toContain('sm-pill--s');
    expect(pill.querySelector('.dot')!.getAttribute('aria-hidden')).toBe('true');
    expect(pill.querySelector('sm-icon')).not.toBeNull();
  });
});
