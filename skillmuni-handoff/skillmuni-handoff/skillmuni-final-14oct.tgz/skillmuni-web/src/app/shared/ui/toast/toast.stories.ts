import { Component, inject } from '@angular/core';
import type { Meta, StoryObj } from '@storybook/angular-vite';
import { ToastHost } from './toast-host';
import { ToastService } from './toast.service';
import { Button } from '../button/button';

@Component({
  selector: 'sm-toast-demo',
  imports: [ToastHost, Button],
  template: `
    <sm-toast-host />
    <div style="display:flex;gap:var(--sm-space-400)">
      <button sm-button (click)="toasts.reward('Name locked in', '+20 XP')">Reward</button>
      <button sm-button variant="secondary" (click)="toasts.show('Saved')">Success</button>
      <button
        sm-button
        variant="outline-brand"
        (click)="toasts.show('Couldn’t save. Try again?', { tone: 'error' })"
      >
        Error
      </button>
    </div>
  `,
})
class ToastDemo {
  protected readonly toasts = inject(ToastService);
  constructor() {
    this.toasts.reward('Name locked in', '+20 XP');
    this.toasts.show('Saved', { duration: 60_000 });
    this.toasts.show('Couldn’t save. Try again?', { tone: 'error', duration: 60_000 });
    this.toasts.show('12th removed', {
      duration: 60_000,
      action: { label: 'Undo', run: () => this.toasts.show('12th restored') },
    });
  }
}

const meta: Meta<ToastDemo> = {
  title: 'Primitives/Toast',
  component: ToastDemo,
  parameters: { figma: { node: '22:73' } },
};
export default meta;
export const Playground: StoryObj<ToastDemo> = {};
