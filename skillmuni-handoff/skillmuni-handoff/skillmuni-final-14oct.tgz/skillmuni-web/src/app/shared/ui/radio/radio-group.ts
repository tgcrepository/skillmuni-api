import { Component, booleanAttribute, input, model, output } from '@angular/core';
import type { FormValueControl } from '@angular/forms/signals';
import { uniqueId } from '../internal/unique-id';

/**
 * Radio group container (role="radiogroup"). Holds the value; child <sm-radio> items read it.
 * Native radios share one `name`, so arrow-key navigation and form semantics are native.
 * Works with Signal Forms via `[formField]`.
 */
@Component({
  selector: 'sm-radio-group',
  template: `<ng-content />`,
  host: {
    role: 'radiogroup',
    class: 'sm-radio-group',
    '[attr.aria-labelledby]': 'labelledBy() || null',
    '[attr.aria-label]': 'ariaLabel() || null',
    '[attr.aria-describedby]': 'describedBy() || null',
    '[attr.aria-invalid]': 'invalid() || null',
    '[attr.aria-required]': 'required() || null',
  },
  styles: `
    :host {
      display: grid;
      gap: var(--sm-space-200);
    }
  `,
})
export class RadioGroup implements FormValueControl<string | null> {
  readonly value = model<string | null>(null);
  readonly disabled = input(false, { transform: booleanAttribute });
  readonly required = input(false, { transform: booleanAttribute });
  readonly invalid = input(false, { transform: booleanAttribute });
  readonly name = input(uniqueId('radio'));
  readonly labelledBy = input('');
  readonly ariaLabel = input('');
  readonly describedBy = input('');
  readonly touch = output<void>();
}
