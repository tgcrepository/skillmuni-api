import { Component, input } from '@angular/core';

export type TagTone = 'neutral' | 'brand' | 'accent' | 'danger' | 'success' | 'warning' | 'info';

/**
 * Figma: Tags & Pills → Tag (14:16). 22px label next to a field label or card that says where data
 * came from or whether it is required. Neutral = Optional · Danger = Needed · Brand = From your CV ·
 * Accent = Auto-filled · Success = Verified. Never interactive.
 */
@Component({
  selector: 'sm-tag',
  template: `<ng-content />`,
  styleUrl: './tag.scss',
  host: { '[class]': '"sm-tag sm-tag--" + tone()' },
})
export class Tag {
  readonly tone = input<TagTone>('neutral');
}
