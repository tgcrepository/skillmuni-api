import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Field } from '../field/field';
import { Input } from './input';
import { Tag } from '../tag/tag';

@Component({
  imports: [Field, Input, Tag],
  template: `
    <sm-field label="First name" helper="Your nickname in the app." [error]="error()" required>
      <sm-tag>Optional</sm-tag>
      <sm-input [(value)]="name" placeholder="Your first name" autocomplete="given-name" />
    </sm-field>
    <sm-input [(value)]="search" ariaLabel="Search skills" leadingIcon="search" status="valid" />
  `,
})
class Host {
  readonly name = signal('');
  readonly search = signal('');
  readonly error = signal('');
}

describe('Field + Input', () => {
  function setup() {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    return {
      fixture,
      host: fixture.componentInstance,
      el,
      input: el.querySelector('sm-field input') as HTMLInputElement,
    };
  }

  it('links the visible label to the input', () => {
    const { el, input } = setup();
    const label = el.querySelector('label') as HTMLLabelElement;
    expect(label.htmlFor).toBe(input.id);
    expect(label.textContent).toContain('First name');
  });

  it('describes the input with the helper and marks it required', () => {
    const { el, input } = setup();
    const msg = el.querySelector(`#${input.getAttribute('aria-describedby')}`)!;
    expect(msg.textContent).toContain('Your nickname in the app.');
    expect(input.required).toBe(true);
  });

  it('writes typed text to the model', () => {
    const { fixture, host, input } = setup();
    input.value = 'Nkosazana';
    input.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(host.name()).toBe('Nkosazana');
  });

  it('shows the error message, error state and aria-invalid', () => {
    const { fixture, host, el, input } = setup();
    host.error.set('Add your first name to keep going');
    fixture.detectChanges();
    expect(el.querySelector('sm-field')!.classList).toContain('sm-field--error');
    expect(input.getAttribute('aria-invalid')).toBe('true');
    expect(el.querySelector('sm-field .message')!.textContent).toContain('Add your first name');
    expect(el.querySelector('sm-field sm-status-icon')).not.toBeNull();
  });

  it('works standalone with an aria-label and explicit status', () => {
    const { el } = setup();
    const standalone = el.querySelectorAll('sm-input')[1]!;
    expect(standalone.querySelector('input')!.getAttribute('aria-label')).toBe('Search skills');
    expect(standalone.classList).toContain('sm-input--valid');
  });
});
