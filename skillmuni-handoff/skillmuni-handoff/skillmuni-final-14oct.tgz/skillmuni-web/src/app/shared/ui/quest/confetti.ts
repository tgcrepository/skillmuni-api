import { Component } from '@angular/core';

const PIECES = Array.from({ length: 18 }, (_, i) => i);

/**
 * Decorative celebration burst behind the Quest Complete modal (Figma: "Over Scrim + confetti").
 * Transform/opacity only; hidden entirely for reduced-motion users.
 */
@Component({
  selector: 'sm-confetti',
  template: `
    @for (i of pieces; track i) {
      <span class="piece" [style.--_i]="i"></span>
    }
  `,
  styleUrl: './confetti.scss',
  host: { 'aria-hidden': 'true', class: 'sm-confetti' },
})
export class Confetti {
  protected readonly pieces = PIECES;
}
