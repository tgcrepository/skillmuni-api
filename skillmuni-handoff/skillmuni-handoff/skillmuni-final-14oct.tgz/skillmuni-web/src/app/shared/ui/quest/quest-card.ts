import {
  Component,
  DestroyRef,
  ElementRef,
  afterNextRender,
  booleanAttribute,
  inject,
  input,
  output,
  viewChild,
} from '@angular/core';
import { Pill } from '../pill/pill';
import { Button } from '../button/button';
import { SectionStepItem, SectionStepper } from '../hud/section-stepper';
import { Currency } from '../currency/currency';

/**
 * Figma: Cards & Overlays → Quest Card (30:465) + Quest Footer (30:79).
 * Meta (breadcrumb + XP promise) → title (project `<h1 smQuestTitle>` with one `<em>` highlight) → subtitle →
 * Section Stepper → divider → content → footer (Back · counter · Primary).
 * Footer is inline on desktop/tablet and a Bottom Bar pinned to the viewport on mobile (Back moves to the header).
 * The card is a <form>, so Enter submits the primary action.
 */
@Component({
  selector: 'sm-quest-card',
  imports: [Currency, Pill, Button, SectionStepper],
  templateUrl: './quest-card.html',
  styleUrl: './quest-card.scss',
  host: { class: 'sm-quest-card' },
})
export class QuestCard {
  private readonly footer = viewChild<ElementRef<HTMLElement>>('footer');

  constructor() {
    // Toasts sit above the pinned bottom bar, whose height grows when the counter wraps.
    const destroyRef = inject(DestroyRef);
    afterNextRender(() => {
      const el = this.footer()?.nativeElement;
      if (!el || typeof ResizeObserver === 'undefined') return;
      const root = document.documentElement;
      const update = () =>
        root.style.setProperty(
          '--sm-bottom-bar-height',
          getComputedStyle(el).position === 'fixed' ? `${el.offsetHeight}px` : '0px',
        );
      const observer = new ResizeObserver(update);
      observer.observe(el);
      update();
      destroyRef.onDestroy(() => {
        observer.disconnect();
        root.style.removeProperty('--sm-bottom-bar-height');
      });
    });
  }

  /** "Quest 1 of 8 · Who dis? · Part 1 of 3" */
  readonly eyebrow = input.required<string>();
  /** "+50 XP when you’re done" */
  readonly xpPromise = input('');
  readonly subtitle = input('');
  readonly steps = input<readonly SectionStepItem[]>([]);
  readonly currentStep = input(0);

  readonly primaryLabel = input($localize`:@@questCard.next:Next part`);
  readonly primaryXp = input('');
  readonly primaryDisabled = input(false, { transform: booleanAttribute });
  readonly busy = input(false, { transform: booleanAttribute });
  readonly showBack = input(true, { transform: booleanAttribute });
  readonly backLabel = input($localize`:@@questCard.back:Go back`);
  /** Always says what's left or why Primary is disabled ("Verify your number first"). */
  readonly counter = input('');

  /** Optional parts (Figma Q2 part 2): "Skip for now" (outline brand) takes the place of Back. */
  readonly skipLabel = input('');

  readonly back = output<void>();
  readonly next = output<void>();
  readonly skip = output<void>();
  /** A done part in the stepper was clicked. */
  readonly goTo = output<number>();

  protected readonly counterId = `sm-quest-counter`;

  protected submit(event: Event): void {
    event.preventDefault();
    if (!this.primaryDisabled() && !this.busy()) this.next.emit();
  }
}
