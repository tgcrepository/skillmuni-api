import { Component, input } from '@angular/core';
import { Icon } from '../icon/icon';
import { IconName } from '../icon/icons';

export type BadgeMedalRarity = 'common' | 'rare' | 'epic' | 'legendary';
export type BadgeMedalState = 'earned' | 'locked' | 'secret';

/**
 * Figma Badge Medal (169:4668). Earned medals are tinted by rarity (Common / Rare / Epic / Legendary =
 * owned by >50% / 20–50% / 5–20% / <5% of learners); Locked = dashed + lock; Secret = "?" until earned.
 * Sizes: sm 36 (list) · md 60 (grid) · lg 120 (detail). Decorative: the badge name sits next to it,
 * so pass `label` only when it stands alone.
 */
@Component({
  selector: 'sm-badge-medal',
  imports: [Icon],
  template: `
    @if (state() === 'secret') {
      <span class="secret" aria-hidden="true">?</span>
    } @else if (image()) {
      <img class="art" [src]="image()" alt="" />
    } @else {
      <sm-icon [name]="icon()" size="inherit" />
    }
    @if (state() === 'locked') {
      <span class="lock" aria-hidden="true"><sm-icon name="lock" size="inherit" /></span>
    }
  `,
  styleUrl: './badge-medal.scss',
  host: {
    '[class]': '"sm-badge-medal is-" + state() + " r-" + rarity() + " s-" + size()',
    '[attr.role]': 'label() ? "img" : null',
    '[attr.aria-label]': 'label() || null',
    '[attr.aria-hidden]': 'label() ? null : "true"',
  },
})
export class BadgeMedal {
  readonly icon = input<IconName>('star');
  /** 3D artwork instead of the line icon (quest badges, corrections #24). */
  readonly image = input<string | null | undefined>(null);
  readonly rarity = input<BadgeMedalRarity>('common');
  readonly state = input<BadgeMedalState>('earned');
  readonly size = input<'sm' | 'md' | 'lg'>('md');
  readonly label = input('');
}
