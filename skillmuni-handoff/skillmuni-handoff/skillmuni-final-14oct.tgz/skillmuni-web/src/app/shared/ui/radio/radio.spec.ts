import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Radio } from './radio';
import { RadioGroup } from './radio-group';

@Component({
  imports: [RadioGroup, Radio],
  template: `
    <sm-radio-group [(value)]="level" ariaLabel="Highest level">
      <sm-radio value="matric">Matric</sm-radio>
      <sm-radio value="degree">Degree</sm-radio>
      <sm-radio value="phd" disabled>PhD</sm-radio>
    </sm-radio-group>
  `,
})
class Host {
  readonly level = signal<string | null>('matric');
}

describe('RadioGroup', () => {
  it('is a labelled radiogroup whose radios share one name', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const group = fixture.nativeElement.querySelector('sm-radio-group') as HTMLElement;
    const inputs = [...group.querySelectorAll('input')] as HTMLInputElement[];
    expect(group.getAttribute('role')).toBe('radiogroup');
    expect(group.getAttribute('aria-label')).toBe('Highest level');
    expect(new Set(inputs.map((i) => i.name)).size).toBe(1);
    expect(inputs[0]!.checked).toBe(true);
    expect(inputs[2]!.disabled).toBe(true);
  });

  it('updates the group value on selection', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const inputs = fixture.nativeElement.querySelectorAll('input') as NodeListOf<HTMLInputElement>;
    inputs[1]!.click();
    fixture.detectChanges();
    expect(fixture.componentInstance.level()).toBe('degree');
  });
});
