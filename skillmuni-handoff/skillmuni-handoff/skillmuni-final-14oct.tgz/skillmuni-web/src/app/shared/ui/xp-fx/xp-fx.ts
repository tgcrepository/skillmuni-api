import { LiveAnnouncer } from '@angular/cdk/a11y';
import { DOCUMENT } from '@angular/common';
import { Service, inject, signal } from '@angular/core';
import { SoundFx } from '../../../core/audio/sound-fx';

export interface XpBurst {
  readonly id: number;
  readonly label: string;
  readonly size: 'sm' | 'lg';
  /** Start point, viewport px. */
  readonly x: number;
  readonly y: number;
  /** Travel to the XP target, px (or a short float up when there's none on screen). */
  readonly dx: number;
  readonly dy: number;
  readonly landed: boolean;
}

const LIFETIME = 1300; // matches celebrate × 1.8 in xp-fx-layer.scss, plus a beat

/**
 * XP micro-celebrations (A-263): a "+20 XP" chip pops where the learner earned it, sparkles, and
 * flies into the XP counter on screen (any element with `data-xp-target`), which then pulses.
 * Screen readers hear the gain once. Reduced motion: the chip fades in place, nothing travels.
 */
@Service()
export class XpFx {
  private readonly doc = inject(DOCUMENT);
  private readonly announcer = inject(LiveAnnouncer);
  private readonly sfx = inject(SoundFx);
  private next = 0;
  readonly bursts = signal<readonly XpBurst[]>([]);

  burst(
    amount: number,
    from?: Element | null,
    opts: { readonly size?: 'sm' | 'lg'; readonly announce?: boolean; readonly label?: string } = {},
  ): void {
    if (amount <= 0) return;
    const label = opts.label ?? $localize`:@@fx.xp:+${amount}:n: XP`;
    if (opts.announce !== false) void this.announcer.announce(label, 'polite');
    this.sfx.play(opts.size === 'lg' ? 'celebrate' : 'xp');
    const win = this.doc.defaultView;
    if (!win) return;
    const origin = this.centre(from) ?? { x: win.innerWidth / 2, y: win.innerHeight * 0.45 };
    const target = this.target();
    const rise = Math.min(96, win.innerHeight * 0.12);
    const burst: XpBurst = {
      id: ++this.next,
      label,
      size: opts.size ?? 'sm',
      x: origin.x,
      y: origin.y,
      dx: target ? target.x - origin.x : 0,
      dy: target ? target.y - origin.y : -rise,
      landed: !!target,
    };
    this.bursts.update((list) => [...list, burst]);
    win.setTimeout(() => {
      this.bursts.update((list) => list.filter((b) => b.id !== burst.id));
      if (target) this.pulse(target.el);
    }, LIFETIME);
  }

  private centre(el?: Element | null): { x: number; y: number } | null {
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (!r.width && !r.height) return null;
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }

  /** The first visible XP counter on screen. */
  private target(): { x: number; y: number; el: Element } | null {
    const win = this.doc.defaultView;
    for (const el of Array.from(this.doc.querySelectorAll('[data-xp-target]'))) {
      const r = el.getBoundingClientRect();
      if (!r.width || !win || r.bottom < 0 || r.top > win.innerHeight) continue;
      return { x: r.left + r.width / 2, y: r.top + r.height / 2, el };
    }
    return null;
  }

  private pulse(el: Element): void {
    el.classList.remove('sm-xp-hit');
    // Force a reflow so the class re-adds as a fresh animation.
    void (el as HTMLElement).offsetWidth;
    el.classList.add('sm-xp-hit');
    this.doc.defaultView?.setTimeout(() => el.classList.remove('sm-xp-hit'), 700);
  }
}
