import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Checkbox } from './checkbox';
import { Switch } from '../switch/switch';

@Component({
  imports: [Checkbox, Switch],
  template: `
    <sm-checkbox [(checked)]="agree" [disabled]="disabled()">I agree</sm-checkbox>
    <sm-switch [(checked)]="current">I still work here</sm-switch>
  `,
})
class Host {
  readonly agree = signal(false);
  readonly current = signal(true);
  readonly disabled = signal(false);
}

describe('Checkbox and Switch', () => {
  function setup() {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    return {
      fixture,
      host: fixture.componentInstance,
      box: el.querySelector('sm-checkbox input') as HTMLInputElement,
      sw: el.querySelector('sm-switch input') as HTMLInputElement,
    };
  }

  it('toggles via the native input and updates the model', () => {
    const { fixture, host, box } = setup();
    box.click();
    fixture.detectChanges();
    expect(host.agree()).toBe(true);
    expect(fixture.nativeElement.querySelector('sm-checkbox').classList).toContain('is-checked');
  });

  it('uses the projected text as the accessible label', () => {
    const { box } = setup();
    expect(box.closest('label')!.textContent).toContain('I agree');
  });

  it('respects disabled', () => {
    const { fixture, host, box } = setup();
    host.disabled.set(true);
    fixture.detectChanges();
    expect(box.disabled).toBe(true);
  });

  it('switch exposes role="switch" and its state', () => {
    const { fixture, host, sw } = setup();
    expect(sw.getAttribute('role')).toBe('switch');
    expect(sw.checked).toBe(true);
    sw.click();
    fixture.detectChanges();
    expect(host.current()).toBe(false);
    expect(sw.getAttribute('aria-checked')).toBe('false');
  });
});
