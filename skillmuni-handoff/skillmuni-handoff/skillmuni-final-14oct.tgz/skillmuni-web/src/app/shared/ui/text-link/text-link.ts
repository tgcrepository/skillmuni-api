import { Component, input } from '@angular/core';

export type TextLinkTone = 'brand' | 'accent';

/**
 * Figma: Buttons → Text Link (12:236). Inline/standalone text actions (Forgot password, Join the squad, See all).
 * Brand = recovery / secondary paths · Accent = sign-up / discovery. Never for the primary forward action.
 */
@Component({
  selector: 'a[sm-text-link], button[sm-text-link]',
  template: `<ng-content />`,
  styleUrl: './text-link.scss',
  host: { '[class]': '"sm-text-link sm-text-link--" + tone()' },
})
export class TextLink {
  readonly tone = input<TextLinkTone>('brand');
}
