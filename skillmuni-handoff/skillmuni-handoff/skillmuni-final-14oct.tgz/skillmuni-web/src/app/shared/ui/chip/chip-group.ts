import {
  Component,
  LOCALE_ID,
  booleanAttribute,
  computed,
  inject,
  input,
  model,
  output,
} from '@angular/core';
import type { FormValueControl } from '@angular/forms/signals';
import { Icon } from '../icon/icon';
import { uniqueId } from '../internal/unique-id';
import { OptionOrder, alphabetical } from '../internal/alphabetical';

export interface ChipOption {
  readonly value: string;
  readonly label: string;
  readonly disabled?: boolean;
}

/**
 * Figma: Selection Controls → Chip (16:38). 44px pill answers in a wrapping row (gap 10).
 * single → radiogroup of native radios · multi → group of native checkboxes.
 * Selected = Ember tint + check (never colour alone). "Add more" appears when `addMoreLabel` is set
 * and emits `addMore` (Figma: opens a searchable list when options > 7).
 * Value is a string (single) or string[] (multi). Works with Signal Forms via `[formField]`.
 */
@Component({
  selector: 'sm-chip-group',
  imports: [Icon],
  template: `
    @for (option of ordered(); track option.value) {
      <label
        class="chip"
        [class.is-selected]="isSelected(option.value)"
        [class.is-disabled]="isDisabled(option)"
      >
        <input
          [type]="multiple() ? 'checkbox' : 'radio'"
          [name]="name()"
          [value]="option.value"
          [checked]="isSelected(option.value)"
          [disabled]="isDisabled(option)"
          (change)="toggle(option.value, $event)"
          (blur)="touch.emit()"
        />
        <span class="check" aria-hidden="true"><sm-icon name="check" size="inherit" /></span>
        <span class="text">{{ option.label }}</span>
      </label>
    }
    @if (addMoreLabel()) {
      <button type="button" class="chip chip--add" (click)="addMore.emit()">
        <span class="text">{{ addMoreLabel() }}</span>
      </button>
    }
  `,
  styleUrl: './chip.scss',
  host: {
    class: 'sm-chip-group',
    '[attr.role]': 'multiple() ? "group" : "radiogroup"',
    '[attr.aria-labelledby]': 'labelledBy() || null',
    '[attr.aria-label]': 'ariaLabel() || null',
    '[attr.aria-describedby]': 'describedBy() || null',
    '[attr.aria-invalid]': 'invalid() || null',
  },
})
export class ChipGroup implements FormValueControl<string | string[] | null> {
  readonly value = model<string | string[] | null>(null);
  readonly options = input.required<readonly ChipOption[]>();
  /** A–Z by default (A-258); `given` for ranges, scales and Yes/No pairs. */
  readonly order = input<OptionOrder>('alpha');
  private readonly locale = inject(LOCALE_ID);
  protected readonly ordered = computed(() =>
    this.order() === 'alpha'
      ? alphabetical(this.options(), (o) => o.label, this.locale)
      : this.options(),
  );
  readonly multiple = input(false, { transform: booleanAttribute });
  readonly disabled = input(false, { transform: booleanAttribute });
  readonly invalid = input(false, { transform: booleanAttribute });
  readonly name = input(uniqueId('chips'));
  readonly labelledBy = input('');
  readonly ariaLabel = input('');
  readonly describedBy = input('');
  readonly addMoreLabel = input('');
  readonly addMore = output<void>();
  readonly touch = output<void>();

  private readonly selected = computed(() => {
    const v = this.value();
    return new Set(v === null ? [] : Array.isArray(v) ? v : [v]);
  });

  protected isSelected(value: string): boolean {
    return this.selected().has(value);
  }

  protected isDisabled(option: ChipOption): boolean {
    return this.disabled() || !!option.disabled;
  }

  protected toggle(value: string, event: Event): void {
    const on = (event.target as HTMLInputElement).checked;
    if (!this.multiple()) {
      this.value.set(value);
      return;
    }
    const next = new Set(this.selected());
    if (on) next.add(value);
    else next.delete(value);
    this.value.set(
      this.options()
        .map((o) => o.value)
        .filter((v) => next.has(v)),
    );
  }
}
