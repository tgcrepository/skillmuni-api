import {
  Component,
  booleanAttribute,
  computed,
  contentChildren,
  inject,
  input,
} from '@angular/core';
import { FIELD_CONTEXT, FieldContext, FieldStatus, MARK_NEEDED } from './field-context';
import { Tag } from '../tag/tag';
import { uniqueId } from '../internal/unique-id';

/**
 * Figma: Inputs & Fields → Field (19:84). Label (+ optional Tag) · control · helper.
 * The label is always visible (never placeholder-as-label). Helper turns green/red with the status.
 * The error message replaces the helper and is announced politely.
 *
 * <sm-field label="First name" helper="…" [error]="err()">
 *   <sm-tag tone="neutral">Optional</sm-tag>
 *   <sm-input [formField]="f.firstName" />
 * </sm-field>
 */
@Component({
  selector: 'sm-field',
  imports: [Tag],
  template: `
    <div class="label-row">
      <label class="label" [attr.for]="context.controlId" [id]="labelId">{{ label() }}</label>
      <ng-content select="sm-tag" />
      @if (autoNeeded()) {
        <sm-tag tone="danger" i18n="@@ui.needed">Needed</sm-tag>
      } @else if (autoOptional()) {
        <sm-tag i18n="@@ui.optional">Optional</sm-tag>
      }
    </div>
    <ng-content />
    <p class="message" [id]="messageId" aria-live="polite">
      @if (message()) {
        {{ message() }}
      }
    </p>
  `,
  styleUrl: './field.scss',
  providers: [{ provide: FIELD_CONTEXT, useFactory: () => inject(Field).context }],
  host: {
    '[class]': '"sm-field sm-field--" + resolvedStatus()',
    '[class.is-disabled]': 'disabled()',
  },
})
export class Field {
  readonly label = input.required<string>();
  readonly helper = input('');
  /** Validation message. When set, the field shows the error state. */
  readonly error = input('');
  /** Explicit status for valid / warning feedback (error is implied by `error`). */
  readonly status = input<FieldStatus>('none');
  readonly required = input(false, { transform: booleanAttribute });
  readonly disabled = input(false, { transform: booleanAttribute });

  private readonly markNeeded = inject(MARK_NEEDED);
  private readonly tags = contentChildren(Tag);
  /** Required, inside a quest, and the page didn't place its own Needed/Optional tag. */
  protected readonly autoNeeded = computed(
    () => this.markNeeded && this.required() && this.tags().length === 0,
  );
  /** Corrections #14: inside a quest every field says whether it's needed or optional. */
  protected readonly autoOptional = computed(
    () => this.markNeeded && !this.required() && this.tags().length === 0 && !this.bare(),
  );
  /** A field that is part of a bigger question (e.g. "Add a role" under "Roles I'd like"): no tag. */
  readonly bare = input(false, { transform: booleanAttribute });

  protected readonly labelId = uniqueId('field-label');
  protected readonly messageId = uniqueId('field-msg');

  protected readonly resolvedStatus = computed<FieldStatus>(() =>
    this.error() ? 'error' : this.status(),
  );
  protected readonly message = computed(() => this.error() || this.helper());

  /** @internal read by the projected control */
  readonly context: FieldContext = {
    controlId: uniqueId('field-control'),
    label: this.label,
    describedBy: computed(() => (this.message() ? this.messageId : '')),
    status: this.resolvedStatus,
    required: this.required,
  };
}
