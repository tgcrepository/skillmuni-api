import { Component, ElementRef, effect, inject } from '@angular/core';
import { StatusIcon } from '../status-icon/status-icon';
import { ToastService } from './toast.service';
import { Currency } from '../currency/currency';
import { Icon } from '../icon/icon';

/**
 * Figma: Feedback → Toast (22:73). Top-centre at every size, under the top bar (corrections sweep).
 * On top it sits just under the page's header bar (any `[data-toast-anchor]`), never over its title (A-291).
 * A polite live region announces each toast. Place once in the app shell.
 */
@Component({
  selector: 'sm-toast-host',
  imports: [Currency, Icon, StatusIcon],
  template: `
    @for (toast of service.toasts(); track toast.id) {
      <div
        [class]="'toast toast--' + toast.tone"
        animate.enter="toast-in"
        animate.leave="toast-out"
        (pointerenter)="service.pause(toast.id)"
        (pointerleave)="service.resume(toast.id)"
        (focusin)="service.pause(toast.id)"
        (focusout)="service.resume(toast.id)"
      >
        @if (toast.tone === 'reward') {
          <span class="xp"><sm-currency kind="xp" size="xs" pop />{{ toast.xp }}</span>
        } @else {
          <sm-status-icon [tone]="toast.tone" />
        }
        <span class="message">{{ toast.message }}</span>
        @if (toast.action; as action) {
          <button type="button" class="action" (click)="service.act(toast)">
            {{ action.label }}
          </button>
          <!-- A toast with an action can be closed straight away. -->
          <button
            type="button"
            class="close"
            [attr.aria-label]="closeLabel"
            (click)="service.dismiss(toast.id)"
          >
            <sm-icon name="x" size="sm" />
          </button>
        }
      </div>
    }
  `,
  styleUrl: './toast-host.scss',
  host: {
    class: 'sm-toast-host',
    role: 'status',
    'aria-live': 'polite',
    'aria-atomic': 'false',
  },
})
export class ToastHost {
  protected readonly service = inject(ToastService);
  protected readonly closeLabel = $localize`:@@toast.close:Close notification`;
  private readonly host = inject(ElementRef).nativeElement as HTMLElement;

  constructor() {
    effect(() => {
      if (this.service.toasts().length) this.clearHeader();
    });
  }

  /** Measure the visible header bars and drop the stack below the lowest one. */
  private clearHeader(): void {
    const doc = this.host.ownerDocument;
    const view = doc.defaultView;
    if (!view) return;
    let bottom = 0;
    for (const el of Array.from(doc.querySelectorAll<HTMLElement>('[data-toast-anchor]'))) {
      const r = el.getBoundingClientRect();
      if (r.height && r.bottom > bottom && r.bottom < view.innerHeight / 2) bottom = r.bottom;
    }
    if (bottom) this.host.style.setProperty('--_top', `${Math.round(bottom)}px`);
    else this.host.style.removeProperty('--_top');
  }
}
