import type { Meta, StoryObj } from '@storybook/angular-vite';
import { SegmentedControl } from './segmented-control';
import { Tabs } from '../tabs/tabs';
import { ProgressBar } from '../progress-bar/progress-bar';

const meta: Meta = {
  title: 'Primitives/Navigation and progress',
  parameters: { figma: { node: 'Segmented Control 27:194 · Tab 27:188 · Progress Bar 24:26' } },
  decorators: [
    (story) => ({ ...story(), moduleMetadata: { imports: [SegmentedControl, Tabs, ProgressBar] } }),
  ],
};
export default meta;

export const Segmented: StoryObj = {
  render: () => ({
    props: {
      two: [
        { value: 'done', label: 'Completed' },
        { value: 'studying', label: 'Still studying' },
      ],
      three: [
        { value: 'otp', label: 'Mobile OTP' },
        { value: 'email', label: 'Email' },
        { value: 'google', label: 'Google' },
      ],
      a: 'done',
      b: 'email',
    },
    template: `
      <div style="display:grid;gap:var(--sm-space-600)">
        <sm-segmented-control [segments]="two" [(value)]="a" ariaLabel="Study status" />
        <sm-segmented-control [segments]="three" [(value)]="b" ariaLabel="Login method" />
      </div>`,
  }),
};

export const FilterTabs: StoryObj = {
  render: () => ({
    props: {
      tabs: [
        'For you',
        'Tech',
        'Data',
        'People',
        'Creative',
        'Business',
        'Trades',
        'Languages',
      ].map((l) => ({ value: l, label: l })),
      value: 'For you',
    },
    template: `<div style="max-inline-size:calc(var(--sm-layout-shell-rail-width) + var(--sm-space-1600))"><sm-tabs [tabs]="tabs" [(value)]="value" ariaLabel="Skill categories" /></div>`,
  }),
};

export const Progress: StoryObj = {
  render: () => ({
    template: `
      <div style="display:grid;gap:var(--sm-space-500);inline-size:var(--sm-layout-shell-rail-width)">
        @for (v of [0, 10, 25, 50, 75, 100]; track v) {
          <sm-progress-bar [value]="v" label="Progress" />
        }
        @for (v of [10, 50, 100]; track v) {
          <sm-progress-bar [value]="v" size="s" label="Progress" />
        }
      </div>`,
  }),
};
