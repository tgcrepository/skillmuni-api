import {
  Component,
  ElementRef,
  booleanAttribute,
  computed,
  inject,
  input,
  model,
  output,
  signal,
  viewChild,
} from '@angular/core';
import type { FormValueControl } from '@angular/forms/signals';
import { FIELD_CONTEXT } from '../field/field-context';
import { uniqueId } from '../internal/unique-id';

export type OtpStatus = 'none' | 'error' | 'success';

/**
 * Figma: Inputs & Fields → OTP Digit (19:98). 6 boxes (48 × 58, gap 8).
 * One real input (autocomplete="one-time-code") under the boxes, so paste fills all six,
 * SMS autofill works, typing auto-advances and screen readers hear a single field.
 * Error = all boxes red · Success = all boxes green.
 */
@Component({
  selector: 'sm-otp',
  template: `
    <div class="boxes" aria-hidden="true">
      @for (slot of slots(); track $index) {
        <span class="box" [class.is-active]="slot.active" [class.is-filled]="!!slot.char">
          @if (slot.active && !slot.char) {
            <span class="caret"></span>
          }
          {{ slot.char }}
        </span>
      }
    </div>
    <input
      #field
      [id]="id"
      type="text"
      inputmode="numeric"
      autocomplete="one-time-code"
      pattern="[0-9]*"
      [attr.maxlength]="length()"
      [value]="value()"
      [disabled]="disabled()"
      [attr.aria-invalid]="status() === 'error' || null"
      [attr.aria-describedby]="describedBy() || null"
      [attr.aria-label]="ariaLabel() || null"
      (input)="onInput($event)"
      (focus)="focused.set(true)"
      (blur)="onBlur()"
      (select)="keepCaretAtEnd()"
    />
  `,
  styleUrl: './otp.scss',
  host: {
    '[class]': '"sm-otp sm-otp--" + status()',
    '[class.is-disabled]': 'disabled()',
    '(click)': 'focus()',
  },
})
export class Otp implements FormValueControl<string> {
  private readonly field = inject(FIELD_CONTEXT, { optional: true });
  private readonly inputEl = viewChild.required<ElementRef<HTMLInputElement>>('field');

  readonly value = model('');
  readonly length = input(6);
  readonly status = input<OtpStatus>('none');
  readonly disabled = input(false, { transform: booleanAttribute });
  readonly ariaLabel = input('');
  /** Emits the full code once all digits are entered. */
  readonly completed = output<string>();
  readonly touch = output<void>();

  protected readonly id = this.field?.controlId ?? uniqueId('otp');
  protected readonly focused = signal(false);
  protected readonly describedBy = computed(() => this.field?.describedBy() ?? '');

  protected readonly slots = computed(() => {
    const chars = this.value().split('');
    const active = this.focused() ? Math.min(chars.length, this.length() - 1) : -1;
    return Array.from({ length: this.length() }, (_, i) => ({
      char: chars[i] ?? '',
      active: i === active,
    }));
  });

  focus(): void {
    this.inputEl().nativeElement.focus();
  }

  protected onInput(event: Event): void {
    const el = event.target as HTMLInputElement;
    const digits = el.value.replace(/\D/g, '').slice(0, this.length());
    el.value = digits;
    this.value.set(digits);
    if (digits.length === this.length()) this.completed.emit(digits);
  }

  protected onBlur(): void {
    this.focused.set(false);
    this.touch.emit();
  }

  protected keepCaretAtEnd(): void {
    const el = this.inputEl().nativeElement;
    const end = el.value.length;
    if (el.selectionStart !== end) el.setSelectionRange(end, end);
  }
}
