import { Component, booleanAttribute, input } from '@angular/core';
import { Icon } from '../icon/icon';
import { IconName } from '../icon/icons';

export type PillTone = 'accent' | 'brand' | 'inset' | 'success' | 'neutral';
export type PillSize = 'm' | 's';

/**
 * Figma: Tags & Pills → Pill (14:77). Rounded status / reward label.
 * Accent = XP promise · Brand = promo ribbon (Speedrun) · Inset = progress inside reward cards ·
 * Success = live / earned · Neutral = counts (8 of 15). M = 34px in headers, S = 28px in cards.
 */
@Component({
  selector: 'sm-pill',
  imports: [Icon],
  template: `
    @if (dot()) {
      <span class="dot" aria-hidden="true"></span>
    }
    @if (icon(); as name) {
      <sm-icon [name]="name" size="inherit" />
    }
    <ng-content />
  `,
  styleUrl: './pill.scss',
  host: { '[class]': '"sm-pill sm-pill--" + tone() + " sm-pill--" + size()' },
})
export class Pill {
  readonly tone = input<PillTone>('accent');
  readonly size = input<PillSize>('m');
  readonly dot = input(false, { transform: booleanAttribute });
  readonly icon = input<IconName | null>(null);
}
