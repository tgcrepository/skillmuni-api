import { DialogRef } from '@angular/cdk/dialog';
import {
  Component,
  DestroyRef,
  ElementRef,
  afterNextRender,
  booleanAttribute,
  inject,
  input,
  signal,
  viewChild,
} from '@angular/core';
import { IconButton } from '../icon-button/icon-button';
import { uniqueId } from '../internal/unique-id';
import { OVERLAY_KIND, requestClose } from './overlay.service';

/** Distance (fraction of sheet height) or fling speed (px/ms) that dismisses a dragged sheet. */
const DISMISS_FRACTION = 0.25;
const DISMISS_VELOCITY = 0.5;

/**
 * Layout for anything opened with OverlayService.
 * Figma: Bottom Sheet (31:168) on mobile — grabber, title, subtitle, scrolling content, full-width action,
 * max 85% viewport height, drag down to dismiss. Modal (Quest Complete 31:112 geometry) elsewhere.
 * Put actions in `<div smDialogActions>`.
 */
@Component({
  selector: 'sm-dialog',
  imports: [IconButton],
  template: `
    @if (kind === 'sheet') {
      <div
        class="grab-zone"
        (pointerdown)="dragStart($event)"
        (pointermove)="dragMove($event)"
        (pointerup)="dragEnd($event)"
        (pointercancel)="dragEnd($event)"
      >
        <span class="grabber" aria-hidden="true"></span>
      </div>
    } @else if (dismissible()) {
      <button
        sm-icon-button
        class="close"
        icon="x"
        tone="ghost"
        [label]="closeLabel()"
        (click)="close()"
      ></button>
    }
    @if (title()) {
      <header class="head">
        <ng-content select="[smDialogLead]" />
        <h2 class="title" [id]="titleId">{{ title() }}</h2>
        @if (subtitle()) {
          <p class="subtitle" [id]="subtitleId">{{ subtitle() }}</p>
        }
      </header>
    }
    <div class="body" #body [attr.tabindex]="scrollable() ? 0 : null"><ng-content /></div>
    <ng-content select="[smDialogActions]" />
  `,
  styleUrl: './dialog.scss',
  host: {
    '[class]': '"sm-dialog sm-dialog--" + kind',
    '[class.is-dragging]': 'dragging()',
    '[class.is-centered]': 'centered()',
    '[class.is-stacked]': 'stacked()',
    '[style.--_drag]': 'dragY() + "px"',
  },
})
export class SmDialog {
  private readonly ref = inject(DialogRef, { optional: true });
  private readonly host = inject(ElementRef).nativeElement as HTMLElement;
  protected readonly kind = inject(OVERLAY_KIND, { optional: true }) ?? 'modal';

  readonly title = input('');
  readonly subtitle = input('');
  /** Id of a custom heading inside the content, when `title` is not used. */
  readonly labelledBy = input('');
  readonly dismissible = input(true, { transform: booleanAttribute });
  /** Centre the head in a sheet too (permission primers, PM1). Modals are always centred. */
  readonly centered = input(false, { transform: booleanAttribute });
  /** Full-width actions stacked vertically (SE1, PM1, PM2). */
  readonly stacked = input(false, { transform: booleanAttribute });
  readonly closeLabel = input($localize`:@@ui.dialog.close:Close`);

  protected readonly titleId = uniqueId('dialog-title');
  protected readonly subtitleId = uniqueId('dialog-sub');
  protected readonly dragY = signal(0);
  /** A body that scrolls must be reachable by keyboard (WCAG 2.1.1, axe scrollable-region-focusable). */
  protected readonly scrollable = signal(false);
  private readonly bodyEl = viewChild<ElementRef<HTMLElement>>('body');
  private readonly destroyRef = inject(DestroyRef);
  protected readonly dragging = signal(false);
  private start = { y: 0, t: 0 };

  constructor() {
    afterNextRender(() => {
      const body = this.bodyEl()?.nativeElement;
      if (body && typeof ResizeObserver !== 'undefined') {
        const check = () => this.scrollable.set(body.scrollHeight > body.clientHeight + 1);
        const observer = new ResizeObserver(check);
        observer.observe(body);
        for (const child of Array.from(body.children)) observer.observe(child);
        // Entry animations (e.g. the Player Card flip) change the overflow without resizing observed
        // boxes, so re-check every frame while a finite animation runs.
        const watch = () => {
          check();
          const running = body
            .getAnimations({ subtree: true })
            .some(
              (a) =>
                a.playState === 'running' && a.effect?.getComputedTiming().iterations !== Infinity,
            );
          if (running) requestAnimationFrame(watch);
        };
        body.addEventListener('animationstart', watch, true);
        watch();
        this.destroyRef.onDestroy(() => observer.disconnect());
        check();
      }
      const container = this.host.closest('[role="dialog"]');
      if (!container) return;
      const labelId = this.labelledBy() || (this.title() ? this.titleId : '');
      if (labelId) container.setAttribute('aria-labelledby', labelId);
      if (this.subtitle()) container.setAttribute('aria-describedby', this.subtitleId);
    });
  }

  close(result?: unknown): void {
    if (this.ref) requestClose(this.ref, result);
  }

  protected dragStart(event: PointerEvent): void {
    if (!this.dismissible()) return;
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
    this.start = { y: event.clientY, t: performance.now() };
    this.dragging.set(true);
  }

  protected dragMove(event: PointerEvent): void {
    if (!this.dragging()) return;
    this.dragY.set(Math.max(0, event.clientY - this.start.y));
  }

  protected dragEnd(event: PointerEvent): void {
    if (!this.dragging()) return;
    this.dragging.set(false);
    const distance = Math.max(0, event.clientY - this.start.y);
    const velocity = distance / Math.max(1, performance.now() - this.start.t);
    if (distance > this.host.offsetHeight * DISMISS_FRACTION || velocity > DISMISS_VELOCITY) {
      this.close();
    } else {
      this.dragY.set(0);
    }
  }
}
