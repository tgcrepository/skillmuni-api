import { Component, computed, input, output } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { ProgressBar } from '../progress-bar/progress-bar';
import { StepState, StepStatus } from './step-status';

export interface SectionStepItem {
  readonly label: string;
  /** Mobile label, e.g. "ID & bday" (Figma 200:13165). Falls back to `label`. */
  readonly short?: string;
  readonly answered: number;
  readonly total: number;
  /** e.g. "+20 XP" */
  readonly xp?: string;
}

/**
 * Figma: Progress & Game HUD → Section Stepper (26:354) + Section Step (26:44).
 * 3-part quest progress under the subtitle. In progress = Ember label + live count ("1 of 2 answered").
 * Done = green check + earned XP. Exposed as an ordered list with aria-current on the active part.
 */
@Component({
  selector: 'sm-section-stepper',
  imports: [ProgressBar, StepStatus, NgTemplateOutlet],
  template: `
    <ol class="steps" [attr.aria-label]="ariaLabel()">
      @for (step of view(); track $index) {
        <li
          class="step"
          [class]="'step step--' + step.state"
          [attr.aria-current]="step.state === 'current' ? 'step' : null"
        >
          <sm-progress-bar [value]="step.percent" [label]="step.label" />
          @if (step.state === 'done' && navigable()) {
            <button type="button" class="row jump" (click)="goTo.emit($index)">
              <ng-container
                [ngTemplateOutlet]="rowTpl"
                [ngTemplateOutletContext]="{ $implicit: step }"
              />
              <span class="sm-visually-hidden" i18n="@@stepper.goBack">, go back and edit</span>
            </button>
          } @else {
            <span class="row">
              <ng-container
                [ngTemplateOutlet]="rowTpl"
                [ngTemplateOutletContext]="{ $implicit: step }"
              />
            </span>
          }
        </li>
      }
    </ol>

    <ng-template #rowTpl let-step>
      <sm-step-status [status]="step.state" />
      <span class="label">
        <span class="long">{{ step.label }}</span>
        <span class="short" aria-hidden="true">{{ step.short ?? step.label }}</span>
        @if (step.state === 'current' && step.total > 0) {
          <span class="count" i18n="@@stepper.answered"
            >· {{ step.answered }} of {{ step.total }} answered</span
          >
          <span class="count-short" aria-hidden="true">· {{ step.answered }}/{{ step.total }}</span>
        }
      </span>
      @if (step.xp && step.state !== 'current') {
        <span class="xp">{{ step.xp }}</span>
      }
    </ng-template>
  `,
  styleUrl: './section-stepper.scss',
  host: { class: 'sm-section-stepper' },
})
export class SectionStepper {
  readonly steps = input.required<readonly SectionStepItem[]>();
  /** Index of the part the learner is on. */
  readonly current = input(0);
  readonly ariaLabel = input($localize`:@@stepper.label:Quest parts`);
  /** Done parts become buttons that jump back to that part (A-165). */
  readonly navigable = input(false);
  readonly goTo = output<number>();

  protected readonly view = computed(() =>
    this.steps().map((s, i) => {
      const state: StepState =
        i < this.current() ? 'done' : i === this.current() ? 'current' : 'upcoming';
      const percent = state === 'done' ? 100 : s.total > 0 ? (s.answered / s.total) * 100 : 0;
      return { ...s, state, percent: state === 'upcoming' ? 0 : percent };
    }),
  );
}
