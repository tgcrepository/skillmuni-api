import { Component, booleanAttribute, computed, input, model, output } from '@angular/core';
import type { FormValueControl } from '@angular/forms/signals';
import { Icon } from '../icon/icon';
import { uniqueId } from '../internal/unique-id';

export interface OptionCardItem {
  readonly value: string;
  readonly title: string;
  readonly description?: string;
  /** 2-letter code tile, e.g. "IN" for Internship. */
  readonly code?: string;
  /** Dashed opt-out card ("Not yet, I'm a fresher"), mutually exclusive with all others. */
  readonly optOut?: boolean;
  readonly disabled?: boolean;
}

/**
 * Figma: Selection Controls → Option Card (16:202). Multi-select tiles for richer choices
 * (work types, education level). 4 columns (gap 10) on desktop, 2 on mobile.
 * Native checkboxes (or radios when `multiple` is false) inside a labelled group.
 */
@Component({
  selector: 'sm-option-cards',
  imports: [Icon],
  template: `
    @for (item of items(); track item.value) {
      <label
        class="card"
        [class.is-selected]="isSelected(item.value)"
        [class.is-opt-out]="item.optOut"
        [class.is-disabled]="disabled() || item.disabled"
      >
        <input
          [type]="multiple() ? 'checkbox' : 'radio'"
          [name]="groupName"
          [value]="item.value"
          [checked]="isSelected(item.value)"
          [disabled]="disabled() || item.disabled"
          [attr.aria-describedby]="item.description ? groupName + '-' + item.value : null"
          (change)="toggle(item, $event)"
          (blur)="touch.emit()"
        />
        <span class="top" aria-hidden="true">
          <span class="code" [class.is-emoji]="isPicture(item.code)">{{
            item.optOut ? '–' : item.code
          }}</span>
          <span class="box"><sm-icon name="check" size="inherit" /></span>
        </span>
        <span class="title">{{ item.title }}</span>
        @if (item.description) {
          <span class="description" [id]="groupName + '-' + item.value">{{
            item.description
          }}</span>
        }
      </label>
    }
  `,
  styleUrl: './option-cards.scss',
  host: {
    class: 'sm-option-cards',
    '[attr.role]': 'multiple() ? "group" : "radiogroup"',
    '[attr.aria-label]': 'ariaLabel() || null',
    '[attr.aria-labelledby]': 'labelledBy() || null',
    '[attr.aria-invalid]': 'invalid() || null',
  },
})
export class OptionCards implements FormValueControl<string[]> {
  /** A picture (emoji) instead of a 2-letter code gets a bigger glyph, no letter-spacing. */
  protected isPicture(code: string | undefined): boolean {
    return !!code && /\p{Extended_Pictographic}/u.test(code);
  }

  readonly value = model<string[]>([]);
  readonly items = input.required<readonly OptionCardItem[]>();
  readonly multiple = input(true, { transform: booleanAttribute });
  readonly disabled = input(false, { transform: booleanAttribute });
  readonly invalid = input(false, { transform: booleanAttribute });
  readonly ariaLabel = input('');
  readonly labelledBy = input('');
  readonly touch = output<void>();

  protected readonly groupName = uniqueId('option-cards');
  private readonly selected = computed(() => new Set(this.value()));

  protected isSelected(value: string): boolean {
    return this.selected().has(value);
  }

  protected toggle(item: OptionCardItem, event: Event): void {
    const on = (event.target as HTMLInputElement).checked;
    if (!this.multiple() || item.optOut) {
      this.value.set(on ? [item.value] : []);
      return;
    }
    const optOuts = new Set(
      this.items()
        .filter((i) => i.optOut)
        .map((i) => i.value),
    );
    const next = new Set([...this.selected()].filter((v) => !optOuts.has(v)));
    if (on) next.add(item.value);
    else next.delete(item.value);
    this.value.set(
      this.items()
        .map((i) => i.value)
        .filter((v) => next.has(v)),
    );
  }
}
