import { Component, computed, input } from '@angular/core';

export type PowerLevel = 0 | 1 | 2 | 3;

/**
 * Figma: Progress & Game HUD → Power Meter (24:58). 3-pip skill level:
 * 1 Just started · 2 Getting there · 3 Confident · 0 not set. Always has a text label (role="img").
 */
@Component({
  selector: 'sm-power-meter',
  template: `
    @for (pip of [1, 2, 3]; track pip) {
      <span class="pip" [class.is-on]="pip <= level()"></span>
    }
  `,
  styleUrl: './power-meter.scss',
  host: { class: 'sm-power-meter', role: 'img', '[attr.aria-label]': 'label()' },
})
export class PowerMeter {
  readonly level = input<PowerLevel>(0);

  protected readonly label = computed(
    () =>
      ({
        0: $localize`:@@power.0:Level not set`,
        1: $localize`:@@power.1:Just started`,
        2: $localize`:@@power.2:Getting there`,
        3: $localize`:@@power.3:Confident`,
      })[this.level()],
  );
}
