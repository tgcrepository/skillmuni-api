import { Component, booleanAttribute, computed, input } from '@angular/core';
import { ASSETS } from '../../assets';

export type CurrencyKind = 'xp' | 'coin' | 'credit' | 'quiz';
export type CurrencySize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'inherit';

/**
 * Reward currency art (A-278): XP thunder, gold coin, credits cap — and the 3D bulb for quizzes
 * (corrections #20). Decorative — the amount next to
 * it says what it is. `live` adds a gentle idle shimmer; `pop` plays the "just earned" zap.
 */
@Component({
  selector: 'sm-currency',
  template: `<img [src]="src()" alt="" width="128" height="128" decoding="async" />`,
  styleUrl: './currency.scss',
  host: {
    'aria-hidden': 'true',
    '[class]': '"sm-currency sm-currency--" + kind() + " sm-currency--" + size()',
    '[class.is-live]': 'live()',
    '[class.is-pop]': 'pop()',
  },
})
export class Currency {
  readonly kind = input<CurrencyKind>('xp');
  readonly size = input<CurrencySize>('sm');
  readonly live = input(false, { transform: booleanAttribute });
  readonly pop = input(false, { transform: booleanAttribute });
  protected readonly src = computed(() =>
    this.kind() === 'quiz' ? ASSETS.quizBulb : ASSETS.currency[this.kind() as 'xp' | 'coin' | 'credit'],
  );
}
