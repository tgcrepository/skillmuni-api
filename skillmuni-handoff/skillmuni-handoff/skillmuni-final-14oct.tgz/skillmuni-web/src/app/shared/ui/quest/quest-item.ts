import { Component, computed, input, output } from '@angular/core';
import { QuestIllustration } from './quest-illustration';
import { ProgressBar } from '../progress-bar/progress-bar';

export type QuestItemState = 'active' | 'next' | 'locked' | 'done';
/** row: desktop rail · tile: tablet strip (art, short name, status) · icon: mobile strip (art only). */
export type QuestItemVariant = 'row' | 'tile' | 'icon';

/**
 * Figma: Navigation → Quest Item (26:497). One row in the Quest Lineup.
 * Active (Ember card + mini progress + "In your era · N of 3 done") · Next ("Up next · +50 XP") ·
 * Locked (50% art, "Locked for now") · Done (green meta). Unlocked items are buttons; locked are disabled.
 */
@Component({
  selector: 'sm-quest-item',
  imports: [QuestIllustration, ProgressBar],
  template: `
    <button
      type="button"
      class="row"
      [disabled]="state() === 'locked'"
      [attr.aria-current]="state() === 'active' ? 'step' : null"
      [attr.aria-label]="variant() === 'icon' ? title() + ', ' + meta() : null"
      (click)="open.emit(quest())"
    >
      <sm-quest-illustration [quest]="quest()" />
      @if (variant() !== 'icon') {
        <span class="text">
          <span class="title">{{ variant() === 'tile' ? short() || title() : title() }}</span>
          @if (state() === 'active' && variant() === 'row') {
            <sm-progress-bar size="s" [value]="progress()" [label]="title()" />
          }
          <span class="meta">{{ variant() === 'tile' ? tileMeta() : meta() }}</span>
        </span>
      }
    </button>
  `,
  styleUrl: './quest-item.scss',
  host: { '[class]': '"sm-quest-item sm-quest-item--" + state() + " is-" + variant()' },
})
export class QuestItem {
  readonly quest = input.required<number>();
  readonly title = input.required<string>();
  readonly short = input('');
  readonly state = input<QuestItemState>('locked');
  readonly variant = input<QuestItemVariant>('row');
  /** Parts done in the active quest. */
  readonly partsDone = input(0);
  readonly parts = input(3);
  readonly xp = input(50);
  readonly open = output<number>();

  protected readonly progress = computed(() =>
    this.parts() ? (this.partsDone() / this.parts()) * 100 : 0,
  );

  protected readonly meta = computed(() => {
    switch (this.state()) {
      case 'active':
        return $localize`:@@questItem.active:In your era · ${this.partsDone()}:done: of ${this.parts()}:parts: done`;
      case 'next':
        return $localize`:@@questItem.next:Up next · +${this.xp()}:xp: XP`;
      case 'done':
        return $localize`:@@questItem.done:Done · +${this.xp()}:xp: XP earned`;
      default:
        return $localize`:@@questItem.lockedMeta:Locked for now · +${this.xp()}:xp: XP`;
    }
  });

  /** Tablet strip status (Figma tablet frames: "0 of 3 done", "Up next", "Locked"). */
  protected readonly tileMeta = computed(() => {
    switch (this.state()) {
      case 'active':
        return $localize`:@@questItem.tileActive:${this.partsDone()}:done: of ${this.parts()}:parts: done`;
      case 'next':
        return $localize`:@@questItem.tileNext:Up next`;
      case 'done':
        return $localize`:@@questItem.tileDone:Done`;
      default:
        return $localize`:@@questItem.tileLocked:Locked`;
    }
  });
}
