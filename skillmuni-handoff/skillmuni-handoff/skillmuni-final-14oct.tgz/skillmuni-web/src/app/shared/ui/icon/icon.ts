import { Component, computed, input } from '@angular/core';
import { ICONS, IconName, IconPath } from './icons';

/** `inherit` takes the size from the parent's `--sm-icon-size` (used inside buttons, chips, fields). */
export type IconSize = 'xs' | 'sm' | 'md' | 'lg' | 'inherit';

/**
 * Figma: Icons page (Icon/*). Inherits colour from `color`.
 * Decorative by default (aria-hidden). Pass `label` when the icon is the only content that carries meaning.
 */
@Component({
  selector: 'sm-icon',
  template: `
    <svg
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      [attr.role]="label() ? 'img' : null"
      [attr.aria-label]="label() || null"
      [attr.aria-hidden]="label() ? null : 'true'"
      focusable="false"
    >
      @for (p of paths(); track $index) {
        <path
          [attr.d]="p.d"
          [attr.fill]="p.filled || p.solid ? 'currentColor' : 'none'"
          [attr.stroke]="
            p.solid ? 'none' : p.knockout ? 'var(--sm-color-bg-canvas)' : 'currentColor'
          "
          [attr.stroke-width]="p.knockout ? 2.2 : 2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      }
    </svg>
  `,
  styleUrl: './icon.scss',
  host: {
    '[class]': '"sm-icon sm-icon--" + size()',
    '[class.sm-icon--spin]': 'name() === "spinner"',
    '[class.sm-icon--mirror]': 'mirrorInRtl()',
  },
})
export class Icon {
  readonly name = input.required<IconName>();
  readonly size = input<IconSize>('md');
  /** Accessible name. Leave empty for decorative icons next to visible text. */
  readonly label = input<string>('');

  protected readonly paths = computed<readonly IconPath[]>(() => ICONS[this.name()]);

  /** Directional icons flip in right-to-left layouts. */
  protected readonly mirrorInRtl = computed(() =>
    ['chevron-left', 'chevron-right', 'arrow-right', 'arrow-left'].includes(this.name()),
  );
}
