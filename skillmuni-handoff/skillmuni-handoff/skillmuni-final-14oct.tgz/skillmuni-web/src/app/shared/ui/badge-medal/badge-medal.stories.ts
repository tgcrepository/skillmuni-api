import type { Meta, StoryObj } from '@storybook/angular-vite';
import { BadgeMedal } from './badge-medal';

const meta: Meta<BadgeMedal> = {
  title: 'Game/Badge Medal',
  component: BadgeMedal,
  parameters: { figma: { node: '169:4668' } },
};
export default meta;

export const AllStates: StoryObj<BadgeMedal> = {
  render: () => ({
    template: `
      <div style="display:flex;gap:var(--sm-space-600);align-items:center;padding:var(--sm-space-600)">
        <sm-badge-medal rarity="common" label="Common badge" />
        <sm-badge-medal rarity="rare" icon="flame" label="Rare badge" />
        <sm-badge-medal rarity="epic" icon="check-circle" label="Epic badge" />
        <sm-badge-medal rarity="legendary" label="Legendary badge" />
        <sm-badge-medal state="locked" label="Locked badge" />
        <sm-badge-medal state="secret" label="Secret badge" />
      </div>
      <div style="display:flex;gap:var(--sm-space-600);align-items:center;padding:var(--sm-space-600)">
        <sm-badge-medal size="sm" rarity="legendary" label="Small" />
        <sm-badge-medal size="md" rarity="legendary" label="Medium" />
        <sm-badge-medal size="lg" rarity="legendary" label="Large" />
        <sm-badge-medal size="lg" state="locked" label="Large locked" />
      </div>`,
    moduleMetadata: { imports: [BadgeMedal] },
  }),
};
