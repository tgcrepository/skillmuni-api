import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { BreakpointObserver } from '@angular/cdk/layout';
import { QuestCard } from './quest-card';
import { Select } from '../select/select';
import { Field } from '../field/field';

@Component({
  imports: [QuestCard, Select, Field],
  template: `
    <sm-quest-card
      eyebrow="Quest 1 of 8 · Who dis? · Part 1 of 3"
      xpPromise="+50 XP when you’re done"
      subtitle="Use the name on your ID."
      [steps]="steps"
      counter="Add your last name to keep going"
      primaryXp="+20 XP"
      [primaryDisabled]="disabled()"
      (next)="nexts = nexts + 1"
    >
      <h1 smQuestTitle>First up, what should we <em>call you?</em></h1>
      <sm-field label="Relationship"><sm-select [options]="options" [(value)]="rel" /></sm-field>
    </sm-quest-card>
  `,
})
class Host {
  readonly steps = [
    { label: 'Name', answered: 1, total: 2 },
    { label: 'ID & bday', answered: 0, total: 2, xp: '+20 XP' },
  ];
  readonly options = ['Parent', 'Guardian', 'Sibling'].map((l) => ({ value: l, label: l }));
  readonly rel = signal<string | null>(null);
  readonly disabled = signal(false);
  nexts = 0;
}

describe('QuestCard', () => {
  afterEach(() => document.querySelector('.cdk-overlay-container')?.replaceChildren());

  it('renders the heading, stepper and an explained primary action', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('h1')!.textContent).toContain('call you?');
    expect(el.querySelector('sm-section-stepper')).not.toBeNull();
    const primary = el.querySelector('button[type="submit"]')!;
    const counter = el.querySelector(`#${primary.getAttribute('aria-describedby')}`)!;
    expect(counter.textContent).toContain('Add your last name');
  });

  it('submitting the form fires next unless disabled', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const form = fixture.nativeElement.querySelector('form') as HTMLFormElement;
    form.dispatchEvent(new Event('submit', { cancelable: true }));
    expect(fixture.componentInstance.nexts).toBe(1);
    fixture.componentInstance.disabled.set(true);
    fixture.detectChanges();
    form.dispatchEvent(new Event('submit', { cancelable: true }));
    expect(fixture.componentInstance.nexts).toBe(1);
  });

  it('select opens a bottom sheet titled by the field label on mobile', async () => {
    TestBed.overrideProvider(BreakpointObserver, { useValue: { isMatched: () => true } });
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    (fixture.nativeElement.querySelector('button[role="combobox"]') as HTMLButtonElement).click();
    fixture.detectChanges();
    await fixture.whenStable();
    const pane = document.querySelector('.sm-pane--sheet')!;
    expect(pane).not.toBeNull();
    expect(pane.querySelector('h2')!.textContent).toContain('Relationship');
    const options = [...pane.querySelectorAll<HTMLElement>('[role="option"]')];
    // A–Z (A-258)
    const labels = options.map((o) => o.textContent?.trim() ?? '');
    expect(labels).toEqual([...labels].sort((a, b) => a.localeCompare(b)));
    options.find((o) => o.textContent?.includes('Guardian'))!.click();
    fixture.detectChanges();
    expect(fixture.componentInstance.rel()).toBe('Guardian');
  });
});
