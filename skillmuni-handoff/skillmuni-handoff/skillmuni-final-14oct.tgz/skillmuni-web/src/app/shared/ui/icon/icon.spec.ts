import { TestBed } from '@angular/core/testing';
import { Icon } from './icon';
import { ICON_NAMES } from './icons';

function render(inputs: Record<string, unknown>) {
  const fixture = TestBed.createComponent(Icon);
  for (const [k, v] of Object.entries(inputs)) fixture.componentRef.setInput(k, v);
  fixture.detectChanges();
  return fixture.nativeElement as HTMLElement;
}

describe('Icon', () => {
  it('ships the Figma icons (24 + 22 Home v2) plus eye-off, trend and arrow-left (A-74, A-169)', () => {
    expect(ICON_NAMES).toHaveLength(71); // + volume-x (A-279)
  });

  it('is hidden from assistive tech when decorative', () => {
    const svg = render({ name: 'check' }).querySelector('svg')!;
    expect(svg.getAttribute('aria-hidden')).toBe('true');
    expect(svg.getAttribute('role')).toBeNull();
  });

  it('exposes an accessible name when labelled', () => {
    const svg = render({ name: 'x', label: 'Close' }).querySelector('svg')!;
    expect(svg.getAttribute('role')).toBe('img');
    expect(svg.getAttribute('aria-label')).toBe('Close');
  });

  it('draws with currentColor and applies the size class', () => {
    const host = render({ name: 'search', size: 'lg' });
    expect(host.classList).toContain('sm-icon--lg');
    expect(host.querySelectorAll('path')).toHaveLength(2);
    expect(host.querySelector('path')!.getAttribute('stroke')).toBe('currentColor');
  });

  it('marks directional icons for RTL mirroring', () => {
    expect(render({ name: 'arrow-right' }).classList).toContain('sm-icon--mirror');
    expect(render({ name: 'check' }).classList).not.toContain('sm-icon--mirror');
  });
});
