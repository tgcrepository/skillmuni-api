import { Component, booleanAttribute, computed, inject, input } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Icon } from '../icon/icon';
import { IconName } from '../icon/icons';
import { MuniAvatar } from '../muni/muni-avatar';
import { MUNI_EMPTY_LINES, MuniTalk } from '../muni/muni-talk';

export type StateKind = 'error' | 'empty' | 'offline' | 'no-permission';

/**
 * Full-card state for data-backed screens. Figma: MM3 "Couldn't load your matches" (204:9085) —
 * Muni avatar, title, reassurance line, one primary action. Reused for empty, offline and
 * no-permission (A-65). Project the action as `<button sm-button smStateAction>`.
 * Error and offline announce assertively; empty and no-permission politely.
 */
@Component({
  selector: 'sm-state-block',
  imports: [Icon, MuniAvatar, MuniTalk, RouterLink],
  template: `
    @if (chatty()) {
      <h2 class="title">{{ title() }}</h2>
      <sm-muni-talk class="talk" [say]="body()" [lines]="lines()" [compact]="compact()" [large]="fill()" />
    } @else {
      <sm-muni-avatar [size]="56" />
      <h2 class="title">{{ title() }}</h2>
      @if (body()) {
        <p class="body">{{ body() }}</p>
      }
    }
    <div class="actions"><ng-content select="[smStateAction]" /></div>
    @if (fill() && chatty() && ideas().length) {
      <!-- A-303: a full-screen empty state always offers somewhere fun to go next -->
      <nav class="ideas" [attr.aria-label]="ideasLabel">
        <p class="ideas-title" aria-hidden="true">{{ ideasLabel }}</p>
        <ul class="ideas-list">
          @for (idea of ideas(); track idea.link) {
            <li>
              <a class="idea" [routerLink]="idea.link">
                <span class="idea-icon"><sm-icon [name]="idea.icon" size="sm" /></span>
                <span class="idea-text">
                  <span class="idea-label">{{ idea.label }}</span>
                  <span class="idea-sub">{{ idea.sub }}</span>
                </span>
                <sm-icon name="chevron-right" size="sm" class="idea-go" />
              </a>
            </li>
          }
        </ul>
      </nav>
    }
    <ng-content />
  `,
  styleUrl: './state-block.scss',
  host: {
    '[class]': '"sm-state-block sm-state-block--" + kind()',
    '[attr.role]': 'role()',
    '[class.sm-state-block--fill]': 'fill()',
  },
})
export class StateBlock {
  readonly kind = input<StateKind>('error');
  readonly title = input.required<string>();
  readonly body = input('');
  /**
   * A-270: empty and locked screens are a chat with Muni: he says the body, and each tap on him
   * brings another line. Pass screen-specific lines for extra fun.
   */
  readonly lines = input<readonly string[]>(MUNI_EMPTY_LINES);
  /** Smaller Muni inside cards and panels. */
  readonly compact = input(false, { transform: booleanAttribute });
  /** A-283: a full-screen empty state (the whole page has nothing else to show). */
  readonly fill = input(false, { transform: booleanAttribute });

  private readonly router = inject(Router, { optional: true });
  protected readonly ideasLabel = $localize`:@@state.ideas:Meanwhile, try one of these`;
  /** Up to three places worth a visit, never the screen you're on. */
  protected readonly ideas = computed(() => {
    const here = this.router?.url.split('?')[0] ?? '';
    return IDEAS.filter((i) => !here.startsWith(i.link)).slice(0, 3);
  });

  protected readonly chatty = computed(
    () => this.kind() === 'empty' || this.kind() === 'no-permission',
  );

  protected readonly role = computed(() =>
    this.kind() === 'error' || this.kind() === 'offline' ? 'alert' : 'status',
  );
}

interface Idea {
  readonly link: string;
  readonly icon: IconName;
  readonly label: string;
  readonly sub: string;
}

const IDEAS: readonly Idea[] = [
  {
    link: '/learn/brain-vita',
    icon: 'play',
    label: $localize`:@@state.ideaLearn:Learn something new`,
    sub: $localize`:@@state.ideaLearnSub:Short briefs and a quick quiz`,
  },
  {
    link: '/arena',
    icon: 'trophy',
    label: $localize`:@@state.ideaArena:Climb the Arena`,
    sub: $localize`:@@state.ideaArenaSub:See who’s cooking this week`,
  },
  {
    link: '/launchpad',
    icon: 'briefcase',
    label: $localize`:@@state.ideaLaunch:Career Launchpad`,
    sub: $localize`:@@state.ideaLaunchSub:Jobs, fests and your next step`,
  },
  {
    link: '/stats',
    icon: 'bar-chart',
    label: $localize`:@@state.ideaStats:Check My Stats`,
    sub: $localize`:@@state.ideaStatsSub:Your XP, streak and badges`,
  },
];
