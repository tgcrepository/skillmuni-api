import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { SegmentedControl } from './segmented-control';
import { Tabs } from '../tabs/tabs';
import { ProgressBar } from '../progress-bar/progress-bar';

@Component({
  imports: [SegmentedControl, Tabs, ProgressBar],
  template: `
    <sm-segmented-control [segments]="segments" [(value)]="mode" ariaLabel="Study status" />
    <sm-tabs [tabs]="tabs" [(value)]="tab" ariaLabel="Skill categories" controls="skills" />
    <sm-progress-bar [value]="progress()" label="Quest progress" valueText="120 of 400 XP" />
  `,
})
class Host {
  readonly segments = [
    { value: 'done', label: 'Completed' },
    { value: 'studying', label: 'Still studying' },
  ];
  readonly tabs = ['For you', 'Tech', 'Data', 'People'].map((l) => ({
    value: l.toLowerCase(),
    label: l,
  }));
  readonly mode = signal('done');
  readonly tab = signal('for you');
  readonly progress = signal(30);
}

describe('Segmented control, Tabs, Progress bar', () => {
  function setup() {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    return { fixture, host: fixture.componentInstance, el: fixture.nativeElement as HTMLElement };
  }

  it('segmented control is a radiogroup that updates the value', () => {
    const { fixture, host, el } = setup();
    const group = el.querySelector('sm-segmented-control')!;
    expect(group.getAttribute('role')).toBe('radiogroup');
    (group.querySelectorAll('input')[1] as HTMLInputElement).click();
    fixture.detectChanges();
    expect(host.mode()).toBe('studying');
    expect(group.querySelectorAll('.is-selected')[0]!.textContent).toContain('Still studying');
  });

  it('tabs use roving tabindex and arrow keys select', () => {
    const { fixture, host, el } = setup();
    const tabs = [...el.querySelectorAll<HTMLButtonElement>('[role="tab"]')];
    expect(tabs.map((t) => t.tabIndex)).toEqual([0, -1, -1, -1]);
    tabs[0]!.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight' }));
    fixture.detectChanges();
    expect(host.tab()).toBe('tech');
    expect(tabs[1]!.getAttribute('aria-selected')).toBe('true');
    tabs[1]!.dispatchEvent(new KeyboardEvent('keydown', { key: 'End' }));
    fixture.detectChanges();
    expect(host.tab()).toBe('people');
  });

  it('progress bar exposes clamped value and text', () => {
    const { fixture, host, el } = setup();
    const bar = el.querySelector('sm-progress-bar')!;
    expect(bar.getAttribute('aria-valuenow')).toBe('30');
    expect(bar.getAttribute('aria-valuetext')).toBe('120 of 400 XP');
    host.progress.set(140);
    fixture.detectChanges();
    expect(bar.getAttribute('aria-valuenow')).toBe('100');
  });
});
