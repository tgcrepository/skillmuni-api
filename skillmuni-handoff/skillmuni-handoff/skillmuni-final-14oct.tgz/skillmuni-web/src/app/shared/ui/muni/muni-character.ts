import { NgOptimizedImage } from '@angular/common';
import { signal } from '@angular/core';
import { Component, booleanAttribute, input } from '@angular/core';
import { ASSETS } from '../../assets';

/**
 * Figma: Muni → Muni Character (28:2). Full-body Muni for the desktop reward rail and intro.
 * Alt text from the Figma dev note: "Muni, your Skillmuni guide". Gently bobs (off with reduced motion).
 */
@Component({
  imports: [NgOptimizedImage],
  selector: 'sm-muni-character',
  template: `<img
    [ngSrc]="src"
    [alt]="alt()"
    width="208"
    height="369"
    [priority]="priority()"
    (error)="missing.set(true)"
    [class.is-missing]="missing()"
  />`,
  styleUrl: './muni-character.scss',
  host: {
    class: 'sm-muni-character',
    '[class.is-idle]': 'idle()',
    '[class.is-grounded]': 'grounded()',
    '[class.fit-height]': "fit() === 'height'",
  },
})
export class MuniCharacter {
  protected readonly missing = signal(false);
  readonly alt = input($localize`:@@muni.alt:Muni, your Skillmuni guide`);
  /** Idle bob animation. */
  readonly idle = input(true);
  /** Standing on the page: soft contact shadow under the feet (A-240). */
  readonly grounded = input(false, { transform: booleanAttribute });
  /** `height`: fill the host's height (a rail that shrinks on short screens), keeping his shape. */
  readonly fit = input<'width' | 'height'>('width');
  /** Set when Muni is above the fold (LCP image). */
  readonly priority = input(false);
  protected readonly src = ASSETS.muniCharacter;
}
