import { Component, inject } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ToastHost } from './toast-host';
import { ToastService } from './toast.service';
import { Banner } from '../banner/banner';

@Component({
  imports: [ToastHost, Banner],
  template: `
    <sm-toast-host />
    <sm-banner tone="error" dismissible (dismiss)="dismissed = true"
      >Fix the highlighted answers</sm-banner
    >
    <sm-banner tone="success">Bank-level encryption.</sm-banner>
  `,
})
class Host {
  readonly toasts = inject(ToastService);
  dismissed = false;
}

describe('Toast and Banner', () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it('shows the same message once while it is still up (A-288)', () => {
    const service = TestBed.inject(ToastService);
    const a = service.show('2 new jobs match you');
    const b = service.show('2 new jobs match you');
    expect(b).toBe(a);
    expect(service.toasts().length).toBe(1);
  });

  it('runs an Undo action once and closes the toast', () => {
    const fixture = TestBed.createComponent(Host);
    const run = vi.fn();
    fixture.componentInstance.toasts.show('12th removed', {
      duration: 6000,
      action: { label: 'Undo', run },
    });
    fixture.detectChanges();
    const button = fixture.nativeElement.querySelector('.toast .action') as HTMLButtonElement;
    expect(button.textContent?.trim()).toBe('Undo');
    button.click();
    expect(run).toHaveBeenCalledTimes(1);
    expect(fixture.componentInstance.toasts.toasts()).toHaveLength(0);
  });

  it('announces toasts politely and auto-dismisses after 3 s', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const host = fixture.nativeElement.querySelector('sm-toast-host') as HTMLElement;
    expect(host.getAttribute('aria-live')).toBe('polite');

    fixture.componentInstance.toasts.reward('Name locked in', '+20 XP');
    fixture.detectChanges();
    expect(host.textContent).toContain('+20 XP');
    expect(host.textContent).toContain('Name locked in');

    vi.advanceTimersByTime(3001);
    expect(fixture.componentInstance.toasts.toasts()).toHaveLength(0);
  });

  it('pauses the timer while hovered', () => {
    const fixture = TestBed.createComponent(Host);
    const service = fixture.componentInstance.toasts;
    const id = service.show('Saved');
    service.pause(id);
    vi.advanceTimersByTime(10_000);
    expect(service.toasts()).toHaveLength(1);
    service.resume(id);
    vi.advanceTimersByTime(3001);
    expect(service.toasts()).toHaveLength(0);
  });

  it('keeps at most 3 toasts', () => {
    const fixture = TestBed.createComponent(Host);
    const service = fixture.componentInstance.toasts;
    for (const m of ['a', 'b', 'c', 'd']) service.show(m);
    expect(service.toasts().map((t) => t.message)).toEqual(['b', 'c', 'd']);
  });

  it('error banners are alerts and can be dismissed', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const [error, success] = fixture.nativeElement.querySelectorAll(
      'sm-banner',
    ) as NodeListOf<HTMLElement>;
    expect(error!.getAttribute('role')).toBe('alert');
    expect(success!.getAttribute('role')).toBeNull();
    (error!.querySelector('button') as HTMLButtonElement).click();
    expect(fixture.componentInstance.dismissed).toBe(true);
  });
});
