import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Button, ButtonVariant } from './button';

@Component({
  imports: [Button],
  template: `
    <button
      sm-button
      [variant]="variant()"
      [disabled]="disabled()"
      [loading]="loading()"
      [xp]="xp()"
      trailingIcon="arrow-right"
      (click)="clicks = clicks + 1"
    >
      Next part
    </button>
    <a sm-button href="/somewhere" variant="secondary">Go back</a>
  `,
})
class Host {
  readonly variant = signal<ButtonVariant>('primary');
  readonly disabled = signal(false);
  readonly loading = signal(false);
  readonly xp = signal('');
  clicks = 0;
}

function setup() {
  const fixture = TestBed.createComponent(Host);
  fixture.detectChanges();
  const button = fixture.nativeElement.querySelector('button') as HTMLButtonElement;
  return { fixture, host: fixture.componentInstance, button };
}

describe('Button', () => {
  it('renders the label on a native button with type="button"', () => {
    const { button } = setup();
    expect(button.textContent).toContain('Next part');
    expect(button.getAttribute('type')).toBe('button');
    expect(button.classList).toContain('sm-button--primary');
  });

  it('does not add a type attribute to links', () => {
    const { fixture } = setup();
    const link = fixture.nativeElement.querySelector('a') as HTMLAnchorElement;
    expect(link.hasAttribute('type')).toBe(false);
    expect(link.classList).toContain('sm-button--secondary');
  });

  it('blocks clicks and stays focusable when disabled', () => {
    const { fixture, host, button } = setup();
    host.disabled.set(true);
    fixture.detectChanges();
    button.click();
    expect(host.clicks).toBe(0);
    expect(button.getAttribute('aria-disabled')).toBe('true');
    expect(button.hasAttribute('disabled')).toBe(false);
  });

  it('announces loading, hides the label from AT and blocks clicks', () => {
    const { fixture, host, button } = setup();
    host.loading.set(true);
    fixture.detectChanges();
    button.click();
    expect(host.clicks).toBe(0);
    expect(button.getAttribute('aria-busy')).toBe('true');
    expect(button.querySelector('[role="status"]')!.textContent).toContain('Saving…');
    expect(button.querySelector('.content')!.getAttribute('aria-hidden')).toBe('true');
  });

  it('shows the XP reward chip only when set', () => {
    const { fixture, host, button } = setup();
    expect(button.querySelector('.xp')).toBeNull();
    host.xp.set('+20 XP');
    fixture.detectChanges();
    expect(button.querySelector('.xp')!.textContent).toBe('+20 XP');
  });

  it('switches variant class', () => {
    const { fixture, host, button } = setup();
    host.variant.set('outline-brand');
    fixture.detectChanges();
    expect(button.classList).toContain('sm-button--outline-brand');
  });
});
