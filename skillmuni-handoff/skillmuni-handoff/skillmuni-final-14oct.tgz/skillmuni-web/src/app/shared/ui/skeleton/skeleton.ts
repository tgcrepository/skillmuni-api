import { Component, input } from '@angular/core';

export type SkeletonShape = 'line' | 'block' | 'pill' | 'circle';

/**
 * Figma: MM1 Loading (skeleton) (204:8692). Placeholder bars inside the real card frames.
 * Decorative: wrap a group of skeletons in an element with aria-busy="true" and a visually hidden
 * "Loading…" label. Shimmer is transform-only and stops under reduced motion.
 */
@Component({
  selector: 'sm-skeleton',
  template: '',
  styleUrl: './skeleton.scss',
  host: {
    '[class]': '"sm-skeleton sm-skeleton--" + shape()',
    'aria-hidden': 'true',
    '[style.inline-size]': 'width()',
  },
})
export class Skeleton {
  readonly shape = input<SkeletonShape>('line');
  /** Any CSS length, ideally a token or percentage, e.g. "60%". */
  readonly width = input<string | null>(null);
}
