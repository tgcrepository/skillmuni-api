import { Component, booleanAttribute, input, model, output } from '@angular/core';
import type { FormCheckboxControl } from '@angular/forms/signals';
import { Icon } from '../icon/icon';

/**
 * Figma: Selection Controls → Checkbox (16:60). 20px, radius/sm; checked = Ember gradient + white check.
 * Multi-select cards, consent ("I agree…"), "Make it a signature move".
 * A native checkbox under the hood; works with Signal Forms via `[formField]`.
 */
@Component({
  selector: 'sm-checkbox',
  imports: [Icon],
  template: `
    <label class="row">
      <span class="box">
        <input
          type="checkbox"
          [checked]="checked()"
          [indeterminate]="indeterminate()"
          [disabled]="disabled()"
          [required]="required()"
          [attr.aria-invalid]="invalid() || null"
          [attr.aria-describedby]="describedBy() || null"
          [attr.name]="name() || null"
          (change)="onChange($event)"
          (blur)="touch.emit()"
        />
        <span class="mark" aria-hidden="true">
          @if (indeterminate()) {
            <span class="dash"></span>
          } @else {
            <sm-icon name="check" size="inherit" />
          }
        </span>
      </span>
      <span class="label"><ng-content /></span>
    </label>
  `,
  styleUrl: './checkbox.scss',
  host: {
    class: 'sm-checkbox',
    '[class.is-checked]': 'checked() || indeterminate()',
    '[class.is-disabled]': 'disabled()',
    '[class.is-invalid]': 'invalid()',
  },
})
export class Checkbox implements FormCheckboxControl {
  readonly checked = model(false);
  readonly indeterminate = input(false, { transform: booleanAttribute });
  readonly disabled = input(false, { transform: booleanAttribute });
  readonly required = input(false, { transform: booleanAttribute });
  readonly invalid = input(false, { transform: booleanAttribute });
  readonly name = input('');
  /** Id(s) of helper / error text. */
  readonly describedBy = input('');
  readonly touch = output<void>();

  protected onChange(event: Event): void {
    this.checked.set((event.target as HTMLInputElement).checked);
  }
}
