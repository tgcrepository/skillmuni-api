import { Component, inject } from '@angular/core';
import type { Meta, StoryObj } from '@storybook/angular-vite';
import { OverlayService } from './overlay.service';
import { SmDialog } from './dialog';
import { Button } from '../button/button';
import { ChipGroup } from '../chip/chip-group';
import { Panel } from '../panel/panel';

@Component({
  selector: 'sm-demo-relationship',
  imports: [SmDialog, Button, ChipGroup],
  template: `
    <sm-dialog #d title="Who are they to you?" subtitle="Pick one. You can change it later.">
      <sm-chip-group [options]="options" ariaLabel="Relationship" />
      <div smDialogActions><button sm-button (click)="d.close()">Done</button></div>
    </sm-dialog>
  `,
})
class RelationshipPicker {
  readonly options = [
    'Parent',
    'Guardian',
    'Sibling',
    'Spouse / Partner',
    'Friend',
    'Relative',
  ].map((l) => ({ value: l, label: l }));
}

@Component({
  selector: 'sm-demo-overlays',
  imports: [Button],
  template: `
    <div style="display:flex;gap:var(--sm-space-400)">
      <button sm-button (click)="overlays.modal(picker)">Open modal</button>
      <button sm-button variant="secondary" (click)="overlays.sheet(picker)">
        Open bottom sheet
      </button>
      <button sm-button variant="outline-brand" (click)="overlays.adaptive(picker)">
        Adaptive
      </button>
    </div>
  `,
})
class OverlayDemo {
  protected readonly overlays = inject(OverlayService);
  protected readonly picker = RelationshipPicker;
}

const meta: Meta = {
  title: 'Composites/Overlays',
  parameters: { figma: { node: 'Panel 30:49 · Bottom Sheet 31:168 · Scrim 31:182' } },
};
export default meta;

export const ModalAndSheet: StoryObj = {
  render: () => ({ template: `<sm-demo-overlays />`, moduleMetadata: { imports: [OverlayDemo] } }),
};

export const Panels: StoryObj = {
  parameters: { layout: 'padded' },
  render: () => ({
    template: `
      <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:var(--sm-space-800);max-inline-size:var(--sm-layout-content-max-width)">
        @for (v of ['glass','glass-muted','raised','inset']; track v) {
          <sm-panel [variant]="$any(v)"><p class="sm-text-title">{{ v }}</p><p class="sm-text-body-sm">Panel content</p></sm-panel>
        }
      </div>`,
    moduleMetadata: { imports: [Panel] },
  }),
};
