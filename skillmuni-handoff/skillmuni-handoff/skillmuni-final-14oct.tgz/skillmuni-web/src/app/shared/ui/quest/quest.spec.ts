import { Component, inject } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { QuestMap } from './quest-map';
import { LootDropCard } from './loot-drop-card';
import { BadgeRing } from './badge-ring';
import { QuestComplete, QuestCompleteData } from './quest-complete';
import { OverlayService } from '../overlay/overlay.service';

@Component({
  imports: [QuestMap, LootDropCard, BadgeRing],
  template: `
    <sm-quest-map [progress]="{ completed: 1, partsDone: 1 }" (open)="opened = $event" />
    <sm-loot-drop-card [quest]="2" badge="Link Up Badge" reward="+50 XP" [progress]="80" />
    <sm-badge-ring [quest]="1" [progress]="100" label="Main Character Badge" />
  `,
})
class Host {
  readonly overlays = inject(OverlayService);
  opened = 0;
}

const DATA: QuestCompleteData = {
  quest: 1,
  eyebrow: 'Quest 1 of 8: done and dusted',
  body: 'Your basics are saved.',
  xpEarned: 50,
  rank: 'Rookie',
  level: 1,
  xpBefore: 90,
  xpTarget: 400,
  nextRank: 'Pathfinder',
  next: { quest: 2, name: 'Hit Me Up', meta: '2 mins · +110 XP' },
};

describe('Quest composites', () => {
  function setup() {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    return { fixture, el: fixture.nativeElement as HTMLElement };
  }

  afterEach(() => document.querySelector('.cdk-overlay-container')?.replaceChildren());

  it('quest map derives done / active / next / locked from progress', () => {
    const { el } = setup();
    const items = [...el.querySelectorAll('sm-quest-item')];
    expect(items).toHaveLength(8);
    expect(items[0]!.classList).toContain('sm-quest-item--done');
    expect(items[1]!.classList).toContain('sm-quest-item--active');
    expect(items[2]!.classList).toContain('sm-quest-item--next');
    expect(items[3]!.classList).toContain('sm-quest-item--locked');
    expect(items[1]!.querySelector('button')!.getAttribute('aria-current')).toBe('step');
    expect((items[3]!.querySelector('button') as HTMLButtonElement).disabled).toBe(true);
    expect(el.querySelector('sm-quest-map')!.getAttribute('role')).toBe('navigation');
  });

  it('emits the quest id when an unlocked row is chosen', () => {
    const { fixture, el } = setup();
    (el.querySelectorAll('sm-quest-item button')[2] as HTMLButtonElement).click();
    expect(fixture.componentInstance.opened).toBe(3);
  });

  it('loot drop card and badge ring describe progress in text', () => {
    const { el } = setup();
    expect(el.querySelector('sm-loot-drop-card')!.textContent).toContain('80% there, almost');
    const ring = el.querySelector('sm-badge-ring:not(sm-loot-drop-card sm-badge-ring)')!;
    expect(ring.getAttribute('role')).toBe('img');
    expect(ring.classList).toContain('is-unlocked');
  });

  it('quest complete modal is labelled by its title and offers continue / review', async () => {
    const { fixture } = setup();
    const ref = fixture.componentInstance.overlays.modal<QuestComplete, QuestCompleteData, string>(
      QuestComplete,
      { data: DATA },
    );
    fixture.detectChanges();
    await fixture.whenStable();
    const dialog = document.querySelector('[role="dialog"]')!;
    expect(document.getElementById(dialog.getAttribute('aria-labelledby')!)!.textContent).toContain(
      'Badge unlocked!',
    );
    expect(dialog.textContent).toContain('Hit Me Up');
    let result: string | undefined;
    ref.closed.subscribe((r) => (result = r));
    const buttons = dialog.querySelectorAll<HTMLButtonElement>('[smDialogActions] button');
    buttons[1]!.click();
    await new Promise((r) => setTimeout(r, 0));
    expect(result).toBe('continue');
  });
});
