import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { IconButton } from './icon-button';

@Component({
  imports: [IconButton],
  template: `<button
    sm-icon-button
    icon="edit"
    label="Edit first name"
    [disabled]="disabled()"
    (click)="clicks = clicks + 1"
  ></button>`,
})
class Host {
  readonly disabled = signal(false);
  clicks = 0;
}

describe('IconButton', () => {
  it('has an accessible name, button type and the 44px default size', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const btn = fixture.nativeElement.querySelector('button') as HTMLButtonElement;
    expect(btn.getAttribute('aria-label')).toBe('Edit first name');
    expect(btn.getAttribute('type')).toBe('button');
    expect(btn.classList).toContain('sm-icon-button--44');
  });

  it('ignores clicks when disabled', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.componentInstance.disabled.set(true);
    fixture.detectChanges();
    const btn = fixture.nativeElement.querySelector('button') as HTMLButtonElement;
    btn.click();
    expect(fixture.componentInstance.clicks).toBe(0);
    expect(btn.getAttribute('aria-disabled')).toBe('true');
  });
});
