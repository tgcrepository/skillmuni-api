import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { StateBlock } from './state-block';
import { Skeleton } from '../skeleton/skeleton';

@Component({
  imports: [StateBlock, Skeleton],
  template: `
    <sm-state-block id="err" title="Couldn’t load your matches" body="Your profile is safe.">
      <button smStateAction type="button">Try again</button>
    </sm-state-block>
    <sm-state-block id="empty" kind="empty" title="No matches yet" />
    <sm-skeleton shape="pill" width="60%" />
  `,
})
class Host {}

describe('StateBlock and Skeleton', () => {
  it('errors are alerts with a heading and action; empty is a polite status', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('#err')?.getAttribute('role')).toBe('alert');
    expect(el.querySelector('#err h2')?.textContent).toContain('Couldn’t load');
    expect(el.querySelector('#err button')?.textContent).toContain('Try again');
    expect(el.querySelector('#empty')?.getAttribute('role')).toBe('status');
    expect(el.querySelector('#empty .body')).toBeNull();
    // A-270: empty states talk through Muni
    expect(el.querySelector('#empty sm-muni-talk')).not.toBeNull();
  });

  it('skeletons are hidden from assistive tech', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const sk = (fixture.nativeElement as HTMLElement).querySelector('sm-skeleton') as HTMLElement;
    expect(sk.getAttribute('aria-hidden')).toBe('true');
    expect(sk.classList).toContain('sm-skeleton--pill');
    expect(sk.style.inlineSize).toBe('60%');
  });
});
