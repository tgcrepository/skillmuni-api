import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Icon } from './icon';
import { ICON_NAMES } from './icons';

const meta: Meta<Icon> = {
  title: 'Primitives/Icon',
  component: Icon,
  parameters: { figma: { node: 'Icons page (8:9)' } },
  argTypes: {
    name: { control: 'select', options: ICON_NAMES },
    size: { control: 'inline-radio', options: ['xs', 'sm', 'md', 'lg'] },
  },
  args: { name: 'sparkle', size: 'lg', label: '' },
};
export default meta;
type Story = StoryObj<Icon>;

export const Playground: Story = {};

export const AllIcons: Story = {
  render: () => ({
    props: { names: ICON_NAMES },
    template: `
      <ul style="display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:var(--sm-space-600);list-style:none;padding:0;margin:0;color:var(--sm-color-icon-default)">
        @for (n of names; track n) {
          <li style="display:grid;justify-items:center;gap:var(--sm-space-200)">
            <sm-icon [name]="n" size="lg" />
            <code class="sm-text-caption">{{ n }}</code>
          </li>
        }
      </ul>`,
    moduleMetadata: { imports: [Icon] },
  }),
};
