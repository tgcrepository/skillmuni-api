import {
  Component,
  DestroyRef,
  DOCUMENT,
  ElementRef,
  booleanAttribute,
  computed,
  inject,
  input,
  LOCALE_ID,
  linkedSignal,
  model,
  output,
  signal,
  TemplateRef,
  viewChild,
} from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { DialogRef } from '@angular/cdk/dialog';
import { CdkConnectedOverlay, CdkOverlayOrigin, ConnectedPosition } from '@angular/cdk/overlay';
import type { FormValueControl } from '@angular/forms/signals';
import { Icon } from '../icon/icon';
import { StatusIcon, StatusTone } from '../status-icon/status-icon';
import { FIELD_CONTEXT, FieldStatus } from '../field/field-context';
import { uniqueId } from '../internal/unique-id';
import { OptionOrder, alphabetical } from '../internal/alphabetical';
import { OverlayService, requestClose } from '../overlay/overlay.service';
import { SmDialog } from '../overlay/dialog';

export interface SelectOption {
  readonly value: string;
  readonly label: string;
  readonly disabled?: boolean;
}

/** Figma Menu rule: more than 7 options → search on top and "See all" at the bottom. */
const MAX_VISIBLE = 7;

const POSITIONS: ConnectedPosition[] = [
  { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 8 },
  { originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom', offsetY: -8 },
];

/**
 * Figma: Select & Menu → Select (21:149), Menu (21:243), Menu Option (21:102).
 * WAI-ARIA combobox + listbox: focus stays on the trigger (or the search box) and the active option is
 * announced with aria-activedescendant. Keys: ↑ ↓ Home End to move, Enter/Space to pick, Esc to close,
 * type-ahead on the trigger. Same height, radius and states as Input so fields line up in a row.
 * Works with Signal Forms via `[formField]`.
 */
@Component({
  selector: 'sm-select',
  imports: [Icon, StatusIcon, CdkConnectedOverlay, CdkOverlayOrigin, NgTemplateOutlet, SmDialog],
  templateUrl: './select.html',
  styleUrl: './select.scss',
  host: {
    '[class]': '"sm-select sm-select--" + resolvedStatus()',
    '[class.is-open]': 'open()',
    '[class.is-disabled]': 'disabled()',
    '[class.is-filled]': '!!selected()',
  },
})
export class Select implements FormValueControl<string | null> {
  private readonly field = inject(FIELD_CONTEXT, { optional: true });
  private readonly document = inject(DOCUMENT);
  private readonly triggerEl = viewChild.required<ElementRef<HTMLButtonElement>>('trigger');
  private readonly searchEl = viewChild<ElementRef<HTMLInputElement>>('search');
  private readonly sheetTpl = viewChild.required<TemplateRef<unknown>>('sheet');
  private readonly overlays = inject(OverlayService);
  private sheetRef: DialogRef<unknown, unknown> | null = null;

  constructor() {
    // The sheet renders this component's template: if the select goes away (e.g. its row is removed right
    // after a pick), close the sheet at once so the scrim and scroll lock don't outlive it.
    inject(DestroyRef).onDestroy(() => this.sheetRef?.close());
  }

  readonly value = model<string | null>(null);
  readonly options = input.required<readonly SelectOption[]>();
  /**
   * A–Z by default (A-258). Use `given` only for lists with a natural order: years, levels,
   * ranges, sort orders.
   */
  readonly order = input<OptionOrder>('alpha');
  private readonly locale = inject(LOCALE_ID);
  protected readonly ordered = computed(() =>
    this.order() === 'alpha'
      ? alphabetical(this.options(), (o) => o.label, this.locale)
      : this.options(),
  );
  readonly placeholder = input($localize`:@@ui.select.placeholder:Select an option`);
  readonly disabled = input(false, { transform: booleanAttribute });
  readonly required = input(false, { transform: booleanAttribute });
  readonly invalid = input(false, { transform: booleanAttribute });
  /**
   * Bound by Signal Forms' [formField]. A required-but-empty field is "invalid" from the start; it only
   * turns red once touched (or when <sm-field> shows an error, e.g. after Next).
   */
  readonly touched = input(true);
  readonly loading = input(false, { transform: booleanAttribute });
  /** Search box; on by default (A-163). Turn off only for tiny fixed lists such as months or sort. */
  readonly searchable = input<boolean | undefined>(undefined);
  readonly groupLabel = input('');
  /** Show every option without "See all" (short fixed lists such as the 12 months). */
  readonly showAll = input(false, { transform: booleanAttribute });
  /**
   * "Not listed? Type it in" (A-163): on by default. The typed text becomes the value (and `custom` fires),
   * so every form gets it without extra wiring. Turn off for lists that must match (months, years, sort).
   */
  readonly allowCustom = input(true, { transform: booleanAttribute });
  readonly ariaLabel = input('');
  readonly status = input<FieldStatus | null>(null);
  readonly custom = output<string>();
  readonly touch = output<void>();

  protected readonly id = this.field?.controlId ?? uniqueId('select');
  protected readonly listId = uniqueId('select-list');
  protected readonly positions = POSITIONS;

  /** closed · menu (dropdown, tablet/desktop) · sheet (bottom sheet, mobile) */
  protected readonly mode = signal<'closed' | 'menu' | 'sheet'>('closed');
  protected readonly open = computed(() => this.mode() !== 'closed');
  protected readonly sheetTitle = computed(
    () => this.field?.label() || this.ariaLabel() || this.placeholder(),
  );
  protected readonly query = signal('');
  protected readonly typing = signal(false);
  protected readonly searchPlaceholder = $localize`:@@ui.select.search:Search`;
  protected readonly typePlaceholder = $localize`:@@ui.select.typeHere:Type it here, then press Enter`;
  protected readonly expanded = signal(false);
  protected readonly panelWidth = signal(0);

  protected readonly isSearchable = computed(() => this.searchable() ?? true);
  /** A typed-in value that isn't one of the options still shows as the selection. */
  protected readonly selected = computed<SelectOption | null>(() => {
    const v = this.value();
    if (!v) return null;
    return (
      this.options().find((o) => o.value === v) ??
      (this.allowCustom() ? { value: v, label: v } : null)
    );
  });
  /** Offer "Use “…”" while typing unless the text matches an option exactly. */
  protected readonly customText = computed(() => {
    const q = this.query().trim();
    if (!this.allowCustom() || !q) return '';
    const exact = this.options().some((o) => o.label.toLocaleLowerCase() === q.toLocaleLowerCase());
    return exact ? '' : q;
  });

  protected readonly filtered = computed(() => {
    const q = this.query().trim().toLocaleLowerCase();
    return q
      ? this.ordered().filter((o) => o.label.toLocaleLowerCase().includes(q))
      : this.ordered();
  });
  protected readonly visible = computed(() =>
    this.showAll() || this.expanded() || this.query()
      ? this.filtered()
      : this.filtered().slice(0, MAX_VISIBLE),
  );
  protected readonly hiddenCount = computed(() => this.filtered().length - this.visible().length);

  protected readonly active = linkedSignal(() => {
    const list = this.visible();
    const i = list.findIndex((o) => o.value === this.value());
    return i >= 0 ? i : list.findIndex((o) => !o.disabled);
  });
  protected readonly activeId = computed(() =>
    this.open() && this.active() >= 0 ? this.optionId(this.active()) : null,
  );

  protected readonly resolvedStatus = computed<FieldStatus>(
    () =>
      this.status() ??
      (this.invalid() && this.touched() ? 'error' : (this.field?.status() ?? 'none')),
  );
  protected readonly statusTone = computed<StatusTone | null>(() => {
    const s = this.resolvedStatus();
    return s === 'none' ? null : s === 'valid' ? 'success' : s;
  });
  protected readonly describedBy = computed(() => this.field?.describedBy() ?? '');
  protected readonly isRequired = computed(
    () => this.required() || (this.field?.required() ?? false),
  );

  protected optionId(index: number): string {
    return `${this.listId}-${index}`;
  }

  protected toggle(): void {
    if (this.open()) this.close();
    else this.show();
  }

  protected show(): void {
    if (this.disabled() || this.loading()) return;
    this.panelWidth.set(this.triggerEl().nativeElement.getBoundingClientRect().width);
    this.query.set('');
    this.expanded.set(false);
    if (this.overlays.isMobile()) {
      this.mode.set('sheet');
      this.sheetRef = this.overlays.sheet(this.sheetTpl());
      this.sheetRef.closed.subscribe(() => {
        this.sheetRef = null;
        if (this.mode() === 'sheet') this.mode.set('closed');
        this.touch.emit();
      });
      return;
    }
    this.mode.set('menu');
    if (this.isSearchable()) queueMicrotask(() => this.searchEl()?.nativeElement.focus());
  }

  protected close(restoreFocus = true): void {
    if (!this.open()) return;
    const wasSheet = this.mode() === 'sheet';
    this.mode.set('closed');
    this.typing.set(false);
    if (wasSheet && this.sheetRef) {
      // CDK Dialog restores focus to the trigger itself.
      requestClose(this.sheetRef);
      return;
    }
    if (restoreFocus) this.triggerEl().nativeElement.focus();
  }

  protected pick(option: SelectOption): void {
    if (option.disabled) return;
    this.value.set(option.value);
    this.close();
  }

  protected useCustom(): void {
    const text = this.query().trim();
    if (!text) return;
    this.value.set(text);
    this.custom.emit(text);
    this.close();
  }

  /** "Not listed? Type it in": puts the cursor in the search box, which doubles as the free-text field. */
  protected typeIn(): void {
    this.typing.set(true);
    queueMicrotask(() => this.searchEl()?.nativeElement.focus());
  }

  protected onBlur(): void {
    if (!this.open()) this.touch.emit();
  }

  protected onKeydown(event: KeyboardEvent): void {
    const list = this.visible();
    if (!this.open()) {
      if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(event.key)) {
        event.preventDefault();
        this.show();
      } else if (event.key.length === 1 && !this.isSearchable()) {
        this.typeAhead(event.key, list, true);
      }
      return;
    }
    switch (event.key) {
      case 'ArrowDown':
        event.preventDefault();
        this.move(1, list);
        break;
      case 'ArrowUp':
        event.preventDefault();
        this.move(-1, list);
        break;
      case 'Home':
        event.preventDefault();
        this.active.set(list.findIndex((o) => !o.disabled));
        break;
      case 'End':
        event.preventDefault();
        this.active.set(list.length - 1 - [...list].reverse().findIndex((o) => !o.disabled));
        break;
      case 'Enter': {
        event.preventDefault();
        const option = list[this.active()];
        if (option) this.pick(option);
        else if (this.allowCustom()) this.useCustom();
        break;
      }
      case ' ':
        if (!this.isSearchable()) {
          event.preventDefault();
          const option = list[this.active()];
          if (option) this.pick(option);
        }
        break;
      case 'Escape':
        event.preventDefault();
        this.close();
        break;
      case 'Tab':
        this.close(false);
        break;
      default:
        if (event.key.length === 1 && !this.isSearchable()) this.typeAhead(event.key, list, false);
    }
  }

  protected onSearch(event: Event): void {
    this.query.set((event.target as HTMLInputElement).value);
    this.active.set(this.visible().findIndex((o) => !o.disabled));
  }

  private move(step: 1 | -1, list: readonly SelectOption[]): void {
    if (!list.length) return;
    // Walk in the given direction (wrapping) to the next enabled option.
    const order = list.map(
      (_, n) => (this.active() + step * (n + 1) + list.length * 2) % list.length,
    );
    const i = order.find((n) => !list[n]?.disabled) ?? this.active();
    this.active.set(i);
    queueMicrotask(() =>
      this.document.getElementById(this.optionId(i))?.scrollIntoView({ block: 'nearest' }),
    );
  }

  private typeAhead(key: string, list: readonly SelectOption[], select: boolean): void {
    const k = key.toLocaleLowerCase();
    const start = this.active() + 1;
    const ordered = [...list.slice(start), ...list.slice(0, start)];
    const hit = ordered.find((o) => !o.disabled && o.label.toLocaleLowerCase().startsWith(k));
    if (!hit) return;
    const index = list.indexOf(hit);
    this.active.set(index);
    if (select) this.value.set(hit.value);
  }
}
