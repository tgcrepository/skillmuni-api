import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Select } from './select';
import { Field } from '../field/field';

const relationships = [
  'Parent',
  'Guardian',
  'Sibling',
  'Spouse / Partner',
  'Friend',
  'Relative',
  'Other (type it in)',
].map((l) => ({ value: l, label: l }));
const states = [
  'Andhra Pradesh',
  'Arunachal Pradesh',
  'Assam',
  'Bihar',
  'Chhattisgarh',
  'Goa',
  'Gujarat',
  'Haryana',
  'Himachal Pradesh',
  'Jharkhand',
  'Karnataka',
  'Kerala',
  'Maharashtra',
].map((l) => ({ value: l, label: l }));

const meta: Meta<Select> = {
  title: 'Primitives/Select',
  component: Select,
  parameters: {
    figma: { node: 'Select 21:149 · Menu 21:243 · Menu Option 21:102' },
    layout: 'padded',
  },
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [Select, Field] } })],
};
export default meta;

export const States: StoryObj<Select> = {
  render: () => ({
    props: { relationships, states },
    template: `
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(var(--sm-layout-shell-map-width),1fr));gap:var(--sm-space-800);max-inline-size:var(--sm-layout-content-max-width)">
        <sm-field label="Relationship"><sm-select [options]="relationships" placeholder="Pick one" /></sm-field>
        <sm-field label="Relationship"><sm-select [options]="relationships" value="Parent" /></sm-field>
        <sm-field label="State" status="valid"><sm-select [options]="states" value="Maharashtra" /></sm-field>
        <sm-field label="State" error="Pick your state to keep going"><sm-select [options]="states" placeholder="Select your state" /></sm-field>
        <sm-field label="Area" disabled helper="Add your PIN first"><sm-select [options]="states" placeholder="Select your area" disabled /></sm-field>
        <sm-field label="Area"><sm-select [options]="states" placeholder="Loading areas…" loading /></sm-field>
      </div>`,
  }),
};

export const SearchableWithCustom: StoryObj<Select> = {
  render: () => ({
    props: { states },
    template: `<div style="inline-size:var(--sm-layout-shell-rail-width)"><sm-field label="State"><sm-select [options]="states" groupLabel="States & UTs" placeholder="Select your state" allowCustom /></sm-field></div>`,
  }),
};
