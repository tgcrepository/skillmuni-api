import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, inject, viewChild } from '@angular/core';
import { Button } from '../button/button';
import { MuniAvatar } from '../muni/muni-avatar';
import { SmDialog } from '../overlay/dialog';

export interface MuniPromptData {
  readonly title: string;
  readonly body: string;
  readonly primary: string;
  readonly secondary?: string;
  /** Close X (modal) / drag-to-dismiss (sheet). False for critical prompts like SE1. */
  readonly dismissible?: boolean;
}

/** Result of a Muni prompt: which action was taken, or undefined when dismissed. */
export type MuniPromptResult = 'primary' | 'secondary' | undefined;

/**
 * Muni-led decision dialog — SE1 Session expired (203:9762), PM1 Camera primer (203:8534),
 * PM2 Notifications primer (203:8988). Avatar, title, one-paragraph body, stacked full-width actions.
 * Open with OverlayService (modal, sheet or adaptive).
 */
@Component({
  selector: 'sm-muni-prompt',
  imports: [SmDialog, MuniAvatar, Button],
  template: `
    <sm-dialog
      centered
      stacked
      [title]="data.title"
      [subtitle]="data.body"
      [dismissible]="data.dismissible ?? true"
    >
      <sm-muni-avatar smDialogLead [size]="56" />
      <div smDialogActions>
        <button sm-button type="button" (click)="choose('primary')">{{ data.primary }}</button>
        @if (data.secondary) {
          <button sm-button variant="secondary" type="button" (click)="choose('secondary')">
            {{ data.secondary }}
          </button>
        }
      </div>
    </sm-dialog>
  `,
  styles: `
    sm-dialog ::ng-deep .subtitle {
      max-inline-size: calc(var(--sm-size-modal-width-sm) * 0.82);
      color: var(--sm-color-text-body);
      font: var(--sm-font-body);
    }
  `,
})
export class MuniPrompt {
  protected readonly data = inject<MuniPromptData>(DIALOG_DATA);
  private readonly dialog = viewChild.required(SmDialog);

  protected choose(result: Exclude<MuniPromptResult, undefined>): void {
    this.dialog().close(result);
  }
}
