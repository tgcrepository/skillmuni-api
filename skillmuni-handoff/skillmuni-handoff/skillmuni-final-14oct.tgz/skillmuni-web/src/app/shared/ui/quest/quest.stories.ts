import { Component, inject } from '@angular/core';
import type { Meta, StoryObj } from '@storybook/angular-vite';
import { QuestMap } from './quest-map';
import { LootDropCard } from './loot-drop-card';
import { BadgeRing } from './badge-ring';
import { QuestComplete } from './quest-complete';
import { OverlayService } from '../overlay/overlay.service';
import { Button } from '../button/button';

@Component({
  selector: 'sm-demo-complete',
  imports: [Button],
  template: `<button sm-button (click)="open()">Finish quest 1</button>`,
})
class CompleteDemo {
  private readonly overlays = inject(OverlayService);
  constructor() {
    this.open();
  }
  open(): void {
    this.overlays.modal(QuestComplete, {
      data: {
        quest: 1,
        eyebrow: 'Quest 1 of 8: done and dusted',
        body: 'Yash, that was quick. Your basics are saved and the Hit Me Up quest just dropped.',
        xpEarned: 50,
        rank: 'Rookie',
        level: 1,
        xpBefore: 90,
        xpTarget: 400,
        nextRank: 'Pathfinder',
        next: { quest: 2, name: 'Hit Me Up', meta: '2 mins · +110 XP' },
      },
    });
  }
}

const meta: Meta = {
  title: 'Composites/Quest',
  parameters: {
    figma: {
      node: 'Quest Map 27:104 · Quest Item 26:497 · Loot Drop 29:89 · Badge Ring 29:33 · Complete 31:112',
    },
    layout: 'padded',
  },
  decorators: [
    (story) => ({
      ...story(),
      moduleMetadata: { imports: [QuestMap, LootDropCard, BadgeRing, CompleteDemo] },
    }),
  ],
};
export default meta;

export const MapAndRewards: StoryObj = {
  render: () => ({
    template: `
      <div style="display:flex;gap:var(--sm-space-800);align-items:flex-start;flex-wrap:wrap">
        <sm-quest-map style="inline-size:var(--sm-layout-shell-map-width)" [progress]="{ completed: 0, partsDone: 0 }" />
        <div style="display:grid;gap:var(--sm-space-600);inline-size:var(--sm-layout-shell-rail-width)">
          <sm-loot-drop-card [quest]="1" badge="Main Character Badge" reward="+50 XP, and the Hit Me Up quest unlocks" [progress]="10" />
          <sm-loot-drop-card [quest]="1" badge="Main Character Badge" reward="+50 XP, and the Hit Me Up quest unlocks" [progress]="100" />
        </div>
        <div style="display:flex;gap:var(--sm-space-400)">
          @for (p of [10, 45, 80, 100]; track p) {
            <sm-badge-ring [quest]="1" [progress]="p" label="Badge" />
          }
        </div>
      </div>`,
  }),
};

export const LineupStrip: StoryObj = {
  render: () => ({
    template: `<sm-quest-map variant="strip" [progress]="{ completed: 2, partsDone: 1 }" />`,
  }),
};

export const LineupCompact: StoryObj = {
  render: () => ({
    template: `<div style="max-inline-size:calc(var(--sm-layout-shell-rail-width) + var(--sm-space-400))"><sm-quest-map variant="compact" [progress]="{ completed: 0, partsDone: 1 }" /></div>`,
  }),
};

export const LootCompact: StoryObj = {
  render: () => ({
    template: `<div style="max-inline-size:calc(var(--sm-layout-shell-rail-width) + var(--sm-space-400))"><sm-loot-drop-card compact [quest]="1" badge="Main Character Badge" reward="+50 XP · unlocks Hit Me Up" [progress]="10" /></div>`,
  }),
};

export const QuestCompleteModal: StoryObj = {
  render: () => ({ template: `<sm-demo-complete />` }),
};
