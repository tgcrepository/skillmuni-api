import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { TextLink } from './text-link';

@Component({
  imports: [TextLink],
  template: `<a sm-text-link tone="accent" href="/signup">Join the squad</a>`,
})
class Host {}

describe('TextLink', () => {
  it('keeps native link semantics and applies the tone', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const a = fixture.nativeElement.querySelector('a') as HTMLAnchorElement;
    expect(a.getAttribute('href')).toBe('/signup');
    expect(a.classList).toContain('sm-text-link--accent');
  });
});
