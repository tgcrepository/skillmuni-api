import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Field } from '../field/field';
import { Input } from './input';
import { Tag } from '../tag/tag';
import { IconButton } from '../icon-button/icon-button';
import { StatusIcon } from '../status-icon/status-icon';

const meta: Meta = {
  title: 'Primitives/Field and Input',
  parameters: {
    figma: { node: 'Field 19:84 · Input 18:131 · Status Icon 18:22' },
    layout: 'padded',
  },
  decorators: [
    (story) => ({
      ...story(),
      moduleMetadata: { imports: [Field, Input, Tag, IconButton, StatusIcon] },
    }),
  ],
};
export default meta;

export const States: StoryObj = {
  render: () => ({
    template: `
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(var(--sm-layout-shell-map-width),1fr));gap:var(--sm-space-800);max-inline-size:var(--sm-layout-content-max-width)">
        <sm-field label="First name" helper="Your nickname in the app. Totally optional.">
          <sm-tag>Optional</sm-tag>
          <sm-input placeholder="Your first name" />
        </sm-field>
        <sm-field label="Last name" status="valid" helper="Looks good">
          <sm-input value="Dlamini" />
        </sm-field>
        <sm-field label="Email" error="That email looks off — check for typos">
          <sm-input type="email" value="nkosazana@gmail" />
        </sm-field>
        <sm-field label="Area" status="warning" helper="Found a suburb only — add your postal code">
          <sm-input value="Randburg, Gauteng" />
        </sm-field>
        <sm-field label="Year finished" disabled helper="Pick your level first">
          <sm-input placeholder="YYYY" disabled />
        </sm-field>
        <sm-field label="Age" helper="Worked out from your birthday">
          <sm-input value="22" readonly />
        </sm-field>
        <sm-field label="Password">
          <sm-input type="password" value="hunter22" leadingIcon="lock">
            <button sm-icon-button icon="eye" label="Show password" tone="ghost" [size]="36"></button>
          </sm-input>
        </sm-field>
        <sm-field label="Long content" helper="Overflow is ellipsed in the field; helper text wraps across as many lines as it needs without breaking the layout.">
          <sm-input value="Call centre agent (internship) · Teleperformance · Johannesburg North · Jan – Jun 2024" />
        </sm-field>
      </div>`,
  }),
};

export const StatusIcons: StoryObj = {
  render: () => ({
    template: `
      <div style="display:grid;grid-template-columns:repeat(4,max-content);gap:var(--sm-space-600)">
        @for (s of ['m','l']; track s) {
          @for (t of ['success','error','warning','info']; track t) {
            <sm-status-icon [tone]="$any(t)" [size]="$any(s)" />
          }
        }
      </div>`,
  }),
};
