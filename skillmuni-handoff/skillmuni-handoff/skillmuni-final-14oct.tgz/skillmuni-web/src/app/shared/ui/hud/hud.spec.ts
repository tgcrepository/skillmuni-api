import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { XpHud } from './xp-hud';
import { SectionStepper } from './section-stepper';
import { SkillChip } from './skill-chip';
import { PowerMeter } from './power-meter';
import { OptionCards, OptionCardItem } from '../option-card/option-cards';

const WORK: OptionCardItem[] = [
  { value: 'job', title: 'Full-time job', code: 'FT' },
  { value: 'intern', title: 'Internship', code: 'IN', description: 'Paid or unpaid' },
  {
    value: 'fresher',
    title: 'Not yet, I’m a fresher',
    description: 'Totally fine, skip ahead',
    optOut: true,
  },
];

@Component({
  imports: [XpHud, SectionStepper, SkillChip, PowerMeter, OptionCards],
  template: `
    <sm-xp-hud [level]="1" rank="Rookie" [xp]="50" [target]="400" />
    <sm-section-stepper [steps]="steps" [current]="0" />
    <sm-skill-chip skill="Communication" [level]="2" (remove)="removed = true" />
    <sm-power-meter [level]="3" />
    <sm-option-cards [items]="work" [(value)]="types" ariaLabel="Work types" />
  `,
})
class Host {
  readonly work = WORK;
  readonly types = signal<string[]>([]);
  readonly steps = [
    { label: 'Name', answered: 1, total: 2 },
    { label: 'ID & bday', answered: 0, total: 2, xp: '+20 XP' },
    { label: 'The tea', answered: 0, total: 3, xp: '+20 XP' },
  ];
  removed = false;
}

describe('HUD and option cards', () => {
  function setup() {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    return { fixture, host: fixture.componentInstance, el: fixture.nativeElement as HTMLElement };
  }

  it('XP HUD reports progress with a readable caption', () => {
    const { el } = setup();
    const bar = el.querySelector('sm-xp-hud [role="progressbar"]')!;
    expect(bar.getAttribute('aria-valuenow')).toBe('13');
    expect(el.querySelector('sm-xp-hud')!.textContent).toContain('350 more to level up');
  });

  it('section stepper marks the current part and shows the answered count', () => {
    const { el } = setup();
    const current = el.querySelector('[aria-current="step"]')!;
    expect(current.textContent).toContain('1 of 2 answered');
    expect(el.querySelectorAll('.step--upcoming')).toHaveLength(2);
  });

  it('power meter and skill chip have text alternatives', () => {
    const { fixture, host, el } = setup();
    expect(el.querySelectorAll('sm-power-meter')[1]!.getAttribute('aria-label')).toBe('Confident');
    const remove = el.querySelector('sm-skill-chip .remove') as HTMLButtonElement;
    expect(remove.getAttribute('aria-label')).toBe('Remove Communication');
    remove.click();
    fixture.detectChanges();
    expect(host.removed).toBe(true);
  });

  it('opt-out option card clears the others and vice versa', () => {
    const { fixture, host, el } = setup();
    const inputs = el.querySelectorAll<HTMLInputElement>('sm-option-cards input');
    inputs[0]!.click();
    inputs[1]!.click();
    fixture.detectChanges();
    expect(host.types()).toEqual(['job', 'intern']);
    inputs[2]!.click();
    fixture.detectChanges();
    expect(host.types()).toEqual(['fresher']);
    inputs[0]!.click();
    fixture.detectChanges();
    expect(host.types()).toEqual(['job']);
  });
});
