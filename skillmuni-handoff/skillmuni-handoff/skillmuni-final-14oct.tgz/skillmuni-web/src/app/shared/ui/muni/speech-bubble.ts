import { Component, input } from '@angular/core';
import { Typewriter } from './typewriter';

export type BubbleTail = 'bottom' | 'left' | 'none';

/**
 * Figma: Muni → Speech Bubble (28:29). Muni's voice: white bubble, Ember outline, indigo text.
 * Tail bottom (Muni below, desktop rail) · left (avatar to the left, mobile tip) · none (inline quote).
 * Celebrate mood adds a Caveat exclamation. Text is live and translatable (Figma dev note).
 */
@Component({
  selector: 'sm-speech-bubble',
  imports: [Typewriter],
  template: `
    @if (exclamation()) {
      <p class="exclaim">{{ exclamation() }}</p>
    }
    <div class="message" smTypewriter><ng-content /></div>
  `,
  styleUrl: './speech-bubble.scss',
  host: { '[class]': '"sm-speech-bubble sm-speech-bubble--tail-" + tail()' },
})
export class SpeechBubble {
  readonly tail = input<BubbleTail>('bottom');
  /** Celebrate mood, e.g. "Slay, Yash!" */
  readonly exclamation = input('');
}
