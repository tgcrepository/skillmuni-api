import type { Meta, StoryObj } from '@storybook/angular-vite';
import { QuestCard } from './quest-card';
import { Field } from '../field/field';
import { Input } from '../input/input';
import { Tag } from '../tag/tag';

const meta: Meta<QuestCard> = {
  title: 'Composites/Quest Card',
  component: QuestCard,
  parameters: { figma: { node: 'Quest Card 30:465 · Quest Footer 30:79' }, layout: 'padded' },
  decorators: [
    (story) => ({ ...story(), moduleMetadata: { imports: [QuestCard, Field, Input, Tag] } }),
  ],
};
export default meta;

export const Part1: StoryObj<QuestCard> = {
  render: () => ({
    props: {
      steps: [
        { label: 'Name', answered: 1, total: 2 },
        { label: 'ID & bday', answered: 0, total: 2, xp: '+20 XP' },
        { label: 'The tea', answered: 0, total: 3, xp: '+20 XP' },
      ],
    },
    template: `
      <div style="max-inline-size:var(--sm-layout-shell-card-max-width)">
        <sm-quest-card
          eyebrow="Quest 1 of 8 · Who dis? · Part 1 of 3"
          xpPromise="+50 XP when you’re done"
          subtitle="Use the name on your ID, it goes on your certificates. Takes like 20 seconds, fr."
          [steps]="steps"
          counter="1 more to go"
          primaryXp="+20 XP">
          <h1 smQuestTitle>First up, what should we <em>call you?</em></h1>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(var(--sm-layout-shell-map-width),100%),1fr));gap:var(--sm-space-600)">
            <sm-field label="First name" status="valid" helper="Looks good"><sm-input value="Nkosazana" /></sm-field>
            <sm-field label="Last name"><sm-input placeholder="Your last name" /></sm-field>
            <sm-field label="Nickname" helper="Your nickname in the app. Totally optional."><sm-tag>Optional</sm-tag><sm-input placeholder="What your friends call you" /></sm-field>
          </div>
        </sm-quest-card>
      </div>`,
  }),
};
