import { Component, booleanAttribute, computed, input, model, output } from '@angular/core';
import type { FormValueControl } from '@angular/forms/signals';
import { uniqueId } from '../internal/unique-id';

export interface Segment {
  readonly value: string;
  readonly label: string;
}

/**
 * Figma: Navigation → Segmented Control (27:194) + Segment (27:193).
 * 2–3 mutually exclusive modes that change the form below (Completed vs Still studying).
 * Native radios in a radiogroup; the Arcane thumb slides to the selected segment.
 */
@Component({
  selector: 'sm-segmented-control',
  template: `
    <span
      class="thumb"
      aria-hidden="true"
      [style.--_index]="index()"
      [class.is-hidden]="index() < 0"
    ></span>
    @for (segment of segments(); track segment.value; let i = $index) {
      <label class="segment" [class.is-selected]="i === index()">
        <input
          type="radio"
          [name]="groupName"
          [value]="segment.value"
          [checked]="i === index()"
          [disabled]="disabled()"
          (change)="value.set(segment.value)"
          (blur)="touch.emit()"
        />
        <span>{{ segment.label }}</span>
      </label>
    }
  `,
  styleUrl: './segmented-control.scss',
  host: {
    role: 'radiogroup',
    class: 'sm-segmented-control',
    '[style.--_count]': 'segments().length',
    '[attr.aria-label]': 'ariaLabel() || null',
    '[attr.aria-labelledby]': 'labelledBy() || null',
    '[class.is-disabled]': 'disabled()',
  },
})
export class SegmentedControl implements FormValueControl<string> {
  readonly value = model('');
  readonly segments = input.required<readonly Segment[]>();
  readonly disabled = input(false, { transform: booleanAttribute });
  readonly ariaLabel = input('');
  readonly labelledBy = input('');
  readonly touch = output<void>();

  protected readonly groupName = uniqueId('segments');
  protected readonly index = computed(() =>
    this.segments().findIndex((s) => s.value === this.value()),
  );
}
