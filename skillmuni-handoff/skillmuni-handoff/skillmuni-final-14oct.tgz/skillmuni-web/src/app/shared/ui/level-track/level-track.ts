import { Component, booleanAttribute, computed, input } from '@angular/core';
import { LADDER, levelFor } from '../../../core/quests/levels';

/**
 * Corrections #13: the whole level ladder at a glance — Rookie 0 · Pathfinder 400 · Trailblazer 800 ·
 * Legend 1200 · Icon 1600. Finished levels are ticked, the current one glows and its segment fills,
 * so the learner sees exactly where one level ended and the next began.
 * Screen readers get one sentence instead of the drawing.
 */
@Component({
  selector: 'sm-level-track',
  template: `
    <p class="sm-visually-hidden">{{ summary() }}</p>
    <ol class="track" aria-hidden="true">
      @for (s of steps(); track s.level) {
        <li class="step" [class.is-done]="s.done" [class.is-current]="s.current">
          @if (!$first) {
            <span class="seg"><span class="seg-fill" [style.inline-size.%]="s.fill"></span></span>
          }
          <span class="node">
            @if (s.done) {
              <svg viewBox="0 0 16 16" class="tick"><path d="M3.5 8.5l3 3 6-7" /></svg>
            } @else {
              {{ s.level }}
            }
          </span>
          @if (!compact()) {
            <span class="name">{{ s.rank }}</span>
            <span class="min" i18n="@@lvl.min">{{ s.min }} XP</span>
          }
        </li>
      }
    </ol>
    @if (!compact() && showCaption()) {
      <p class="caption" aria-hidden="true">{{ caption() }}</p>
    }
  `,
  styleUrl: './level-track.scss',
  host: { class: 'sm-level-track', '[class.is-compact]': 'compact()' },
})
export class LevelTrack {
  readonly xp = input.required<number>();
  /** Nodes and bar only (no names, no caption), for tight spots. */
  readonly compact = input(false, { transform: booleanAttribute });
  /** Hide the sentence under the ladder when the card already says "N to Level X". */
  readonly showCaption = input(true, { transform: booleanAttribute });

  private readonly lvl = computed(() => levelFor(this.xp()));

  protected readonly steps = computed(() => {
    const xp = this.xp();
    return LADDER.map((s, i) => {
      const prev = LADDER.at(i - 1);
      const span = i === 0 || !prev ? 1 : s.min - prev.min;
      const fill =
        i === 0 || !prev ? 100 : Math.max(0, Math.min(100, ((xp - prev.min) / span) * 100));
      return {
        level: s.level,
        rank: s.rank,
        min: s.min,
        done: xp >= s.min && s.level < this.lvl().level,
        current: s.level === this.lvl().level,
        fill,
      };
    });
  });

  private readonly next = computed(() => LADDER.find((s) => s.level === this.lvl().level + 1));

  protected readonly caption = computed(() => {
    const l = this.lvl();
    const n = this.next();
    return n
      ? $localize`:@@lvl.caption:Level ${l.level}:n: · ${l.rank}:rank: since ${l.start}:start: XP. ${n.min - this.xp()}:left: XP to Level ${n.level}:next: · ${n.rank}:nextRank:.`
      : $localize`:@@lvl.captionTop:Level ${l.level}:n: · ${l.rank}:rank:. You’ve reached the top level!`;
  });

  protected readonly summary = computed(() => {
    const l = this.lvl();
    const n = this.next();
    return n
      ? $localize`:@@lvl.sr:Level ${l.level}:n: of ${LADDER.length}:total:, ${l.rank}:rank:, with ${this.xp()}:xp: XP. ${n.rank}:nextRank: starts at ${n.min}:min: XP.`
      : $localize`:@@lvl.srTop:Top level, ${l.rank}:rank:, with ${this.xp()}:xp: XP.`;
  });
}
