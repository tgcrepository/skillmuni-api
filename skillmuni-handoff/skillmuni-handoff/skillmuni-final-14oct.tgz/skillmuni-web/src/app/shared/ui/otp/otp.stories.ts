import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Otp } from './otp';
import { Field } from '../field/field';

const meta: Meta<Otp> = {
  title: 'Primitives/OTP',
  component: Otp,
  parameters: { figma: { node: '19:98' } },
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [Otp, Field] } })],
};
export default meta;

export const Empty: StoryObj<Otp> = {
  render: () => ({
    template: `<sm-field label="Enter the 6-digit code" helper="Sent to +91 98765 43210"><sm-otp /></sm-field>`,
  }),
};
export const Error: StoryObj<Otp> = {
  render: () => ({
    template: `<sm-field label="Enter the 6-digit code" error="That code didn’t match. Try again?"><sm-otp value="482913" status="error" /></sm-field>`,
  }),
};
export const Success: StoryObj<Otp> = {
  render: () => ({
    template: `<sm-field label="Enter the 6-digit code" status="valid" helper="Verified"><sm-otp value="482916" status="success" /></sm-field>`,
  }),
};
