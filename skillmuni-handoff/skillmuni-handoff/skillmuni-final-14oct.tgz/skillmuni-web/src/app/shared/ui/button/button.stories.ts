import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Button } from './button';

const meta: Meta<Button> = {
  title: 'Primitives/Button',
  component: Button,
  parameters: { figma: { node: '12:182' } },
  argTypes: {
    variant: {
      control: 'inline-radio',
      options: ['primary', 'accent', 'secondary', 'outline-brand'],
    },
    trailingIcon: { control: 'select', options: [null, 'arrow-right', 'check', 'chevron-right'] },
  },
  args: { variant: 'primary', disabled: false, loading: false, xp: '', trailingIcon: null },
  render: (args) => ({
    props: args,
    template: `<button sm-button [variant]="variant" [disabled]="disabled" [loading]="loading" [xp]="xp" [trailingIcon]="trailingIcon">Next part</button>`,
  }),
};
export default meta;
type Story = StoryObj<Button>;

export const Playground: Story = {};
export const WithXpReward: Story = { args: { xp: '+20 XP', trailingIcon: 'arrow-right' } };
export const Loading: Story = { args: { loading: true } };
export const Disabled: Story = { args: { disabled: true } };

/** Mirrors the Figma variant grid: 4 styles × default / disabled / loading. Hover, press and focus are live. */
export const AllVariants: Story = {
  render: () => ({
    template: `
      <div style="display:grid;grid-template-columns:repeat(3,max-content);gap:var(--sm-space-600)">
        @for (v of ['primary','accent','secondary','outline-brand']; track v) {
          <button sm-button [variant]="$any(v)">Next part</button>
          <button sm-button [variant]="$any(v)" disabled>Next part</button>
          <button sm-button [variant]="$any(v)" loading>Next part</button>
        }
      </div>`,
    moduleMetadata: { imports: [Button] },
  }),
};
