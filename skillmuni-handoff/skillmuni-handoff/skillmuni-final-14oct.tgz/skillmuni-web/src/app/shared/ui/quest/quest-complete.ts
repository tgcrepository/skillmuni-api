import { levelFor } from '../../../core/quests/levels';
import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { SmDialog } from '../overlay/dialog';
import { Button } from '../button/button';
import { LevelTrack } from '../level-track/level-track';
import { BadgeRing } from './badge-ring';
import { QuestIllustration } from './quest-illustration';
import { Confetti } from './confetti';
import { Currency } from '../currency/currency';
import { SoundFx } from '../../../core/audio/sound-fx';

export interface QuestCompleteData {
  readonly quest: number;
  /** "Quest 1 of 8: done and dusted" */
  readonly eyebrow: string;
  readonly body: string;
  readonly xpEarned: number;
  readonly rank: string;
  readonly level: number;
  /** XP before this reward. */
  readonly xpBefore: number;
  readonly xpTarget: number;
  readonly nextRank: string;
  readonly next?: { readonly quest: number; readonly name: string; readonly meta: string };
  /** "Level 2 · Pathfinder unlocked" pill when this quest levelled the learner up (Figma 200:31873). */
  readonly levelUp?: string;
  /** Title override, second part highlighted, e.g. ["Lore saved.", "You levelled up!"]. */
  readonly title?: readonly [string, string];
  /** Secondary button override, e.g. "Double-check my lore". */
  readonly reviewLabel?: string;
  /** Primary button override, e.g. "Yes, I have a code". */
  readonly primaryLabel?: string;
  /** Card instead of "Up next" (Figma RG: bonus quest; P5: bank check in progress). */
  readonly bonus?: {
    readonly eyebrow: string;
    readonly title: string;
    readonly meta: string;
    /** One character shown in the tile, e.g. "#" or "₹". */
    readonly mark: string;
    readonly tone?: 'brand' | 'success';
  };
}

export type QuestCompleteResult = 'continue' | 'review' | 'later';

/**
 * Figma: Cards & Overlays → Quest Complete Modal (31:112). Open with OverlayService.modal(QuestComplete, { data }).
 * Badge (100%) → eyebrow → title (reward highlighted) → body → animated XP well → Up next → actions.
 * Focus lands on the primary; Esc = continue later.
 */
@Component({
  selector: 'sm-quest-complete',
  imports: [Currency, SmDialog, Button, LevelTrack, BadgeRing, QuestIllustration, Confetti],
  templateUrl: './quest-complete.html',
  styleUrl: './quest-complete.scss',
})
export class QuestComplete {
  protected readonly data = inject<QuestCompleteData>(DIALOG_DATA);
  protected readonly xp = signal(this.data.xpBefore);

  constructor() {
    // A-279: badge chime; a rising fanfare when the quest also levelled them up.
    const before = levelFor(this.data.xpBefore).level;
    const after = levelFor(this.data.xpBefore + this.data.xpEarned).level;
    inject(SoundFx).play(after > before ? 'level' : 'badge');
    const reduce = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const end = this.data.xpBefore + this.data.xpEarned;
    if (reduce || typeof requestAnimationFrame !== 'function') {
      this.xp.set(end);
      return;
    }
    const start = performance.now();
    const duration = 900;
    let frame = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      this.xp.set(Math.round(this.data.xpBefore + this.data.xpEarned * eased));
      if (t < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    inject(DestroyRef).onDestroy(() => cancelAnimationFrame(frame));
  }

  /** Bar fills within the current level (A-249), so a fresh level starts empty, not half full. */
  protected readonly lvl = computed(() => levelFor(this.xp()));
}
