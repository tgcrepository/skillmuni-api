import { DOCUMENT } from '@angular/common';
import {
  DestroyRef,
  Directive,
  ElementRef,
  afterNextRender,
  inject,
} from '@angular/core';

/** Untyped text is painted transparent through one shared CSS highlight (styles.scss). */
const HIGHLIGHT = 'sm-untyped';
const MS_PER_CHAR = 26;
const MAX_MS = 2600;

interface HighlightApi {
  set(name: string, h: unknown): void;
  get(name: string): { add(r: Range): void; delete(r: Range): void } | undefined;
}

/**
 * Muni's lines type themselves out (A-281). The DOM text never changes — the not-yet-typed part is
 * painted transparent with the CSS Custom Highlight API — so the bubble keeps its final size from
 * the start, screen readers get the whole line at once, and Angular stays in charge of the text.
 * Restarts whenever the text changes. Muni has no voice (corrections #2): the line is read, not spoken.
 * Reduced motion (or no Highlight API): the line simply appears.
 */
@Directive({ selector: '[smTypewriter]' })
export class Typewriter {
  private readonly el = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  private readonly doc = inject(DOCUMENT);
  private range: Range | null = null;
  private frame = 0;
  private lastText = '';

  constructor() {
    const destroy = inject(DestroyRef);
    afterNextRender(() => {
      this.start();
      const mo = new MutationObserver(() => this.start());
      mo.observe(this.el, { characterData: true, childList: true, subtree: true });
      destroy.onDestroy(() => {
        mo.disconnect();
        this.stop();
      });
    });
  }

  private start(): void {
    const text = this.textNodes()
      .map((t) => t.data)
      .join('')
      .replace(/\s+/g, ' ')
      .trim();
    if (text === this.lastText) return;
    this.lastText = text;
    this.stop();
    if (!text) return;
    const win = this.doc.defaultView as (Window & { CSS?: { highlights?: HighlightApi } }) | null;
    const highlights = win?.CSS?.highlights;
    const Ctor = (win as unknown as { Highlight?: new () => unknown } | null)?.Highlight;
    const reduce = win?.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (!highlights || !Ctor || reduce) return;
    if (!highlights.get(HIGHLIGHT)) highlights.set(HIGHLIGHT, new Ctor());
    const set = highlights.get(HIGHLIGHT);
    const nodes = this.textNodes();
    const total = nodes.reduce((n, t) => n + t.data.length, 0);
    if (!set || !total) return;
    const range = this.doc.createRange();
    this.range = range;
    set.add(range);
    const perChar = Math.min(MS_PER_CHAR, MAX_MS / total);
    let begin = 0;
    const tick = (t: number) => {
      begin ||= t;
      const typed = Math.min(total, Math.floor((t - begin) / perChar));
      if (typed >= total) return this.stop();
      this.place(range, nodes, typed);
      this.frame = requestAnimationFrame(tick);
    };
    this.place(range, nodes, 0);
    this.frame = requestAnimationFrame(tick);
  }

  /** Untyped = from character `typed` to the end of the element. */
  private place(range: Range, nodes: readonly Text[], typed: number): void {
    let left = typed;
    for (const node of nodes) {
      if (left <= node.data.length) {
        range.setStart(node, left);
        break;
      }
      left -= node.data.length;
    }
    const last = nodes[nodes.length - 1];
    if (last) range.setEnd(last, last.data.length);
  }

  private textNodes(): Text[] {
    const out: Text[] = [];
    const walker = this.doc.createTreeWalker(this.el, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const t = n as Text;
      // Skip screen-reader-only text: it isn't painted anyway.
      if (t.parentElement?.closest('.sm-visually-hidden')) continue;
      if (t.data.length) out.push(t);
    }
    return out;
  }

  private stop(): void {
    cancelAnimationFrame(this.frame);
    const win = this.doc.defaultView as (Window & { CSS?: { highlights?: HighlightApi } }) | null;
    if (this.range) win?.CSS?.highlights?.get(HIGHLIGHT)?.delete(this.range);
    this.range = null;
  }
}
