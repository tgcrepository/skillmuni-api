import { levelFor } from '../../../core/quests/levels';
import {
  Component,
  DestroyRef,
  PLATFORM_ID,
  computed,
  effect,
  inject,
  input,
  signal,
  untracked,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { LevelOrb } from './level-orb';
import { ProgressBar } from '../progress-bar/progress-bar';
import { Currency } from '../currency/currency';

const SPARKS = [0, 1, 2, 3, 4, 5];

/**
 * Figma: Progress & Game HUD → XP HUD (26:18). Persistent progress in the app header.
 * Full (desktop/tablet): orb + rank + XP bar + caption. Compact (mobile): orb + XP pill.
 *
 * `journey` (A-264): during the registration quests the bar runs over all the quest XP
 * (+20 a step, +50 a quest), with a notch where the next level unlocks, instead of the level span.
 * Every gain counts up, pops a "+N" with sparks and pulses the orb (A-263). It is also the landing
 * spot for XP bursts (`data-xp-target`).
 */
@Component({
  selector: 'sm-xp-hud',
  imports: [LevelOrb, ProgressBar, Currency],
  template: `
    <span class="orb-wrap" [class]="'orb-wrap pulse-' + (bump() % 2)">
      <sm-level-orb [level]="level()" [size]="layout() === 'compact' ? 's' : 'l'" />
    </span>
    @if (layout() === 'full') {
      <div class="column">
        <p class="rank-row">
          <span class="rank">{{ rank() }}</span>
          <span class="level" i18n="@@hud.level">Lvl {{ level() }}</span>
        </p>
        <span class="bar-wrap">
          <sm-progress-bar [value]="percent()" [label]="barLabel()" [valueText]="caption()" />
          @if (notch(); as n) {
            <span class="notch" [style.inset-inline-start.%]="n" aria-hidden="true"></span>
          }
        </span>
        <p class="caption" aria-hidden="true">
          <sm-currency kind="xp" size="xs" [pop]="gain() > 0" />{{ shownCaption() }}
        </p>
      </div>
    } @else if (layout() === 'medium') {
      <div class="column column--medium">
        <p class="rank-row">
          <span class="rank" aria-hidden="true">{{ rank() + ' · ' + shown() + ' XP' }}</span>
          <span class="sm-visually-hidden" i18n="@@hud.rankXp">{{ rank() }} · {{ xp() }} XP</span>
        </p>
        <span class="bar-wrap">
          <sm-progress-bar [value]="percent()" [label]="barLabel()" [valueText]="caption()" />
          @if (notch(); as n) {
            <span class="notch" [style.inset-inline-start.%]="n" aria-hidden="true"></span>
          }
        </span>
      </div>
    } @else {
      <span class="xp" aria-hidden="true"
        ><sm-currency kind="xp" size="xs" [pop]="gain() > 0" />{{ shown() + ' XP' }}</span
      >
      <span class="sm-visually-hidden" i18n="@@hud.xp">{{ xp() }} XP</span>
      <span class="sm-visually-hidden">{{ barLabel() }}, {{ caption() }}</span>
    }
    @for (k of gainKey(); track k) {
      <span class="gain" aria-hidden="true">
        @for (s of sparks; track s) {
          <span class="spark" [style.--a]="s"></span>
        }
        <sm-currency kind="xp" size="sm" pop />{{ '+' + gain() }}
      </span>
    }
  `,
  styleUrl: './xp-hud.scss',
  host: {
    '[class]': '"sm-xp-hud sm-xp-hud--" + layout()',
    'data-xp-target': '',
  },
})
export class XpHud {
  readonly level = input.required<number>();
  readonly rank = input.required<string>();
  readonly xp = input.required<number>();
  /** XP needed for the next level, e.g. 400. */
  readonly target = input.required<number>();
  /** full: desktop · medium: tablet header · compact: mobile pill (Figma XP HUD 26:18 + tablet frames). */
  readonly layout = input<'full' | 'medium' | 'compact'>('full');
  /** All the XP on offer in this journey (quests: 760). Null: the bar spans the current level. */
  readonly journey = input<number | null>(null);

  protected readonly sparks = SPARKS;
  private readonly browser = isPlatformBrowser(inject(PLATFORM_ID));

  /** Fill within the current level (A-249), or across the whole journey (A-264). */
  protected readonly percent = computed(() => {
    const j = this.journey();
    if (j) return Math.min(100, (this.xp() / j) * 100);
    const start = levelFor(this.xp()).start;
    const span = this.target() - start;
    return span > 0 ? Math.min(100, ((this.xp() - start) / span) * 100) : 0;
  });
  /** Where the next level unlocks on a journey bar. */
  protected readonly notch = computed(() => {
    const j = this.journey();
    return j && this.target() < j && this.target() > this.xp() ? (this.target() / j) * 100 : null;
  });
  protected readonly barLabel = computed(
    () => $localize`:@@hud.barLabel:${this.rank()}:rank:, level ${this.level()}:level:`,
  );
  protected readonly caption = computed(() => this.captionFor(this.xp()));
  protected readonly shownCaption = computed(() => this.captionFor(this.shown()));

  /** The number on screen: counts up to the new total after a gain. */
  protected readonly shown = signal(0);
  protected readonly gain = signal(0);
  protected readonly bump = signal(0);
  protected readonly gainKey = computed(() => (this.gain() > 0 ? [this.bump()] : []));
  private frame = 0;
  private clear: ReturnType<typeof setTimeout> | undefined;

  constructor() {
    let prev: number | null = null;
    inject(DestroyRef).onDestroy(() => {
      cancelAnimationFrame(this.frame);
      clearTimeout(this.clear);
    });
    effect(() => {
      const xp = this.xp();
      untracked(() => {
        const from = prev;
        prev = xp;
        if (from === null || xp <= from || !this.browser) {
          this.shown.set(xp);
          return;
        }
        this.celebrate(from, xp);
      });
    });
  }

  private captionFor(xp: number): string {
    const j = this.journey();
    if (j) {
      if (xp >= j) return $localize`:@@hud.journeyDone:${xp}:xp: / ${j}:total: XP · all quest XP earned`;
      if (this.target() > xp && this.target() < j)
        return $localize`:@@hud.journeyCaption:${xp}:xp: / ${j}:total: XP · Level ${this.level() + 1}:next: at ${this.target()}:target:`;
      return $localize`:@@hud.journeyPlain:${xp}:xp: / ${j}:total: XP`;
    }
    const left = Math.max(0, this.target() - xp);
    return $localize`:@@hud.caption:${xp}:xp: / ${this.target()}:target: XP · ${left}:left: more to level up`;
  }

  private celebrate(from: number, to: number): void {
    this.gain.set(to - from);
    this.bump.update((n) => n + 1);
    clearTimeout(this.clear);
    this.clear = setTimeout(() => this.gain.set(0), 1400);
    const reduce =
      typeof matchMedia === 'undefined' || matchMedia('(prefers-reduced-motion: reduce)').matches;
    cancelAnimationFrame(this.frame);
    if (reduce) {
      this.shown.set(to);
      return;
    }
    let start = 0;
    const step = (t: number) => {
      start ||= t;
      const p = Math.min(1, (t - start) / 700);
      this.shown.set(Math.round(from + (to - from) * (1 - (1 - p) ** 3)));
      if (p < 1) this.frame = requestAnimationFrame(step);
    };
    this.frame = requestAnimationFrame(step);
  }
}
