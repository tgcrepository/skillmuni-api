import { Component, ElementRef, input, model, viewChildren } from '@angular/core';

export interface TabItem {
  readonly value: string;
  readonly label: string;
}

/**
 * Figma: Navigation → Tab (27:188). Pill filter tabs above a browsable set
 * (skill categories: For you · Tech · Data · People…). Selected = Arcane gradient.
 * WAI-ARIA tabs with roving tabindex: ← → Home End move and select. Scrolls horizontally, never wraps.
 * Point `controls` at the id of the panel the tabs filter.
 */
@Component({
  selector: 'sm-tabs',
  template: `
    @for (tab of tabs(); track tab.value; let i = $index) {
      <button
        #tabEl
        type="button"
        role="tab"
        class="tab"
        [class.is-selected]="tab.value === value()"
        [attr.aria-selected]="tab.value === value()"
        [attr.aria-controls]="controls() || null"
        [tabindex]="tab.value === value() ? 0 : -1"
        (click)="select(i)"
        (keydown)="onKeydown($event, i)"
      >
        {{ tab.label }}
      </button>
    }
  `,
  styleUrl: './tabs.scss',
  host: {
    role: 'tablist',
    class: 'sm-tabs',
    '[attr.aria-label]': 'ariaLabel() || null',
  },
})
export class Tabs {
  private readonly tabEls = viewChildren<ElementRef<HTMLButtonElement>>('tabEl');

  readonly value = model('');
  readonly tabs = input.required<readonly TabItem[]>();
  readonly ariaLabel = input('');
  readonly controls = input('');

  protected select(index: number): void {
    const tab = this.tabs()[index];
    if (!tab) return;
    this.value.set(tab.value);
    const el = this.tabEls()[index]?.nativeElement;
    el?.focus();
    el?.scrollIntoView?.({ block: 'nearest', inline: 'nearest' });
  }

  protected onKeydown(event: KeyboardEvent, index: number): void {
    const last = this.tabs().length - 1;
    const rtl = getComputedStyle(event.target as Element).direction === 'rtl';
    const next: Record<string, number> = {
      ArrowRight: rtl ? index - 1 : index + 1,
      ArrowLeft: rtl ? index + 1 : index - 1,
      Home: 0,
      End: last,
    };
    const target = next[event.key];
    if (target === undefined) return;
    event.preventDefault();
    this.select((target + last + 1) % (last + 1));
  }
}
