import { Component, computed, input } from '@angular/core';

/**
 * Figma: Progress & Game HUD → Progress Bar (24:26). Ember gradient on the track.
 * M (8px, glow) for XP and section progress · S (6px) inside list items.
 * role="progressbar"; the fill animates with transform only.
 */
@Component({
  selector: 'sm-progress-bar',
  template: `<span class="fill" [style.--_value]="clamped() / 100"></span>`,
  styleUrl: './progress-bar.scss',
  host: {
    role: 'progressbar',
    'aria-valuemin': '0',
    'aria-valuemax': '100',
    '[attr.aria-valuenow]': 'clamped()',
    '[attr.aria-valuetext]': 'valueText() || null',
    '[attr.aria-label]': 'label()',
    '[class]': '"sm-progress-bar sm-progress-bar--" + size()',
  },
})
export class ProgressBar {
  /** 0–100 */
  readonly value = input(0);
  readonly size = input<'m' | 's'>('m');
  readonly label = input.required<string>();
  /** e.g. "120 of 400 XP" */
  readonly valueText = input('');

  protected readonly clamped = computed(() => Math.round(Math.min(100, Math.max(0, this.value()))));
}
