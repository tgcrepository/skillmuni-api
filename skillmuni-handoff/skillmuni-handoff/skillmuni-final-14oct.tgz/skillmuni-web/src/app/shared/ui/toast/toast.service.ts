import { Service, signal } from '@angular/core';

export type ToastTone = 'reward' | 'success' | 'error';

export interface Toast {
  readonly id: number;
  readonly tone: ToastTone;
  readonly message: string;
  /** Reward chip text, e.g. "+20 XP". */
  readonly xp?: string;
  readonly action?: ToastAction;
}

/** One inline action, e.g. Undo after a delete (Q3 §7: 6 s). */
export interface ToastAction {
  readonly label: string;
  readonly run: () => void;
}

export interface ToastOptions {
  readonly tone?: ToastTone;
  readonly xp?: string;
  /** Milliseconds before auto-dismiss. Figma: 3 s. Errors stay a little longer. */
  readonly duration?: number;
  readonly action?: ToastAction;
}

const MAX_VISIBLE = 3;

/**
 * Transient confirmations (Figma: Feedback → Toast, 22:73).
 * Rendered by <sm-toast-host> (once, in the app shell). Timers pause while a toast is hovered or focused.
 */
@Service()
export class ToastService {
  private nextId = 0;
  private readonly timers = new Map<
    number,
    { remaining: number; started: number; handle?: ReturnType<typeof setTimeout> }
  >();

  readonly toasts = signal<readonly Toast[]>([]);

  show(message: string, options: ToastOptions = {}): number {
    const tone = options.tone ?? 'success';
    // The same message twice while the first is still up is one toast, not a stack (A-288).
    const twin = this.toasts().find((t) => t.message === message && t.tone === tone);
    if (twin) return twin.id;
    const toast: Toast = {
      id: ++this.nextId,
      tone,
      message,
      ...(options.xp ? { xp: options.xp } : {}),
      ...(options.action ? { action: options.action } : {}),
    };
    this.toasts.update((list) => [...list, toast].slice(-MAX_VISIBLE));
    this.timers.set(toast.id, {
      remaining: options.duration ?? (tone === 'error' ? 5000 : 3000),
      started: 0,
    });
    this.resume(toast.id);
    return toast.id;
  }

  reward(message: string, xp: string): number {
    return this.show(message, { tone: 'reward', xp });
  }

  /** Run a toast's action, then close it. */
  act(toast: Toast): void {
    toast.action?.run();
    this.dismiss(toast.id);
  }

  dismiss(id: number): void {
    const timer = this.timers.get(id);
    if (timer?.handle) clearTimeout(timer.handle);
    this.timers.delete(id);
    this.toasts.update((list) => list.filter((t) => t.id !== id));
  }

  pause(id: number): void {
    const timer = this.timers.get(id);
    if (!timer?.handle) return;
    clearTimeout(timer.handle);
    timer.handle = undefined;
    timer.remaining -= Date.now() - timer.started;
  }

  resume(id: number): void {
    const timer = this.timers.get(id);
    if (!timer || timer.handle) return;
    timer.started = Date.now();
    timer.handle = setTimeout(() => this.dismiss(id), Math.max(timer.remaining, 0));
  }
}
