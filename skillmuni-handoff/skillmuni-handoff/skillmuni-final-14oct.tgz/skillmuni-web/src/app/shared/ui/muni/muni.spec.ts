import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { MuniTip } from './muni-tip';
import { MuniCharacter } from './muni-character';
import { SpeechBubble } from './speech-bubble';

@Component({
  imports: [MuniTip, MuniCharacter, SpeechBubble],
  template: `
    <sm-muni-tip live exclamation="Slay, Yash!">What should we call you?</sm-muni-tip>
    <sm-muni-character />
    <sm-speech-bubble tail="none">Inline quote</sm-speech-bubble>
  `,
})
class Host {}

describe('Muni', () => {
  it('tip renders a decorative avatar and a live, translatable bubble', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    const tip = el.querySelector('sm-muni-tip')!;
    expect(tip.getAttribute('aria-live')).toBe('polite');
    expect(tip.querySelector('sm-muni-avatar')!.getAttribute('aria-hidden')).toBe('true');
    expect(tip.textContent).toContain('Slay, Yash!');
    expect(tip.querySelector('sm-speech-bubble')!.classList).toContain(
      'sm-speech-bubble--tail-left',
    );
  });

  it('character has the Figma alt text', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('sm-muni-character img').alt).toBe(
      'Muni, your Skillmuni guide',
    );
  });
});
