import { NgOptimizedImage } from '@angular/common';
import {
  Component,
  booleanAttribute,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import { ASSETS } from '../../assets';
import { Typewriter } from './typewriter';
import { SoundFx } from '../../../core/audio/sound-fx';

/** Muni's spare lines when there's nothing to show (A-270). Tapping him cycles through them. */
export const MUNI_EMPTY_LINES: readonly string[] = [
  $localize`:@@muniTalk.l1:Plot twist: nothing here yet. Your move!`,
  $localize`:@@muniTalk.l2:I checked twice. Still empty. Still believing in you.`,
  $localize`:@@muniTalk.l3:Empty today, legendary tomorrow. Let’s go!`,
  $localize`:@@muniTalk.l4:Okay okay, I’ll stop poking. Mostly.`,
];

/**
 * Muni with a speech bubble (A-270): the voice of every empty and first-time screen. Each line
 * types itself out (A-281). Tap Muni and he hops and says the next line, so an empty screen
 * becomes a little conversation. Lines are live text in a polite live region.
 */
@Component({
  selector: 'sm-muni-talk',
  imports: [NgOptimizedImage, Typewriter],
  template: `
    @if (large()) {
      <!-- A-303: a little stage for empty screens: spotlight, drifting sparks to catch, a nudge to tap Muni -->
      <div class="scene" aria-hidden="true">
        <span class="glow glow--a"></span>
        <span class="glow glow--b"></span>
        @for (s of sparks(); track s.id) {
          <span
            class="spark"
            [class.is-popped]="s.popped"
            [style.--x.%]="s.x"
            [style.--d]="s.delay"
            [style.--s]="s.size"
            (pointerdown)="catchSpark(s.id, $event)"
          ></span>
        }
      </div>
      @if (caught()) {
        <p class="caught" aria-live="polite">
          <span class="caught-icon" aria-hidden="true">✦</span>
          <ng-container i18n="@@muniTalk.caught">{{ caught() }} caught</ng-container>
        </p>
      }
    }
    <button
      type="button"
      class="muni"
      [class.is-hop]="hop() % 2 === 1"
      [class.is-hop2]="hop() > 0 && hop() % 2 === 0"
      [attr.aria-label]="askLabel"
      (click)="next()"
    >
      @if (compact()) {
        <!-- Corrections #39: a small Muni reads as a face in a ring, never a tiny full-body figure. -->
        <img [ngSrc]="face" alt="" width="192" height="192" />
      } @else {
        <img [ngSrc]="pose" alt="" width="424" height="530" />
      }
      @if (large()) {
        <span class="platform" aria-hidden="true"></span>
        @if (!hop()) {
          <span class="tap-me" aria-hidden="true" i18n="@@muniTalk.tapMe">Tap me</span>
        }
      }
    </button>
    <div class="bubble" aria-live="polite">
      @for (l of [line()]; track l) {
        <p class="line" smTypewriter>{{ l }}</p>
      }
    </div>
  `,
  styleUrl: './muni-talk.scss',
  host: {
    class: 'sm-muni-talk',
    '[class.sm-muni-talk--compact]': 'compact()',
    '[class.sm-muni-talk--large]': 'large()',
  },
})
export class MuniTalk {
  /** What Muni says first (usually the screen's own explanation). */
  readonly say = input('');
  /** Further lines for each tap; defaults to his generic pep talk. */
  readonly lines = input<readonly string[]>(MUNI_EMPTY_LINES);
  /** Smaller Muni for cards and panels. */
  readonly compact = input(false, { transform: booleanAttribute });
  /** Hero-size Muni for full-screen empty states (A-283). */
  readonly large = input(false, { transform: booleanAttribute });

  protected readonly pose = ASSETS.muniPose.right;
  protected readonly face = ASSETS.muniFace;
  protected readonly askLabel = $localize`:@@muniTalk.ask:Tap Muni for another line`;
  private readonly all = computed(() => [this.say(), ...this.lines()].filter(Boolean));
  private readonly index = signal(0);
  private readonly bonus = signal('');
  protected readonly line = computed(() => {
    const all = this.all();
    return this.bonus() || (all.length ? all[this.index() % all.length] : '');
  });

  /** Sparks drifting across the large stage; tap one to catch it (just for fun, no XP). */
  protected readonly sparks = signal(
    Array.from({ length: 7 }, (_, id) => ({ id, ...spot(id), popped: false })),
  );
  protected readonly caught = signal(0);

  protected catchSpark(id: number, event: PointerEvent): void {
    event.stopPropagation();
    const spark = this.sparks().find((s) => s.id === id);
    if (!spark || spark.popped) return;
    this.sfx.play('coin');
    this.caught.update((n) => n + 1);
    this.sparks.update((all) => all.map((s) => (s.id === id ? { ...s, popped: true } : s)));
    const n = this.caught();
    if (n === 3) this.bonus.set($localize`:@@muniTalk.spark3:Ooh, quick hands. Three sparks already!`);
    else if (n === 7)
      this.bonus.set($localize`:@@muniTalk.spark7:Seven! Save some of that energy for real XP 😄`);
    // A new spark drifts in a moment later, somewhere else.
    setTimeout(
      () =>
        this.sparks.update((all) =>
          all.map((s) => (s.id === id ? { ...s, ...spot(id + n * 3), popped: false } : s)),
        ),
      1600,
    );
  }
  protected readonly hop = signal(0);
  private readonly sfx = inject(SoundFx);

  protected next(): void {
    this.sfx.play('tap');
    this.bonus.set('');
    this.hop.update((n) => n + 1);
    this.index.update((i) => i + 1);
  }
}

/** Spread sparks across the stage with a little variety (deterministic, so tests are stable). */
function spot(seed: number): { x: number; delay: string; size: number } {
  const r = (n: number) => ((Math.sin(seed * 12.9898 + n * 78.233) * 43758.5453) % 1 + 1) % 1;
  return { x: 6 + r(1) * 88, delay: `${(r(2) * -9).toFixed(2)}s`, size: 0.7 + r(3) * 0.7 };
}
