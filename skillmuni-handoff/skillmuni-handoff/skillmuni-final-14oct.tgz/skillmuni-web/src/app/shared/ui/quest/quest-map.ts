import { booleanAttribute, Component, computed, input, output } from '@angular/core';
import { QuestItem, QuestItemState } from './quest-item';
import { QUESTS, TOTAL_XP, questXp } from '../../../core/quests/quest-catalog';
import { uniqueId } from '../internal/unique-id';

export interface QuestProgress {
  /** Highest completed quest id (0 = none). */
  readonly completed: number;
  /** Parts done in the current quest. */
  readonly partsDone: number;
}

export type QuestMapVariant = 'rail' | 'strip' | 'compact';

/**
 * Figma: Navigation → Quest Map (27:104) — left rail on desktop.
 * Tablet: horizontal lineup strip of 8 tiles. Mobile: icon strip + active-quest summary + "See all" (opens the
 * full map in a sheet; the parent handles `seeAll`). A navigation landmark in every variant.
 */
@Component({
  selector: 'sm-quest-map',
  imports: [QuestItem],
  templateUrl: './quest-map.html',
  styleUrl: './quest-map.scss',
  host: {
    role: 'navigation',
    '[class]': '"sm-quest-map is-" + variant()',
    '[attr.aria-labelledby]': 'headingId',
    '[class.is-plain]': 'plain()',
  },
})
export class QuestMap {
  readonly progress = input.required<QuestProgress>();
  readonly variant = input<QuestMapVariant>('rail');
  /** Drop the panel chrome when hosted in a sheet/modal. */
  readonly plain = input(false, { transform: booleanAttribute });
  readonly open = output<number>();
  readonly seeAll = output<void>();

  protected readonly quests = QUESTS;
  protected readonly totalXp = TOTAL_XP;
  protected readonly totalOf = questXp;
  protected readonly headingId = uniqueId('quest-map-heading');

  protected readonly items = computed(() => {
    const done = this.progress().completed;
    return QUESTS.map((q) => {
      const state: QuestItemState =
        q.id <= done
          ? 'done'
          : q.id === done + 1
            ? 'active'
            : q.id === done + 2
              ? 'next'
              : 'locked';
      return { ...q, state };
    });
  });

  protected readonly active = computed(
    () => this.items().find((q) => q.state === 'active') ?? null,
  );
  protected readonly inProgress = computed(() =>
    Math.min(this.progress().completed + 1, QUESTS.length),
  );
}
