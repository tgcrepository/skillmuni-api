import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Select, SelectOption } from './select';
import { Field } from '../field/field';

const RELATIONSHIPS: SelectOption[] = [
  'Parent',
  'Guardian',
  'Sibling',
  'Spouse / Partner',
  'Friend',
  'Relative',
].map((l) => ({ value: l.toLowerCase(), label: l }));
const STATES: SelectOption[] = [
  'Andhra Pradesh',
  'Arunachal Pradesh',
  'Assam',
  'Bihar',
  'Chhattisgarh',
  'Goa',
  'Gujarat',
  'Haryana',
  'Kerala',
].map((l) => ({ value: l, label: l }));

@Component({
  imports: [Select, Field],
  template: `
    <sm-field label="Relationship"
      ><sm-select [options]="rel" [searchable]="false" [(value)]="relationship"
    /></sm-field>
    <sm-select
      [options]="states"
      [(value)]="state"
      ariaLabel="State"
      allowCustom
      (custom)="custom = $event"
    />
  `,
})
class Host {
  readonly rel = RELATIONSHIPS;
  readonly states = STATES;
  readonly relationship = signal<string | null>(null);
  readonly state = signal<string | null>(null);
  custom = '';
}

describe('Select', () => {
  function setup() {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    const [rel, states] = [...el.querySelectorAll<HTMLButtonElement>('button[role="combobox"]')];
    return { fixture, host: fixture.componentInstance, rel: rel!, states: states! };
  }
  const key = (el: HTMLElement, k: string) =>
    el.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true }));
  const overlay = () => document.querySelector('.cdk-overlay-container') as HTMLElement;

  afterEach(() => overlay()?.replaceChildren());

  it('is a labelled combobox showing the placeholder', () => {
    const { rel } = setup();
    expect(rel.getAttribute('aria-haspopup')).toBe('listbox');
    expect(rel.getAttribute('aria-expanded')).toBe('false');
    expect(document.querySelector(`label[for="${rel.id}"]`)!.textContent).toContain('Relationship');
  });

  it('opens with the keyboard, moves with arrows and picks with Enter', async () => {
    const { fixture, host, rel } = setup();
    key(rel, 'ArrowDown');
    fixture.detectChanges();
    await fixture.whenStable();
    expect(rel.getAttribute('aria-expanded')).toBe('true');
    expect(overlay().querySelectorAll('[role="option"]')).toHaveLength(6);
    key(rel, 'ArrowDown');
    fixture.detectChanges();
    expect(rel.getAttribute('aria-activedescendant')).toBe(
      overlay().querySelectorAll('[role="option"]')[1]!.id,
    );
    key(rel, 'Enter');
    fixture.detectChanges();
    expect(host.relationship()).toBe('guardian');
    expect(rel.textContent).toContain('Guardian');
  });

  it('type-ahead selects on a closed trigger', () => {
    const { fixture, host, rel } = setup();
    key(rel, 's');
    fixture.detectChanges();
    expect(host.relationship()).toBe('sibling');
  });

  it('shows search, "See all" and a custom-value escape hatch for long lists', async () => {
    const { fixture, host, states } = setup();
    states.click();
    fixture.detectChanges();
    await fixture.whenStable();
    expect(overlay().querySelector('input[type="search"]')).not.toBeNull();
    expect(overlay().querySelectorAll('[role="option"]')).toHaveLength(7);
    expect(overlay().querySelector('.see-all')!.textContent).toContain('See all 9');

    const search = overlay().querySelector('input[type="search"]') as HTMLInputElement;
    search.value = 'xyz nagar';
    search.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(overlay().textContent).toContain('No matches for “xyz nagar”');
    (overlay().querySelector('.use-custom') as HTMLButtonElement).click();
    fixture.detectChanges();
    expect(host.custom).toBe('xyz nagar');
  });
});

describe('Select · type it in (A-163)', () => {
  @Component({
    imports: [Select],
    template: `<sm-select ariaLabel="College" [options]="opts" [(value)]="value" />`,
  })
  class TypeHost {
    readonly opts = [{ value: 'iit', label: 'IIT Bombay' }];
    value: string | null = null;
  }

  it('searches by default and keeps a typed value that is not in the list', async () => {
    const fixture = TestBed.createComponent(TypeHost);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    el.querySelector<HTMLButtonElement>('button[role="combobox"]')!.click();
    fixture.detectChanges();
    await fixture.whenStable();
    const search = document.querySelector<HTMLInputElement>('input[type="search"]')!;
    expect(search).toBeTruthy();
    expect(document.body.textContent).toContain('Not listed? Type it in');
    search.value = 'Sunrise Institute';
    search.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    search.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter' }));
    fixture.detectChanges();
    expect(fixture.componentInstance.value).toBe('Sunrise Institute');
    expect(el.querySelector('.value')?.textContent).toContain('Sunrise Institute');
  });
});
