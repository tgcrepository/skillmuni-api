import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Banner } from './banner';
import { TextLink } from '../text-link/text-link';

const meta: Meta<Banner> = {
  title: 'Primitives/Banner',
  component: Banner,
  parameters: { figma: { node: '22:56' }, layout: 'padded' },
};
export default meta;

export const AllTones: StoryObj<Banner> = {
  render: () => ({
    template: `
      <div style="display:grid;gap:var(--sm-space-600);max-inline-size:var(--sm-layout-shell-card-max-width)">
        <sm-banner tone="success">Bank-level encryption. We only use your ID to verify it’s you, never for anything else.</sm-banner>
        <sm-banner tone="error">2 answers need a look before you can lock this in. <a sm-text-link smBannerAction href="#">Fix it</a></sm-banner>
        <sm-banner tone="warning" dismissible>That date is in the future — double-check it?</sm-banner>
        <sm-banner tone="info">Tip: you can drop your CV later in the Receipts quest.</sm-banner>
      </div>`,
    moduleMetadata: { imports: [Banner, TextLink] },
  }),
};
