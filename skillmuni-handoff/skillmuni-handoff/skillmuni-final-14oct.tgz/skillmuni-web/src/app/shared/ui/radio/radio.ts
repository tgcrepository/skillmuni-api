import { Component, booleanAttribute, computed, inject, input } from '@angular/core';
import { RadioGroup } from './radio-group';

/**
 * Figma: Selection Controls → Radio (16:70). 20px; selected = Ember ring + dot.
 * Prefer Chips for short answer sets; use Radio in dense lists and settings.
 * Must sit inside <sm-radio-group>.
 */
@Component({
  selector: 'sm-radio',
  template: `
    <label class="row">
      <span class="ring">
        <input
          type="radio"
          [name]="group.name()"
          [value]="value()"
          [checked]="selected()"
          [disabled]="isDisabled()"
          [required]="group.required()"
          (change)="group.value.set(value())"
          (blur)="group.touch.emit()"
        />
        <span class="dot" aria-hidden="true"></span>
      </span>
      <span class="label"><ng-content /></span>
    </label>
  `,
  styleUrl: './radio.scss',
  host: {
    class: 'sm-radio',
    '[class.is-selected]': 'selected()',
    '[class.is-disabled]': 'isDisabled()',
  },
})
export class Radio {
  protected readonly group = inject(RadioGroup);
  readonly value = input.required<string>();
  readonly disabled = input(false, { transform: booleanAttribute });

  protected readonly selected = computed(() => this.group.value() === this.value());
  protected readonly isDisabled = computed(() => this.disabled() || this.group.disabled());
}
