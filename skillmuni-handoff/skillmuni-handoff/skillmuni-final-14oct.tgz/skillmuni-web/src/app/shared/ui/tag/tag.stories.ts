import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Tag } from './tag';

const meta: Meta<Tag> = {
  title: 'Primitives/Tag',
  component: Tag,
  parameters: { figma: { node: '14:16' } },
};
export default meta;

export const AllTones: StoryObj<Tag> = {
  render: () => ({
    template: `
      <div style="display:flex;gap:var(--sm-space-400)">
        <sm-tag tone="neutral">Optional</sm-tag>
        <sm-tag tone="brand">From your CV</sm-tag>
        <sm-tag tone="accent">Auto-filled</sm-tag>
        <sm-tag tone="danger">Needed</sm-tag>
        <sm-tag tone="success">Verified</sm-tag>
        <sm-tag tone="warning">Check this</sm-tag>
        <sm-tag tone="info">Tip</sm-tag>
      </div>`,
    moduleMetadata: { imports: [Tag] },
  }),
};
