import { Component, booleanAttribute, input } from '@angular/core';
import { Icon } from '../icon/icon';
import { blockInertClicks } from '../internal/block-inert-clicks';
import { IconName } from '../icon/icons';

export type IconButtonTone = 'neutral' | 'ghost';
export type IconButtonSize = 44 | 36;

/**
 * Figma: Buttons → Icon Button (12:223). Edit, remove, back, clear.
 * Size 44 is the default (meets the 44×44 touch target); 36 only inside an existing 44px tap area.
 * `label` is required — it is the button's accessible name.
 */
@Component({
  selector: 'button[sm-icon-button]',
  imports: [Icon],
  template: `<sm-icon [name]="icon()" size="inherit" />`,
  styleUrl: './icon-button.scss',
  host: {
    type: 'button',
    '[class]': '"sm-icon-button sm-icon-button--" + tone() + " sm-icon-button--" + size()',
    '[attr.aria-label]': 'label()',
    '[attr.aria-disabled]': 'disabled() ? "true" : null',
    '[class.is-disabled]': 'disabled()',
  },
})
export class IconButton {
  readonly icon = input.required<IconName>();
  readonly label = input.required<string>();
  readonly tone = input<IconButtonTone>('neutral');
  readonly size = input<IconButtonSize>(44);
  readonly disabled = input(false, { transform: booleanAttribute });

  constructor() {
    blockInertClicks(() => this.disabled());
  }
}
