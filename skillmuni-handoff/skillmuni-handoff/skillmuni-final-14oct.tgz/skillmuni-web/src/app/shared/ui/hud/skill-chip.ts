import { Component, input, output } from '@angular/core';
import { PowerLevel, PowerMeter } from './power-meter';

export type SkillChipKind = 'default' | 'signature' | 'unset';

/**
 * Figma: Progress & Game HUD → Skill Chip (26:73). A picked skill in the learner's deck:
 * category dot + name + Power Meter + remove. Signature = one of the top 3. Unset = level not chosen ("Set level").
 * The chip body is a button that opens the level picker; remove is a separate button.
 */
@Component({
  selector: 'sm-skill-chip',
  imports: [PowerMeter],
  template: `
    <button type="button" class="main" (click)="edit.emit()" [attr.aria-label]="editLabel()">
      <span class="dot" aria-hidden="true"></span>
      <span class="name">{{ skill() }}</span>
      @if (kind() === 'unset') {
        <span class="set" i18n="@@skill.setLevel">Set level</span>
      } @else {
        <sm-power-meter [level]="level()" />
      }
    </button>
    <button type="button" class="remove" (click)="remove.emit()" [attr.aria-label]="removeLabel()">
      <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path
          d="M6 6L18 18M18 6L6 18"
          stroke="currentColor"
          stroke-width="3"
          stroke-linecap="round"
        />
      </svg>
    </button>
  `,
  styleUrl: './skill-chip.scss',
  host: { '[class]': '"sm-skill-chip sm-skill-chip--" + kind()' },
})
export class SkillChip {
  readonly skill = input.required<string>();
  readonly kind = input<SkillChipKind>('default');
  readonly level = input<PowerLevel>(0);
  readonly edit = output<void>();
  readonly remove = output<void>();

  protected editLabel(): string {
    return $localize`:@@skill.edit:Change level for ${this.skill()}:skill:`;
  }

  protected removeLabel(): string {
    return $localize`:@@skill.remove:Remove ${this.skill()}:skill:`;
  }
}
