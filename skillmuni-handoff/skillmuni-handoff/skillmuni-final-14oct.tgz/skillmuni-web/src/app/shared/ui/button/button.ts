import {
  Component,
  DestroyRef,
  ElementRef,
  afterNextRender,
  booleanAttribute,
  computed,
  inject,
  input,
} from '@angular/core';
import { Icon } from '../icon/icon';
import { blockInertClicks } from '../internal/block-inert-clicks';
import { IconName } from '../icon/icons';
import { Currency } from '../currency/currency';

export type ButtonVariant = 'primary' | 'accent' | 'secondary' | 'outline-brand';

/**
 * Figma: Buttons → Button (12:182).
 * Primary (Ember) = one forward action per view · Accent (Arcane) = alternative/celebratory forward ·
 * Secondary = back/cancel · Outline Brand = optional skip. Height 52, pill.
 *
 * Applied to a native <button> or <a> so keyboard, form and link semantics stay native.
 * Disabled and loading use aria-disabled (still focusable, so the reason can be read nearby);
 * clicks are blocked (capture phase) while either is set.
 */
@Component({
  selector: 'button[sm-button], a[sm-button]',
  imports: [Currency, Icon],
  template: `
    <span class="content" [attr.aria-hidden]="loading() ? 'true' : null">
      <span class="label"><ng-content /></span>
      @if (xp()) {
        <span class="xp"><sm-currency kind="xp" size="xs" />{{ xp() }}</span>
      }
      @if (trailingIcon(); as icon) {
        <sm-icon [name]="icon" size="inherit" />
      }
    </span>
    @if (loading()) {
      <span class="busy" role="status">
        <sm-icon name="spinner" size="inherit" />
        <span>{{ loadingLabel() }}</span>
      </span>
    }
  `,
  styleUrl: './button.scss',
  host: {
    class: 'sm-button',
    '[class]': '"sm-button--" + variant()',
    '[class.is-loading]': 'loading()',
    '[class.is-disabled]': 'disabled()',
    '[attr.aria-disabled]': 'inert() ? "true" : null',
    '[attr.aria-busy]': 'loading() ? "true" : null',
    '[attr.type]': 'typeAttr()',
  },
})
export class Button {
  readonly variant = input<ButtonVariant>('primary');
  readonly disabled = input(false, { transform: booleanAttribute });
  readonly loading = input(false, { transform: booleanAttribute });
  /** Shown while loading. Figma: "Saving…". */
  readonly loadingLabel = input($localize`:@@ui.button.saving:Saving…`);
  /** XP reward chip, e.g. "+20 XP". Shown only when the action grants XP. */
  readonly xp = input<string>('');
  readonly trailingIcon = input<IconName | null>(null);
  /** Native button type. Ignored on links. */
  readonly type = input<'button' | 'submit' | 'reset'>('button');

  protected readonly inert = computed(() => this.disabled() || this.loading());
  private readonly isLink =
    (inject(ElementRef).nativeElement as HTMLElement).tagName.toLowerCase() === 'a';

  protected readonly typeAttr = computed(() => (this.isLink ? null : this.type()));

  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;

  constructor() {
    blockInertClicks(() => this.inert());
    // A-275: keep the label on one line by stepping down padding, then type size.
    const destroyRef = inject(DestroyRef);
    afterNextRender(() => {
      if (typeof ResizeObserver === 'undefined') return;
      let frame = 0;
      const ro = new ResizeObserver(() => {
        cancelAnimationFrame(frame);
        frame = requestAnimationFrame(() => this.fit());
      });
      ro.observe(this.host);
      const content = this.host.querySelector('.content');
      if (content) ro.observe(content);
      destroyRef.onDestroy(() => {
        ro.disconnect();
        cancelAnimationFrame(frame);
      });
    });
  }

  private fit(): void {
    const el = this.host;
    // Last resort on very narrow phones: drop the XP chip (the toast still announces the XP).
    const levels = ['is-tight', 'is-tighter', 'is-tightest', 'is-cramped'];
    el.classList.remove(...levels);
    for (const level of levels) {
      if (el.scrollWidth <= el.clientWidth + 1) return;
      el.classList.remove(...levels);
      el.classList.add(level);
      if (level === 'is-cramped') el.classList.add('is-tightest');
    }
  }
}
