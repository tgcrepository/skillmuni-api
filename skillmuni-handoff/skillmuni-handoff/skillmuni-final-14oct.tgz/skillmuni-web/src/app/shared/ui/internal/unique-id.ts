let next = 0;

/** Stable, unique DOM id for label/description wiring. */
export function uniqueId(prefix: string): string {
  next += 1;
  return `sm-${prefix}-${next}`;
}
