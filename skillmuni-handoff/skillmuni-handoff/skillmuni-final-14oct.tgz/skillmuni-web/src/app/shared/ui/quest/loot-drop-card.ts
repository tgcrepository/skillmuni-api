import { booleanAttribute, Component, computed, input } from '@angular/core';
import { BadgeRing } from './badge-ring';

/**
 * Figma: Cards & Overlays → Loot Drop Card (29:89). The reward the learner is working toward,
 * top of the right rail: badge + progress ring, what it unlocks, status pill.
 */
@Component({
  selector: 'sm-loot-drop-card',
  imports: [BadgeRing],
  template: `
    @if (compact()) {
      <sm-badge-ring size="s" [quest]="quest()" [progress]="progress()" [label]="badgeLabel()" />
      <div class="text">
        <p class="name">
          {{ badge() }} <span class="pct">· {{ pct() }}%</span>
        </p>
        <p class="reward">{{ reward() }}</p>
      </div>
    } @else {
      <p class="eyebrow" i18n="@@loot.eyebrow">Loot drop</p>
      <sm-badge-ring [quest]="quest()" [progress]="progress()" [label]="badgeLabel()" />
      <h3 class="name">{{ badge() }}</h3>
      <p class="reward">{{ reward() }}</p>
      <p class="status">{{ status() }}</p>
    }
  `,
  styleUrl: './loot-drop-card.scss',
  host: {
    class: 'sm-loot-drop-card',
    '[class.is-unlocked]': 'progress() >= 100',
    '[class.is-compact]': 'compact()',
    role: 'region',
    '[attr.aria-label]': 'badge()',
  },
})
export class LootDropCard {
  readonly quest = input.required<number>();
  readonly badge = input.required<string>();
  /** What it unlocks, e.g. "+50 XP, and the Hit Me Up quest unlocks". */
  readonly reward = input.required<string>();
  readonly progress = input(0);
  /** Mobile / tablet row layout (Figma 200:13165): small ring, "Badge · N%", reward line. */
  readonly compact = input(false, { transform: booleanAttribute });

  protected readonly pct = computed(() => Math.round(Math.min(100, Math.max(0, this.progress()))));

  protected readonly status = computed(() => {
    const p = Math.round(this.progress());
    if (p >= 100) return $localize`:@@loot.unlocked:Unlocked`;
    if (p >= 75) return $localize`:@@loot.almost:${p}:p:% there, almost`;
    if (p >= 25) return $localize`:@@loot.going:${p}:p:% there, keep going`;
    return $localize`:@@loot.start:Just getting started`;
  });

  protected readonly badgeLabel = computed(
    () => $localize`:@@loot.badgeLabel:${this.badge()}:badge:, ${this.status()}:status:`,
  );
}
