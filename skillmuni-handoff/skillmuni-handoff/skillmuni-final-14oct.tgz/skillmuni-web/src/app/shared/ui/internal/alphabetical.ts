/**
 * A–Z order for option lists (A-258). Catch-all answers ("Other", "None", "Prefer not to say"…)
 * stay at the end in the order given, as people look for them last. Uses the app locale's collation,
 * so accents and numbers sort the way readers expect.
 */
const PINNED_LAST =
  /^(other|others|something else|none|none of these|not sure|not listed|prefer not to say|i'?d rather not say|rather not say)\b/i;

/** "All …" / "Any …" lead the list. */
const PINNED_FIRST = /^(all|any)\b/i;

export type OptionOrder = 'alpha' | 'given';

export function alphabetical<T>(
  items: readonly T[],
  label: (item: T) => string,
  locale?: string,
): T[] {
  const collator = new Intl.Collator(locale, { sensitivity: 'base', numeric: true });
  const rank = (item: T) => {
    const text = label(item).trim().replace(/[’]/g, "'");
    return PINNED_FIRST.test(text) ? -1 : PINNED_LAST.test(text) ? 1 : 0;
  };
  return [...items].sort((a, b) => {
    const ra = rank(a);
    const rb = rank(b);
    if (ra || rb) return ra - rb;
    return collator.compare(label(a), label(b));
  });
}
