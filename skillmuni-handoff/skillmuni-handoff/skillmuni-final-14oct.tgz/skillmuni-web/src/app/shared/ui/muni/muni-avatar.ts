import { NgOptimizedImage } from '@angular/common';
import { signal } from '@angular/core';
import { Component, computed, input } from '@angular/core';
import { ASSETS } from '../../assets';

/**
 * Figma: Muni → Muni Avatar (28:4). Circular head crop for compact placements
 * (mobile tip row, login greeting, toasts). 56 default; 32 / 40 / 44 / 56, and 72 / 96 / 120
 * (large face circle that replaces a tiny full-body Muni, corrections #39).
 * Decorative unless `label` is set.
 */
@Component({
  imports: [NgOptimizedImage],
  selector: 'sm-muni-avatar',
  template: `<img
    [ngSrc]="big() ? face : src"
    [attr.alt]="label()"
    [width]="px()"
    [height]="px()"
    (error)="missing.set(true)"
    [class.is-missing]="missing()"
  />`,
  styleUrl: './muni-avatar.scss',
  host: {
    '[class]': '"sm-muni-avatar sm-muni-avatar--" + size()',
    '[attr.aria-hidden]': 'label() ? null : "true"',
  },
})
export class MuniAvatar {
  /** Artwork not exported yet / failed to load: hide the broken image, keep the tinted placeholder. */
  protected readonly missing = signal(false);
  readonly size = input<32 | 40 | 44 | 56 | 72 | 96 | 120>(56);
  protected readonly px = computed(() => this.size());
  readonly label = input('');
  protected readonly src = ASSETS.muniAvatar;
  protected readonly face = ASSETS.muniFace;
  protected readonly big = computed(() => this.size() > 56);
}
