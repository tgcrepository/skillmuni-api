import { Component, input } from '@angular/core';

/**
 * Figma: Progress & Game HUD → Level Orb (24:33). L (48) desktop HUD · M (36) cards · S (28) mobile pill.
 * The visible number is decorative; the HUD around it states "Level N" for screen readers.
 */
@Component({
  selector: 'sm-level-orb',
  template: `{{ level() }}`,
  styleUrl: './level-orb.scss',
  host: { '[class]': '"sm-level-orb sm-level-orb--" + size()', 'aria-hidden': 'true' },
})
export class LevelOrb {
  readonly level = input.required<number>();
  readonly size = input<'l' | 'm' | 's'>('l');
}
