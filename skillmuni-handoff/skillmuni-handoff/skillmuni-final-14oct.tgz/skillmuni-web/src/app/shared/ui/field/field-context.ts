import { InjectionToken, Signal } from '@angular/core';

export type FieldStatus = 'none' | 'valid' | 'error' | 'warning';

/** Shared by <sm-field> and the control inside it, so ids and states are wired automatically. */
export interface FieldContext {
  readonly controlId: string;
  /** Visible label text (used as the title of a mobile picker sheet). */
  readonly label: Signal<string>;
  readonly describedBy: Signal<string>;
  readonly status: Signal<FieldStatus>;
  readonly required: Signal<boolean>;
}

export const FIELD_CONTEXT = new InjectionToken<FieldContext>('FIELD_CONTEXT');

/**
 * Set by the quest shell (A-251): inside quests every `required` field shows the red "Needed" tag
 * by itself, so no required field is ever unmarked. Auth forms (all fields required) don't set it.
 */
export const MARK_NEEDED = new InjectionToken<boolean>('MARK_NEEDED', {
  providedIn: 'root',
  factory: () => false,
});
