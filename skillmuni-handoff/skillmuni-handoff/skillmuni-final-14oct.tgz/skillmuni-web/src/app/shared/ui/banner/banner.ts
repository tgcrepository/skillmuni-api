import { Component, booleanAttribute, computed, input, output } from '@angular/core';
import { StatusIcon, StatusTone } from '../status-icon/status-icon';
import { IconButton } from '../icon-button/icon-button';

/**
 * Figma: Feedback → Banner (22:56). Inline, persistent message inside a card, full container width.
 * Success = trust / reassurance · Error = blocking validation for a section · Warning = likely mistake ·
 * Info = neutral tip. Not for transient confirmations (use Toast).
 * Project an action as `<a sm-text-link smBannerAction>`.
 * Error banners use role="alert" so they are announced when they appear.
 */
@Component({
  selector: 'sm-banner',
  imports: [StatusIcon, IconButton],
  template: `
    <sm-status-icon [tone]="tone()" size="l" />
    <div class="message"><ng-content /></div>
    <ng-content select="[smBannerAction]" />
    @if (dismissible()) {
      <button
        sm-icon-button
        icon="x"
        tone="ghost"
        [size]="36"
        [label]="dismissLabel()"
        (click)="dismiss.emit()"
      ></button>
    }
  `,
  styleUrl: './banner.scss',
  host: {
    '[class]': '"sm-banner sm-banner--" + tone()',
    '[attr.role]': 'role()',
  },
})
export class Banner {
  readonly tone = input<StatusTone>('info');
  readonly dismissible = input(false, { transform: booleanAttribute });
  readonly dismissLabel = input($localize`:@@ui.banner.dismiss:Dismiss`);
  readonly dismiss = output<void>();

  protected readonly role = computed(() => (this.tone() === 'error' ? 'alert' : null));
}
