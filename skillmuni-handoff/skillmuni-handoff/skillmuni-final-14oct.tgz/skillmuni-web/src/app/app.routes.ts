import { Routes } from '@angular/router';
import { environment } from '../environments/environment';
import { authRoutes } from './features/auth/auth.routes';
import { onboardingRoutes } from './features/onboarding/onboarding.routes';
import { questRoutes } from './features/quests/quests.routes';
import { matchesRoutes } from './features/matches/matches.routes';
import { programmeRoutes } from './features/programme/programme.routes';
import { claimRoutes } from './features/claim/claim.routes';
import { homeRoutes } from './features/home/home.routes';
import { arenaRoutes } from './features/arena/arena.routes';
import { learnRoutes } from './features/learn/learn.routes';
import { profileRoutes } from './features/profile/profile.routes';
import { statsRoutes } from './features/stats/stats.routes';
import { launchpadRoutes } from './features/launchpad/launchpad.routes';
import { jobProfileRoutes } from './features/job-profile/job-profile.routes';
import { assessmentRoutes } from './features/assessment/assessment.routes';
import { jobsRoutes } from './features/jobs/jobs.routes';
import { festRoutes } from './features/fest/fest.routes';
import { legalRoutes } from './features/legal/legal.routes';
import { soonRoutes } from './features/soon/soon.routes';

/** Dev-only routes are never registered in production builds. */
const devRoutes: Routes = environment.production
  ? []
  : [
      {
        path: '_dev/tokens',
        title: $localize`:@@route.dev.tokens:Design tokens · Skillmuni`,
        loadComponent: () =>
          import('./features/dev/tokens-preview/tokens-preview').then((m) => m.TokensPreview),
      },
      {
        path: '_dev/states',
        title: $localize`:@@route.dev.states:Global states · Skillmuni`,
        loadComponent: () =>
          import('./features/dev/states-preview/states-preview').then((m) => m.StatesPreview),
      },
    ];

export const routes: Routes = [
  ...devRoutes,
  ...authRoutes,
  ...onboardingRoutes,
  ...questRoutes,
  ...matchesRoutes,
  ...programmeRoutes,
  ...claimRoutes,
  ...homeRoutes,
  ...arenaRoutes,
  ...learnRoutes,
  ...profileRoutes,
  ...statsRoutes,
  ...launchpadRoutes,
  ...jobProfileRoutes,
  ...assessmentRoutes,
  ...jobsRoutes,
  ...festRoutes,
  ...legalRoutes,
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  // Placeholders + catch-all last.
  ...soonRoutes,
];
