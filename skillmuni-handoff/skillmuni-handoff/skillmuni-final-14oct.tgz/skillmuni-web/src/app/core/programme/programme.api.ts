import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';
import { LearnerProgress } from '../progress/progress.api';

/** A programme / project unlocked by a code (Figma section 13, P1–P5). */
export interface Programme {
  readonly code: string;
  readonly name: string;
  /** e.g. "NSQF Level 4 · Aarambh Foundation × Skill India" */
  readonly partner: string;
  readonly centre: string;
  /** ISO date */
  readonly batchStarts: string;
  readonly duration: string;
  /** Empty when the programme pays no stipend (then no bank section). */
  readonly stipend: string;
  /** Marks rule, e.g. Class 12 with 50% in English and Maths. */
  readonly marksFrom: '10' | '12';
  readonly minEnglish: number;
  readonly minMaths: number;
  readonly eligibility: string;
}

export interface BankBranch {
  readonly bank: string;
  readonly branch: string;
}

export type Proficiency = 'basic' | 'okay' | 'good' | 'pro';

export interface ProgrammeSubmission {
  readonly code: string;
  readonly marksFrom: '10' | '12';
  readonly english: string;
  readonly maths: string;
  readonly proficiency: Readonly<Record<string, Proficiency>>;
  readonly bank: {
    readonly holder: string;
    readonly type: 'savings' | 'current' | 'cheque';
    readonly account: string;
    /** India IFSC, or the South African universal branch code. */
    readonly routing: string;
    readonly upi: string;
  } | null;
}

export interface ProgrammeResult {
  readonly xpEarned: number;
  readonly progress: LearnerProgress;
  /** Last 2 digits of the account the ₹1 / R1 check was sent to. */
  readonly accountTail: string;
}

/**
 * Programme code bonus quest. `check` 404s for unknown codes and 429s after 5 wrong tries
 * (30-minute cool-down, Figma P4). `ifsc` looks up bank + branch (India).
 */
export interface ProgrammeApi {
  check(code: string): Observable<Programme>;
  ifsc(code: string): Observable<BankBranch>;
  submit(body: ProgrammeSubmission): Observable<ProgrammeResult>;
}

@Service()
export class HttpProgrammeApi implements ProgrammeApi {
  private readonly api = inject(ApiClient);

  check(code: string): Observable<Programme> {
    return this.api.get(`programmes/${encodeURIComponent(code)}`);
  }

  ifsc(code: string): Observable<BankBranch> {
    return this.api.get(`banks/ifsc/${encodeURIComponent(code)}`);
  }

  submit(body: ProgrammeSubmission): Observable<ProgrammeResult> {
    return this.api.post('me/programme', body);
  }
}

export const PROGRAMME_API = new InjectionToken<ProgrammeApi>('PROGRAMME_API', {
  factory: () => inject(HttpProgrammeApi),
});
