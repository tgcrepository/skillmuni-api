import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

/**
 * My Job Profile v2 — the Living CV (Figma 308:43436, note 310:55447). The registration quests ARE
 * the job profile: one record, no second form. Every section says which quest collected it, and Edit
 * deep-links back into that quest part.
 */

export type ProofStatus = 'verified' | 'checking' | 'none';

/** Where Edit sends the learner: `/quests/<slug>?part=<part>`. */
export interface QuestRef {
  readonly slug: string;
  readonly part: number;
  readonly name: string;
}

export interface RadarStats {
  readonly people: number;
  readonly business: number;
  readonly data: number;
  readonly creative: number;
  readonly tech: number;
}

export interface WorkItem {
  readonly id: string;
  readonly initials: string;
  readonly role: string;
  readonly employer: string;
  readonly city: string;
  /** "Jan 2025 – Jun 2025 · 6 mos" */
  readonly period: string;
  readonly bullets: readonly string[];
  readonly proof: ProofStatus;
}

export interface EducationItem {
  readonly id: string;
  readonly initials: string;
  readonly title: string;
  readonly school: string;
  readonly detail: string;
  readonly proof: ProofStatus;
}

export interface LanguageItem {
  readonly name: string;
  readonly skills: string;
  readonly level: string;
}

export interface SkillItem {
  readonly name: string;
  /** 1–3 power pips; null = level not set yet. */
  readonly power: number | null;
  readonly signature: boolean;
}

export interface CertificateItem {
  readonly id: string;
  readonly title: string;
  readonly issuer: string;
  readonly status: ProofStatus;
  /** "48 h" while checking. */
  readonly eta: string | null;
}

export interface QuickWin {
  readonly id: string;
  readonly title: string;
  readonly impact: string;
  readonly link: string;
  readonly query: Readonly<Record<string, string | number>>;
}

export interface PendingQuest {
  readonly slug: string;
  readonly title: string;
  readonly detail: string;
  readonly xp: number;
}

/** A-262: one row per registration quest — which steps are in and which are still empty. */
export interface QuestFill {
  readonly id: number;
  readonly slug: string;
  readonly name: string;
  readonly filled: number;
  readonly total: number;
  readonly left: readonly { readonly key: string; readonly label: string; readonly part: number }[];
}

export interface JobProfile {
  readonly name: string;
  readonly initials: string;
  readonly headline: string;
  readonly archetype: { readonly name: string; readonly strongest: string } | null;
  readonly radar: RadarStats | null;
  readonly signature: readonly { readonly name: string; readonly power: number }[];
  readonly counts: {
    readonly skills: number;
    readonly languages: number;
    readonly trophies: number;
  };
  readonly byQuest: readonly QuestFill[];
  readonly strength: {
    readonly percent: number;
    readonly label: string;
    readonly jobMatches: number;
    readonly quickWins: readonly QuickWin[];
  };
  readonly contact: {
    readonly mobile: string;
    readonly mobileVerified: boolean;
    readonly email: string;
    readonly location: string;
    readonly city: string;
    readonly discoverable: boolean;
    readonly invitesBy: string;
    readonly neverShown: string;
  };
  readonly about: {
    readonly text: string;
    readonly byMuni: boolean;
    readonly tags: readonly string[];
  };
  readonly work: readonly WorkItem[];
  readonly education: readonly EducationItem[];
  readonly languages: readonly LanguageItem[];
  readonly skills: readonly SkillItem[];
  readonly certificates: readonly CertificateItem[];
  /** `private` rows (expected pay) never show in the employer view. */
  readonly lookingFor: readonly {
    readonly label: string;
    readonly value: string;
    readonly good?: boolean;
    readonly private?: boolean;
  }[];
  /** Short code on the CV footer: skillmuni.app/v/<code>. */
  readonly verifyCode: string;
  readonly verifiedCount: number;
  /** ISO date-time of the last change to the record. */
  readonly updatedAt: string;
  /** P6: sections a newly-added programme still needs (Career Launchpad added later). */
  readonly pending: readonly PendingQuest[];
  /** Section → quest that collected it. */
  readonly sources: Readonly<Record<SectionId, QuestRef>>;
}

export type SectionId =
  | 'about'
  | 'contact'
  | 'work'
  | 'education'
  | 'languages'
  | 'skills'
  | 'certificates'
  | 'lookingFor';

/** P5: one difference between the newer CV and the record. */
export interface CvChange {
  readonly id: string;
  readonly kind: 'job' | 'skill' | 'certificate' | 'contact';
  readonly title: string;
  readonly detail: string;
  /** Contact changes default to "keep current" (the record holds the verified value). */
  readonly suggest: 'add' | 'keep';
}

export interface ShareSettings {
  readonly url: string;
  readonly hideContact: boolean;
  readonly expiresDays: number;
  readonly viewsThisWeek: number;
}

/** Full contact for the learner's own CV file (never part of the profile payload or employer view). */
export interface CvContact {
  readonly phone: string;
  readonly email: string;
  readonly location: string;
  readonly linkedin: string | null;
  readonly expectedPay: string;
}

export interface JobProfileApi {
  cvContact(): Observable<CvContact>;
  profile(): Observable<JobProfile>;
  saveAbout(text: string): Observable<JobProfile>;
  /** Upload a newer CV; resolves with what changed (nothing is applied yet). */
  uploadCv(file: File): Observable<readonly CvChange[]>;
  applyChanges(ids: readonly string[]): Observable<JobProfile>;
  share(): Observable<ShareSettings>;
  updateShare(s: Pick<ShareSettings, 'hideContact' | 'expiresDays'>): Observable<ShareSettings>;
}

@Service()
export class HttpJobProfileApi implements JobProfileApi {
  private readonly api = inject(ApiClient);

  profile(): Observable<JobProfile> {
    return this.api.get('job-profile');
  }

  cvContact(): Observable<CvContact> {
    return this.api.get('job-profile/cv-contact');
  }

  saveAbout(text: string): Observable<JobProfile> {
    return this.api.put('job-profile/about', { text });
  }

  uploadCv(file: File): Observable<readonly CvChange[]> {
    const body = new FormData();
    body.append('cv', file);
    return this.api.post('job-profile/cv', body);
  }

  applyChanges(ids: readonly string[]): Observable<JobProfile> {
    return this.api.post('job-profile/cv/apply', { ids });
  }

  share(): Observable<ShareSettings> {
    return this.api.get('job-profile/share');
  }

  updateShare(s: Pick<ShareSettings, 'hideContact' | 'expiresDays'>): Observable<ShareSettings> {
    return this.api.put('job-profile/share', s);
  }
}

export const JOB_PROFILE_API = new InjectionToken<JobProfileApi>('JOB_PROFILE_API', {
  factory: () => inject(HttpJobProfileApi),
});
