import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';
import { AuthUser, OtpChallenge } from '../auth/auth.api';

/** A CV an institute uploaded for a learner (Figma section 11: V1 200:36751 · V2 200:36844). */
export interface ClaimInvite {
  readonly institute: string;
  /** Name as the institute entered it. */
  readonly name: string;
  readonly programme: string;
  readonly batch: string;
  /** e.g. "Contact, education, 8 skills, 2 languages, 1 job" */
  readonly fromCv: string;
  /** Masked number the code goes to, e.g. "+91 98•••• 4521". */
  readonly sentTo: string;
  readonly resendIn: number;
  readonly triesLeft: number;
  /** ISO date the CV is deleted if nobody claims it. */
  readonly deleteBy: string;
  /** e.g. "NSQF L4 certificate" — shown on the verify-certificate choice. */
  readonly certificate: string;
  /**
   * Present when this session already verified the code (e.g. the learner left V3 to edit a quest and
   * opened the link again): where to pick up.
   */
  readonly resume?: ClaimResume;
}

export interface ClaimResume {
  readonly stage: 'consent' | 'validate' | 'confirmed';
  readonly sections: readonly ClaimSection[];
  readonly result: ClaimResult | null;
}

/** Where a value in a V3 section came from. */
export type ClaimSource = 'institute' | 'verified' | 'you' | null;

export interface ClaimRow {
  readonly label: string;
  readonly value: string;
  readonly source: ClaimSource;
  /** e.g. "end date missing" — flags the row in a "Fix this" section. */
  readonly issue?: string;
}

export type ClaimSectionStatus = 'confirmed' | 'review' | 'fix';

/** V3 · one quest's worth of what the institute added. */
export interface ClaimSection {
  /** Quest slug, e.g. "big-brain-stuff". */
  readonly slug: string;
  readonly quest: number;
  readonly title: string;
  readonly summary: string;
  readonly status: ClaimSectionStatus;
  readonly rows: readonly ClaimRow[];
}

export interface ClaimLeftQuest {
  readonly quest: number;
  readonly slug: string;
  readonly name: string;
  readonly blurb: string;
  readonly xp: number;
}

/** V4 · Confirmed — next steps. */
export interface ClaimResult {
  readonly profilePercent: number;
  readonly verifiedItems: number;
  readonly jobs: number;
  readonly xpLeft: number;
  readonly minutesLeft: number;
  readonly left: readonly ClaimLeftQuest[];
}

export type DeclineReason = 'not-me' | 'not-now' | 'has-account' | 'other';

export interface ClaimConsent {
  readonly shareProgress: boolean;
  readonly verifyCertificate: boolean;
  readonly applyForMe: boolean;
}

/**
 * Institute claim link. `invite` 404s for unknown links and 410s for claimed / expired / deleted ones
 * (`errors.code`: claimed · expired · deleted). `verify` signs the learner in (session cookie).
 */
export interface ClaimApi {
  invite(token: string): Observable<ClaimInvite>;
  resend(token: string): Observable<OtpChallenge>;
  verify(token: string, code: string): Observable<AuthUser>;
  /** Saves the choices and returns the sections to validate (V3). */
  consent(token: string, choices: ClaimConsent): Observable<readonly ClaimSection[]>;
  /** V3 "Looks right" on one section. */
  confirmSection(token: string, slug: string): Observable<void>;
  /** All sections confirmed → V4 numbers. */
  finish(token: string): Observable<ClaimResult>;
  /** V5 · deletes the CV and everything read from it; the institute sees "Declined", not why. */
  decline(token: string, reason: DeclineReason | null): Observable<void>;
}

@Service()
export class HttpClaimApi implements ClaimApi {
  private readonly api = inject(ApiClient);

  invite(token: string): Observable<ClaimInvite> {
    return this.api.get(`claims/${encodeURIComponent(token)}`);
  }

  resend(token: string): Observable<OtpChallenge> {
    return this.api.post(`claims/${encodeURIComponent(token)}/otp`, {});
  }

  verify(token: string, code: string): Observable<AuthUser> {
    return this.api.post(`claims/${encodeURIComponent(token)}/verify`, { code });
  }

  consent(token: string, choices: ClaimConsent): Observable<readonly ClaimSection[]> {
    return this.api.post(`claims/${encodeURIComponent(token)}/consent`, choices);
  }

  confirmSection(token: string, slug: string): Observable<void> {
    return this.api.post(
      `claims/${encodeURIComponent(token)}/sections/${encodeURIComponent(slug)}/confirm`,
      {},
    );
  }

  finish(token: string): Observable<ClaimResult> {
    return this.api.post(`claims/${encodeURIComponent(token)}/finish`, {});
  }

  decline(token: string, reason: DeclineReason | null): Observable<void> {
    return this.api.post(`claims/${encodeURIComponent(token)}/decline`, { reason });
  }
}

export const CLAIM_API = new InjectionToken<ClaimApi>('CLAIM_API', {
  factory: () => inject(HttpClaimApi),
});
