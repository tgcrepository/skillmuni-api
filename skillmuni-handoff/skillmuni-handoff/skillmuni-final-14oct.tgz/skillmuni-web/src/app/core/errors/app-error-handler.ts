import { ErrorHandler, Injectable, inject } from '@angular/core';
import { ApiError } from '../api/api-error';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { isViewTransitionError } from '../layout/view-transitions';

/** At most one generic error toast in this window, so a burst of failures doesn't stack toasts. */
const TOAST_COOLDOWN = 10_000;

/**
 * Last line of defence for errors no screen handled. Screens own their own error states (MM3 pattern);
 * this only logs and shows one calm toast. Auth and offline errors are handled by SE1 / OF1, so they
 * are not toasted here.
 */
@Injectable()
export class AppErrorHandler implements ErrorHandler {
  private readonly toast = inject(ToastService);
  private last = 0;

  handleError(error: unknown): void {
    // A skipped or timed-out page animation is cosmetic: the navigation still completes.
    if (
      isViewTransitionError(error) ||
      isViewTransitionError((error as { rejection?: unknown })?.rejection)
    ) {
      console.warn(error);
      return;
    }
    console.error(error);
    if (error instanceof ApiError && (error.kind === 'unauthorized' || error.kind === 'offline'))
      return;
    const now = Date.now();
    if (now - this.last < TOAST_COOLDOWN) return;
    this.last = now;
    this.toast.show($localize`:@@error.generic:Something went sideways. Try that again.`, {
      tone: 'error',
    });
  }
}
