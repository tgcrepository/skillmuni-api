import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

/** Who is on the board (Figma Leaderboard v2 · scope tabs). */
export type ArenaScope = 'everyone' | 'batch' | 'friends';
/** Which window the XP counts over (period tabs). */
export type ArenaPeriod = 'week' | 'month' | 'all';

/** One player on the board. `movement` = places gained (+) or lost (−) since yesterday. */
export interface ArenaPlayer {
  readonly id: string;
  readonly rank: number;
  readonly name: string;
  readonly initials: string;
  readonly photo?: string;
  readonly xp: number;
  readonly streak: number;
  readonly modulesDone: number;
  readonly movement: number;
  readonly you: boolean;
  /** Player Peek (58:445) */
  readonly title: string;
  readonly level: number;
  readonly badges: number;
  readonly topSkill: string;
  readonly cheers: number;
  readonly cheered: boolean;
}

export type StreakDay = 'done' | 'today' | 'upcoming' | 'missed';

export interface ArenaBoard {
  readonly scope: ArenaScope;
  readonly period: ArenaPeriod;
  /** Ranked by XP, ties to the earlier timestamp (already sorted by the server). */
  readonly players: readonly ArenaPlayer[];
  /** The learner's own standing, even when they're far down the list. */
  readonly me: {
    readonly rank: number;
    readonly xp: number;
    readonly rankToday: number;
    readonly streak: number;
    /** Name of the player just above, for "N XP to pass X". */
    readonly nextName: string | null;
    readonly nextXp: number | null;
    readonly topXp: number;
  };
  /** Mon → Sun */
  readonly week: readonly StreakDay[];
  /** Top N move up a league. */
  readonly promotionRank: number;
  readonly league: string;
  /** The learner passed someone since their last visit. */
  readonly rankUp: { readonly to: number; readonly passed: string } | null;
  readonly rewards: {
    readonly coins: number;
    readonly voucher: {
      readonly discount: string;
      readonly title: string;
      readonly cost: number;
      readonly ready: number;
    } | null;
  };
}

export interface ArenaApi {
  board(scope: ArenaScope, period: ArenaPeriod): Observable<ArenaBoard>;
  /** Toggle a cheer; returns the new count. */
  cheer(playerId: string, on: boolean): Observable<{ cheers: number }>;
  /** Invite to a friendly 1-week XP race. */
  challenge(playerId: string): Observable<void>;
}

@Service()
export class HttpArenaApi implements ArenaApi {
  private readonly api = inject(ApiClient);

  board(scope: ArenaScope, period: ArenaPeriod): Observable<ArenaBoard> {
    return this.api.get('arena', { params: { scope, period } });
  }

  cheer(playerId: string, on: boolean): Observable<{ cheers: number }> {
    return this.api.post(`arena/players/${encodeURIComponent(playerId)}/cheer`, { on });
  }

  challenge(playerId: string): Observable<void> {
    return this.api.post(`arena/players/${encodeURIComponent(playerId)}/challenge`, {});
  }
}

export const ARENA_API = new InjectionToken<ArenaApi>('ARENA_API', {
  factory: () => inject(HttpArenaApi),
});
