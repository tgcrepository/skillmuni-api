import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

export interface LearnerProgress {
  /** Highest completed quest id (0 = none). */
  readonly completed: number;
  /** Parts done in the current quest. */
  readonly partsDone: number;
  readonly xp: number;
  readonly badges: number;
  readonly level: number;
  readonly rank: string;
  /** XP needed for the next level. */
  readonly target: number;
}

export interface ProgressApi {
  get(): Observable<LearnerProgress>;
}

@Service()
export class HttpProgressApi implements ProgressApi {
  private readonly api = inject(ApiClient);

  get(): Observable<LearnerProgress> {
    return this.api.get('me/progress');
  }
}

export const PROGRESS_API = new InjectionToken<ProgressApi>('PROGRESS_API', {
  factory: () => inject(HttpProgressApi),
});
