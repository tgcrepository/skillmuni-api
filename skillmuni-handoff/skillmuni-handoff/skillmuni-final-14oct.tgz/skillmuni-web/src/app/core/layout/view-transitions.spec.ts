import { isViewTransitionError } from './view-transitions';

describe('isViewTransitionError', () => {
  it('treats skipped or timed-out transitions as harmless', () => {
    expect(
      isViewTransitionError(
        new DOMException('Transition was aborted because of timeout in DOM update', 'TimeoutError'),
      ),
    ).toBe(true);
    expect(isViewTransitionError(new Error('boom'))).toBe(false);
  });
});
