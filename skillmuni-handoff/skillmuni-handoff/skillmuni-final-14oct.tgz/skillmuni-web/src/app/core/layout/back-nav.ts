import { Location } from '@angular/common';
import { Service, inject } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';

/** Path without query or fragment: steps inside one page (`?step=`, `?job=`) are not separate screens. */
const pathOf = (url: string) => url.split(/[?#]/)[0] ?? url;

/**
 * Tabs that live on their own URL are still one screen: Back from "My bookings" leaves Hire Fest
 * (to Launchpad or wherever the learner came from) instead of bouncing between the tabs.
 */
const TAB_FAMILIES: readonly (readonly [string, RegExp])[] = [
  ['/hire-fest', /^\/hire-fest(\/(bookings|past))?$/],
  ['/jobs', /^\/jobs(\/(matching|invitations|bookmarked|applied))?$/],
];

/** The screen a URL belongs to: its path, with sibling tabs folded into one. */
export const screenOf = (url: string): string => {
  const path = pathOf(url);
  return TAB_FAMILIES.find(([, re]) => re.test(path))?.[0] ?? path;
};

/**
 * Back and Up for every screen header (A-234). Walking the browser history — never pushing a new
 * entry — is what stops A → B → "back" → A → "back" → B loops.
 *
 * - `back(fallback)`: return to the previous *screen* in this tab (skipping in-page steps). With no
 *   in-app history (deep link, new tab) it replaces the current entry with `fallback`.
 * - `up(parent)`: go to a named parent. If the learner came through it, pop back to that entry so
 *   the history stays a clean stack; otherwise replace the current entry with it.
 *
 * Needs `canceledNavigationResolution: 'computed'` so the router stamps each entry with a page id.
 */
@Service()
export class BackNav {
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  /** Router page id → URL of that history entry, for this tab’s lifetime. */
  private readonly urls = new Map<number, string>();

  constructor() {
    this.router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe((e) => {
        const id = this.pageId();
        if (id === null) return;
        this.urls.set(id, e.urlAfterRedirects);
        this.noteOrigin(id, e.urlAfterRedirects);
      });
  }

  /** How many steps back the previous screen is, or 0 when there is none in this tab. */
  stepsToPrevious(current?: string): number {
    const id = this.pageId();
    if (id === null) return 0;
    // During activation router.url is still the old URL, so callers can pass where they are.
    const here = screenOf(current ?? this.router.url);
    for (let i = id - 1; i >= 0; i--) {
      const url = this.urls.get(i);
      if (url === undefined) return 0;
      if (screenOf(url) !== here) return id - i;
    }
    return 0;
  }

  /**
   * Corrections #19 / #31: where the learner was before a flow (e.g. the assessment), remembered so
   * its last screen (results) can go straight back there instead of to the flow's own intro.
   */
  private readonly origins = new Map<string, string>();
  /** Multi-screen flows whose entry point is remembered. */
  private static readonly FLOWS = ['/assessments/career'];

  private noteOrigin(id: number, url: string): void {
    const prev = this.urls.get(id - 1);
    if (prev === undefined) return;
    for (const flow of BackNav.FLOWS) {
      if (pathOf(url).startsWith(flow) && !pathOf(prev).startsWith(flow))
        this.origins.set(flow, pathOf(prev));
    }
  }

  origin(flow: string): string | null {
    return this.origins.get(flow) ?? null;
  }

  /** Path of the previous screen in this tab, or null. */
  previousPath(current?: string): string | null {
    const id = this.pageId();
    const n = this.stepsToPrevious(current);
    if (id === null || !n) return null;
    const url = this.urls.get(id - n);
    return url === undefined ? null : pathOf(url);
  }

  back(fallback: string): void {
    const n = this.stepsToPrevious();
    if (n > 0) this.location.historyGo(-n);
    else void this.router.navigateByUrl(fallback, { replaceUrl: true });
  }

  up(parent: string): void {
    const id = this.pageId();
    const target = pathOf(parent);
    if (id !== null) {
      for (let i = id - 1; i >= 0; i--) {
        const url = this.urls.get(i);
        if (url === undefined) break;
        if (pathOf(url) === target) {
          this.location.historyGo(i - id);
          return;
        }
      }
    }
    void this.router.navigateByUrl(parent, { replaceUrl: true });
  }

  private pageId(): number | null {
    const id = (this.location.getState() as { ɵrouterPageId?: unknown } | null)?.ɵrouterPageId;
    return typeof id === 'number' ? id : null;
  }
}
