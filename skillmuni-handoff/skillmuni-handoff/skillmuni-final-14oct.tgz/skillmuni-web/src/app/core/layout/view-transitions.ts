/** Errors a View Transition reports when skipped or timed out (e.g. from third-party code). Never toasted. */
export function isViewTransitionError(error: unknown): boolean {
  return (
    error instanceof DOMException &&
    (error.name === 'TimeoutError' ||
      error.name === 'AbortError' ||
      error.name === 'InvalidStateError') &&
    /transition/i.test(error.message)
  );
}
