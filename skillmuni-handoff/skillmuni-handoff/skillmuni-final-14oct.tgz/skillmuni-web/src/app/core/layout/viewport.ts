import { BreakpointObserver } from '@angular/cdk/layout';
import { Service, computed, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { map } from 'rxjs';

export type ViewportSize = 'mobile' | 'tablet' | 'desktop';

/** Breakpoints from the Figma Spacing & Layout page: mobile < 768 ≤ tablet < 1280 ≤ desktop. */
export const MEDIA = {
  tablet: '(min-width: 768px)',
  desktop: '(min-width: 1280px)',
  /** Laptop-short: less than ~800px of visible height (A-239). Rails go compact. */
  short: '(max-height: 799.98px)',
} as const;

/** Current breakpoint as a signal, for layout decisions that CSS alone can't make (component swaps). */
@Service()
export class Viewport {
  private readonly observer = inject(BreakpointObserver);

  readonly size = toSignal(
    this.observer
      .observe([MEDIA.tablet, MEDIA.desktop])
      .pipe(
        map((): ViewportSize =>
          this.observer.isMatched(MEDIA.desktop)
            ? 'desktop'
            : this.observer.isMatched(MEDIA.tablet)
              ? 'tablet'
              : 'mobile',
        ),
      ),
    { initialValue: 'desktop' as ViewportSize },
  );

  readonly isShort = toSignal(this.observer.observe(MEDIA.short).pipe(map((s) => s.matches)), {
    initialValue: false,
  });

  readonly isMobile = computed(() => this.size() === 'mobile');
  readonly isDesktop = computed(() => this.size() === 'desktop');
}
