import { screenOf } from './back-nav';

describe('screenOf', () => {
  it('folds sibling tab routes into one screen', () => {
    expect(screenOf('/hire-fest/bookings')).toBe('/hire-fest');
    expect(screenOf('/hire-fest/past?fest=f1')).toBe('/hire-fest');
    expect(screenOf('/jobs/applied')).toBe('/jobs');
  });

  it('keeps detail pages and other screens apart', () => {
    expect(screenOf('/hire-fest/fest/f1')).toBe('/hire-fest/fest/f1');
    expect(screenOf('/launchpad?x=1')).toBe('/launchpad');
  });
});
