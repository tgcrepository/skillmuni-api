import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

/* ---------- Module (subcategory) — Figma Brain Vita 67:1228 ---------- */

export interface TopicSummary {
  readonly slug: string;
  readonly title: string;
  readonly art: string;
  readonly quizzesDone: number;
  readonly quizzesTotal: number;
  readonly xp: number;
}

export interface ModuleDetail {
  readonly slug: string;
  readonly title: string;
  readonly tagline: string;
  readonly knook: { readonly slug: string; readonly title: string };
  readonly quizzesDone: number;
  readonly quizzesTotal: number;
  readonly xp: number;
  readonly topics: readonly TopicSummary[];
}

/* ---------- Topic (brief reader) — Figma 78:2520, states 79:3005 ---------- */

export type BriefStatus = 'done' | 'current' | 'locked';

export interface BriefMedia {
  readonly kind: 'image' | 'video';
  readonly src: string;
  readonly alt: string;
  readonly poster?: string;
  /** "4:12" for videos. */
  readonly duration?: string;
}

export interface Brief {
  readonly id: string;
  /** 1-based position in the topic. */
  readonly index: number;
  readonly title: string;
  readonly status: BriefStatus;
  readonly body: string;
  readonly example?: string;
  readonly keyTerm?: string;
  readonly videoUrl?: string;
  readonly media?: BriefMedia;
  readonly bookmarked: boolean;
  readonly helpful: boolean | null;
  /** XP the brief's quiz paid out (0 until passed). */
  readonly xp: number;
  readonly quiz: {
    readonly id: string;
    readonly questions: number;
    /** Last checked score, null until submitted. */
    readonly result: { readonly correct: number; readonly total: number } | null;
  };
}

export interface TopicDetail {
  readonly slug: string;
  readonly title: string;
  readonly module: { readonly slug: string; readonly title: string };
  readonly knook: { readonly title: string };
  readonly quizzesDone: number;
  readonly quizzesTotal: number;
  readonly xp: number;
  readonly briefs: readonly Brief[];
  /** "Next · Course" card — only where the qualification has courses. */
  readonly course: {
    readonly title: string;
    readonly unlocked: boolean;
    readonly link: string;
  } | null;
}

/* ---------- Quiz — Figma 132:2709 (QZ1–QZ5) ---------- */

export interface QuizOption {
  readonly id: string;
  readonly text: string;
}

export interface QuizQuestion {
  readonly id: string;
  readonly prompt: string;
  readonly options: readonly QuizOption[];
}

export interface Quiz {
  readonly id: string;
  readonly title: string;
  readonly module: { readonly slug: string; readonly title: string };
  readonly topic: { readonly slug: string; readonly title: string };
  readonly knook: { readonly title: string };
  readonly quizzesDone: number;
  readonly quizzesTotal: number;
  readonly xp: number;
  readonly questions: readonly QuizQuestion[];
  /** Autosaved picks from an earlier visit. */
  readonly draft: Readonly<Record<string, string>>;
  /** Already checked once: answering again is practice (no XP). */
  readonly alreadyPassed: boolean;
}

export interface QuestionResult {
  readonly questionId: string;
  readonly correctOptionId: string;
  readonly pickedOptionId: string;
  readonly correct: boolean;
  /** Why the right answer is right (always shown). */
  readonly explanation: string;
  /** One line on why the learner's pick was wrong (misses only). */
  readonly pickNote?: string;
}

export interface QuizResult {
  readonly correct: number;
  readonly total: number;
  /** +1 per correct answer, no bonus. */
  readonly xp: number;
  readonly results: readonly QuestionResult[];
  /** Muni's speech bubble. */
  readonly muni: string;
}

export interface LearnApi {
  module(slug: string): Observable<ModuleDetail>;
  topic(module: string, topic: string): Observable<TopicDetail>;
  bookmark(briefId: string, on: boolean): Observable<void>;
  feedback(briefId: string, helpful: boolean | null): Observable<void>;
  quiz(module: string, topic: string): Observable<Quiz>;
  saveDraft(quizId: string, answers: Readonly<Record<string, string>>): Observable<void>;
  submit(quizId: string, answers: Readonly<Record<string, string>>): Observable<QuizResult>;
}

@Service()
export class HttpLearnApi implements LearnApi {
  private readonly api = inject(ApiClient);

  module(slug: string): Observable<ModuleDetail> {
    return this.api.get(`learn/modules/${encodeURIComponent(slug)}`);
  }

  topic(module: string, topic: string): Observable<TopicDetail> {
    return this.api.get(
      `learn/modules/${encodeURIComponent(module)}/topics/${encodeURIComponent(topic)}`,
    );
  }

  bookmark(briefId: string, on: boolean): Observable<void> {
    return this.api.put(`learn/briefs/${encodeURIComponent(briefId)}/bookmark`, { on });
  }

  feedback(briefId: string, helpful: boolean | null): Observable<void> {
    return this.api.put(`learn/briefs/${encodeURIComponent(briefId)}/feedback`, { helpful });
  }

  quiz(module: string, topic: string): Observable<Quiz> {
    return this.api.get(
      `learn/modules/${encodeURIComponent(module)}/topics/${encodeURIComponent(topic)}/quiz`,
    );
  }

  saveDraft(quizId: string, answers: Readonly<Record<string, string>>): Observable<void> {
    return this.api.put(`learn/quizzes/${encodeURIComponent(quizId)}/draft`, { answers });
  }

  submit(quizId: string, answers: Readonly<Record<string, string>>): Observable<QuizResult> {
    return this.api.post(`learn/quizzes/${encodeURIComponent(quizId)}/submit`, { answers });
  }
}

export const LEARN_API = new InjectionToken<LearnApi>('LEARN_API', {
  factory: () => inject(HttpLearnApi),
});

/** Topic status for cards (Figma Topic Card: Mastered / N quiz left / not started). */
export function topicStatus(t: Pick<TopicSummary, 'quizzesDone' | 'quizzesTotal'>) {
  return t.quizzesDone >= t.quizzesTotal ? 'mastered' : t.quizzesDone > 0 ? 'in-progress' : 'new';
}
