import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

/** The four launch missions, in order (Figma Career Launchpad v2 · 241:18014, note 247:19784). */
export type MissionId = 'assessment' | 'profile' | 'apply' | 'fest';

export interface Mission {
  readonly id: MissionId;
  readonly label: string;
  readonly xp: number;
  readonly done: boolean;
}

export interface Readiness {
  /** 0–4, from the server (level rule "to confirm"). */
  readonly level: number;
  readonly levelName: string;
  /** Weighted: assessment 25 · profile 25 × profile % · applied 25 · fest 25. */
  readonly percent: number;
  readonly missions: readonly Mission[];
}

export interface ProfileCard {
  readonly percent: number;
  readonly sectionsLeft: number;
  readonly sectionsTotal: number;
  /** Quest steps still empty (skipped optional steps), A-262. */
  readonly stepsLeft: number;
  /** Names of sections still to do, e.g. Documents · Skills · Availability. */
  readonly missing: readonly string[];
}

export interface AssessmentCard {
  readonly status: 'not-started' | 'paused' | 'done';
  readonly answered: number;
  readonly total: number;
  readonly minutes: number;
  readonly archetype: {
    readonly name: string;
    readonly emoji: string;
    readonly traits: readonly string[];
  } | null;
  readonly mandatoryCourses: number;
}

export interface JobsCard {
  /** My Jobs unlocks at `unlockAt`% profile (rule "to confirm"). */
  readonly locked: boolean;
  readonly unlockAt: number;
  readonly matched: number;
  readonly applied: number;
  readonly saved: number;
  readonly newMatches: number;
  readonly interviews: number;
  readonly top: {
    readonly title: string;
    readonly employer: string;
    readonly city: string;
    readonly match: number;
  } | null;
}

export interface FestCard {
  readonly fest: {
    readonly id: string;
    readonly name: string;
    /** ISO date */
    readonly date: string;
    readonly daysAway: number;
    readonly recruiters: number;
    readonly free: boolean;
    readonly mode: string;
    readonly slotsLeft: number;
    readonly slotsTotal: number;
    /** "11:30 AM" once booked. */
    readonly bookedSlot: string | null;
  } | null;
  readonly alertsOn: boolean;
}

export interface Sector {
  readonly id: string;
  readonly name: string;
  /** Placeholder icon set (note: "sector icon set — emoji placeholders now"). */
  readonly emoji: string;
  readonly jobs: number;
  readonly newJobs: number;
  /** 0–100 match from the assessment; null before it's taken. */
  readonly fit: number | null;
}

export interface LaunchpadApi {
  readiness(): Observable<Readiness>;
  profile(): Observable<ProfileCard>;
  assessment(): Observable<AssessmentCard>;
  jobs(): Observable<JobsCard>;
  fest(): Observable<FestCard>;
  sectors(): Observable<readonly Sector[]>;
  setFestAlerts(on: boolean): Observable<FestCard>;
}

@Service()
export class HttpLaunchpadApi implements LaunchpadApi {
  private readonly api = inject(ApiClient);

  readiness(): Observable<Readiness> {
    return this.api.get('launchpad/readiness');
  }

  profile(): Observable<ProfileCard> {
    return this.api.get('launchpad/profile');
  }

  assessment(): Observable<AssessmentCard> {
    return this.api.get('launchpad/assessment');
  }

  jobs(): Observable<JobsCard> {
    return this.api.get('launchpad/jobs');
  }

  fest(): Observable<FestCard> {
    return this.api.get('launchpad/fest');
  }

  sectors(): Observable<readonly Sector[]> {
    return this.api.get('launchpad/sectors');
  }

  setFestAlerts(on: boolean): Observable<FestCard> {
    return this.api.put('launchpad/fest/alerts', { on });
  }
}

export const LAUNCHPAD_API = new InjectionToken<LaunchpadApi>('LAUNCHPAD_API', {
  factory: () => inject(HttpLaunchpadApi),
});
