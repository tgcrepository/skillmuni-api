import { clashes } from './slots';

describe('Hire Fest slot rules', () => {
  const cg = { employerId: 'cg', date: '2026-12-01', time: '10:30' };

  it('blocks the same time and anything within the 30-min gap', () => {
    for (const time of ['10:30', '10:00', '11:00', '11:29'])
      expect(clashes({ employerId: 'tp', date: '2026-12-01', time }, [cg], 30, 30)).toBe(true);
  });

  it('allows times a full gap away', () => {
    for (const time of ['09:30', '11:30', '12:00'])
      expect(clashes({ employerId: 'tp', date: '2026-12-01', time }, [cg], 30, 30)).toBe(false);
  });

  it('ignores other days and the same employer', () => {
    expect(clashes({ employerId: 'tp', date: '2026-12-02', time: '10:30' }, [cg], 30, 30)).toBe(
      false,
    );
    expect(clashes({ employerId: 'cg', date: '2026-12-01', time: '11:00' }, [cg], 30, 30)).toBe(
      false,
    );
  });
});
