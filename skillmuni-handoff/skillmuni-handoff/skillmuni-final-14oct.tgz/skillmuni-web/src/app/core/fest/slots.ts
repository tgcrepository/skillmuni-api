export interface SlotPick {
  readonly employerId: string;
  readonly date: string;
  readonly time: string;
}

export const toMinutes = (t: string): number => {
  const [h = 0, m = 0] = t.split(':').map(Number);
  return h * 60 + m;
};

/**
 * H4 rule (handoff 318:55923): a time is blocked when it overlaps another chosen interview on the
 * same day or starts within `buffer` minutes of it ending (and vice versa).
 */
export function clashes(
  candidate: SlotPick,
  picks: readonly SlotPick[],
  minutes: number,
  buffer: number,
): boolean {
  const start = toMinutes(candidate.time);
  return picks.some((p) => {
    if (p.employerId === candidate.employerId || p.date !== candidate.date) return false;
    const other = toMinutes(p.time);
    return start < other + minutes + buffer && other < start + minutes + buffer;
  });
}
