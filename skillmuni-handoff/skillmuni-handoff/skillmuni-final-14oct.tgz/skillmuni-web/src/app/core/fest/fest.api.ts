import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

/** Hire Fest v2 (Figma 315:44812, handoff 318:55923). */

export type FestMode = 'in-person' | 'online';

export interface FestEmployer {
  readonly id: string;
  readonly company: string;
  readonly initials: string;
  readonly role: string;
  readonly openings: number;
  readonly slotsLeft: number;
  /** "Day 1–3" for multi-day fests. */
  readonly days: string;
  readonly match: number;
  readonly full: boolean;
}

export interface Fest {
  readonly id: string;
  readonly name: string;
  readonly mode: FestMode;
  readonly city: string;
  /** ISO dates (first and last day). */
  readonly start: string;
  readonly end: string;
  /** "1 – 3 Dec 2026", "Wed, 14 Jan 2027". */
  readonly dateLabel: string;
  readonly hours: string;
  readonly venue: string;
  readonly venueNote: string;
  readonly distance: string | null;
  readonly organiser: string;
  readonly employers: readonly FestEmployer[];
  readonly employerCount: number;
  readonly roleCount: number;
  /** Display price: "Free", "₹199". */
  readonly price: string;
  readonly free: boolean;
  readonly seatsLeft: number;
  readonly matchingRoles: number;
  readonly bookingCloses: string;
  readonly cancelPolicy: string;
  readonly beforeYouGo: readonly string[];
  readonly booked: boolean;
  readonly waitlistOpen: boolean;
  readonly saved: boolean;
}

export interface FestDay {
  readonly date: string;
  readonly label: string;
  readonly fewLeft: boolean;
}

export interface Slot {
  /** "10:30" (24 h, fest local time). */
  readonly time: string;
  readonly label: string;
  readonly left: number;
}

export interface SlotGrid {
  readonly days: readonly FestDay[];
  /** employerId → date → slots. */
  readonly slots: Readonly<Record<string, Readonly<Record<string, readonly Slot[]>>>>;
  /** Interview length and the gap kept between two interviews (minutes). */
  readonly minutes: number;
  readonly buffer: number;
  readonly maxEmployers: number;
}

export interface BookedInterview {
  readonly employerId: string;
  readonly company: string;
  readonly initials: string;
  readonly role: string;
  readonly date: string;
  readonly dayLabel: string;
  readonly time: string;
  readonly range: string;
  readonly desk: string;
}

export interface Booking {
  readonly id: string;
  readonly code: string;
  readonly fest: Fest;
  readonly interviews: readonly BookedInterview[];
  readonly daysToGo: number;
  readonly reminders: Reminders;
  readonly cv: string;
  readonly live: LiveState | null;
}

export interface LiveState {
  readonly checkedInAt: string;
  readonly current: {
    readonly employerId: string;
    readonly position: number;
    readonly waitMinutes: number;
    readonly lateBy: number;
    readonly progress: number;
  };
}

export interface Reminders {
  readonly whatsapp: boolean;
  readonly sms: boolean;
  readonly calendar: boolean;
}

export type Outcome = 'offer' | 'waiting' | 'no' | null;

export interface PastFest {
  readonly id: string;
  readonly name: string;
  readonly date: string;
  readonly day: string;
  readonly month: string;
  readonly year: string;
  readonly interviews: readonly {
    readonly employerId: string;
    readonly company: string;
    readonly initials: string;
    readonly role: string;
    readonly outcome: Outcome;
  }[];
  readonly rating: number | null;
}

export interface FestSummary {
  readonly upcoming: number;
  readonly bookings: number;
  readonly past: number;
  readonly profilePercent: number;
  readonly unlockAt: number;
  readonly missing: readonly {
    readonly title: string;
    readonly detail: string;
    readonly xp: number;
    readonly link: string;
  }[];
  readonly city: string;
}

export interface WaitlistInfo {
  readonly position: number;
  readonly odds: string;
}

export interface FestAlerts {
  readonly city: boolean;
  readonly online: boolean;
}

export interface BookRequest {
  readonly picks: readonly {
    readonly employerId: string;
    readonly date: string;
    readonly time: string;
  }[];
  readonly reminders: Reminders;
  readonly cvTemplate: string;
}

export interface FestApi {
  summary(): Observable<FestSummary>;
  fests(filter: string): Observable<readonly Fest[]>;
  fest(id: string): Observable<Fest>;
  slots(id: string, employers: readonly string[]): Observable<SlotGrid>;
  book(id: string, body: BookRequest): Observable<Booking>;
  bookings(): Observable<readonly Booking[]>;
  booking(id: string): Observable<Booking>;
  cancel(id: string, employerId: string | null, reason: string): Observable<Booking | null>;
  waitlist(
    festId: string,
    employerId: string,
    auto: boolean,
    whatsapp: boolean,
  ): Observable<WaitlistInfo>;
  waitlistInfo(festId: string, employerId: string): Observable<WaitlistInfo>;
  past(): Observable<readonly PastFest[]>;
  outcome(festId: string, employerId: string, outcome: Outcome): Observable<PastFest>;
  rate(festId: string, stars: number): Observable<PastFest>;
  alerts(): Observable<FestAlerts>;
  setAlerts(a: FestAlerts): Observable<FestAlerts>;
  save(id: string, saved: boolean): Observable<Fest>;
}

@Service()
export class HttpFestApi implements FestApi {
  private readonly api = inject(ApiClient);

  summary(): Observable<FestSummary> {
    return this.api.get('fests/summary');
  }

  fests(filter: string): Observable<readonly Fest[]> {
    return this.api.get('fests', { params: { filter } });
  }

  fest(id: string): Observable<Fest> {
    return this.api.get(`fests/${id}`);
  }

  slots(id: string, employers: readonly string[]): Observable<SlotGrid> {
    return this.api.get(`fests/${id}/slots`, { params: { employers: employers.join(',') } });
  }

  book(id: string, body: BookRequest): Observable<Booking> {
    return this.api.post(`fests/${id}/book`, body);
  }

  bookings(): Observable<readonly Booking[]> {
    return this.api.get('fests/bookings');
  }

  booking(id: string): Observable<Booking> {
    return this.api.get(`fests/bookings/${id}`);
  }

  cancel(id: string, employerId: string | null, reason: string): Observable<Booking | null> {
    return this.api.post(`fests/bookings/${id}/cancel`, { employerId, reason });
  }

  waitlist(
    festId: string,
    employerId: string,
    auto: boolean,
    whatsapp: boolean,
  ): Observable<WaitlistInfo> {
    return this.api.post(`fests/${festId}/waitlist`, { employerId, auto, whatsapp });
  }

  waitlistInfo(festId: string, employerId: string): Observable<WaitlistInfo> {
    return this.api.get(`fests/${festId}/waitlist`, { params: { employerId } });
  }

  past(): Observable<readonly PastFest[]> {
    return this.api.get('fests/past');
  }

  outcome(festId: string, employerId: string, outcome: Outcome): Observable<PastFest> {
    return this.api.put(`fests/past/${festId}/outcome`, { employerId, outcome });
  }

  rate(festId: string, stars: number): Observable<PastFest> {
    return this.api.put(`fests/past/${festId}/rating`, { stars });
  }

  alerts(): Observable<FestAlerts> {
    return this.api.get('fests/alerts');
  }

  setAlerts(a: FestAlerts): Observable<FestAlerts> {
    return this.api.put('fests/alerts', a);
  }

  save(id: string, saved: boolean): Observable<Fest> {
    return this.api.put(`fests/${id}/saved`, { saved });
  }
}

export const FEST_API = new InjectionToken<FestApi>('FEST_API', {
  providedIn: 'root',
  factory: () => inject(HttpFestApi),
});
