import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { Session } from './session';
import { SessionExpiry } from './session-expiry';

describe('Session', () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => {
    vi.useRealTimers();
    document.querySelector('.cdk-overlay-container')?.replaceChildren();
  });

  it('expires after 30 idle minutes; activity pushes the deadline back', () => {
    const session = TestBed.inject(Session);
    session.start();
    vi.advanceTimersByTime(20 * 60_000);
    session.touch();
    vi.advanceTimersByTime(20 * 60_000);
    expect(session.status()).toBe('active');
    vi.advanceTimersByTime(11 * 60_000);
    expect(session.status()).toBe('expired');
  });

  it('SE1: shows a critical "logged out" prompt and sends the learner to log in', async () => {
    const router = TestBed.inject(Router);
    const nav = vi.spyOn(router, 'navigate').mockResolvedValue(true);
    TestBed.inject(SessionExpiry);
    const session = TestBed.inject(Session);
    session.start();
    session.resumeLabel.set('Big Brain Stuff');
    session.expire();
    TestBed.tick();

    const pane = document.querySelector('.sm-pane');
    expect(pane?.textContent).toContain('You’ve been logged out');
    expect(pane?.textContent).toContain('carry on from Big Brain Stuff');
    expect(pane?.querySelector('.close')).toBeNull();

    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    expect(document.querySelector('.sm-pane')).toBeTruthy();

    (pane?.querySelector('button[sm-button]') as HTMLButtonElement).click();
    await vi.advanceTimersByTimeAsync(1000);
    expect(nav).toHaveBeenCalledWith(['/login'], { queryParams: { returnUrl: '/' } });
  });
});
