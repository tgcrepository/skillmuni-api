import { Service, effect, inject, untracked } from '@angular/core';
import { Router } from '@angular/router';
import {
  MuniPrompt,
  MuniPromptData,
  MuniPromptResult,
} from '../../shared/ui/muni-prompt/muni-prompt';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { Session } from './session';

/** Where SE1 "Log in again" goes. The login slice (Phase 6a) owns this route. */
export const LOGIN_PATH = '/login';

/**
 * SE1 Session expired (203:9092 · 203:9398 · 203:9762). When the session ends, keep queued answers,
 * show a critical prompt (no close, no Esc, no scrim tap) and send the learner to log in,
 * returning them to where they were afterwards.
 */
@Service()
export class SessionExpiry {
  private readonly session = inject(Session);
  private readonly overlay = inject(OverlayService);
  private readonly router = inject(Router);
  private open = false;

  constructor() {
    effect(() => {
      if (this.session.status() === 'expired') untracked(() => this.prompt());
    });
  }

  private prompt(): void {
    if (this.open) return;
    this.open = true;
    const where = this.session.resumeLabel();
    // Quest names like "Who Dis?" already end in punctuation: no extra full stop.
    const punctuated = /[.!?]$/.test(where);
    const data: MuniPromptData = {
      title: $localize`:@@session.title:You’ve been logged out`,
      body: punctuated
        ? $localize`:@@session.bodyWherePunct:For your safety we log you out after 30 minutes away. Your answers are saved — log in to carry on from ${where}:where:`
        : where
          ? $localize`:@@session.bodyWhere:For your safety we log you out after 30 minutes away. Your answers are saved — log in to carry on from ${where}:where:.`
          : $localize`:@@session.body:For your safety we log you out after 30 minutes away. Your answers are saved — log in to carry on.`,
      primary: $localize`:@@session.login:Log in again`,
      dismissible: false,
    };
    const ref = this.overlay.adaptive<MuniPrompt, MuniPromptData, MuniPromptResult>(MuniPrompt, {
      data,
      critical: true,
      size: 'sm',
    });
    ref.closed.subscribe(() => {
      this.open = false;
      // Queued writes stay in sessionStorage and replay once the new session is active.
      void this.router.navigate([LOGIN_PATH], {
        queryParams: { returnUrl: this.session.returnUrl() },
      });
    });
  }
}
