import { DOCUMENT } from '@angular/common';
import { DestroyRef, Service, inject, signal } from '@angular/core';
import { environment } from '../../../environments/environment';

export type SessionStatus = 'signed-out' | 'active' | 'expired';

const MINUTE = 60_000;
/** Activity is recorded at most this often (keeps listeners cheap). */
const TOUCH_THROTTLE = 15_000;
const ACTIVITY_EVENTS = ['pointerdown', 'keydown', 'scroll', 'touchstart'] as const;

/**
 * Client view of the auth session. The server is the authority: a 401 also expires it
 * (apiErrorInterceptor). Idle expiry matches the SE1 copy, "after 30 minutes away".
 * Returning to a hidden tab past the limit expires immediately.
 */
@Service()
export class Session {
  private readonly doc = inject(DOCUMENT);
  private readonly idleMs = environment.sessionIdleMinutes * MINUTE;
  private timer: ReturnType<typeof setTimeout> | undefined;
  private lastActivity = 0;

  readonly status = signal<SessionStatus>('signed-out');
  /** Where the learner was, for SE1 "log in to carry on from {where}". Features set this. */
  readonly resumeLabel = signal('');
  /** URL to return to after logging in again. */
  readonly returnUrl = signal('/');

  constructor() {
    const onActivity = () => this.touch();
    const onVisible = () => {
      if (this.doc.visibilityState === 'visible') this.checkIdle();
    };
    for (const e of ACTIVITY_EVENTS) this.doc.addEventListener(e, onActivity, { passive: true });
    this.doc.addEventListener('visibilitychange', onVisible);
    inject(DestroyRef).onDestroy(() => {
      for (const e of ACTIVITY_EVENTS) this.doc.removeEventListener(e, onActivity);
      this.doc.removeEventListener('visibilitychange', onVisible);
      clearTimeout(this.timer);
    });
  }

  start(): void {
    this.status.set('active');
    this.lastActivity = 0;
    this.touch();
  }

  /** Record activity and push the idle deadline back. */
  touch(now = Date.now()): void {
    if (this.status() !== 'active' || now - this.lastActivity < TOUCH_THROTTLE) return;
    this.lastActivity = now;
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.checkIdle(), this.idleMs);
  }

  expire(): void {
    if (this.status() !== 'active') return;
    clearTimeout(this.timer);
    this.returnUrl.set(this.doc.location.pathname + this.doc.location.search);
    this.status.set('expired');
  }

  end(): void {
    clearTimeout(this.timer);
    this.status.set('signed-out');
  }

  private checkIdle(now = Date.now()): void {
    if (this.status() === 'active' && now - this.lastActivity >= this.idleMs) this.expire();
  }
}
