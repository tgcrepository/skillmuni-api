import { HttpErrorResponse } from '@angular/common/http';

export type ApiErrorKind =
  | 'offline'
  | 'unauthorized'
  | 'forbidden'
  | 'not-found'
  | 'conflict'
  | 'validation'
  | 'rate-limited'
  | 'server'
  | 'unknown';

/** Field-level messages from a 422 response: `{ errors: { phone: ['…'] } }`. */
export type FieldErrors = Readonly<Record<string, readonly string[]>>;

/** The only error type features see. Screens map `kind` to a state (error, offline, no-permission, validation). */
export class ApiError extends Error {
  constructor(
    readonly kind: ApiErrorKind,
    readonly status: number,
    message: string,
    readonly fieldErrors: FieldErrors = {},
  ) {
    super(message);
    this.name = 'ApiError';
  }

  /** Safe to retry automatically (idempotent requests only). */
  get transient(): boolean {
    return this.kind === 'offline' || this.kind === 'server' || this.kind === 'rate-limited';
  }
}

function kindFor(status: number, online: boolean): ApiErrorKind {
  if (status === 0) return online ? 'server' : 'offline';
  if (status === 401) return 'unauthorized';
  if (status === 403) return 'forbidden';
  if (status === 404) return 'not-found';
  if (status === 409) return 'conflict';
  if (status === 400 || status === 422) return 'validation';
  if (status === 429) return 'rate-limited';
  if (status >= 500) return 'server';
  return 'unknown';
}

export function toApiError(error: unknown, online: boolean): ApiError {
  if (error instanceof ApiError) return error;
  if (error instanceof HttpErrorResponse) {
    const body = (error.error ?? {}) as { message?: unknown; errors?: unknown };
    const fieldErrors =
      body.errors && typeof body.errors === 'object' ? (body.errors as FieldErrors) : {};
    const message = typeof body.message === 'string' ? body.message : error.message;
    return new ApiError(kindFor(error.status, online), error.status, message, fieldErrors);
  }
  return new ApiError(online ? 'unknown' : 'offline', 0, String(error));
}
