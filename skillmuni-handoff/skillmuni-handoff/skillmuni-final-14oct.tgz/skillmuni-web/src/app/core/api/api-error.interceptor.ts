import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { Connectivity } from '../network/connectivity';
import { Session } from '../session/session';
import { SKIP_SESSION_CHECK } from './api-client';
import { toApiError } from './api-error';

/** Normalises every HTTP failure to ApiError; a 401 on a normal request ends the session (SE1). */
export const apiErrorInterceptor: HttpInterceptorFn = (req, next) => {
  const connectivity = inject(Connectivity);
  const session = inject(Session);
  return next(req).pipe(
    catchError((err: unknown) => {
      const error = toApiError(err, connectivity.online());
      if (error.kind === 'unauthorized' && !req.context.get(SKIP_SESSION_CHECK)) session.expire();
      return throwError(() => error);
    }),
  );
};
