import { HttpClient, HttpContext, HttpContextToken, HttpParams } from '@angular/common/http';
import { Service, inject } from '@angular/core';
import { Observable, retry, timer } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiError } from './api-error';

/** Requests that must not trigger the session-expired flow (login, refresh). */
export const SKIP_SESSION_CHECK = new HttpContextToken<boolean>(() => false);

/** GETs retry twice on transient failures, backing off 400 ms then 1.2 s. */
const RETRY_COUNT = 2;
const RETRY_BASE_DELAY = 400;

export interface RequestOptions {
  readonly params?: Record<string, string | number | boolean>;
  readonly skipSessionCheck?: boolean;
}

/**
 * Thin typed wrapper around HttpClient. Feature clients (AuthApi, QuestApi…) are interfaces with an
 * Http implementation built on this and an MSW mock behind the same URLs. Errors arrive as ApiError
 * (see apiErrorInterceptor).
 */
@Service()
export class ApiClient {
  private readonly http = inject(HttpClient);
  private readonly base = environment.apiBaseUrl;

  get<T>(path: string, options: RequestOptions = {}): Observable<T> {
    return this.http.get<T>(this.url(path), this.opts(options)).pipe(
      retry({
        count: RETRY_COUNT,
        delay: (error: unknown, attempt) => {
          if (error instanceof ApiError && error.transient && error.kind !== 'offline') {
            return timer(RETRY_BASE_DELAY * 3 ** (attempt - 1));
          }
          throw error;
        },
      }),
    );
  }

  post<T>(path: string, body: unknown, options: RequestOptions = {}): Observable<T> {
    return this.http.post<T>(this.url(path), body, this.opts(options));
  }

  put<T>(path: string, body: unknown, options: RequestOptions = {}): Observable<T> {
    return this.http.put<T>(this.url(path), body, this.opts(options));
  }

  patch<T>(path: string, body: unknown, options: RequestOptions = {}): Observable<T> {
    return this.http.patch<T>(this.url(path), body, this.opts(options));
  }

  delete<T>(path: string, options: RequestOptions = {}): Observable<T> {
    return this.http.delete<T>(this.url(path), this.opts(options));
  }

  private url(path: string): string {
    return `${this.base}/${path.replace(/^\//, '')}`;
  }

  private opts(options: RequestOptions) {
    return {
      withCredentials: true,
      params: options.params ? new HttpParams({ fromObject: options.params }) : undefined,
      context: new HttpContext().set(SKIP_SESSION_CHECK, options.skipSessionCheck ?? false),
    };
  }
}
