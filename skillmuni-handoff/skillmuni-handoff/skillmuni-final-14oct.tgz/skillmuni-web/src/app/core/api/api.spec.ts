import { HttpErrorResponse, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { Session } from '../session/session';
import { ApiClient } from './api-client';
import { ApiError, toApiError } from './api-error';
import { apiErrorInterceptor } from './api-error.interceptor';

describe('API layer', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([apiErrorInterceptor])),
        provideHttpClientTesting(),
      ],
    }),
  );

  it('maps HTTP failures to ApiError kinds with field errors', () => {
    const e = toApiError(
      new HttpErrorResponse({
        status: 422,
        error: { message: 'Bad', errors: { phone: ['Too short'] } },
      }),
      true,
    );
    expect(e.kind).toBe('validation');
    expect(e.fieldErrors['phone']).toEqual(['Too short']);
    expect(toApiError(new HttpErrorResponse({ status: 0 }), false).kind).toBe('offline');
    expect(toApiError(new HttpErrorResponse({ status: 503 }), true).transient).toBe(true);
  });

  it('a 401 ends an active session; skipSessionCheck requests do not', async () => {
    const api = TestBed.inject(ApiClient);
    const http = TestBed.inject(HttpTestingController);
    const session = TestBed.inject(Session);
    session.start();

    const login = firstValueFrom(api.post('auth/login', {}, { skipSessionCheck: true }));
    http.expectOne('/api/auth/login').flush(null, { status: 401, statusText: 'Unauthorized' });
    await expect(login).rejects.toBeInstanceOf(ApiError);
    expect(session.status()).toBe('active');

    const me = firstValueFrom(api.post('quests/1', {}));
    http.expectOne('/api/quests/1').flush(null, { status: 401, statusText: 'Unauthorized' });
    await expect(me).rejects.toMatchObject({ kind: 'unauthorized' });
    expect(session.status()).toBe('expired');
  });

  it('GET retries transient server errors, not validation errors', async () => {
    vi.useFakeTimers();
    const api = TestBed.inject(ApiClient);
    const http = TestBed.inject(HttpTestingController);
    const result = firstValueFrom(api.get<{ ok: boolean }>('matches'));
    http.expectOne('/api/matches').flush(null, { status: 503, statusText: 'Down' });
    await vi.advanceTimersByTimeAsync(400);
    http.expectOne('/api/matches').flush({ ok: true });
    await expect(result).resolves.toEqual({ ok: true });

    const bad = firstValueFrom(api.get('matches'));
    http.expectOne('/api/matches').flush(null, { status: 422, statusText: 'Bad' });
    await expect(bad).rejects.toMatchObject({ kind: 'validation' });
    http.verify();
    vi.useRealTimers();
  });
});
