import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

/** Which greeting to show. The server decides from the learner's local time zone (A-170). */
export type Daypart = 'morning' | 'afternoon' | 'evening';

/** Colour family of a pathway card (Figma Pathway Card: Arcane · Ember · Success). */
export type PathwayTone = 'arcane' | 'ember' | 'success';

/** "Pick up where you left off" (Figma Home v2 · Continue learning 129:3784). */
export interface ResumeCard {
  /** e.g. "Brain Vita" */
  readonly module: string;
  /** e.g. "Non-Verbal Reasoning" */
  readonly topic: string;
  readonly brief: number;
  readonly briefs: number;
  /** e.g. "1 quiz away from 100% mastery" */
  readonly note: string;
  /** 0–100 */
  readonly percent: number;
  /** XP the next step earns. */
  readonly xp: number;
  readonly art: string;
  /** App route to continue. */
  readonly link: string;
}

export interface Pathway {
  readonly slug: string;
  readonly title: string;
  readonly blurb: string;
  readonly tone: PathwayTone;
  readonly art: string;
  /** App route, or null while that pathway isn't open yet. */
  readonly link: string | null;
}

/** One module tile inside a Knook (Figma Knook Tile 48:207). */
export interface KnookModule {
  readonly slug: string;
  readonly title: string;
  readonly art: string;
  readonly link: string;
}

/** A shelf of modules (Skill Knook, Industry Knook…). */
export interface Knook {
  readonly slug: string;
  readonly title: string;
  readonly icon: string;
  /** Open on first load (Figma: Skill and Industry open, the rest collapsed). */
  readonly expanded: boolean;
  readonly modules: readonly KnookModule[];
}

/** A first-time learner's next move on the Lobby (A-233). */
export interface FirstStep {
  readonly id: 'assessment' | 'learn' | 'jobs';
  readonly title: string;
  /** e.g. "36 quick this-or-that picks · ~12 min" */
  readonly meta: string;
  /** XP on offer, or null when the step earns none. */
  readonly xp: number | null;
  readonly link: string;
  readonly done: boolean;
}

/** Everything the Lobby needs in one call. */
export interface HomeFeed {
  readonly daypart: Daypart;
  readonly resume: ResumeCard | null;
  /** New learners only: three guided first moves. Null for a returning learner. */
  readonly firstSteps?: readonly FirstStep[] | null;
  /** A-266: bonus for finishing all first moves; `claimed` once the learner has collected it. */
  readonly firstMovesBonus?: { readonly xp: number; readonly claimed: boolean } | null;
  readonly pathways: readonly Pathway[];
  readonly knooks: readonly Knook[];
  /** Vouchers ready to redeem (badge on Rewards). */
  readonly rewardsReady: number;
  readonly unreadNotifications: number;
}

export interface HomeApi {
  feed(): Observable<HomeFeed>;
  /** A first move done by visiting it (e.g. opening My Jobs from the Lobby). */
  completeStep(id: FirstStep['id']): Observable<void>;
  /** Collect the first-moves bonus; returns the XP added. */
  claimFirstMoves(): Observable<{ readonly xp: number }>;
}

@Service()
export class HttpHomeApi implements HomeApi {
  private readonly api = inject(ApiClient);

  feed(): Observable<HomeFeed> {
    return this.api.get('home');
  }

  completeStep(id: FirstStep['id']): Observable<void> {
    return this.api.post(`home/first-steps/${id}`, {});
  }

  claimFirstMoves(): Observable<{ readonly xp: number }> {
    return this.api.post('home/first-moves/claim', {});
  }
}

export const HOME_API = new InjectionToken<HomeApi>('HOME_API', {
  factory: () => inject(HttpHomeApi),
});
