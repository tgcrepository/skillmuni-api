import { DOCUMENT } from '@angular/common';
import { Service, inject } from '@angular/core';
import { AudioPrefs } from './audio-prefs';

export type Cue = 'xp' | 'coin' | 'badge' | 'celebrate' | 'level' | 'tap';

/** Career assessment cues (A-300): a soft marimba per pick, a glassy coin drop, an island fanfare. */
export type AssessmentCue = 'drop' | 'skip' | 'undo' | 'tick' | 'island' | 'reveal';

interface Note {
  readonly f: number;
  readonly at: number;
  readonly len: number;
  readonly gain?: number;
  readonly type?: OscillatorType;
}

/**
 * Premium-feeling reward sounds, synthesised so there are no files to load (A-279): soft bell
 * tones (sine + a quiet octave partial), gentle attack, a short room reverb, kept quiet. Muted with
 * the header toggle; silent until the learner has interacted with the page.
 */
@Service()
export class SoundFx {
  private readonly doc = inject(DOCUMENT);
  private readonly prefs = inject(AudioPrefs);
  private ctx: AudioContext | null = null;
  private out: GainNode | null = null;
  private readonly lastAt = new Map<string, number>();

  play(cue: Cue): void {
    const ready = this.ready(cue);
    if (!ready) return;
    const [ctx, out, now] = ready;
    for (const n of CUES[cue]) this.bell(ctx, out, now + n.at, n);
    if (cue === 'celebrate' || cue === 'level') this.swoosh(ctx, out, now);
  }

  /**
   * A pick on the 4-notch seesaw: a warm marimba note, lower toward "This" and higher toward "That",
   * so the scale itself is audible (A-300).
   */
  pick(notch: 0 | 1 | 2 | 3): void {
    const ready = this.ready('pick');
    if (!ready) return;
    const [ctx, out, now] = ready;
    const f = [G5 * 0.75, G5, C6, E6][notch] ?? C6;
    this.marimba(ctx, out, now, f, 0.55);
    this.marimba(ctx, out, now + 0.045, f * 1.5, 0.18);
  }

  assessment(cue: AssessmentCue): void {
    const ready = this.ready(cue);
    if (!ready) return;
    const [ctx, out, now] = ready;
    switch (cue) {
      case 'drop':
        // A coin falling into glass: two bright plinks and a short settle.
        this.bell(ctx, out, now, { f: B6 * 1.5, at: 0, len: 0.16, gain: 0.32 });
        this.bell(ctx, out, now + 0.09, { f: E6 * 1.5, at: 0, len: 0.22, gain: 0.26 });
        this.bell(ctx, out, now + 0.17, { f: B6, at: 0, len: 0.5, gain: 0.2 });
        break;
      case 'skip':
        this.marimba(ctx, out, now, C5, 0.3);
        this.marimba(ctx, out, now + 0.09, C5 * 0.89, 0.22);
        break;
      case 'undo':
        this.marimba(ctx, out, now, E5 * 1.5, 0.32);
        this.marimba(ctx, out, now + 0.07, C5 * 1.5, 0.28);
        break;
      case 'tick':
        this.marimba(ctx, out, now, C6, 0.22);
        break;
      case 'island':
        // Warm pad chord under a rising chime run and a sparkle on top.
        this.pad(ctx, out, now, [C5, E5, G5, C6 * 1.125], 2.2, 0.16);
        [C6, E6, G6, C7].forEach((f, i) =>
          this.bell(ctx, out, now + 0.12 + i * 0.11, { f, at: 0, len: 0.7 + i * 0.15, gain: 0.42 }),
        );
        this.bell(ctx, out, now + 0.62, { f: E6 * 2, at: 0, len: 1.4, gain: 0.22 });
        this.swoosh(ctx, out, now);
        break;
      case 'reveal':
        this.pad(ctx, out, now, [C5 * 0.5, G5 * 0.5, E5, G5, C6], 3, 0.14);
        for (const n of CUES.celebrate) this.bell(ctx, out, now + 0.35 + n.at, n);
        this.swoosh(ctx, out, now + 0.25);
        break;
    }
  }

  /** Common gate: sound on, page interacted with, and the same cue not fired twice in 80 ms. */
  private ready(key: string): [AudioContext, GainNode, number] | null {
    if (!this.prefs.sounds() || !this.prefs.unlocked) return null;
    const ctx = this.context();
    if (!ctx || !this.out) return null;
    const now = ctx.currentTime;
    if (now - (this.lastAt.get(key) ?? -1) < 0.08) return null;
    this.lastAt.set(key, now);
    return [ctx, this.out, now];
  }

  /** Woody mallet: sine + a 4× overtone that dies fast, with a tiny pitch settle. */
  private marimba(ctx: AudioContext, out: AudioNode, t: number, f: number, peak: number): void {
    for (const [mult, level, len] of [
      [1, 1, 0.42],
      [3.98, 0.22, 0.07],
    ] as const) {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f * mult * 1.012, t);
      osc.frequency.exponentialRampToValueAtTime(f * mult, t + 0.03);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(peak * level, t + 0.005);
      g.gain.exponentialRampToValueAtTime(0.0001, t + len);
      osc.connect(g);
      g.connect(out);
      osc.start(t);
      osc.stop(t + len + 0.05);
    }
  }

  /** Soft, slightly detuned pad that blooms and fades. */
  private pad(
    ctx: AudioContext,
    out: AudioNode,
    t: number,
    notes: readonly number[],
    len: number,
    peak: number,
  ): void {
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(900, t);
    lp.frequency.exponentialRampToValueAtTime(2600, t + len * 0.4);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + 0.25);
    g.gain.exponentialRampToValueAtTime(0.0001, t + len);
    lp.connect(g);
    g.connect(out);
    for (const f of notes) {
      for (const detune of [-7, 7]) {
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, t);
        osc.detune.setValueAtTime(detune, t);
        osc.connect(lp);
        osc.start(t);
        osc.stop(t + len + 0.1);
      }
    }
  }

  private context(): AudioContext | null {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return this.ctx;
    }
    const win = this.doc.defaultView as unknown as {
      AudioContext?: typeof AudioContext;
      webkitAudioContext?: typeof AudioContext;
    } | null;
    const Ctor = win?.AudioContext ?? win?.webkitAudioContext;
    if (!Ctor) return null;
    const ctx = new Ctor();
    const master = ctx.createGain();
    master.gain.value = 0.22;
    // Short, airy room: a generated impulse response, mixed low under the dry signal.
    const verb = ctx.createConvolver();
    verb.buffer = impulse(ctx, 1.1);
    const wet = ctx.createGain();
    wet.gain.value = 0.28;
    const tone = ctx.createBiquadFilter();
    tone.type = 'lowpass';
    tone.frequency.value = 7200;
    master.connect(tone);
    tone.connect(ctx.destination);
    tone.connect(verb);
    verb.connect(wet);
    wet.connect(ctx.destination);
    this.ctx = ctx;
    this.out = master;
    return ctx;
  }

  private bell(ctx: AudioContext, out: AudioNode, t: number, n: Note): void {
    const peak = n.gain ?? 0.6;
    for (const [mult, level] of [
      [1, 1],
      [2, 0.18],
      [3.01, 0.06],
    ] as const) {
      const osc = ctx.createOscillator();
      osc.type = n.type ?? 'sine';
      osc.frequency.setValueAtTime(n.f * mult, t);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(peak * level, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + n.len);
      osc.connect(g);
      g.connect(out);
      osc.start(t);
      osc.stop(t + n.len + 0.05);
    }
  }

  /** A soft, filtered air sweep under big moments. */
  private swoosh(ctx: AudioContext, out: AudioNode, t: number): void {
    const len = 0.6;
    const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * len), ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 0.8;
    bp.frequency.setValueAtTime(600, t);
    bp.frequency.exponentialRampToValueAtTime(5200, t + len);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.12, t + 0.15);
    g.gain.exponentialRampToValueAtTime(0.0001, t + len);
    src.connect(bp);
    bp.connect(g);
    g.connect(out);
    src.start(t);
  }
}

// Pentatonic-ish, bright but soft. Frequencies in Hz.
const E6 = 1318.5;
const B6 = 1975.5;
const G5 = 784;
const C6 = 1046.5;
const E5 = 659.3;
const C5 = 523.3;
const G6 = 1568;
const C7 = 2093;

const CUES: Record<Cue, readonly Note[]> = {
  // A two-note sparkle, like a coin of light.
  xp: [
    { f: E6, at: 0, len: 0.28, gain: 0.5 },
    { f: B6, at: 0.07, len: 0.45, gain: 0.42 },
  ],
  coin: [
    { f: B6, at: 0, len: 0.18, gain: 0.45 },
    { f: E6 * 2, at: 0.06, len: 0.4, gain: 0.3 },
  ],
  // Rising major arpeggio, last note rings.
  badge: [
    { f: C5, at: 0, len: 0.5 },
    { f: E5, at: 0.09, len: 0.5 },
    { f: G5, at: 0.18, len: 0.55 },
    { f: C6, at: 0.27, len: 1.1, gain: 0.7 },
  ],
  celebrate: [
    { f: G5, at: 0, len: 0.4 },
    { f: C6, at: 0.08, len: 0.45 },
    { f: E6, at: 0.16, len: 0.5 },
    { f: G6, at: 0.24, len: 0.6 },
    { f: C7, at: 0.34, len: 1.2, gain: 0.5 },
    { f: E6, at: 0.34, len: 1.0, gain: 0.3 },
  ],
  level: [
    { f: C5, at: 0, len: 0.35 },
    { f: G5, at: 0.1, len: 0.4 },
    { f: C6, at: 0.2, len: 0.45 },
    { f: E6, at: 0.3, len: 0.5 },
    { f: G6, at: 0.42, len: 1.3, gain: 0.55 },
  ],
  tap: [{ f: C6, at: 0, len: 0.12, gain: 0.25 }],
};

function impulse(ctx: AudioContext, seconds: number): AudioBuffer {
  const len = Math.floor(ctx.sampleRate * seconds);
  const buf = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
  }
  return buf;
}
