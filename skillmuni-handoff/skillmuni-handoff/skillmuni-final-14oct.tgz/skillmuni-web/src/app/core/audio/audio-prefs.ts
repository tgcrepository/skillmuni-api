import { DOCUMENT } from '@angular/common';
import { Service, effect, inject, signal } from '@angular/core';

const KEY = 'sm_audio';

/**
 * Sound effects on/off (A-279; Muni's voice removed, corrections #2). Remembered on this device. Both stay
 * silent until the learner has interacted with the page (browsers block audio before that), and
 * Settings turns them off at any time (WCAG 1.4.2).
 */
@Service()
export class AudioPrefs {
  private readonly doc = inject(DOCUMENT);
  readonly sounds = signal(true);

  constructor() {
    try {
      const saved = JSON.parse(this.doc.defaultView?.localStorage.getItem(KEY) ?? 'null') as {
        sounds?: boolean;
      } | null;
      if (saved) this.sounds.set(saved.sounds !== false);
    } catch {
      /* storage blocked: defaults */
    }
    effect(() => {
      const value = JSON.stringify({ sounds: this.sounds() });
      try {
        this.doc.defaultView?.localStorage.setItem(KEY, value);
      } catch {
        /* storage blocked */
      }
    });
  }

  /** True once the learner has clicked, tapped or typed on the page. */
  get unlocked(): boolean {
    const nav = this.doc.defaultView?.navigator as (Navigator & {
      userActivation?: { hasBeenActive: boolean };
    }) | undefined;
    return nav?.userActivation?.hasBeenActive ?? true;
  }
}
