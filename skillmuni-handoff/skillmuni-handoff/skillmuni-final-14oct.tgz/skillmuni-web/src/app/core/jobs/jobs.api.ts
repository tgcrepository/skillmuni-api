import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

/** My Jobs v2 tabs, in their fixed order (Figma 272:22353, handoff 282:26513). */
export type JobsTab = 'available' | 'matching' | 'invitations' | 'bookmarked' | 'applied';

export type WorkMode = 'onsite' | 'hybrid' | 'remote';
export type JobType = 'full-time' | 'part-time' | 'learnership' | 'contract';

export interface MatchInfo {
  readonly percent: number;
  /** "Matches: Communication, English, Customer service". */
  readonly skills: readonly string[];
  readonly reasons: readonly { readonly ok: boolean; readonly text: string }[];
  readonly gap: { readonly label: string; readonly link: string } | null;
}

export interface Job {
  readonly id: string;
  readonly title: string;
  readonly company: string;
  readonly initials: string;
  readonly city: string;
  readonly state: string;
  /** "Pune, Maharashtra" or "Remote · India". */
  readonly place: string;
  readonly sector: string;
  readonly role: string;
  readonly workMode: WorkMode;
  readonly jobType: JobType;
  /** "Contract · 6 months", "Learnership". Display label from the server. */
  readonly jobTypeLabel: string;
  /** Display pay: "₹2.4–3.0 LPA", "₹15,000 / month stipend" (format per country, A-221). */
  readonly pay: string;
  readonly postedDays: number;
  readonly applicants: number;
  readonly applyBy: string;
  /** Days until applications close; null when not closing soon. */
  readonly closingInDays: number | null;
  readonly closed: boolean;
  readonly isNew: boolean;
  readonly saved: boolean;
  readonly savedDays: number | null;
  readonly appliedOn: string | null;
  readonly experience: string;
  readonly openings: number;
  readonly shift: string;
  readonly about: string;
  readonly duties: readonly string[];
  readonly requirements: readonly string[];
  readonly skills: readonly string[];
  readonly companyAbout: string;
  readonly match: MatchInfo | null;
}

export type InvitationStatus = 'new' | 'accepted' | 'declined' | 'expired';

export interface Invitation {
  readonly id: string;
  readonly job: Job;
  readonly recruiter: { readonly name: string; readonly initials: string; readonly title: string };
  readonly type: 'apply' | 'interview';
  /** ISO; set for interview invites. */
  readonly interviewAt: string | null;
  readonly message: string;
  readonly respondBy: string;
  readonly daysLeft: number;
  readonly status: InvitationStatus;
}

export type ApplicationStatus =
  'applied' | 'viewed' | 'shortlisted' | 'interview' | 'offer' | 'not-selected' | 'withdrawn';

export interface TimelineStep {
  readonly label: string;
  readonly date: string | null;
  readonly state: 'done' | 'current' | 'todo' | 'failed';
}

export interface Application {
  readonly id: string;
  readonly job: Job;
  readonly appliedOn: string;
  readonly updated: string;
  readonly cv: string;
  readonly status: ApplicationStatus;
  readonly timeline: readonly TimelineStep[];
  readonly interview: {
    readonly at: string;
    readonly mode: string;
    readonly detail: string;
  } | null;
  readonly answers: readonly { readonly q: string; readonly a: string }[];
  readonly similar: number;
}

export interface JobsSummary {
  readonly available: number;
  readonly matching: number;
  readonly invitations: number;
  readonly invitationsNew: number;
  readonly bookmarked: number;
  readonly applied: number;
  /** Matching Jobs unlock at `unlockAt`% profile (J8). */
  readonly profilePercent: number;
  readonly unlockAt: number;
  readonly missing: readonly string[];
  readonly minutesToUnlock: number;
  readonly defaultPlace: string;
}

/** Filter values per key; every value is a list of option ids (single values use one). */
export type FilterState = Readonly<Record<string, readonly string[]>>;

export interface FacetOption {
  readonly id: string;
  readonly label: string;
  readonly count: number;
}

export interface Facet {
  readonly key: string;
  readonly options: readonly FacetOption[];
}

export interface ListQuery {
  readonly q: string;
  readonly place: string;
  readonly filters: FilterState;
  readonly sort: string;
  readonly limit: number;
}

export interface Suggestion {
  readonly key: string;
  readonly id: string;
  readonly label: string;
  readonly count: number;
}

export interface ListResult<T> {
  readonly items: readonly T[];
  readonly total: number;
  readonly facets: readonly Facet[];
  /** J6: filters to remove and the jobs each would bring back. */
  readonly suggestions: readonly Suggestion[];
  /** "1 closing soon", "1 interview coming up". */
  readonly note: string | null;
}

export interface ApplyInfo {
  readonly name: string;
  readonly contact: string;
  readonly cvs: readonly { readonly id: string; readonly name: string; readonly meta: string }[];
  readonly questions: readonly {
    readonly id: string;
    readonly text: string;
    readonly kind: 'yes-no' | 'text';
  }[];
}

export interface ApplyRequest {
  readonly cvId: string;
  readonly answers: Readonly<Record<string, string>>;
  readonly invitationId?: string;
}

export interface AlertSettings {
  readonly on: boolean;
  readonly frequency: 'daily' | 'weekly';
  readonly searches: readonly string[];
}

export interface JobsApi {
  summary(): Observable<JobsSummary>;
  jobs(tab: 'available' | 'matching' | 'bookmarked', q: ListQuery): Observable<ListResult<Job>>;
  invitations(q: ListQuery): Observable<ListResult<Invitation>>;
  applications(q: ListQuery): Observable<ListResult<Application>>;
  job(id: string): Observable<Job>;
  invitation(id: string): Observable<Invitation>;
  application(id: string): Observable<Application>;
  save(id: string, saved: boolean): Observable<Job>;
  applyInfo(id: string): Observable<ApplyInfo>;
  uploadCv(file: File): Observable<{ id: string; name: string; meta: string }>;
  apply(id: string, body: ApplyRequest): Observable<Application>;
  respond(
    id: string,
    action: 'accept' | 'decline' | 'suggest',
    note?: string,
  ): Observable<Invitation>;
  withdraw(id: string): Observable<Application>;
  alerts(): Observable<AlertSettings>;
  setAlerts(body: AlertSettings): Observable<AlertSettings>;
}

const toParams = (q: ListQuery): Record<string, string | number> => ({
  q: q.q,
  place: q.place,
  sort: q.sort,
  limit: q.limit,
  filters: JSON.stringify(q.filters),
});

@Service()
export class HttpJobsApi implements JobsApi {
  private readonly api = inject(ApiClient);

  summary(): Observable<JobsSummary> {
    return this.api.get('jobs/summary');
  }

  jobs(tab: 'available' | 'matching' | 'bookmarked', q: ListQuery): Observable<ListResult<Job>> {
    return this.api.get(`jobs/list/${tab}`, { params: toParams(q) });
  }

  invitations(q: ListQuery): Observable<ListResult<Invitation>> {
    return this.api.get('jobs/invitations', { params: toParams(q) });
  }

  applications(q: ListQuery): Observable<ListResult<Application>> {
    return this.api.get('jobs/applications', { params: toParams(q) });
  }

  job(id: string): Observable<Job> {
    return this.api.get(`jobs/job/${id}`);
  }

  invitation(id: string): Observable<Invitation> {
    return this.api.get(`jobs/invitations/${id}`);
  }

  application(id: string): Observable<Application> {
    return this.api.get(`jobs/applications/${id}`);
  }

  save(id: string, saved: boolean): Observable<Job> {
    return this.api.put(`jobs/job/${id}/saved`, { saved });
  }

  applyInfo(id: string): Observable<ApplyInfo> {
    return this.api.get(`jobs/job/${id}/apply`);
  }

  uploadCv(file: File): Observable<{ id: string; name: string; meta: string }> {
    const body = new FormData();
    body.append('file', file);
    return this.api.post('jobs/cv', body);
  }

  apply(id: string, body: ApplyRequest): Observable<Application> {
    return this.api.post(`jobs/job/${id}/apply`, body);
  }

  respond(
    id: string,
    action: 'accept' | 'decline' | 'suggest',
    note?: string,
  ): Observable<Invitation> {
    return this.api.post(`jobs/invitations/${id}/${action}`, { note: note ?? '' });
  }

  withdraw(id: string): Observable<Application> {
    return this.api.post(`jobs/applications/${id}/withdraw`, {});
  }

  alerts(): Observable<AlertSettings> {
    return this.api.get('jobs/alerts');
  }

  setAlerts(body: AlertSettings): Observable<AlertSettings> {
    return this.api.put('jobs/alerts', body);
  }
}

export const JOBS_API = new InjectionToken<JobsApi>('JOBS_API', {
  providedIn: 'root',
  factory: () => inject(HttpJobsApi),
});
