import { Service, computed, signal } from '@angular/core';
import { FilterState, JobsTab } from './jobs.api';

export type FilterKind = 'multi' | 'single' | 'location';

export interface FilterDef {
  readonly key: string;
  readonly label: string;
  readonly kind: FilterKind;
  /** Search box inside the quick filter (long lists like Sector). */
  readonly searchable?: boolean;
  /** Options show 3 until "Show all". */
  readonly collapsed?: boolean;
}

export interface TabConfig {
  readonly filters: readonly FilterDef[];
  /** How many filters show as quick chips on mobile (desktop shows them all). */
  readonly mobileQuick: number;
  readonly sorts: readonly { readonly id: string; readonly label: string }[];
  readonly search: string;
  readonly searchMobile: string;
  /** Available and Matching also search by place. */
  readonly place: boolean;
}

const sector: FilterDef = {
  key: 'sector',
  label: $localize`:@@jobs.f.sector:Sector`,
  kind: 'multi',
  searchable: true,
  collapsed: true,
};
const role: FilterDef = { key: 'role', label: $localize`:@@jobs.f.role:Role`, kind: 'multi' };
const loc: FilterDef = {
  key: 'location',
  label: $localize`:@@jobs.f.location:Location`,
  kind: 'location',
};
const workMode: FilterDef = {
  key: 'workMode',
  label: $localize`:@@jobs.f.workMode:Work mode`,
  kind: 'multi',
};
const jobType: FilterDef = {
  key: 'jobType',
  label: $localize`:@@jobs.f.jobType:Job type`,
  kind: 'multi',
};
const company: FilterDef = {
  key: 'company',
  label: $localize`:@@jobs.f.company:Company`,
  kind: 'multi',
};
const status: FilterDef = {
  key: 'status',
  label: $localize`:@@jobs.f.status:Status`,
  kind: 'multi',
};

/** Handoff 282:26513 "Filters and sort per tab". */
export const TABS: Readonly<Record<JobsTab, TabConfig>> = {
  available: {
    filters: [
      sector,
      role,
      loc,
      workMode,
      jobType,
      { key: 'pay', label: $localize`:@@jobs.f.salary:Salary`, kind: 'single' },
      { key: 'posted', label: $localize`:@@jobs.f.posted:Date posted`, kind: 'single' },
    ],
    mobileQuick: 3,
    sorts: [
      { id: 'relevant', label: $localize`:@@jobs.s.relevant:Most relevant` },
      { id: 'newest', label: $localize`:@@jobs.s.newest:Newest` },
      { id: 'salary', label: $localize`:@@jobs.s.salary:Salary` },
    ],
    search: $localize`:@@jobs.searchJobs:Search job title, company or skill`,
    searchMobile: $localize`:@@jobs.searchMobile:Search jobs or skills`,
    place: true,
  },
  matching: {
    filters: [
      { key: 'match', label: $localize`:@@jobs.f.match:Match`, kind: 'single' },
      sector,
      loc,
      workMode,
      jobType,
    ],
    mobileQuick: 3,
    sorts: [
      { id: 'match', label: $localize`:@@jobs.s.match:Best match` },
      { id: 'newest', label: $localize`:@@jobs.s.newest:Newest` },
    ],
    search: $localize`:@@jobs.searchJobs:Search job title, company or skill`,
    searchMobile: $localize`:@@jobs.searchMobile:Search jobs or skills`,
    place: true,
  },
  invitations: {
    filters: [
      status,
      { key: 'inviteType', label: $localize`:@@jobs.f.inviteType:Invite type`, kind: 'multi' },
      company,
    ],
    mobileQuick: 3,
    sorts: [
      { id: 'respond', label: $localize`:@@jobs.s.respond:Respond by` },
      { id: 'newest', label: $localize`:@@jobs.s.newest:Newest` },
    ],
    search: $localize`:@@jobs.searchInvites:Search job invitations`,
    searchMobile: $localize`:@@jobs.searchInvites:Search job invitations`,
    place: false,
  },
  bookmarked: {
    filters: [
      { key: 'jobStatus', label: $localize`:@@jobs.f.jobStatus:Job status`, kind: 'multi' },
      sector,
      workMode,
    ],
    mobileQuick: 3,
    sorts: [
      { id: 'saved', label: $localize`:@@jobs.s.saved:Recently saved` },
      { id: 'closing', label: $localize`:@@jobs.s.closing:Closing soon` },
    ],
    search: $localize`:@@jobs.searchSaved:Search bookmarked jobs`,
    searchMobile: $localize`:@@jobs.searchSaved:Search bookmarked jobs`,
    place: false,
  },
  applied: {
    filters: [
      status,
      { key: 'dateApplied', label: $localize`:@@jobs.f.dateApplied:Date applied`, kind: 'single' },
      sector,
      company,
    ],
    mobileQuick: 3,
    sorts: [
      { id: 'updated', label: $localize`:@@jobs.s.updated:Recently updated` },
      { id: 'newest', label: $localize`:@@jobs.s.appliedDate:Date applied` },
    ],
    search: $localize`:@@jobs.searchApplied:Search applied jobs`,
    searchMobile: $localize`:@@jobs.searchApplied:Search applied jobs`,
    place: false,
  },
};

/** Location is one chip over three server keys. */
export const LOCATION_KEYS = ['state', 'city', 'remote'] as const;

export function keysOf(def: FilterDef): readonly string[] {
  return def.kind === 'location' ? LOCATION_KEYS : [def.key];
}

export function countActive(f: FilterState, def: FilterDef): number {
  return keysOf(def).reduce((n, k) => n + (k === 'state' ? 0 : (f[k]?.length ?? 0)), 0);
}

export interface TabQuery {
  readonly q: string;
  readonly place: string;
  readonly filters: FilterState;
  readonly sort: string;
}

const KEY = 'sm_jobs_filters';

/** Search, filters and sort remembered per tab for the session (handoff: "remembered per tab"). */
@Service()
export class JobsFilterStore {
  private readonly state = signal<Partial<Record<JobsTab, TabQuery>>>(this.read());

  query(tab: JobsTab, defaultPlace = ''): TabQuery {
    return (
      this.state()[tab] ?? {
        q: '',
        place: tab === 'available' ? defaultPlace : '',
        filters: {},
        sort: TABS[tab].sorts[0]?.id ?? '',
      }
    );
  }

  readonly version = computed(() => this.state());

  set(tab: JobsTab, next: TabQuery): void {
    this.state.update((s) => ({ ...s, [tab]: next }));
    try {
      sessionStorage.setItem(KEY, JSON.stringify(this.state()));
    } catch {
      /* private mode */
    }
  }

  private read(): Partial<Record<JobsTab, TabQuery>> {
    try {
      return JSON.parse(sessionStorage.getItem(KEY) ?? '{}') as Partial<Record<JobsTab, TabQuery>>;
    } catch {
      return {};
    }
  }
}

/** Career Launchpad sector ids → My Jobs sector names (mock catalogues differ; one id list in the real API). */
export const SECTOR_ALIASES: Readonly<Record<string, string>> = {
  bpo: 'BPO / Contact centre',
  insurance: 'Insurance',
  it: 'IT & Tech support',
  hospitality: 'Hospitality',
  retail: 'Retail',
  fashion: 'Retail',
  banking: 'Banking & Finance',
  healthcare: 'Healthcare',
  pharma: 'Healthcare',
  telecom: 'Telecom',
  marketing: 'Media & Marketing',
  manufacturing: 'Manufacturing',
  engineering: 'Manufacturing',
};
