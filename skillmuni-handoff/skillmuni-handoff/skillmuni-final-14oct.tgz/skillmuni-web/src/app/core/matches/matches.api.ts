import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

export type MatchKind = 'job' | 'learnership' | 'internship' | 'apprenticeship' | 'course';
/** Why it's on your list (Figma M1 filter chips). */
export type MatchStatus =
  'invited' | 'shortlisted' | 'recommended' | 'saved' | 'applied' | 'accepted';
/** Evidence behind a skill (A-108: Assessed / Verified count 1.0, Declared 0.8). */
export type Evidence = 'assessed' | 'verified' | 'declared' | 'level';

export interface MatchSkill {
  readonly name: string;
  readonly evidence: Evidence;
  /** e.g. "C2 / C1" for languages. */
  readonly note?: string;
}

export interface MatchJob {
  readonly id: string;
  readonly title: string;
  readonly employer: string;
  readonly kind: MatchKind;
  readonly location: string;
  readonly distanceKm: number | null;
  /** 0–100 */
  readonly match: number;
  readonly pay: string;
  readonly status: MatchStatus;
  /** ISO date-time of the interview slot when invited. */
  readonly interviewAt: string | null;
  readonly skills: readonly MatchSkill[];
  /** Power-up or gap, e.g. "Add Call centre systems proof → +3%". */
  readonly tip: string;
  readonly tipKind: 'boost' | 'gap';
  readonly industry: string;
}

export interface IndustryFit {
  readonly id: string;
  readonly name: string;
  readonly fit: number;
  readonly why: string;
  readonly roles: string;
  /** Next step to get in, e.g. "Short course: Retail NQF 2 (8 weeks)". */
  readonly path: string;
  /** The learner already holds this path. */
  readonly pathDone: boolean;
  readonly jobs: number;
}

export interface MatchBoard {
  readonly total: number;
  readonly shortlisted: number;
  readonly invites: number;
  readonly profileComplete: number;
  readonly visible: boolean;
  readonly jobs: readonly MatchJob[];
  readonly industries: readonly IndustryFit[];
  /** Career Compass summary, e.g. "Top interests: Social, Enterprising…". */
  readonly compass: { readonly takenOn: string; readonly summary: string } | null;
}

export interface MatchPreview {
  readonly count: number;
  readonly radiusKm: number;
  readonly top: readonly Pick<MatchJob, 'id' | 'title' | 'kind' | 'match'>[];
}

export interface VisibilitySettings {
  /** Employers on Skillmuni can find me (needed for matches). */
  readonly discoverable: boolean;
  /** Employers can invite me by email and WhatsApp. */
  readonly invites: boolean;
}

/** Matches and profile publishing (Figma Q8 Vibe Check 200:35577, My Matches §12). */
export interface MatchesApi {
  preview(): Observable<MatchPreview>;
  publish(settings: VisibilitySettings): Observable<void>;
  board(): Observable<MatchBoard>;
  apply(id: string): Observable<void>;
  save(id: string, saved: boolean): Observable<void>;
  acceptInvite(id: string): Observable<void>;
}

@Service()
export class HttpMatchesApi implements MatchesApi {
  private readonly api = inject(ApiClient);

  preview(): Observable<MatchPreview> {
    return this.api.get('me/matches/preview');
  }

  publish(settings: VisibilitySettings): Observable<void> {
    return this.api.post('me/profile/publish', settings);
  }

  board(): Observable<MatchBoard> {
    return this.api.get('me/matches');
  }

  save(id: string, saved: boolean): Observable<void> {
    return this.api.post(`me/matches/${id}/save`, { saved });
  }

  apply(id: string): Observable<void> {
    return this.api.post(`me/matches/${id}/apply`, {});
  }

  acceptInvite(id: string): Observable<void> {
    return this.api.post(`me/matches/${id}/accept`, {});
  }
}

export const MATCHES_API = new InjectionToken<MatchesApi>('MATCHES_API', {
  factory: () => inject(HttpMatchesApi),
});
