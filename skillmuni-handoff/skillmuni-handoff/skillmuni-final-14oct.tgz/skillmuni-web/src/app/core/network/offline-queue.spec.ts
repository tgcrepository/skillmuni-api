import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { apiErrorInterceptor } from '../api/api-error.interceptor';
import { Connectivity } from './connectivity';
import { OfflineQueue, QueuedWrite } from './offline-queue';

const write = (key: string, body: unknown): QueuedWrite => ({
  key,
  method: 'PUT',
  path: `drafts/${key}`,
  body,
});

describe('OfflineQueue (OF1)', () => {
  const online = signal(true);

  beforeEach(() => {
    sessionStorage.clear();
    online.set(true);
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([apiErrorInterceptor])),
        provideHttpClientTesting(),
        { provide: Connectivity, useValue: { online } },
      ],
    });
  });

  it('sends immediately when online', async () => {
    const queue = TestBed.inject(OfflineQueue);
    const http = TestBed.inject(HttpTestingController);
    const result = queue.save(write('a', 1));
    http.expectOne('/api/drafts/a').flush(null);
    await expect(result).resolves.toBe('saved');
  });

  it('queues while offline (latest write per key wins) and replays in order when back', async () => {
    const queue = TestBed.inject(OfflineQueue);
    const http = TestBed.inject(HttpTestingController);
    online.set(false);
    await expect(queue.save(write('a', 1))).resolves.toBe('queued');
    await queue.save(write('b', 2));
    await queue.save(write('a', 3));
    expect(queue.pending().map((w) => [w.key, w.body])).toEqual([
      ['b', 2],
      ['a', 3],
    ]);
    expect(sessionStorage.getItem('sm.offline-queue')).toContain('"b"');

    online.set(true);
    TestBed.tick();
    http.expectOne('/api/drafts/b').flush(null);
    await Promise.resolve();
    await Promise.resolve();
    http.expectOne('/api/drafts/a').flush(null);
    await vi.waitFor(() => expect(queue.pending()).toEqual([]));
    expect(queue.flushed()).toBe(1);
    expect(sessionStorage.getItem('sm.offline-queue')).toBeNull();
  });

  it('does not queue validation errors — the caller shows them', async () => {
    const queue = TestBed.inject(OfflineQueue);
    const http = TestBed.inject(HttpTestingController);
    const result = queue.save(write('a', 1));
    http.expectOne('/api/drafts/a').flush(null, { status: 422, statusText: 'Bad' });
    await expect(result).rejects.toMatchObject({ kind: 'validation' });
    expect(queue.pending()).toEqual([]);
  });
});
