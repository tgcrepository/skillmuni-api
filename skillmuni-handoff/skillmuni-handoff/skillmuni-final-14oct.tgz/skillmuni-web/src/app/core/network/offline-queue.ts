import { DOCUMENT } from '@angular/common';
import { Service, effect, inject, signal, untracked } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { ApiClient } from '../api/api-client';
import { ApiError, toApiError } from '../api/api-error';
import { Connectivity } from './connectivity';

export interface QueuedWrite {
  /** Dedupe key: a newer write with the same key replaces the older one (e.g. "quest-3/part-1"). */
  readonly key: string;
  readonly method: 'PUT' | 'POST' | 'PATCH';
  readonly path: string;
  readonly body: unknown;
}

export type SaveOutcome = 'saved' | 'queued';

/** sessionStorage, not localStorage: answers can hold personal data, so the queue dies with the tab (A-66). */
const STORAGE_KEY = 'sm.offline-queue';

/**
 * OF1 "Offline — answers queued". Inputs stay usable; saves go through `save()`, which sends now or
 * queues when offline / the network drops. The queue replays in order when the browser is back online.
 * Validation / auth errors are not queued — they are thrown to the caller.
 */
@Service()
export class OfflineQueue {
  private readonly api = inject(ApiClient);
  private readonly connectivity = inject(Connectivity);
  private readonly storage = inject(DOCUMENT).defaultView?.sessionStorage;
  private flushing = false;

  readonly pending = signal<readonly QueuedWrite[]>(this.restore());
  /** Increments every time a non-empty queue is fully flushed (drives the "saved" toast). */
  readonly flushed = signal(0);

  constructor() {
    effect(() => {
      if (this.connectivity.online() && untracked(this.pending).length) void this.flush();
    });
  }

  async save(write: QueuedWrite): Promise<SaveOutcome> {
    if (!this.connectivity.online()) {
      this.enqueue(write);
      return 'queued';
    }
    try {
      await this.send(write);
      return 'saved';
    } catch (err) {
      const error = toApiError(err, this.connectivity.online());
      if (error.kind !== 'offline') throw error;
      this.enqueue(write);
      return 'queued';
    }
  }

  async flush(): Promise<void> {
    if (this.flushing) return;
    this.flushing = true;
    try {
      while (this.pending().length && this.connectivity.online()) {
        const next = this.pending()[0];
        if (!next) break;
        try {
          await this.send(next);
        } catch (err) {
          const error = err instanceof ApiError ? err : toApiError(err, this.connectivity.online());
          // Still offline or server down: stop and wait for the next "online". Anything else is dropped
          // (it would fail forever) — the server copy stays authoritative.
          if (error.transient) return;
        }
        this.set(this.pending().slice(1));
        if (!this.pending().length) this.flushed.update((n) => n + 1);
      }
    } finally {
      this.flushing = false;
    }
  }

  private send(write: QueuedWrite): Promise<unknown> {
    const call =
      write.method === 'PUT'
        ? this.api.put(write.path, write.body)
        : write.method === 'PATCH'
          ? this.api.patch(write.path, write.body)
          : this.api.post(write.path, write.body);
    return firstValueFrom(call);
  }

  private enqueue(write: QueuedWrite): void {
    this.set([...this.pending().filter((w) => w.key !== write.key), write]);
  }

  private set(list: readonly QueuedWrite[]): void {
    this.pending.set(list);
    try {
      if (list.length) this.storage?.setItem(STORAGE_KEY, JSON.stringify(list));
      else this.storage?.removeItem(STORAGE_KEY);
    } catch {
      /* storage blocked: the in-memory queue still works for this page */
    }
  }

  private restore(): readonly QueuedWrite[] {
    try {
      const raw = this.storage?.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as QueuedWrite[]) : [];
    } catch {
      return [];
    }
  }
}
