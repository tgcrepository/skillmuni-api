import { DOCUMENT } from '@angular/common';
import { DestroyRef, Service, inject, signal } from '@angular/core';

/** Browser online/offline as a signal. `navigator.onLine` false is reliable; true only means "maybe". */
@Service()
export class Connectivity {
  private readonly win = inject(DOCUMENT).defaultView;
  readonly online = signal(this.win?.navigator.onLine ?? true);

  constructor() {
    if (!this.win) return;
    const up = () => this.online.set(true);
    const down = () => this.online.set(false);
    this.win.addEventListener('online', up);
    this.win.addEventListener('offline', down);
    inject(DestroyRef).onDestroy(() => {
      this.win?.removeEventListener('online', up);
      this.win?.removeEventListener('offline', down);
    });
  }
}
