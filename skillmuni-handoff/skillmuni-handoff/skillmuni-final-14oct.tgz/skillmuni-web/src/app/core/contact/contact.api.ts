import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';
import { OtpChallenge } from '../auth/auth.api';
import { MarketCode } from '../market/market';

export interface PostalArea {
  readonly name: string;
  /** District / municipality shown under the area name. */
  readonly sub: string;
}

export interface PostalLookup {
  /** State / UT (IN) or Province (ZA). */
  readonly region: string;
  /** District (IN) or Municipality (ZA). */
  readonly district: string;
  readonly city: string;
  readonly areas: readonly PostalArea[];
}

/** Q2 Hit Me Up: verify the contact number and look addresses up by PIN / postal code. */
export interface ContactApi {
  sendPhoneCode(phone: string): Observable<OtpChallenge>;
  verifyPhone(phone: string, code: string): Observable<void>;
  /** 404 → "PIN not found" state (pick the state yourself). */
  lookupPostal(market: MarketCode, code: string): Observable<PostalLookup>;
  regions(market: MarketCode): Observable<readonly string[]>;
}

@Service()
export class HttpContactApi implements ContactApi {
  private readonly api = inject(ApiClient);

  sendPhoneCode(phone: string): Observable<OtpChallenge> {
    return this.api.post('me/phone/code', { phone });
  }

  verifyPhone(phone: string, code: string): Observable<void> {
    return this.api.post('me/phone/verify', { phone, code });
  }

  lookupPostal(market: MarketCode, code: string): Observable<PostalLookup> {
    return this.api.get(`geo/${market}/postal/${encodeURIComponent(code)}`);
  }

  regions(market: MarketCode): Observable<readonly string[]> {
    return this.api.get(`geo/${market}/regions`);
  }
}

export const CONTACT_API = new InjectionToken<ContactApi>('CONTACT_API', {
  factory: () => inject(HttpContactApi),
});

/** Common email-domain typos → suggestion ("Did you mean …@gmail.com?"). */
const DOMAIN_FIXES: Readonly<Record<string, string>> = {
  'gmial.com': 'gmail.com',
  'gmal.com': 'gmail.com',
  'gmai.com': 'gmail.com',
  'gamil.com': 'gmail.com',
  'gnail.com': 'gmail.com',
  'gmail.co': 'gmail.com',
  'yaho.com': 'yahoo.com',
  'yahooo.com': 'yahoo.com',
  'hotmal.com': 'hotmail.com',
  'hotmial.com': 'hotmail.com',
  'outlok.com': 'outlook.com',
  'rediffmai.com': 'rediffmail.com',
};

export function emailSuggestion(email: string): string | null {
  const at = email.lastIndexOf('@');
  if (at < 1) return null;
  const domain = email.slice(at + 1).toLowerCase();
  const fix = DOMAIN_FIXES[domain];
  return fix ? `${email.slice(0, at)}@${fix}` : null;
}
