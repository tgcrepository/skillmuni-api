import { emailSuggestion } from './contact.api';

describe('emailSuggestion', () => {
  it('fixes common domain typos and leaves good ones alone', () => {
    expect(emailSuggestion('yash@gmial.com')).toBe('yash@gmail.com');
    expect(emailSuggestion('a.b@YAHOO0.com')).toBeNull();
    expect(emailSuggestion('yash@gmail.com')).toBeNull();
    expect(emailSuggestion('nope')).toBeNull();
  });
});
