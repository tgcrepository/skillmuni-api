import { HttpClient, HttpEvent, HttpEventType } from '@angular/common/http';
import { InjectionToken, Service, inject } from '@angular/core';
import { Observable, catchError, filter, map, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiClient } from '../api/api-client';
import { toApiError } from '../api/api-error';
import { Connectivity } from '../network/connectivity';

/** Upload progress (0–100) and, at the end, the stored CV id. */
export type UploadEvent =
  | { readonly kind: 'progress'; readonly percent: number }
  | { readonly kind: 'done'; readonly cvId: string };

/**
 * Outcome codes the parser can return — Figma S1–S9:
 * unsupported-type (S1) · too-large (S2) · locked-pdf (S3) · blurry-photo (S4) · other-language (S5) ·
 * parse-failed (S6) · no-work-history (S7) · little-found (S8) · email-taken (S9).
 */
export type CvOutcome =
  | 'unsupported-type'
  | 'too-large'
  | 'locked-pdf'
  | 'blurry-photo'
  | 'other-language'
  | 'parse-failed'
  | 'no-work-history'
  | 'little-found'
  | 'email-taken';

export interface ParseStatus {
  readonly state: 'parsing' | 'done' | 'failed';
  /** 0–100 */
  readonly percent: number;
  /** Index of the step in progress (0–5); steps before it are done. */
  readonly step: number;
  /** Muni's live reaction to what was found, e.g. "Ooh, a call-centre internship? Love that for you." */
  readonly quip?: string;
  readonly outcome?: CvOutcome;
  /** Detail for the outcome copy: language name, details found, support reference. */
  readonly detail?: string;
}

export interface CvField {
  readonly key: string;
  readonly label: string;
  readonly value: string;
  /** Amber "Check" rows: why it needs a look, e.g. "Found a suburb only — add your postal code". */
  readonly check?: string;
}

export interface CvSection {
  readonly quest: number;
  readonly title: string;
  /** Badge text, e.g. "4 found · 1 to check", "9 skills · 3 languages". */
  readonly badge: string;
  readonly fields: readonly CvField[];
  readonly chips?: readonly string[];
}

export interface CvSummary {
  readonly questsPrefilled: number;
  readonly detailsFound: number;
  readonly toCheck: number;
  readonly skillsMatched: number;
  readonly sections: readonly CvSection[];
  /** Personal details the parser skipped and did not keep, e.g. ["photo", "ID number"]. */
  readonly skipped: readonly string[];
}

export interface CvApi {
  /** One file, or several photographed pages (F1) sent together as `pages`. */
  upload(file: File | readonly File[]): Observable<UploadEvent>;
  status(cvId: string): Observable<ParseStatus>;
  summary(cvId: string): Observable<CvSummary>;
  remove(cvId: string): Observable<void>;
}

@Service()
export class HttpCvApi implements CvApi {
  private readonly http = inject(HttpClient);
  private readonly api = inject(ApiClient);
  private readonly connectivity = inject(Connectivity);

  upload(file: File | readonly File[]): Observable<UploadEvent> {
    const body = new FormData();
    if (Array.isArray(file))
      for (const page of file as readonly File[]) body.append('pages', page, page.name);
    else body.append('file', file as File, (file as File).name);
    return this.http
      .post<{ cvId: string }>(`${environment.apiBaseUrl}/cv`, body, {
        reportProgress: true,
        observe: 'events',
        withCredentials: true,
      })
      .pipe(
        filter(
          (e: HttpEvent<{ cvId: string }>) =>
            e.type === HttpEventType.UploadProgress || e.type === HttpEventType.Response,
        ),
        map((e): UploadEvent => {
          if (e.type === HttpEventType.UploadProgress) {
            return {
              kind: 'progress',
              percent: e.total ? Math.round((e.loaded / e.total) * 100) : 0,
            };
          }
          return { kind: 'done', cvId: (e.type === HttpEventType.Response && e.body?.cvId) || '' };
        }),
        catchError((err: unknown) => throwError(() => toApiError(err, this.connectivity.online()))),
      );
  }

  status(cvId: string): Observable<ParseStatus> {
    return this.api.get(`cv/${cvId}/status`);
  }

  summary(cvId: string): Observable<CvSummary> {
    return this.api.get(`cv/${cvId}/summary`);
  }

  remove(cvId: string): Observable<void> {
    return this.api.delete(`cv/${cvId}`);
  }
}

export const CV_API = new InjectionToken<CvApi>('CV_API', { factory: () => inject(HttpCvApi) });

/** Client-side checks before upload (S1 / S2). 10 MB per the dropzone copy. */
export const CV_MAX_BYTES = 10 * 1024 * 1024;
export const CV_ACCEPT = '.pdf,.doc,.docx,image/jpeg,image/png,image/heic,image/webp';
const CV_EXTENSIONS = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'heic', 'webp'];

export function checkCvFile(file: File): CvOutcome | null {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
  if (!CV_EXTENSIONS.includes(ext)) return 'unsupported-type';
  if (file.size > CV_MAX_BYTES) return 'too-large';
  return null;
}
