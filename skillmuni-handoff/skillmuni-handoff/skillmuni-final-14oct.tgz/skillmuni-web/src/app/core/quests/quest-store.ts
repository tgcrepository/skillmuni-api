import { Service, computed, inject, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { OfflineQueue, SaveOutcome } from '../network/offline-queue';
import { LearnerProgress, PROGRESS_API } from '../progress/progress.api';
import { LADDER, STEP_XP, levelFor } from './levels';
import { QUESTS, QuestDef } from './quest-catalog';
import { QUEST_API, QuestAnswers, QuestCompletion } from './quest.api';

/** +20 XP for each step the first time it's done, +50 when the quest is finished (A-249). */
export const PART_XP = STEP_XP;

/** Answer key holding a part's bonus XP total (see `saveBonus`). */
export const BONUS_KEY = 'bonusXp';

/**
 * Where the learner is across the 8 quests, their answers, and XP. Parts save through the offline queue
 * (OF1), so answering never blocks on the network; XP shown is optimistic and reconciled on completion.
 */
@Service()
export class QuestStore {
  private readonly progressApi = inject(PROGRESS_API);
  private readonly api = inject(QUEST_API);
  private readonly queue = inject(OfflineQueue);

  readonly progress = signal<LearnerProgress | null>(null);
  private readonly answersBySlug = signal<Readonly<Record<string, QuestAnswers>>>({});

  readonly hud = computed(() => {
    const p = this.progress();
    return p ? { level: p.level, rank: p.rank, xp: p.xp, target: p.target } : null;
  });

  async load(): Promise<LearnerProgress> {
    const p = this.withXp(await firstValueFrom(this.progressApi.get()), 0);
    this.progress.set(p);
    return p;
  }

  async loadAnswers(slug: string): Promise<QuestAnswers> {
    const cached = this.answersBySlug()[slug];
    if (cached) return cached;
    const answers = await firstValueFrom(this.api.answers(slug));
    this.answersBySlug.update((all) => ({ ...all, [slug]: answers }));
    return answers;
  }

  answers(slug: string): QuestAnswers {
    return this.answersBySlug()[slug] ?? {};
  }

  /** Can the learner open this quest? Done ones and the next one are open; later ones are locked. */
  isOpen(quest: QuestDef): boolean {
    return quest.id <= (this.progress()?.completed ?? 0) + 1;
  }

  /** Save a part's answers. `partDone` moves the stepper on and grants part XP. */
  async savePart(
    slug: string,
    part: number,
    values: QuestAnswers,
    partDone: boolean,
    grantXp = partDone,
  ): Promise<SaveOutcome> {
    this.answersBySlug.update((all) => ({ ...all, [slug]: { ...all[slug], ...values } }));
    const outcome = await this.queue.save({
      key: `${slug}/${part}`,
      method: 'PUT',
      path: this.api.partPath(slug, part),
      body: { values, done: partDone, xp: grantXp },
    });
    if (partDone) {
      // XP once per step, only on the quest in progress: going back and forward, or editing a
      // finished quest later, never pays twice. The server is the source of truth.
      const current =
        QUESTS.find((q) => q.slug === slug)?.id === (this.progress()?.completed ?? 0) + 1;
      this.progress.update((p) =>
        p
          ? this.withXp(
              { ...p, partsDone: current ? Math.max(p.partsDone, part) : p.partsDone },
              grantXp && current && part > p.partsDone ? PART_XP : 0,
            )
          : p,
      );
    }
    return outcome;
  }

  /**
   * Save answers that carry bonus XP without finishing the part (Q3 timeline: +10 XP per extra level,
   * counted once per level). `bonusXp` is the part's absolute bonus, so a queued offline write that
   * replaces an older one (same key) can't double count; the shown XP moves by the difference.
   */
  async saveBonus(
    slug: string,
    part: number,
    values: QuestAnswers,
    bonusXp: number,
  ): Promise<SaveOutcome> {
    // A-168: no in-between XP. Extras are still saved; the bonus is always 0.
    bonusXp = 0;
    const before = Number(this.answers(slug)[BONUS_KEY] ?? 0);
    const saved = { ...values, [BONUS_KEY]: bonusXp };
    this.answersBySlug.update((all) => ({ ...all, [slug]: { ...all[slug], ...saved } }));
    const outcome = await this.queue.save({
      key: `${slug}/${part}/bonus`,
      method: 'PUT',
      path: this.api.partPath(slug, part),
      body: { values: saved, done: false, bonusXp },
    });
    const delta = bonusXp - before;
    if (delta) this.progress.update((p) => (p ? this.withXp(p, delta) : p));
    return outcome;
  }

  async complete(slug: string): Promise<QuestCompletion> {
    const result = await firstValueFrom(this.api.complete(slug));
    const progress = this.withXp(result.progress, 0);
    this.progress.set(progress);
    return { ...result, progress };
  }

  nextQuest(after: number): QuestDef | null {
    return QUESTS.find((q) => q.id === after + 1) ?? null;
  }

  /** Level, rank and target always come from the one ladder, so the bar and the label agree. */
  private withXp(p: LearnerProgress, xp: number): LearnerProgress {
    const total = p.xp + xp;
    const l = levelFor(total);
    return { ...p, xp: total, level: l.level, rank: l.rank, target: l.target };
  }
}

export function nextRankName(xp: number): string {
  return LADDER.find((r) => r.min > xp)?.rank ?? LADDER[LADDER.length - 1]?.rank ?? '';
}
