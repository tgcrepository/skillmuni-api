/**
 * One level ladder for the whole platform (A-249): quests HUD, Profile, My Stats and Rewards all
 * read it, so the learner never sees two different levels for the same XP.
 */
export interface LevelStep {
  readonly level: number;
  readonly min: number;
  readonly rank: string;
}

export const LADDER: readonly LevelStep[] = [
  { level: 1, min: 0, rank: $localize`:@@rank.rookie:Rookie` },
  { level: 2, min: 400, rank: $localize`:@@rank.pathfinder:Pathfinder` },
  { level: 3, min: 800, rank: $localize`:@@rank.trailblazer:Trailblazer` },
  { level: 4, min: 1200, rank: $localize`:@@rank.legend:Legend` },
  { level: 5, min: 1600, rank: $localize`:@@rank.icon:Icon` },
];

/** Level, rank and the XP where the next level starts (the last level's target is its own min + 400). */
export function levelFor(xp: number): {
  level: number;
  rank: string;
  start: number;
  target: number;
} {
  const step = [...LADDER].reverse().find((s) => xp >= s.min) ?? LADDER[0];
  const next = LADDER.find((s) => s.min > xp);
  const s = step ?? { level: 1, min: 0, rank: '' };
  return { level: s.level, rank: s.rank, start: s.min, target: next?.min ?? s.min + 400 };
}

/** XP rules for the registration quests (A-249). */
export const STEP_XP = 20;
export const QUEST_XP = 50;
