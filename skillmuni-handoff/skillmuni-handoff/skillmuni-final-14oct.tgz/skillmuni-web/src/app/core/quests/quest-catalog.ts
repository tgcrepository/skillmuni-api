import { STEP_XP } from './levels';

/**
 * The 8 registration quests (Figma: Quest Illustration 26:448, Quest Map 27:104, E1 intro).
 * Copy is the English source; every string is marked for translation.
 */
export interface QuestDef {
  readonly id: number;
  readonly slug: string;
  readonly name: string;
  /** Short label for the tablet lineup strip (Figma tablet frames). */
  readonly short: string;
  readonly tagline: string;
  readonly xp: number;
  /** Badge earned on completion. */
  readonly badge: string;
  /** Parts per quest (Section Stepper). */
  readonly parts: number;
}

export const QUESTS: readonly QuestDef[] = [
  {
    id: 1,
    slug: 'who-dis',
    short: $localize`:@@quest.1.short:Who Dis?`,
    name: $localize`:@@quest.1.name:Who Dis?`,
    tagline: $localize`:@@quest.1.tagline:The basics, zero stress`,
    xp: 50,
    badge: $localize`:@@quest.1.badge:Main Character Badge`,
    parts: 3,
  },
  {
    id: 2,
    slug: 'hit-me-up',
    short: $localize`:@@quest.2.short:Hit Me Up`,
    name: $localize`:@@quest.2.name:Hit Me Up`,
    tagline: $localize`:@@quest.2.tagline:So we can hit you up`,
    xp: 50,
    badge: $localize`:@@quest.2.badge:Link Up Badge`,
    parts: 3,
  },
  {
    id: 3,
    slug: 'big-brain-stuff',
    short: $localize`:@@quest.3.short:Big Brain`,
    name: $localize`:@@quest.3.name:Big Brain Stuff`,
    tagline: $localize`:@@quest.3.tagline:School, uni, all of it`,
    xp: 50,
    badge: $localize`:@@quest.3.badge:Big Brain Badge`,
    parts: 3,
  },
  {
    id: 4,
    slug: 'your-flex-era',
    short: $localize`:@@quest.4.short:Your Flex`,
    name: $localize`:@@quest.4.name:Your Flex Era`,
    tagline: $localize`:@@quest.4.tagline:Time to flex a little`,
    xp: 50,
    badge: $localize`:@@quest.4.badge:Player Card`,
    parts: 3,
  },
  {
    id: 5,
    slug: 'work-lore',
    short: $localize`:@@quest.5.short:Work Lore`,
    name: $localize`:@@quest.5.name:Work Lore`,
    tagline: $localize`:@@quest.5.tagline:Jobs, gigs, side hustles`,
    xp: 50,
    badge: $localize`:@@quest.5.badge:Storyteller Badge`,
    parts: 3,
  },
  {
    id: 6,
    slug: 'pick-your-arc',
    short: $localize`:@@quest.6.short:Your Arc`,
    name: $localize`:@@quest.6.name:Pick Your Arc`,
    tagline: $localize`:@@quest.6.tagline:What’s next?`,
    xp: 50,
    badge: $localize`:@@quest.6.badge:Arc Badge`,
    parts: 1,
  },
  {
    id: 7,
    slug: 'drop-the-receipts',
    short: $localize`:@@quest.7.short:Receipts`,
    name: $localize`:@@quest.7.name:Drop the Receipts`,
    tagline: $localize`:@@quest.7.tagline:Proof you’re legit`,
    xp: 50,
    badge: $localize`:@@quest.7.badge:Receipts Badge`,
    parts: 1,
  },
  {
    id: 8,
    slug: 'vibe-check',
    short: $localize`:@@quest.8.short:Vibe Check`,
    name: $localize`:@@quest.8.name:Vibe Check`,
    tagline: $localize`:@@quest.8.tagline:One last look, then send it`,
    xp: 50,
    badge: $localize`:@@quest.8.badge:Vibe Check Badge`,
    parts: 1,
  },
];

/** XP a whole quest is worth: +20 a step, +50 to finish (A-249). */
export const questXp = (q: QuestDef): number => q.parts * STEP_XP + q.xp;

/** Every step +20, every finished quest +50 (A-249). */
export const TOTAL_XP = QUESTS.reduce((sum, q) => sum + questXp(q), 0);

export function questById(id: number): QuestDef {
  const quest = QUESTS.find((q) => q.id === id);
  if (!quest) throw new Error(`Unknown quest ${id}`);
  return quest;
}
