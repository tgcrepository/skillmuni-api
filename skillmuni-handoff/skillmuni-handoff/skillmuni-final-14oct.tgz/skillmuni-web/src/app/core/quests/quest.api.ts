import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';
import { LearnerProgress } from '../progress/progress.api';

/** One quest's saved answers, keyed by field. Values are plain JSON. */
export type QuestAnswers = Readonly<Record<string, unknown>>;

export interface QuestCompletion {
  readonly xpEarned: number;
  readonly progress: LearnerProgress;
}

export interface QuestApi {
  answers(slug: string): Observable<QuestAnswers>;
  /** Saving goes through the OfflineQueue with this path (PUT, idempotent per part). */
  partPath(slug: string, part: number): string;
  complete(slug: string): Observable<QuestCompletion>;
}

@Service()
export class HttpQuestApi implements QuestApi {
  private readonly api = inject(ApiClient);

  answers(slug: string): Observable<QuestAnswers> {
    return this.api.get(`me/quests/${slug}/answers`);
  }

  partPath(slug: string, part: number): string {
    return `me/quests/${slug}/parts/${part}`;
  }

  complete(slug: string): Observable<QuestCompletion> {
    return this.api.post(`me/quests/${slug}/complete`, {});
  }
}

export const QUEST_API = new InjectionToken<QuestApi>('QUEST_API', {
  factory: () => inject(HttpQuestApi),
});
