import { TestBed } from '@angular/core/testing';
import {
  MARKETS,
  Market,
  isValidId,
  isValidMobile,
  isValidPostal,
  luhn,
  nationalNumber,
} from './market';

describe('Market config', () => {
  const IN = MARKETS.IN;
  const ZA = MARKETS.ZA;

  it('normalises numbers typed with dial code, spaces or trunk 0', () => {
    expect(nationalNumber(IN, '+91 98765-43210')).toBe('9876543210');
    expect(nationalNumber(IN, '098765 43210')).toBe('9876543210');
    expect(nationalNumber(ZA, '+27 71 234 5678')).toBe('712345678');
    expect(nationalNumber(ZA, '071 234 5678')).toBe('712345678');
  });

  it('validates mobiles per market', () => {
    expect(isValidMobile(IN, '98765 43210')).toBe(true);
    expect(isValidMobile(IN, '12345 67890')).toBe(false);
    expect(isValidMobile(IN, '98765')).toBe(false);
    expect(isValidMobile(ZA, '071 234 5678')).toBe(true);
    expect(isValidMobile(ZA, '98765 43210')).toBe(false);
  });

  it('validates PIN vs postal codes', () => {
    expect(isValidPostal(IN, '560001')).toBe(true);
    expect(isValidPostal(IN, '2001')).toBe(false);
    expect(isValidPostal(ZA, '2001')).toBe(true);
  });

  it('checks ID formats, including the SA ID Luhn digit', () => {
    const pan = IN.idTypes.find((t) => t.id === 'pan')!;
    expect(isValidId(pan, 'abcde1234f')).toBe(true);
    const saId = ZA.idTypes.find((t) => t.id === 'sa-id')!;
    expect(luhn('8001015009087')).toBe(true);
    expect(isValidId(saId, '8001015009087')).toBe(true);
    expect(isValidId(saId, '8001015009088')).toBe(false);
  });

  it('defaults to India and can switch', () => {
    const market = TestBed.inject(Market);
    expect(market.config().consentLaw).toContain('Digital Personal Data Protection');
    market.set('ZA');
    expect(market.config().consentLaw).toContain('POPIA');
    expect(market.config().postal.label).toBe('Postal code');
  });
});
