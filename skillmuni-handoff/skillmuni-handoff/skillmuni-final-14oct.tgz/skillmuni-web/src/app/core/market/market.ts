import { Service, computed, signal } from '@angular/core';
import { environment } from '../../../environments/environment';

export type MarketCode = 'IN' | 'ZA';

export interface IdType {
  readonly id: string;
  readonly label: string;
  /** Uppercased, spaces removed before testing. */
  readonly pattern: RegExp;
  /** Extra checksum beyond the pattern (e.g. SA ID Luhn). */
  readonly check?: (value: string) => boolean;
}

export interface MarketConfig {
  readonly code: MarketCode;
  readonly name: string;
  readonly locale: string;
  readonly dialCode: string;
  /** National mobile number, digits only, without trunk 0 or dial code. */
  readonly mobile: { readonly digits: number; readonly pattern: RegExp; readonly example: string };
  readonly postal: { readonly label: string; readonly pattern: RegExp; readonly example: string };
  /** Privacy law the consent copy cites (A-12). */
  readonly consentLaw: string;
  readonly idTypes: readonly IdType[];
  /**
   * How identity is confirmed (A-272). `digilocker` (India): linked through DigiLocker with
   * consent; only the last 4 characters are kept, never the number or a copy. `number`: typed in.
   */
  readonly idVerification: 'digilocker' | 'number';
  /** Home-language chips: the first six show, the rest sit behind "+ N more". */
  readonly languages: readonly string[];
  /** Race is asked only where employment-equity reporting needs it (ZA). A-97 */
  readonly asksRace: boolean;
  /** ID types whose number carries the birthday (SA ID: YYMMDD…). */
  readonly idHasBirthday: readonly string[];
}

/** Luhn check used by the 13-digit South African ID number. */
export function luhn(value: string): boolean {
  let sum = 0;
  for (let i = 0; i < value.length; i++) {
    let d = Number(value[value.length - 1 - i]);
    if (i % 2 === 1) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
  }
  return sum % 10 === 0;
}

/**
 * India is the default market; South Africa is configuration only (approved decision 3, A-12).
 * Adding a market = adding an entry here plus its consent copy.
 */
export const MARKETS: Readonly<Record<MarketCode, MarketConfig>> = {
  IN: {
    code: 'IN',
    name: $localize`:@@market.in:India`,
    locale: 'en-IN',
    dialCode: '+91',
    mobile: { digits: 10, pattern: /^[6-9]\d{9}$/, example: '98765 43210' },
    postal: {
      label: $localize`:@@market.in.postal:PIN code`,
      pattern: /^[1-9]\d{5}$/,
      example: '560001',
    },
    consentLaw: $localize`:@@market.in.law:Digital Personal Data Protection Act, 2023`,
    idTypes: [
      { id: 'aadhaar', label: $localize`:@@market.in.aadhaar:Aadhaar`, pattern: /^[2-9]\d{11}$/ },
      { id: 'pan', label: $localize`:@@market.in.pan:PAN card`, pattern: /^[A-Z]{5}\d{4}[A-Z]$/ },
      {
        id: 'driving-licence',
        label: $localize`:@@market.in.dl:Driving licence`,
        pattern: /^[A-Z]{2}\d{2}\s?\d{11}$/,
      },
    ],
    idVerification: 'digilocker',
    languages: [
      'Hindi',
      'English',
      'Bengali',
      'Marathi',
      'Telugu',
      'Tamil',
      'Gujarati',
      'Urdu',
      'Kannada',
      'Odia',
      'Malayalam',
      'Punjabi',
      'Assamese',
      'Konkani',
      // The rest of the 22 scheduled languages, then widely spoken ones (A-243).
      'Maithili',
      'Santali',
      'Kashmiri',
      'Nepali',
      'Sindhi',
      'Dogri',
      'Manipuri',
      'Bodo',
      'Sanskrit',
      'Bhojpuri',
      'Rajasthani',
      'Tulu',
    ],
    asksRace: false,
    idHasBirthday: [],
  },
  ZA: {
    code: 'ZA',
    name: $localize`:@@market.za:South Africa`,
    locale: 'en-ZA',
    dialCode: '+27',
    mobile: { digits: 9, pattern: /^[6-8]\d{8}$/, example: '71 234 5678' },
    postal: {
      label: $localize`:@@market.za.postal:Postal code`,
      pattern: /^\d{4}$/,
      example: '2001',
    },
    consentLaw: $localize`:@@market.za.law:Protection of Personal Information Act (POPIA)`,
    idTypes: [
      {
        id: 'sa-id',
        label: $localize`:@@market.za.id:SA ID number`,
        pattern: /^\d{13}$/,
        check: luhn,
      },
      { id: 'passport', label: $localize`:@@market.passport:Passport`, pattern: /^[A-Z0-9]{6,9}$/ },
    ],
    languages: [
      'isiZulu',
      'English',
      'isiXhosa',
      'Afrikaans',
      'Sepedi',
      'Setswana',
      'Sesotho',
      'Xitsonga',
      'siSwati',
      'Tshivenda',
      'isiNdebele',
      'SA Sign Language',
    ],
    asksRace: true,
    idHasBirthday: ['sa-id'],
    idVerification: 'number',
  },
};

/** Digits only, with the dial code and trunk 0 removed: "+91 98765-43210" → "9876543210". */
export function nationalNumber(market: MarketConfig, raw: string): string {
  let digits = raw.replace(/\D/g, '');
  const dial = market.dialCode.replace('+', '');
  if (raw.trim().startsWith('+') && digits.startsWith(dial)) digits = digits.slice(dial.length);
  if (digits.length === market.mobile.digits + 1 && digits.startsWith('0'))
    digits = digits.slice(1);
  return digits;
}

export function isValidMobile(market: MarketConfig, raw: string): boolean {
  return market.mobile.pattern.test(nationalNumber(market, raw));
}

export function isValidPostal(market: MarketConfig, raw: string): boolean {
  return market.postal.pattern.test(raw.trim());
}

export function isValidId(type: IdType, raw: string): boolean {
  const value = raw.replace(/\s/g, '').toUpperCase();
  return type.pattern.test(value) && (type.check?.(value) ?? true);
}

/** Birthday from a 13-digit SA ID (YYMMDD…). Two-digit years resolve to the most recent past century. */
export function birthdayFromSaId(id: string, today = new Date()): Date | null {
  const digits = id.replace(/\s/g, '');
  if (!/^\d{13}$/.test(digits)) return null;
  const yy = Number(digits.slice(0, 2));
  const mm = Number(digits.slice(2, 4));
  const dd = Number(digits.slice(4, 6));
  const century = 2000 + yy > today.getFullYear() ? 1900 : 2000;
  const date = new Date(century + yy, mm - 1, dd);
  return date.getMonth() === mm - 1 && date.getDate() === dd ? date : null;
}

/** The learner's market. Defaults per deployment; the Country step (E3) can switch it (A-23). */
@Service()
export class Market {
  readonly code = signal<MarketCode>(environment.market);
  readonly config = computed(() => MARKETS[this.code()]);

  set(code: MarketCode): void {
    this.code.set(code);
  }
}
