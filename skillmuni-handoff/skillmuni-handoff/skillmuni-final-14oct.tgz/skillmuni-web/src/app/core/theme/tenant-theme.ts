import { DOCUMENT, Service, inject, signal } from '@angular/core';

/** Ramp steps a tenant may override. Matches Figma Primitives `color/ember/*` and `color/arcane/*`. */
export const BRAND_STEPS = [
  '50',
  '100',
  '150',
  '200',
  '300',
  '350',
  '400',
  '450',
  '500',
  '550',
  '600',
  '700',
  '800',
  '900',
] as const;
export const ACCENT_STEPS = [
  '50',
  '100',
  '200',
  '300',
  '350',
  '400',
  '450',
  '500',
  '550',
  '600',
  '700',
  '800',
  '900',
] as const;

export type BrandStep = (typeof BRAND_STEPS)[number];
export type AccentStep = (typeof ACCENT_STEPS)[number];

/** White-label tenant theme (ASSUMPTIONS A-13). Only ramps are overridable; semantic tokens follow. */
export interface TenantTheme {
  readonly id: string;
  readonly name: string;
  /** Replaces the Skillmuni "ember" brand ramp. */
  readonly brand?: Partial<Record<BrandStep, string>>;
  /** Replaces the Skillmuni "arcane" accent ramp. */
  readonly accent?: Partial<Record<AccentStep, string>>;
  readonly logoUrl?: string;
}

const HEX = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i;

/**
 * Applies a tenant's brand ramps as CSS custom-property overrides on <html>.
 * Alpha tints are generated with color-mix() from the ramps, so they follow automatically.
 */
@Service()
export class TenantThemeService {
  private readonly root = inject(DOCUMENT).documentElement;
  private applied: string[] = [];

  readonly active = signal<TenantTheme | null>(null);

  apply(theme: TenantTheme): void {
    this.reset();
    const entries: [string, string][] = [
      ...this.entriesFor('ember', theme.brand),
      ...this.entriesFor('arcane', theme.accent),
    ];
    for (const [prop, value] of entries) this.root.style.setProperty(prop, value);
    this.applied = entries.map(([prop]) => prop);
    this.active.set(theme);
  }

  reset(): void {
    for (const prop of this.applied) this.root.style.removeProperty(prop);
    this.applied = [];
    this.active.set(null);
  }

  private entriesFor(
    ramp: 'ember' | 'arcane',
    values?: Partial<Record<string, string>>,
  ): [string, string][] {
    if (!values) return [];
    return Object.entries(values)
      .filter((e): e is [string, string] => typeof e[1] === 'string' && HEX.test(e[1]))
      .map(([step, hex]) => [`--sm-ref-color-${ramp}-${step}`, hex]);
  }
}
