import { TestBed } from '@angular/core/testing';
import { DOCUMENT } from '@angular/core';
import { TenantThemeService } from './tenant-theme';

describe('TenantThemeService', () => {
  let service: TenantThemeService;
  let root: HTMLElement;

  beforeEach(() => {
    service = TestBed.inject(TenantThemeService);
    root = TestBed.inject(DOCUMENT).documentElement;
  });

  afterEach(() => service.reset());

  it('overrides brand and accent ramp tokens on <html>', () => {
    service.apply({
      id: 'acme',
      name: 'Acme',
      brand: { '400': '#1188ff' },
      accent: { '500': '#22aa66' },
    });

    expect(root.style.getPropertyValue('--sm-ref-color-ember-400')).toBe('#1188ff');
    expect(root.style.getPropertyValue('--sm-ref-color-arcane-500')).toBe('#22aa66');
    expect(service.active()?.id).toBe('acme');
  });

  it('ignores values that are not hex colours', () => {
    service.apply({ id: 'bad', name: 'Bad', brand: { '400': 'url(evil)' } });

    expect(root.style.getPropertyValue('--sm-ref-color-ember-400')).toBe('');
  });

  it('removes only what it applied when switching tenants', () => {
    service.apply({ id: 'a', name: 'A', brand: { '400': '#111111' } });
    service.apply({ id: 'b', name: 'B', accent: { '500': '#222222' } });

    expect(root.style.getPropertyValue('--sm-ref-color-ember-400')).toBe('');
    expect(root.style.getPropertyValue('--sm-ref-color-arcane-500')).toBe('#222222');
  });
});
