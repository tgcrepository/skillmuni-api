import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

export type FeedbackMood = 1 | 2 | 3 | 4 | 5;

export interface FeedbackAnswer {
  readonly mood: FeedbackMood;
  readonly tags: readonly string[];
  readonly comment: string;
  /** Screen it was given on, for context. */
  readonly screen: string;
}

export interface FeedbackApi {
  /** Resolves with the XP earned (+5 at most once a month). */
  send(answer: FeedbackAnswer): Observable<{ readonly xp: number }>;
}

@Service()
export class HttpFeedbackApi implements FeedbackApi {
  private readonly api = inject(ApiClient);

  send(answer: FeedbackAnswer): Observable<{ readonly xp: number }> {
    return this.api.post('me/feedback', answer);
  }
}

export const FEEDBACK_API = new InjectionToken<FeedbackApi>('FEEDBACK_API', {
  factory: () => inject(HttpFeedbackApi),
});
