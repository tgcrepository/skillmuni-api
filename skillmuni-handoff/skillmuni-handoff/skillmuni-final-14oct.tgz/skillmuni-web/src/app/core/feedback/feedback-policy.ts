/**
 * When to ask "How's Skillmuni treating you?" (A-274). Pure, so the rules are easy to test and to
 * move server-side. Based on common in-app survey practice and Apple's review-prompt guidance:
 * never in the first session or right at launch, only after something went well, never in the
 * middle of a task, at most once a month and three times a year, and back off when dismissed.
 */
export interface FeedbackState {
  /** First day we saw this learner (ISO date). */
  readonly firstSeen: string;
  /** Distinct days the learner opened the app (ISO dates, most recent last, capped). */
  readonly activeDays: readonly string[];
  /** When the prompt was shown (ISO timestamps, last 365 days). */
  readonly shown: readonly string[];
  readonly lastSubmitted: string | null;
  /** Dismissals in a row without answering. */
  readonly dismissStreak: number;
  /** A success moment happened since the last prompt (quiz passed, quest done…). */
  readonly pendingMoment: boolean;
}

export const FEEDBACK_RULES = {
  /** Account at least this old (days) and used on this many different days. */
  minAgeDays: 3,
  minActiveDays: 3,
  /** At most once a month… */
  gapDays: 30,
  /** …and three times in any 365 days (Apple's cap for review prompts). */
  maxPerYear: 3,
  /** Closed without answering: wait a month; twice in a row: wait a quarter. */
  snoozeDays: 30,
  longSnoozeDays: 90,
  /** Pause after the success moment before asking, so it never cuts in. */
  delayMs: 2000,
} as const;

/** Calm screens where a small card won't interrupt anything. */
export const FEEDBACK_SCREENS = ['/home', '/stats', '/arena', '/launchpad', '/profile', '/learn'];

const DAY = 86_400_000;
const days = (from: string, to: Date) => (to.getTime() - new Date(from).getTime()) / DAY;

export function emptyFeedbackState(now: Date): FeedbackState {
  return {
    firstSeen: now.toISOString().slice(0, 10),
    activeDays: [now.toISOString().slice(0, 10)],
    shown: [],
    lastSubmitted: null,
    dismissStreak: 0,
    pendingMoment: false,
  };
}

export function shouldAsk(s: FeedbackState, now: Date, path: string): boolean {
  const r = FEEDBACK_RULES;
  if (!s.pendingMoment) return false;
  if (!FEEDBACK_SCREENS.some((p) => path === p || path.startsWith(`${p}/`))) return false;
  if (days(s.firstSeen, now) < r.minAgeDays || s.activeDays.length < r.minActiveDays) return false;
  const recent = s.shown.filter((t) => days(t, now) < 365);
  if (recent.length >= r.maxPerYear) return false;
  const last = recent.at(-1);
  if (last) {
    const wait = s.dismissStreak >= 2 ? r.longSnoozeDays : s.dismissStreak === 1 ? r.snoozeDays : r.gapDays;
    if (days(last, now) < wait) return false;
  }
  if (s.lastSubmitted && days(s.lastSubmitted, now) < r.gapDays) return false;
  return true;
}

export function markActive(s: FeedbackState, now: Date): FeedbackState {
  const today = now.toISOString().slice(0, 10);
  if (s.activeDays.at(-1) === today) return s;
  return { ...s, activeDays: [...s.activeDays, today].slice(-30) };
}
