import { DOCUMENT } from '@angular/common';
import { Service, inject, signal } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { Auth } from '../auth/auth';
import {
  FEEDBACK_RULES,
  FeedbackState,
  emptyFeedbackState,
  markActive,
  shouldAsk,
} from './feedback-policy';

/** What just went well; the next calm screen may ask how it's going (A-274). */
export type FeedbackMoment = 'quiz' | 'quest' | 'assessment' | 'apply' | 'fest' | 'first-moves';

/**
 * Decides when the "How's Skillmuni treating you?" card appears (A-274). State is per learner on
 * this device until the backend stores it. `?feedback=now` in the URL forces it (demos, tests).
 */
@Service()
export class FeedbackPrompt {
  private readonly auth = inject(Auth);
  private readonly router = inject(Router);
  private readonly doc = inject(DOCUMENT);
  private timer: ReturnType<typeof setTimeout> | undefined;

  readonly open = signal(false);
  /** Opened from Profile → "Give feedback": never throttled, never counted. */
  readonly manual = signal(false);

  constructor() {
    this.router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe((e) => {
        if (!this.auth.user()) return;
        this.save(markActive(this.load(), new Date()));
        if (/[?&]feedback=now\b/.test(e.urlAfterRedirects)) {
          this.show(false);
          return;
        }
        this.consider();
      });
  }

  /** Call after a success moment (quiz passed, quest finished, applied…). */
  moment(kind: FeedbackMoment): void {
    void kind;
    if (!this.auth.user()) return;
    this.save({ ...this.load(), pendingMoment: true });
    this.consider();
  }

  openManually(): void {
    this.manual.set(true);
    this.open.set(true);
  }

  dismissed(): void {
    this.open.set(false);
    if (this.manual()) return this.manual.set(false);
    const s = this.load();
    this.save({ ...s, dismissStreak: s.dismissStreak + 1, pendingMoment: false });
  }

  submitted(): void {
    const s = this.load();
    this.save({ ...s, lastSubmitted: new Date().toISOString(), dismissStreak: 0, pendingMoment: false });
    this.manual.set(false);
  }

  close(): void {
    this.open.set(false);
  }

  /** Ask after a pause, and only if the learner is still on a calm screen with nothing open. */
  private consider(): void {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      if (this.open() || this.doc.querySelector('.cdk-overlay-pane [role="dialog"]')) return;
      const path = this.router.url.split(/[?#]/)[0] ?? '';
      if (shouldAsk(this.load(), new Date(), path)) this.show(true);
    }, FEEDBACK_RULES.delayMs);
  }

  private show(count: boolean): void {
    if (count) {
      const s = this.load();
      this.save({ ...s, shown: [...s.shown, new Date().toISOString()].slice(-6) });
    }
    this.manual.set(false);
    this.open.set(true);
  }

  private key(): string {
    return `sm_feedback_${this.auth.user()?.id ?? 'anon'}`;
  }

  private load(): FeedbackState {
    try {
      const raw = this.doc.defaultView?.localStorage.getItem(this.key());
      if (raw) return JSON.parse(raw) as FeedbackState;
    } catch {
      /* storage blocked */
    }
    return emptyFeedbackState(new Date());
  }

  private save(s: FeedbackState): void {
    try {
      this.doc.defaultView?.localStorage.setItem(this.key(), JSON.stringify(s));
    } catch {
      /* storage blocked: the prompt just won't remember */
    }
  }
}
