import { FEEDBACK_RULES, FeedbackState, emptyFeedbackState, markActive, shouldAsk } from './feedback-policy';

const day = (n: number) => new Date(Date.UTC(2026, 0, 1 + n, 12));
const ready = (over: Partial<FeedbackState> = {}): FeedbackState => ({
  ...emptyFeedbackState(day(0)),
  activeDays: ['2026-01-01', '2026-01-02', '2026-01-04'],
  pendingMoment: true,
  ...over,
});

describe('feedback policy (A-274)', () => {
  it('never in the first days or sessions, and only after a success moment', () => {
    expect(shouldAsk(ready(), day(1), '/home')).toBe(false); // too new
    expect(shouldAsk(ready({ activeDays: ['2026-01-01'] }), day(10), '/home')).toBe(false);
    expect(shouldAsk(ready({ pendingMoment: false }), day(10), '/home')).toBe(false);
    expect(shouldAsk(ready(), day(10), '/home')).toBe(true);
  });

  it('only on calm screens, never mid-task', () => {
    expect(shouldAsk(ready(), day(10), '/quests/who-dis')).toBe(false);
    expect(shouldAsk(ready(), day(10), '/assessments/career')).toBe(false);
    expect(shouldAsk(ready(), day(10), '/stats/learning')).toBe(true);
  });

  it('at most once a month, three times a year; dismissals back off', () => {
    const shown = [day(10).toISOString()];
    expect(shouldAsk(ready({ shown }), day(30), '/home')).toBe(false);
    expect(shouldAsk(ready({ shown }), day(41), '/home')).toBe(true);
    expect(shouldAsk(ready({ shown, dismissStreak: 2 }), day(60), '/home')).toBe(false);
    expect(shouldAsk(ready({ shown, dismissStreak: 2 }), day(101), '/home')).toBe(true);
    const thrice = [day(10), day(50), day(90)].map((d) => d.toISOString());
    expect(shouldAsk(ready({ shown: thrice }), day(200), '/home')).toBe(false);
    expect(FEEDBACK_RULES.maxPerYear).toBe(3);
  });

  it('counts each day once', () => {
    const s = emptyFeedbackState(day(0));
    expect(markActive(markActive(s, day(0)), day(0)).activeDays).toHaveLength(1);
    expect(markActive(s, day(1)).activeDays).toHaveLength(2);
  });
});
