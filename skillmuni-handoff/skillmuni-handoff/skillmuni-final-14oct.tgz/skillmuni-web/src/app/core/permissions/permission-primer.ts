import { DOCUMENT } from '@angular/common';
import { Service, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import {
  MuniPrompt,
  MuniPromptData,
  MuniPromptResult,
} from '../../shared/ui/muni-prompt/muni-prompt';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';

export type PrimedPermission = 'camera' | 'notifications';

/**
 * granted — the browser permission is on · denied — the learner said no in the browser prompt ·
 * blocked — previously denied, the browser won't ask again (show settings guidance / fallback) ·
 * fallback — they chose the alternative ("Upload a file instead") · later — "Not now" or dismissed ·
 * unsupported — the API isn't available here.
 */
export type PrimerResult = 'granted' | 'denied' | 'blocked' | 'fallback' | 'later' | 'unsupported';

/**
 * PM1 Camera (203:8534 · 203:8660) and PM2 Notifications (203:8789 · 203:8887 · 203:8988) primers.
 * Explain first, then trigger the real browser prompt only if the learner opts in, so a "no" here never
 * burns the one-shot browser prompt. "Not now" for notifications is remembered for the session.
 */
@Service()
export class PermissionPrimer {
  private readonly overlay = inject(OverlayService);
  private readonly win = inject(DOCUMENT).defaultView;
  private notificationsDeferred = false;

  async ask(kind: PrimedPermission): Promise<PrimerResult> {
    const current = await this.state(kind);
    if (current === 'unsupported' || current === 'granted' || current === 'blocked') return current;
    if (kind === 'notifications' && this.notificationsDeferred) return 'later';

    const ref = this.overlay.adaptive<MuniPrompt, MuniPromptData, MuniPromptResult>(MuniPrompt, {
      data: kind === 'camera' ? CAMERA : NOTIFICATIONS,
      size: 'sm',
    });
    const choice = await firstValueFrom(ref.closed);

    if (choice !== 'primary') {
      if (kind === 'notifications') this.notificationsDeferred = true;
      return kind === 'camera' && choice === 'secondary' ? 'fallback' : 'later';
    }
    return this.request(kind);
  }

  private async state(
    kind: PrimedPermission,
  ): Promise<'granted' | 'blocked' | 'prompt' | 'unsupported'> {
    const nav = this.win?.navigator;
    if (kind === 'notifications') {
      const N = this.win && 'Notification' in this.win ? this.win.Notification : undefined;
      if (!N) return 'unsupported';
      return N.permission === 'granted'
        ? 'granted'
        : N.permission === 'denied'
          ? 'blocked'
          : 'prompt';
    }
    if (!nav?.mediaDevices?.getUserMedia) return 'unsupported';
    try {
      const status = await nav.permissions?.query({ name: 'camera' as PermissionName });
      if (status?.state === 'granted') return 'granted';
      if (status?.state === 'denied') return 'blocked';
    } catch {
      /* Firefox/Safari may not support querying camera; fall through to prompt */
    }
    return 'prompt';
  }

  private async request(kind: PrimedPermission): Promise<PrimerResult> {
    const win = this.win;
    if (!win) return 'unsupported';
    try {
      if (kind === 'notifications') {
        const result = await win.Notification.requestPermission();
        return result === 'granted' ? 'granted' : 'denied';
      }
      const stream = await win.navigator.mediaDevices.getUserMedia({ video: true });
      // The capture screen opens its own stream; this one only unlocks the permission.
      stream.getTracks().forEach((t) => t.stop());
      return 'granted';
    } catch {
      return 'denied';
    }
  }
}

const CAMERA: MuniPromptData = {
  title: $localize`:@@primer.camera.title:Snap your CV with the camera?`,
  body: $localize`:@@primer.camera.body:Skillmuni needs your camera to take a photo of your printed CV. We only use it to read the CV — you can delete the photo anytime.`,
  primary: $localize`:@@primer.camera.allow:Allow camera`,
  secondary: $localize`:@@primer.camera.upload:Upload a file instead`,
};

const NOTIFICATIONS: MuniPromptData = {
  title: $localize`:@@primer.notify.title:Want a ping when Muni’s done?`,
  body: $localize`:@@primer.notify.body:We’ll only notify you about your CV, quests and job matches. Turn it off anytime in Settings.`,
  primary: $localize`:@@primer.notify.allow:Turn on notifications`,
  secondary: $localize`:@@primer.notify.later:Not now`,
};
