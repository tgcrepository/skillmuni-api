import { TestBed } from '@angular/core/testing';
import { PermissionPrimer } from './permission-primer';

describe('PermissionPrimer (PM1 / PM2)', () => {
  afterEach(() => {
    document.querySelector('.cdk-overlay-container')?.replaceChildren();
    vi.unstubAllGlobals();
  });

  async function clickIn(label: string): Promise<void> {
    await vi.waitFor(() => expect(document.querySelector('.sm-pane')).toBeTruthy());
    const btn = [
      ...document.querySelectorAll<HTMLButtonElement>('.sm-pane button[sm-button]'),
    ].find((b) => b.textContent?.includes(label));
    btn?.click();
  }

  it('camera: "Upload a file instead" returns fallback without triggering the browser prompt', async () => {
    const getUserMedia = vi.fn();
    Object.defineProperty(navigator, 'mediaDevices', {
      value: { getUserMedia },
      configurable: true,
    });
    const result = TestBed.inject(PermissionPrimer).ask('camera');
    expect(document.querySelector('.sm-pane')?.textContent ?? '').toBe('');
    await clickIn('Upload a file instead');
    await expect(result).resolves.toBe('fallback');
    expect(getUserMedia).not.toHaveBeenCalled();
  });

  it('notifications: opting in calls the browser prompt; "Not now" is remembered', async () => {
    const requestPermission = vi.fn().mockResolvedValue('granted');
    vi.stubGlobal('Notification', { permission: 'default', requestPermission });
    const primer = TestBed.inject(PermissionPrimer);

    const first = primer.ask('notifications');
    await clickIn('Not now');
    await expect(first).resolves.toBe('later');
    await expect(primer.ask('notifications')).resolves.toBe('later');
    expect(requestPermission).not.toHaveBeenCalled();
  });

  it('already granted or blocked skips the primer', async () => {
    vi.stubGlobal('Notification', { permission: 'denied', requestPermission: vi.fn() });
    await expect(TestBed.inject(PermissionPrimer).ask('notifications')).resolves.toBe('blocked');
    expect(document.querySelector('.sm-pane')).toBeNull();
  });
});
