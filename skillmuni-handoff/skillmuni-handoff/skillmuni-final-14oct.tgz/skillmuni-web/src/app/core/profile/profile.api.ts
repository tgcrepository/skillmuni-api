import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';
import { IconName } from '../../shared/ui/icon/icons';

/** Badge rarity = how many learners own it (Figma Badge Medal 169:4668). */
export type BadgeRarity = 'common' | 'rare' | 'epic' | 'legendary';

export interface ShowcaseBadge {
  readonly id: string;
  readonly name: string;
  readonly icon: IconName;
  /** Artwork for the badge (quest badges use the quest's 3D illustration, corrections #24). */
  readonly image?: string | null;
  readonly rarity: BadgeRarity;
}

export type StrengthTaskId = 'contact' | 'name' | 'photo' | 'skills' | 'drivers';

export interface StrengthTask {
  readonly id: StrengthTaskId;
  readonly label: string;
  readonly xp: number;
  readonly done: boolean;
}

export type PrivateField = 'mobile' | 'email' | 'gender' | 'dob' | 'id';

/** Contact details change only after a one-time code to the new address (A-273). */
export type ContactKind = 'mobile' | 'email';

/** Private details always arrive masked; the eye asks the server for the real value. */
export interface MaskedField {
  readonly key: PrivateField;
  readonly label: string;
  readonly masked: string;
  /** Nothing to reveal yet (e.g. date of birth never given). */
  readonly empty: boolean;
}

/** Profile v2 · Player ID (Figma 186:6669). */
export interface PlayerProfile {
  readonly playerId: string;
  readonly name: string;
  readonly initials: string;
  readonly title: string;
  /** ISO date */
  readonly joined: string;
  readonly photoUrl: string | null;
  readonly level: number;
  readonly xp: number;
  /** XP total where the next level starts. */
  readonly nextLevelXp: number;
  /** XP total where the current level started. */
  readonly levelStartXp: number;
  readonly batchRank: number | null;
  readonly bestSkill: string | null;
  readonly archetype: {
    readonly name: string;
    readonly blurb: string;
    /** Corrections #21: shown as a showcase card — the archetype's emoji and top 3 drivers. */
    readonly emoji?: string;
    readonly traits?: readonly string[];
  } | null;
  readonly stats: {
    readonly streakDays: number;
    readonly badges: number;
    readonly learningHours: number;
  };
  readonly strength: { readonly percent: number; readonly tasks: readonly StrengthTask[] };
  readonly showcase: {
    readonly pinned: readonly ShowcaseBadge[];
    readonly next: {
      readonly name: string;
      readonly icon: IconName;
      /** Artwork for the badge (quest badges use the quest's 3D illustration, corrections #24). */
      readonly image?: string | null;
      readonly percent: number;
    } | null;
  };
  readonly privateFields: readonly MaskedField[];
  readonly skills: readonly string[];
}

export type Gender = 'female' | 'male' | 'non-binary' | 'rather-not';

export interface ProfileEdit {
  readonly skills: readonly string[];
  readonly gender: Gender;
  /** ISO date or '' */
  readonly dob: string;
}

/** Saving a change that completes a strength task returns the XP it earned. */
export interface ProfileSaved {
  readonly profile: PlayerProfile;
  readonly xpEarned: number;
}

export interface ProfileApi {
  profile(): Observable<PlayerProfile>;
  reveal(field: PrivateField): Observable<{ readonly value: string }>;
  /** Current editable values (unmasked: only fetched when the learner opens Edit). */
  editable(): Observable<
    ProfileEdit & {
      readonly skillOptions: readonly string[];
      readonly mobile: string;
      readonly email: string;
    }
  >;
  save(edit: ProfileEdit): Observable<ProfileSaved>;
  /** Send a code to the new mobile or email; resolves with where it went. */
  sendContactCode(kind: ContactKind, value: string): Observable<{ readonly sentTo: string }>;
  /** Check the code; the new value is saved only when it matches. */
  verifyContact(kind: ContactKind, value: string, code: string): Observable<void>;
  uploadPhoto(file: File): Observable<ProfileSaved>;
}

@Service()
export class HttpProfileApi implements ProfileApi {
  private readonly api = inject(ApiClient);

  profile(): Observable<PlayerProfile> {
    return this.api.get('profile');
  }

  reveal(field: PrivateField): Observable<{ readonly value: string }> {
    return this.api.post('profile/reveal', { field });
  }

  editable(): Observable<
    ProfileEdit & {
      readonly skillOptions: readonly string[];
      readonly mobile: string;
      readonly email: string;
    }
  > {
    return this.api.get('profile/edit');
  }

  sendContactCode(kind: ContactKind, value: string): Observable<{ readonly sentTo: string }> {
    return this.api.post('profile/contact/code', { kind, value });
  }

  verifyContact(kind: ContactKind, value: string, code: string): Observable<void> {
    return this.api.post('profile/contact/verify', { kind, value, code });
  }

  save(edit: ProfileEdit): Observable<ProfileSaved> {
    return this.api.put('profile', edit);
  }

  uploadPhoto(file: File): Observable<ProfileSaved> {
    const body = new FormData();
    body.append('photo', file);
    return this.api.post('profile/photo', body);
  }
}

export const PROFILE_API = new InjectionToken<ProfileApi>('PROFILE_API', {
  factory: () => inject(HttpProfileApi),
});
