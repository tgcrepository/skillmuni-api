import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

/** Documents DigiLocker issues that can confirm identity in India (A-272). */
export type DigiDoc = 'aadhaar' | 'pan' | 'driving-licence';

/**
 * A government ID linked through DigiLocker (A-272). Skillmuni never receives or stores the full
 * number or a copy of the document: only which document, its last 4 characters, and the verified
 * details the learner agreed to share.
 */
export interface LinkedId {
  readonly doc: DigiDoc;
  /** e.g. "XXXX XXXX 1234" (Aadhaar) or "XXXXXX123F" (PAN) — the server masks it. */
  readonly masked: string;
  readonly last4: string;
  /** Verified by the issuer, ISO date (yyyy-mm-dd). */
  readonly birthday: string | null;
  readonly name: string | null;
  readonly verifiedAt: string;
}

export interface IdentityApi {
  /** Real flow: the server returns DigiLocker's consent URL for this document. */
  start(doc: DigiDoc): Observable<{ readonly authorizeUrl: string }>;
  /** Swap the consent code DigiLocker returned for the masked, verified record. */
  link(doc: DigiDoc, code: string): Observable<LinkedId>;
  current(): Observable<LinkedId | null>;
  unlink(): Observable<void>;
}

@Service()
export class HttpIdentityApi implements IdentityApi {
  private readonly api = inject(ApiClient);

  start(doc: DigiDoc): Observable<{ readonly authorizeUrl: string }> {
    return this.api.post('me/identity/digilocker/start', { doc });
  }

  link(doc: DigiDoc, code: string): Observable<LinkedId> {
    return this.api.post('me/identity/digilocker/link', { doc, code });
  }

  current(): Observable<LinkedId | null> {
    return this.api.get('me/identity');
  }

  unlink(): Observable<void> {
    return this.api.delete('me/identity');
  }
}

export const IDENTITY_API = new InjectionToken<IdentityApi>('IDENTITY_API', {
  factory: () => inject(HttpIdentityApi),
});
