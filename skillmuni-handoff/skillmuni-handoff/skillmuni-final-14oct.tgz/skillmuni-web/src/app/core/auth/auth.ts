import { Service, inject, signal } from '@angular/core';
import { Observable, finalize, firstValueFrom, tap, timeout } from 'rxjs';
import { Session } from '../session/session';
import { AUTH_API, AuthUser, GoogleSignIn } from './auth.api';

const RESTORE_TIMEOUT = 4000;

/** Signed-in learner + the post-login redirect. Screens call the AuthApi through here. */
@Service()
export class Auth {
  private readonly api = inject(AUTH_API);
  private readonly session = inject(Session);

  readonly user = signal<AuthUser | null>(null);

  verifyOtp(phone: string, code: string): Observable<AuthUser> {
    return this.api.verifyOtp(phone, code).pipe(tap((u) => this.signedIn(u)));
  }

  verifyEmailLogin(email: string, code: string): Observable<AuthUser> {
    return this.api.verifyEmailLogin(email, code).pipe(tap((u) => this.signedIn(u)));
  }

  verifyEmail(email: string, code: string): Observable<AuthUser> {
    return this.api.verifyEmail(email, code).pipe(tap((u) => this.signedIn(u)));
  }

  googleSignIn(credential: string): Observable<GoogleSignIn> {
    return this.api.googleSignIn(credential).pipe(tap((r) => this.signedIn(r.user)));
  }

  loginWithPassword(email: string, password: string): Observable<AuthUser> {
    return this.api.loginWithPassword(email, password).pipe(tap((u) => this.signedIn(u)));
  }

  /** Sign-in that happened outside AuthApi (e.g. verifying an institute claim link). */
  adopt(user: AuthUser): void {
    this.signedIn(user);
  }

  /** A-277: a new profile photo shows in the top bar straight away. */
  setPhoto(photoUrl: string | null): void {
    this.user.update((u) => (u ? { ...u, photoUrl } : u));
  }

  /** Boot: pick up an existing server session (cookie) so a reload doesn't log the learner out (A-88). */
  async restore(): Promise<void> {
    try {
      this.signedIn(await firstValueFrom(this.api.me().pipe(timeout(RESTORE_TIMEOUT))));
    } catch {
      /* no session — stay signed out */
    }
  }

  logout(): Observable<void> {
    // Signed out locally even when the server call fails, so Log in never bounces back.
    return this.api.logout().pipe(
      finalize(() => {
        this.user.set(null);
        this.session.end();
      }),
    );
  }

  /** Where to go after logging in: back to where SE1 interrupted, else the homescreen (A-158). */
  nextUrl(returnUrl: string | null | undefined): string {
    return returnUrl &&
      returnUrl.startsWith('/') &&
      !returnUrl.startsWith('//') &&
      !returnUrl.startsWith('/login')
      ? returnUrl
      : '/home';
  }

  private signedIn(user: AuthUser): void {
    forgetOtherLearner(user.id);
    this.user.set(user);
    this.session.start();
  }
}

const LAST_USER = 'sm_last_user';
/** Per-learner UI memory (filters, nudges, drafts). Mock-backend stores are not ours to clear. */
const OWN = /^sm_(?!mock_|persona_|last_user)/;

/**
 * A different learner on this device (e.g. a new account after logging out) must not inherit the
 * previous learner's saved filters, nudges or assessment backup (A-232).
 */
function forgetOtherLearner(id: string): void {
  try {
    const last = sessionStorage.getItem(LAST_USER);
    if (last && last !== id) {
      for (const store of [sessionStorage, localStorage])
        for (const k of Object.keys(store)) if (OWN.test(k)) store.removeItem(k);
    }
    sessionStorage.setItem(LAST_USER, id);
  } catch {
    /* storage unavailable */
  }
}
