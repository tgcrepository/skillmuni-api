import { TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, provideRouter } from '@angular/router';
import { Session } from '../session/session';
import { requireGuest, requireSession } from './auth.guard';

const run = (guard: typeof requireGuest, url = '/x') =>
  TestBed.runInInjectionContext(() =>
    guard({} as ActivatedRouteSnapshot, { url } as RouterStateSnapshot),
  );

describe('auth guards', () => {
  beforeEach(() => TestBed.configureTestingModule({ providers: [provideRouter([])] }));

  it('requireGuest lets a signed-out learner see Log in, and sends a signed-in one to the Lobby', () => {
    expect(run(requireGuest)).toBe(true);
    TestBed.inject(Session).status.set('active');
    const to = run(requireGuest) as UrlTree;
    expect(to.toString()).toBe('/home');
  });

  it('requireSession sends a signed-out learner to Log in with the return URL', () => {
    const to = run(requireSession, '/stats') as UrlTree;
    expect(to.toString()).toBe('/login?returnUrl=%2Fstats');
  });
});
