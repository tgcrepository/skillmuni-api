import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Session } from '../session/session';

/** Signed-in only. Otherwise go to login and come back afterwards. */
export const requireSession: CanActivateFn = (_route, state) => {
  const session = inject(Session);
  if (session.status() === 'active') return true;
  return inject(Router).createUrlTree(['/login'], { queryParams: { returnUrl: state.url } });
};

/** Signed-out only: a signed-in learner opening Log in or Sign up goes to the Lobby instead. */
export const requireGuest: CanActivateFn = () => {
  const session = inject(Session);
  if (session.status() !== 'active') return true;
  return inject(Router).createUrlTree(['/home']);
};
