import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

export interface AuthUser {
  readonly id: string;
  readonly firstName: string;
  readonly email?: string;
  readonly phone?: string;
  /** Profile photo for the top bar (A-277). */
  readonly photoUrl?: string | null;
}

export interface OtpChallenge {
  /** Masked or formatted number the code went to, e.g. "+91 98765 43210". */
  readonly sentTo: string;
  /** Seconds until "Resend" unlocks. */
  readonly resendIn: number;
  readonly triesLeft: number;
}

export interface ResetRequested {
  readonly resendIn: number;
  /** Minutes the reset link stays valid. */
  readonly validFor: number;
}

export interface Registration {
  readonly firstName: string;
  readonly lastName: string;
  readonly email: string;
  readonly password: string;
  readonly consent: boolean;
}

export interface EmailChallenge {
  readonly email: string;
  readonly resendIn: number;
  /** Minutes the code stays valid. */
  readonly validFor: number;
  readonly triesLeft: number;
}

/**
 * Error codes in ApiError.fieldErrors['code'] the auth screens map to states:
 * invalid-code · code-expired · too-many-tries · account-locked · wrong-credentials ·
 * account-not-found (404 from a send-code call: that mobile / email isn't registered, A-308).
 */
export type AuthErrorCode =
  | 'invalid-code'
  | 'code-expired'
  | 'too-many-tries'
  | 'account-locked'
  | 'wrong-credentials'
  | 'account-not-found';

/**
 * A-308: what login hands sign-up (router navigation state, never the URL) when the mobile or
 * email it was given has no account.
 */
export interface SignupPrefill {
  readonly from: 'login';
  readonly email?: string;
  /** Formatted for display, e.g. "+91 91234 56789". */
  readonly phone?: string;
}

export interface AuthApi {
  /** 404 account-not-found when no learner has this mobile (A-308). */
  sendOtp(phone: string): Observable<OtpChallenge>;
  verifyOtp(phone: string, code: string): Observable<AuthUser>;
  /** Email login (A-159): a 6-digit code to the inbox, no password. 404 account-not-found (A-308). */
  sendEmailLoginCode(email: string): Observable<OtpChallenge>;
  verifyEmailLogin(email: string, code: string): Observable<AuthUser>;
  loginWithPassword(email: string, password: string): Observable<AuthUser>;
  requestPasswordReset(email: string): Observable<ResetRequested>;
  logout(): Observable<void>;
  /** The signed-in learner from the session cookie, or a 401 when there is none. */
  me(): Observable<AuthUser>;
  register(data: Registration): Observable<EmailChallenge>;
  verifyEmail(email: string, code: string): Observable<AuthUser>;
  resendEmailCode(email: string): Observable<EmailChallenge>;
  /** A-253: exchange a Google ID token; `isNew` = this Google account just created a learner. */
  googleSignIn(credential: string): Observable<GoogleSignIn>;
}

export interface GoogleSignIn {
  readonly user: AuthUser;
  readonly isNew: boolean;
}

/** HTTP implementation. The mock backend (MSW) serves the same routes in development. */
@Service()
export class HttpAuthApi implements AuthApi {
  private readonly api = inject(ApiClient);
  private readonly opts = { skipSessionCheck: true } as const;

  sendOtp(phone: string): Observable<OtpChallenge> {
    return this.api.post('auth/otp', { phone }, this.opts);
  }

  verifyOtp(phone: string, code: string): Observable<AuthUser> {
    return this.api.post('auth/otp/verify', { phone, code }, this.opts);
  }

  sendEmailLoginCode(email: string): Observable<OtpChallenge> {
    return this.api.post('auth/email/login-code', { email }, this.opts);
  }

  verifyEmailLogin(email: string, code: string): Observable<AuthUser> {
    return this.api.post('auth/email/login-verify', { email, code }, this.opts);
  }

  loginWithPassword(email: string, password: string): Observable<AuthUser> {
    return this.api.post('auth/login', { email, password }, this.opts);
  }

  requestPasswordReset(email: string): Observable<ResetRequested> {
    return this.api.post('auth/password-reset', { email }, this.opts);
  }

  logout(): Observable<void> {
    return this.api.post('auth/logout', {}, this.opts);
  }

  me(): Observable<AuthUser> {
    return this.api.get('session', this.opts);
  }

  register(data: Registration): Observable<EmailChallenge> {
    return this.api.post('auth/register', data, this.opts);
  }

  verifyEmail(email: string, code: string): Observable<AuthUser> {
    return this.api.post('auth/email/verify', { email, code }, this.opts);
  }

  googleSignIn(credential: string): Observable<GoogleSignIn> {
    return this.api.post('auth/google', { credential }, this.opts);
  }

  resendEmailCode(email: string): Observable<EmailChallenge> {
    return this.api.post('auth/email/resend', { email }, this.opts);
  }
}

export const AUTH_API = new InjectionToken<AuthApi>('AUTH_API', {
  factory: () => inject(HttpAuthApi),
});
