import { HttpClient, HttpEvent, HttpEventType } from '@angular/common/http';
import { InjectionToken, Service, inject } from '@angular/core';
import { Observable, catchError, filter, map, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiClient } from '../api/api-client';
import { toApiError } from '../api/api-error';
import { Connectivity } from '../network/connectivity';

/** Trophy file upload progress, then the stored file id. */
export type TrophyUploadEvent =
  | { readonly kind: 'progress'; readonly percent: number }
  | { readonly kind: 'done'; readonly fileId: string };

export interface LinkCheck {
  /** The learner's name was found on the page → "Verified". */
  readonly verified: boolean;
}

export interface ImportedTrophy {
  readonly name: string;
  readonly issuer: string;
  readonly issuedOn: string;
  readonly credentialId: string;
}

/**
 * Q4 trophy shelf backend (Figma §7): server-side credential link check (5 s timeout, never blocks saving),
 * certificate file upload, and the DigiLocker import (Skill India / NPTEL).
 */
export interface FlexApi {
  checkLink(url: string): Observable<LinkCheck>;
  upload(file: File): Observable<TrophyUploadEvent>;
  importDigilocker(): Observable<readonly ImportedTrophy[]>;
}

@Service()
export class HttpFlexApi implements FlexApi {
  private readonly http = inject(HttpClient);
  private readonly api = inject(ApiClient);
  private readonly connectivity = inject(Connectivity);

  checkLink(url: string): Observable<LinkCheck> {
    return this.api.post('me/trophies/check-link', { url });
  }

  upload(file: File): Observable<TrophyUploadEvent> {
    const body = new FormData();
    body.append('file', file, file.name);
    return this.http
      .post<{ fileId: string }>(`${environment.apiBaseUrl}/me/trophies/files`, body, {
        reportProgress: true,
        observe: 'events',
        withCredentials: true,
      })
      .pipe(
        filter(
          (e: HttpEvent<{ fileId: string }>) =>
            e.type === HttpEventType.UploadProgress || e.type === HttpEventType.Response,
        ),
        map((e): TrophyUploadEvent => {
          if (e.type === HttpEventType.UploadProgress)
            return {
              kind: 'progress',
              percent: e.total ? Math.round((e.loaded / e.total) * 100) : 0,
            };
          return {
            kind: 'done',
            fileId: (e.type === HttpEventType.Response && e.body?.fileId) || '',
          };
        }),
        catchError((err: unknown) => throwError(() => toApiError(err, this.connectivity.online()))),
      );
  }

  importDigilocker(): Observable<readonly ImportedTrophy[]> {
    return this.api.post('me/trophies/digilocker', {});
  }
}

export const FLEX_API = new InjectionToken<FlexApi>('FLEX_API', {
  factory: () => inject(HttpFlexApi),
});
