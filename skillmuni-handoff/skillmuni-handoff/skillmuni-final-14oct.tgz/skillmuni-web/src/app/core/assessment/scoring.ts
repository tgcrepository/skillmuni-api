import {
  Answer,
  Archetype,
  DRIVER_IDS,
  DriverId,
  DriverScores,
  Notch,
  Pair,
} from './assessment.api';

/** Max coins one driver can collect: it appears in 8 pairs × 3 coins. */
export const DRIVER_MAX = 24;
/** 36 pairs × 3 coins. */
export const TOTAL_COINS = 108;

/** Coins for [This, That] at each notch: 3·0 · 2·1 · 1·2 · 0·3. */
export function split(notch: Notch): readonly [number, number] {
  return [3 - notch, notch];
}

export function isAnswered(a: Answer | undefined): a is Notch {
  return typeof a === 'number';
}

/** Coins per driver from the answers so far (skipped and unanswered pairs add nothing). */
export function scoreDrivers(pairs: readonly Pair[], answers: readonly Answer[]): DriverScores {
  const s = Object.fromEntries(DRIVER_IDS.map((d) => [d, 0])) as Record<DriverId, number>;
  pairs.forEach((p, i) => {
    const a = answers[i];
    if (!isAnswered(a)) return;
    const [left, right] = split(a);
    s[p.this.driver] += left;
    s[p.that.driver] += right;
  });
  return s;
}

/** Highest score first; ties keep the survey order A → I. */
export function rankDrivers(scores: DriverScores): DriverId[] {
  return [...DRIVER_IDS].sort(
    (a, b) => scores[b] - scores[a] || DRIVER_IDS.indexOf(a) - DRIVER_IDS.indexOf(b),
  );
}

/**
 * Archetype = best match on its dominant drivers (Figma note 268:22368). Tie-break (A-211, to
 * confirm): average of its secondary drivers ("± D or G" counts the stronger of the two), then
 * the order of the survey's reference table.
 */
export function matchArchetype(scores: DriverScores, archetypes: readonly Archetype[]): Archetype {
  const rated = archetypes.map((a, order) => {
    const dominant = a.dominant.reduce((t, d) => t + scores[d], 0);
    const extras = a.secondary.map((d) => scores[d]);
    if (a.eitherOf?.length) extras.push(Math.max(...a.eitherOf.map((d) => scores[d])));
    const secondary = extras.length ? extras.reduce((t, v) => t + v, 0) / extras.length : 0;
    return { a, dominant, secondary, order };
  });
  rated.sort((x, y) => y.dominant - x.dominant || y.secondary - x.secondary || x.order - y.order);
  const [best] = rated;
  if (!best) throw new Error('No archetypes to match');
  return best.a;
}

export type Band = 'high' | 'mid' | 'low';

/** Score bands for the breakdown copy (A-212): 17+ high · 9–16 mid · 0–8 low. */
export function band(score: number): Band {
  return score >= 17 ? 'high' : score >= 9 ? 'mid' : 'low';
}

/** About 10 s per pair (Figma B1 "~6 min" for 36). */
export function minutesLeft(remaining: number): number {
  return Math.max(1, Math.ceil((remaining * 10) / 60));
}
