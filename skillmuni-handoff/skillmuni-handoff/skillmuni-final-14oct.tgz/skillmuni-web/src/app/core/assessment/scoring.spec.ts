import { ARCHETYPES, PAIRS } from '../../../mocks/assessment.data';
import { Answer, DRIVER_IDS, DriverScores, Notch } from './assessment.api';
import {
  DRIVER_MAX,
  TOTAL_COINS,
  band,
  matchArchetype,
  rankDrivers,
  scoreDrivers,
  split,
} from './scoring';

const scores = (s: Partial<DriverScores>): DriverScores =>
  ({ A: 0, B: 0, C: 0, D: 0, E: 0, F: 0, G: 0, H: 0, I: 0, ...s }) as DriverScores;

describe('Career Drivers scoring', () => {
  it('has 36 pairs and every driver appears in exactly 8 of them (max 24)', () => {
    expect(PAIRS.length).toBe(36);
    for (const d of DRIVER_IDS) {
      const n = PAIRS.filter((p) => p.this.driver === d || p.that.driver === d).length;
      expect(n * 3).toBe(DRIVER_MAX);
    }
  });

  it('splits 3 coins as 3·0, 2·1, 1·2, 0·3', () => {
    expect(([0, 1, 2, 3] as Notch[]).map(split)).toEqual([
      [3, 0],
      [2, 1],
      [1, 2],
      [0, 3],
    ]);
  });

  it('totals 108 for any complete set of answers', () => {
    const answers: Answer[] = PAIRS.map((_, i) => (i % 4) as Notch);
    const s = scoreDrivers(PAIRS, answers);
    expect(Object.values(s).reduce((t, v) => t + v, 0)).toBe(TOTAL_COINS);
  });

  it('ignores skipped and unanswered pairs', () => {
    const answers: Answer[] = PAIRS.map(() => null);
    answers[0] = 0; // pair 1: all in A
    answers[1] = 'skip';
    expect(scoreDrivers(PAIRS, answers)).toEqual(scores({ A: 3 }));
  });

  it('gives a driver 24 when it wins every pair it is in', () => {
    const answers: Answer[] = PAIRS.map((p) =>
      p.this.driver === 'E' ? 0 : p.that.driver === 'E' ? 3 : 1,
    );
    expect(scoreDrivers(PAIRS, answers).E).toBe(24);
  });

  it('ranks highest first and keeps survey order on ties', () => {
    expect(rankDrivers(scores({ E: 18, G: 17, I: 14, A: 14 })).slice(0, 4)).toEqual([
      'E',
      'G',
      'A',
      'I',
    ]);
  });

  it('matches the archetype on its dominant drivers (Figma example → Creative Pathfinder)', () => {
    const s = scores({ A: 11, B: 9, C: 10, D: 8, E: 18, F: 9, G: 17, H: 12, I: 14 });
    expect(matchArchetype(s, ARCHETYPES).id).toBe('pathfinder');
  });

  it('breaks a dominant tie on the secondary drivers', () => {
    // People-First (F+H, secondary C B) vs Specialist (D+H, secondary G): both dominant = 30.
    const s = scores({ F: 15, D: 15, H: 15, C: 10, B: 10, G: 2 });
    expect(matchArchetype(s, ARCHETYPES).id).toBe('people-first');
    const t = scores({ F: 15, D: 15, H: 15, C: 2, B: 2, G: 10 });
    expect(matchArchetype(t, ARCHETYPES).id).toBe('specialist');
  });

  it('bands scores for the breakdown copy', () => {
    expect([24, 17, 16, 9, 8, 0].map(band)).toEqual(['high', 'high', 'mid', 'mid', 'low', 'low']);
  });
});
