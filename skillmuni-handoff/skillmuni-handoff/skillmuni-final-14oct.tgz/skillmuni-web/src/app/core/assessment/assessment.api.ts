import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

/** The 9 Career Drivers from the Career Drivers Survey 2025. */
export type DriverId = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G' | 'H' | 'I';
export const DRIVER_IDS: readonly DriverId[] = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'];

/**
 * One tap per pair (Figma note 268:22368): the notch picks one of the 4 valid 3-coin splits.
 * 0 = All in This (3·0) · 1 = Lean This (2·1) · 2 = Lean That (1·2) · 3 = All in That (0·3).
 * `null` = not reached yet, `'skip'` = skipped for now (asked again at the final check).
 */
export type Notch = 0 | 1 | 2 | 3;
export type Answer = Notch | 'skip' | null;

export interface Statement {
  readonly text: string;
  /** Hidden from the learner until the reveal (anti-bias). */
  readonly driver: DriverId;
}

export interface Pair {
  readonly n: number;
  readonly this: Statement;
  readonly that: Statement;
}

export interface Island {
  readonly n: number;
  readonly name: string;
  readonly emoji: string;
  /** First and last pair number (1-based, inclusive). */
  readonly from: number;
  readonly to: number;
}

export interface DriverInfo {
  readonly id: DriverId;
  readonly name: string;
  readonly emoji: string;
  readonly focus: string;
  readonly definition: string;
  readonly blurb: string;
  readonly strengthZones: string;
  readonly families: string;
}

export interface Archetype {
  readonly id: string;
  readonly name: string;
  readonly emoji: string;
  readonly dominant: readonly DriverId[];
  readonly secondary: readonly DriverId[];
  /** "± D or G": the stronger of these counts as a secondary driver. */
  readonly eitherOf?: readonly DriverId[];
  readonly roles: string;
  readonly redFlags: string;
  readonly summary: string;
}

export type DriverScores = Readonly<Record<DriverId, number>>;

export interface AssessmentState {
  readonly status: 'new' | 'in-progress' | 'done';
  readonly pairs: readonly Pair[];
  readonly islands: readonly Island[];
  readonly answers: readonly Answer[];
  /** 0-based index of the pair to show next. */
  readonly current: number;
  /** XP earned in this attempt so far (0 on retakes). */
  readonly xp: number;
  /** First attempt earns XP; retakes don't (Figma S2). */
  readonly earnsXp: boolean;
  readonly remind: boolean;
  readonly attempts: number;
}

export interface AttemptRef {
  readonly n: number;
  readonly date: string;
  readonly archetype: string;
}

export interface AssessmentResult {
  readonly attempt: number;
  readonly date: string;
  readonly scores: DriverScores;
  /** Highest first; ties keep survey order. */
  readonly ranking: readonly DriverId[];
  readonly archetype: Archetype;
  readonly drivers: readonly DriverInfo[];
  readonly previous: DriverScores | null;
  readonly attempts: readonly AttemptRef[];
  readonly xpEarned: number;
  readonly mandatoryCourses: number;
}

export interface SaveRequest {
  readonly answers: readonly Answer[];
  readonly current: number;
}

export interface SaveResponse {
  readonly xp: number;
  /** XP just earned by this save (an island cleared). */
  readonly xpEarned: number;
}

export interface AssessmentApi {
  state(): Observable<AssessmentState>;
  save(body: SaveRequest): Observable<SaveResponse>;
  submit(answers: readonly Answer[]): Observable<AssessmentResult>;
  result(attempt?: number): Observable<AssessmentResult>;
  restart(): Observable<AssessmentState>;
  retake(): Observable<AssessmentState>;
  setRemind(on: boolean): Observable<{ remind: boolean }>;
}

@Service()
export class HttpAssessmentApi implements AssessmentApi {
  private readonly api = inject(ApiClient);

  state(): Observable<AssessmentState> {
    return this.api.get('assessments/career');
  }

  save(body: SaveRequest): Observable<SaveResponse> {
    return this.api.put('assessments/career/answers', body);
  }

  submit(answers: readonly Answer[]): Observable<AssessmentResult> {
    return this.api.post('assessments/career/submit', { answers });
  }

  result(attempt?: number): Observable<AssessmentResult> {
    return this.api.get('assessments/career/result', attempt ? { params: { attempt } } : {});
  }

  restart(): Observable<AssessmentState> {
    return this.api.post('assessments/career/restart', {});
  }

  retake(): Observable<AssessmentState> {
    return this.api.post('assessments/career/retake', {});
  }

  setRemind(on: boolean): Observable<{ remind: boolean }> {
    return this.api.put('assessments/career/remind', { remind: on });
  }
}

export const ASSESSMENT_API = new InjectionToken<AssessmentApi>('ASSESSMENT_API', {
  providedIn: 'root',
  factory: () => inject(HttpAssessmentApi),
});
