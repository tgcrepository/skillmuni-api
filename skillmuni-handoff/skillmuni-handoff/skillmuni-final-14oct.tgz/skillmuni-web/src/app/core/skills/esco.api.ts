import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';

/**
 * ESCO — the European Skills, Competences, Qualifications and Occupations taxonomy (A-245).
 * Our server proxies ESCO's public search (`/search?type=skill&text=…&language=…`), keeps the
 * concept URI and preferred label, and maps each concept to one of our six deck categories (from
 * its ESCO skill group). Skill decks store the URI, so matching and analytics use ESCO codes.
 */
export type EscoSkillType = 'skill' | 'knowledge' | 'transversal';
export type EscoCategory = 'tech' | 'data' | 'creative' | 'business' | 'people' | 'trades';

export interface EscoSkill {
  /** ESCO concept URI, e.g. http://data.europa.eu/esco/skill/… */
  readonly uri: string;
  /** ESCO preferred label in the requested language. */
  readonly label: string;
  readonly type: EscoSkillType;
  readonly category: EscoCategory;
  /** ESCO category name, e.g. "Programming languages" (A-285). */
  readonly escoCategory?: string;
  /** ESCO alternative labels, used for "matched on …". */
  readonly alt?: readonly string[];
}

export interface EscoSearch {
  readonly total: number;
  readonly results: readonly EscoSkill[];
}

export interface EscoApi {
  search(text: string, language: string, limit?: number): Observable<EscoSearch>;
}

@Service()
export class HttpEscoApi implements EscoApi {
  private readonly api = inject(ApiClient);

  search(text: string, language: string, limit = 24): Observable<EscoSearch> {
    return this.api.get('skills/esco', { params: { q: text, lang: language, limit } });
  }
}

export const ESCO_API = new InjectionToken<EscoApi>('ESCO_API', {
  providedIn: 'root',
  factory: () => inject(HttpEscoApi),
});

/** "communicate with customers" → "Communicate with customers" (ESCO labels are lower case). */
export function escoDisplay(label: string): string {
  return label.charAt(0).toUpperCase() + label.slice(1);
}
