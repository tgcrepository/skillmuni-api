import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';
import { IconName } from '../../shared/ui/icon/icons';

/** "For you right now" card (Figma Muni Chat v2 · D1 180:5917). */
export interface MuniSuggestion {
  readonly id: string;
  readonly icon: IconName;
  readonly tone: 'success' | 'accent' | 'brand';
  readonly title: string;
  readonly detail: string;
  readonly cta: string;
  /** App route the CTA opens, or an intent to ask Muni. */
  readonly link?: string;
  readonly intent?: string;
}

/** "Or pick a vibe" topic tile — opens its own options as chips. */
export interface MuniTopic {
  readonly id: 'jobs' | 'learn' | 'assess' | 'me';
  readonly icon: IconName;
  readonly label: string;
  readonly options: number;
}

export interface MuniWelcome {
  readonly firstName: string;
  readonly intro: string;
  readonly suggestions: readonly MuniSuggestion[];
  readonly topics: readonly MuniTopic[];
  /** Launcher badge + one nudge per session. */
  readonly unread: number;
  readonly nudge: { readonly title: string; readonly body: string } | null;
}

/** Profile card: private fields arrive masked; the eye asks the server for the real value. */
export interface MuniProfileCard {
  readonly kind: 'profile';
  readonly initials: string;
  readonly name: string;
  readonly subtitle: string;
  readonly fields: readonly {
    readonly key: 'email' | 'mobile' | 'since';
    readonly label: string;
    readonly value: string;
    readonly masked: boolean;
  }[];
  readonly completeness: number;
  readonly nextStep: string;
}

export interface MuniStatsCard {
  readonly kind: 'stats';
  readonly items: readonly {
    readonly label: string;
    readonly value: string;
    readonly icon: IconName;
  }[];
  readonly link: { readonly label: string; readonly url: string };
}

export interface MuniListCard {
  readonly kind: 'list';
  readonly items: readonly {
    readonly title: string;
    readonly detail: string;
    readonly tag?: string;
    readonly url: string;
  }[];
}

export type MuniBlock =
  { readonly kind: 'text'; readonly text: string } | MuniProfileCard | MuniStatsCard | MuniListCard;

export interface MuniReply {
  readonly blocks: readonly MuniBlock[];
  /** Up to 3 follow-ups, each answerable in one tap. */
  readonly chips: readonly string[];
}

export interface MuniHistoryItem {
  readonly id: string;
  readonly title: string;
  readonly when: string;
  readonly messages: readonly { readonly from: 'me' | 'muni'; readonly text: string }[];
}

export interface MuniApi {
  welcome(): Observable<MuniWelcome>;
  /** `intent` is a topic id or chip text; free text goes in `text`. */
  ask(input: { readonly text: string; readonly intent?: string }): Observable<MuniReply>;
  reveal(field: 'email' | 'mobile'): Observable<{ readonly value: string }>;
  rate(messageId: string, helpful: boolean | null): Observable<void>;
  history(): Observable<readonly MuniHistoryItem[]>;
}

@Service()
export class HttpMuniApi implements MuniApi {
  private readonly api = inject(ApiClient);

  welcome(): Observable<MuniWelcome> {
    return this.api.get('muni/welcome');
  }

  ask(input: { readonly text: string; readonly intent?: string }): Observable<MuniReply> {
    return this.api.post('muni/messages', input);
  }

  reveal(field: 'email' | 'mobile'): Observable<{ readonly value: string }> {
    return this.api.post('muni/reveal', { field });
  }

  rate(messageId: string, helpful: boolean | null): Observable<void> {
    return this.api.put(`muni/messages/${encodeURIComponent(messageId)}/rating`, { helpful });
  }

  history(): Observable<readonly MuniHistoryItem[]> {
    return this.api.get('muni/history');
  }
}

export const MUNI_API = new InjectionToken<MuniApi>('MUNI_API', {
  factory: () => inject(HttpMuniApi),
});
