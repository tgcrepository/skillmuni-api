import { InjectionToken, Service, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../api/api-client';
import { StreakDay } from '../arena/arena.api';
import { BadgeRarity } from '../profile/profile.api';
import { IconName } from '../../shared/ui/icon/icons';

/* ---------- 1 · Rewards — Player HQ (Figma 161:4281) ---------- */

export interface DailyQuest {
  readonly id: string;
  readonly icon: IconName;
  /** Artwork for the badge (quest badges use the quest's 3D illustration, corrections #24). */
  readonly image?: string | null;
  readonly title: string;
  /** "98.86% done", "6 / 15 min" */
  readonly progressLabel: string;
  readonly percent: number;
  /** XP for clearing it. Coins aren't earned for now (A-302). */
  readonly xp: number;
  readonly done: boolean;
  readonly link: string;
}

export interface BadgeProgress {
  readonly id: string;
  readonly name: string;
  readonly icon: IconName;
  /** Artwork for the badge (quest badges use the quest's 3D illustration, corrections #24). */
  readonly image?: string | null;
  /** "98.86%", "2 / 3 days" */
  readonly progressLabel: string;
  readonly percent: number;
}

export interface ShowcaseSlot {
  readonly id: string;
  readonly name: string;
  readonly icon: IconName;
  /** Artwork for the badge (quest badges use the quest's 3D illustration, corrections #24). */
  readonly image?: string | null;
  readonly rarity: BadgeRarity;
}

export interface RewardsDashboard {
  readonly player: {
    readonly name: string;
    readonly initials: string;
    readonly title: string;
    readonly photoUrl: string | null;
    readonly level: number;
    readonly xp: number;
    readonly nextLevelXp: number;
    readonly batchRank: number | null;
  };
  readonly streak: { readonly days: number; readonly week: readonly StreakDay[] };
  readonly wallet: {
    readonly xp: number;
    readonly coins: number;
    readonly coinsEarned: number;
    readonly coinsSpent: number;
    readonly credits: number;
  };
  /** Three daily quests, reset at midnight. */
  readonly quests: { readonly resetsAt: string; readonly items: readonly DailyQuest[] };
  /** Always 6 slots: 3 pinned (null = empty) + 3 closest to unlock (note 177:7597). */
  readonly badges: {
    readonly earned: number;
    readonly total: number;
    readonly showcase: readonly (ShowcaseSlot | null)[];
    readonly upNext: readonly BadgeProgress[];
  };
  readonly rank: {
    readonly rank: number;
    readonly gapXp: number;
    readonly nextName: string;
  } | null;
  readonly learningHours: number;
}

/* ---------- 2 · Learning — Quest Log (Figma 161:4359) ---------- */

export type CourseStatus = 'in-progress' | 'not-started' | 'done';
export type CourseTone = 'arcane' | 'ember' | 'green' | 'amber' | 'pink' | 'blue';

export interface LearningCourse {
  readonly id: string;
  readonly title: string;
  readonly tone: CourseTone;
  readonly percent: number;
  readonly status: CourseStatus;
  readonly kind: string;
  readonly xpOnFinish: number;
  /** Days left; null = no deadline. */
  readonly deadlineDays: number | null;
  readonly timeEstHours: number | null;
  readonly cpdHours: number | null;
  readonly summary: string;
  readonly link: string;
}

export interface LearningDashboard {
  /** Sorted by the server: closest to done first. */
  readonly courses: readonly LearningCourse[];
  readonly currentId: string | null;
  /** Finish-line nudge (e.g. a module at 98.86%). */
  readonly nudge: string | null;
}

/* ---------- 3 · Assessments — Skill Stats (Figma 161:4439 · empty 161:4514) ---------- */

export type SkillTier = 'beginner' | 'intermediate' | 'advanced' | 'expert';

export interface AssessmentResult {
  readonly id: string;
  readonly title: string;
  readonly subtitle: string;
  readonly tier: SkillTier;
  /** 0–100 */
  readonly score: number;
  readonly correct: number;
  readonly total: number;
  /** ISO date */
  readonly completed: string;
  readonly retakeUrl: string;
}

export interface AssessmentsDashboard {
  readonly results: readonly AssessmentResult[];
  readonly available: number;
  readonly firstCardXp: number;
  readonly recommended: { readonly title: string; readonly url: string; readonly why: string };
}

/* ---------- My Badges (Figma 170:4660 · sheet 175:5480) ---------- */

export type BadgeCategory =
  'quests' | 'streaks' | 'learning' | 'quizzes' | 'assessments' | 'social' | 'special';
export type BadgeState = 'earned' | 'progress' | 'locked' | 'secret';

export interface Badge {
  readonly id: string;
  readonly name: string;
  readonly icon: IconName;
  /** Artwork for the badge (quest badges use the quest's 3D illustration, corrections #24). */
  readonly image?: string | null;
  readonly category: BadgeCategory;
  readonly rarity: BadgeRarity;
  readonly state: BadgeState;
  /** ISO date when earned. */
  readonly earnedOn: string | null;
  /** "3 / 5 Knooks"; null when there's nothing to count. */
  readonly progressLabel: string | null;
  readonly percent: number;
  readonly howTo: string;
  /** % of the batch that owns it (drives rarity). */
  readonly ownedPct: number;
  readonly cta: { readonly label: string; readonly url: string } | null;
  /** Tiered badges (Streak Master 3 · 7 · 30): tiers reached of total. */
  readonly tiers: { readonly reached: number; readonly total: number } | null;
  readonly pinned: boolean;
}

export interface BadgeCatalogue {
  readonly earned: number;
  readonly total: number;
  readonly badges: readonly Badge[];
}

export interface StatsApi {
  rewards(): Observable<RewardsDashboard>;
  learning(): Observable<LearningDashboard>;
  assessments(): Observable<AssessmentsDashboard>;
  badges(): Observable<BadgeCatalogue>;
  /** Up to 3 earned badge ids, in showcase order. */
  setShowcase(ids: readonly string[]): Observable<BadgeCatalogue>;
}

@Service()
export class HttpStatsApi implements StatsApi {
  private readonly api = inject(ApiClient);

  rewards(): Observable<RewardsDashboard> {
    return this.api.get('stats/rewards');
  }

  learning(): Observable<LearningDashboard> {
    return this.api.get('stats/learning');
  }

  assessments(): Observable<AssessmentsDashboard> {
    return this.api.get('stats/assessments');
  }

  badges(): Observable<BadgeCatalogue> {
    return this.api.get('badges');
  }

  setShowcase(ids: readonly string[]): Observable<BadgeCatalogue> {
    return this.api.put('badges/showcase', { ids });
  }
}

export const STATS_API = new InjectionToken<StatsApi>('STATS_API', {
  factory: () => inject(HttpStatsApi),
});

/** Placeholder tier floors (note 166:4703 "to confirm"): Expert 90 · Advanced 80 · Intermediate 60. */
export const TIER_FLOORS: Readonly<Record<SkillTier, number>> = {
  beginner: 0,
  intermediate: 60,
  advanced: 80,
  expert: 90,
};
export const TIER_ORDER: readonly SkillTier[] = ['beginner', 'intermediate', 'advanced', 'expert'];
