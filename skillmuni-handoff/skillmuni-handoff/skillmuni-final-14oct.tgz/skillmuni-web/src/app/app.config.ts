import {
  ApplicationConfig,
  ErrorHandler,
  inject,
  provideAppInitializer,
  provideBrowserGlobalErrorListeners,
  provideZonelessChangeDetection,
} from '@angular/core';
import {
  HttpInterceptorFn,
  provideHttpClient,
  withFetch,
  withInterceptors,
} from '@angular/common/http';
import {
  provideRouter,
  withComponentInputBinding,
  withInMemoryScrolling,
  withRouterConfig,
} from '@angular/router';
import { routes } from './app.routes';
import { apiErrorInterceptor } from './core/api/api-error.interceptor';
import { AppErrorHandler } from './core/errors/app-error-handler';
import { SessionExpiry } from './core/session/session-expiry';
import { Auth } from './core/auth/auth';
import { BackNav } from './core/layout/back-nav';

/** `backend` interceptors run last (closest to the network), e.g. the dev mock backend. */
export function createAppConfig(backend: readonly HttpInterceptorFn[] = []): ApplicationConfig {
  return {
    providers: [
      provideBrowserGlobalErrorListeners(),
      provideZonelessChangeDetection(),
      provideHttpClient(withFetch(), withInterceptors([apiErrorInterceptor, ...backend])),
      { provide: ErrorHandler, useClass: AppErrorHandler },
      // SE1 watcher lives for the whole app.
      provideAppInitializer(() => void inject(SessionExpiry)),
      // Back/Up history map must see the very first navigation (A-234).
      provideAppInitializer(() => void inject(BackNav)),
      // Restore a server session before the first route guard runs.
      provideAppInitializer(() => inject(Auth).restore()),
      provideRouter(
        routes,
        withComponentInputBinding(),
        withInMemoryScrolling({ scrollPositionRestoration: 'top', anchorScrolling: 'enabled' }),
        // Page ids in history.state let Back walk history instead of pushing (BackNav, A-234).
        withRouterConfig({ canceledNavigationResolution: 'computed' }),
        // Route entrance is a CSS fade on the new page (styles.scss, A-156); no View Transitions API, so a
        // busy device can never stall a navigation.
      ),
    ],
  };
}

export const appConfig = createAppConfig();
