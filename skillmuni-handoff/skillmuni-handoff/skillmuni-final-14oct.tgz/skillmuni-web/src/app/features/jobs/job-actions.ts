import { Service, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { AlertSettings, Application, Invitation, JOBS_API, Job } from '../../core/jobs/jobs.api';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { downloadIcs } from '../../shared/util/ics';
import {
  AlertsData,
  AlertsDialog,
  ApplicationDialog,
  ApplyData,
  ApplyDialog,
  DeclineDialog,
  SuggestDialog,
  TipsDialog,
  WithdrawDialog,
} from './jobs-dialogs';
import { FeedbackPrompt } from '../../core/feedback/feedback-prompt';

export const JOBS_LINKS = {
  available: '/jobs',
  matching: '/jobs/matching',
  invitations: '/jobs/invitations',
  bookmarked: '/jobs/bookmarked',
  applied: '/jobs/applied',
  profile: '/job-profile',
} as const;

/**
 * Everything a learner can do to a job, shared by the desktop panel and the tablet/mobile detail
 * page. Each action resolves with the updated record (or null when cancelled); `changed` ticks so
 * lists and tab counts refresh.
 */
@Service()
export class JobActions {
  private readonly api = inject(JOBS_API);
  private readonly feedback = inject(FeedbackPrompt);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);

  /** Bumped after any change; pages reload their lists and counts. */
  readonly changed = signal(0);
  /** Job ids applied to in this session (J15 success banner). */
  readonly justApplied = signal<ReadonlySet<string>>(new Set());

  private bump(): void {
    this.changed.update((n) => n + 1);
  }

  async toggleSave(job: Job): Promise<Job | null> {
    try {
      const next = await firstValueFrom(this.api.save(job.id, !job.saved));
      this.toast.show(
        next.saved
          ? $localize`:@@jobs.savedToast:Saved. We’ll remind you before it closes.`
          : $localize`:@@jobs.unsavedToast:Removed from saved jobs`,
        { tone: 'success' },
      );
      this.bump();
      return next;
    } catch {
      this.toast.show($localize`:@@jobs.saveFailed:Couldn’t update saved jobs. Try again.`, { tone: 'error' });
      return null;
    }
  }

  /** J14 → J15. */
  async apply(job: Job, invitationId?: string): Promise<Application | null> {
    const ref = this.overlay.adaptive<ApplyDialog, ApplyData, Application>(ApplyDialog, {
      data: { job, invitationId },
      autoFocus: 'input[type=radio]:checked',
    });
    const app = await firstValueFrom(ref.closed);
    if (!app) return null;
    this.justApplied.update((s) => new Set([...s, job.id]));
    this.feedback.moment('apply');
    this.toast.show($localize`:@@jobs.sentToast:Application sent.`, {
      tone: 'success',
      action: {
        label: $localize`:@@jobs.viewApplied:View in Applied Jobs`,
        run: () => void this.router.navigateByUrl(JOBS_LINKS.applied),
      },
    });
    this.bump();
    return app;
  }

  async share(job: Job): Promise<void> {
    const url = `${location.origin}/jobs/view/${job.id}`;
    const text = $localize`:@@jobs.shareText:${job.title}:title: at ${job.company}:company:`;
    try {
      if (navigator.share) {
        await navigator.share({ title: text, url });
        return;
      }
      await navigator.clipboard.writeText(url);
      this.toast.show($localize`:@@jobs.linkCopied:Link copied`, { tone: 'success' });
    } catch (e) {
      if ((e as DOMException)?.name !== 'AbortError')
        this.toast.show($localize`:@@jobs.shareFailed:Couldn’t share. Try again.`, { tone: 'error' });
    }
  }

  report(): void {
    this.toast.show($localize`:@@jobs.reported:Thanks. Our team will check this job within a day.`, { tone: 'success' });
  }

  /** Accept & apply opens the apply flow; Accept interview confirms the slot. */
  async accept(inv: Invitation): Promise<Invitation | null> {
    if (inv.type === 'apply') {
      const app = await this.apply(inv.job, inv.id);
      return app ? { ...inv, status: 'accepted' } : null;
    }
    try {
      const next = await firstValueFrom(this.api.respond(inv.id, 'accept'));
      this.toast.show($localize`:@@jobs.interviewAccepted:Interview confirmed. ${inv.recruiter.name}:name: will send the link.`, {
        tone: 'success',
        action: { label: $localize`:@@jobs.addCal:Add to calendar`, run: () => this.calendarInvite(inv) },
      });
      this.bump();
      return next;
    } catch {
      this.toast.show($localize`:@@jobs.respondFailed:Couldn’t send your reply. Try again.`, { tone: 'error' });
      return null;
    }
  }

  async decline(inv: Invitation): Promise<Invitation | null> {
    const ref = this.overlay.adaptive<DeclineDialog, Invitation, Invitation>(DeclineDialog, { data: inv, size: 'sm' });
    const next = await firstValueFrom(ref.closed);
    if (!next) return null;
    this.toast.show($localize`:@@jobs.declinedToast:Invitation declined`, { tone: 'success' });
    this.bump();
    return next;
  }

  async suggest(inv: Invitation): Promise<void> {
    const ref = this.overlay.adaptive<SuggestDialog, Invitation, Invitation>(SuggestDialog, { data: inv, size: 'sm' });
    const next = await firstValueFrom(ref.closed);
    if (next)
      this.toast.show($localize`:@@jobs.suggestSent:Sent to ${inv.recruiter.name}:name:. You’ll hear back here.`, { tone: 'success' });
  }

  async withdraw(app: Application): Promise<Application | null> {
    const ref = this.overlay.adaptive<WithdrawDialog, Application, Application>(WithdrawDialog, { data: app, size: 'sm' });
    const next = await firstValueFrom(ref.closed);
    if (!next) return null;
    this.toast.show($localize`:@@jobs.withdrawn:Application withdrawn`, { tone: 'success' });
    this.bump();
    return next;
  }

  viewApplication(app: Application): void {
    this.overlay.adaptive(ApplicationDialog, { data: app, size: 'sm' });
  }

  tips(): void {
    this.overlay.adaptive(TipsDialog, { size: 'sm' });
  }

  async alerts(search: string | null = null): Promise<void> {
    const ref = this.overlay.adaptive<AlertsDialog, AlertsData, AlertSettings>(AlertsDialog, { data: { search }, size: 'sm' });
    const s = await firstValueFrom(ref.closed);
    if (s)
      this.toast.show(
        s.on
          ? $localize`:@@jobs.alertsOn:Job alerts on (${s.frequency}:freq:)`
          : $localize`:@@jobs.alertsOff:Job alerts off`,
        { tone: 'success' },
      );
  }

  calendarApp(app: Application): void {
    if (!app.interview) return;
    downloadIcs({
      id: `interview-${app.id}`,
      title: $localize`:@@jobs.icsTitle:Interview · ${app.job.title}:title:, ${app.job.company}:company:`,
      start: app.interview.at,
      minutes: 30,
      description: app.interview.detail,
    });
  }

  calendarInvite(inv: Invitation): void {
    if (!inv.interviewAt) return;
    downloadIcs({
      id: `interview-${inv.id}`,
      title: $localize`:@@jobs.icsTitle:Interview · ${inv.job.title}:title:, ${inv.job.company}:company:`,
      start: inv.interviewAt,
      minutes: 30,
    });
  }
}
