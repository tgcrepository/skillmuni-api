import { Component, ElementRef, computed, inject, input, linkedSignal, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Application, Invitation, Job } from '../../core/jobs/jobs.api';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { eventWhen } from '../../shared/util/ics';
import { JOBS_LINKS, JobActions } from './job-actions';
import { WORK_MODE, posted } from './job-card';

/**
 * Job detail (Figma J1/J2 panel 272:23775, J7b match box, J9b invitation, J11 closing banner,
 * J12b application status, J15 sent). Desktop shows it as the right panel with a compact sticky
 * header once scrolled (J2); tablet and mobile show it as a page with a sticky Apply bar.
 */
@Component({
  selector: 'sm-job-detail',
  imports: [Button, Icon, RouterLink],
  templateUrl: './job-detail.html',
  styleUrl: './job-detail.scss',
  host: {
    '[class]': '"sm-job-detail sm-job-detail--" + mode()',
    '(scroll)': 'onScroll()',
  },
})
export class JobDetail {
  protected readonly actions = inject(JobActions);
  private readonly router = inject(Router);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);

  readonly job = input.required<Job>();
  readonly invite = input<Invitation | null>(null);
  readonly app = input<Application | null>(null);
  readonly mode = input<'panel' | 'page'>('panel');
  readonly showMatch = input(false);
  readonly bookmarkedView = input(false);

  protected readonly j = linkedSignal(() => this.job());
  protected readonly inv = linkedSignal(() => this.invite());
  protected readonly a = linkedSignal(() => this.app());
  protected readonly compact = signal(false);
  protected readonly busy = signal(false);

  protected readonly workMode = WORK_MODE;
  protected readonly links = JOBS_LINKS;
  protected readonly sent = computed(() => this.actions.justApplied().has(this.j().id));
  protected readonly meta = computed(() => {
    const app = this.a();
    if (app)
      return app.status === 'not-selected' || app.status === 'withdrawn'
        ? `${$localize`:@@jobs.appliedOn:Applied ${app.appliedOn}:date:`} · ${app.updated}`
        : $localize`:@@jobs.appliedCv:Applied ${app.appliedOn}:date: · CV: ${app.cv}:cv:`;
    const j = this.j();
    return $localize`:@@jobs.detailMeta:${posted(j.postedDays)}:posted: · ${j.applicants}:n: applicants · Apply by ${j.applyBy}:date:`;
  });

  protected readonly interviewWhen = computed(() => {
    const at = this.inv()?.interviewAt;
    return at ? eventWhen(at) : '';
  });

  protected onScroll(): void {
    if (this.mode() !== 'panel') return;
    this.compact.set(this.host.nativeElement.scrollTop > 220);
  }

  protected async apply(): Promise<void> {
    const app = await this.actions.apply(this.j(), this.inv()?.status === 'new' ? this.inv()?.id : undefined);
    if (app) {
      this.j.update((j) => ({ ...j, appliedOn: app.appliedOn }));
      if (this.inv()) this.inv.update((i) => (i ? { ...i, status: 'accepted' } : i));
    }
  }

  protected async save(): Promise<void> {
    if (this.busy()) return;
    this.busy.set(true);
    const next = await this.actions.toggleSave(this.j());
    this.busy.set(false);
    if (next) this.j.set(next);
  }

  protected async accept(): Promise<void> {
    const i = this.inv();
    if (!i) return;
    const next = await this.actions.accept(i);
    if (next) {
      this.inv.set(next);
      if (i.type === 'apply') this.j.update((j) => ({ ...j, appliedOn: $localize`:@@jobs.today:today` }));
    }
  }

  protected async decline(): Promise<void> {
    const i = this.inv();
    if (!i) return;
    const next = await this.actions.decline(i);
    if (next) this.inv.set(next);
  }

  protected async withdraw(): Promise<void> {
    const app = this.a();
    if (!app) return;
    const next = await this.actions.withdraw(app);
    if (next) this.a.set(next);
  }

  /** Reschedule reuses "Suggest another time" against the interview on this application. */
  protected reschedule(): void {
    const app = this.a();
    if (!app?.interview) return;
    void this.actions.suggest({
      id: app.id,
      job: app.job,
      recruiter: { name: app.job.company, initials: app.job.initials, title: '' },
      type: 'interview',
      interviewAt: app.interview.at,
      message: '',
      respondBy: '',
      daysLeft: 0,
      status: 'accepted',
    });
  }

  protected track(): void {
    void this.router.navigateByUrl(JOBS_LINKS.applied);
  }

  protected similar(): void {
    const app = this.a();
    if (!app) return;
    void this.router.navigate([JOBS_LINKS.available], { queryParams: { sector: app.job.sector } });
  }
}
