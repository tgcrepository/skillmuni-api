import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, ElementRef, computed, inject, signal, viewChild } from '@angular/core';
import { FormField, applyEach, form, required, submit } from '@angular/forms/signals';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import {
  AlertSettings,
  Application,
  ApplyInfo,
  Invitation,
  JOBS_API,
  Job,
} from '../../core/jobs/jobs.api';
import { Banner } from '../../shared/ui/banner/banner';
import { Button } from '../../shared/ui/button/button';
import { Checkbox } from '../../shared/ui/checkbox/checkbox';
import { Field } from '../../shared/ui/field/field';
import { Icon } from '../../shared/ui/icon/icon';
import { eventWhen } from '../../shared/util/ics';
import { Input } from '../../shared/ui/input/input';
import { SmDialog } from '../../shared/ui/overlay/dialog';
import { Radio } from '../../shared/ui/radio/radio';
import { RadioGroup } from '../../shared/ui/radio/radio-group';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { Switch } from '../../shared/ui/switch/switch';

const CV_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
const CV_MAX = 5 * 1024 * 1024;

export interface ApplyData {
  readonly job: Job;
  readonly invitationId?: string;
}

/** J14 · Apply — review & submit (Figma 277:30742). One screen, three numbered parts. */
@Component({
  selector: 'sm-apply-dialog',
  imports: [Banner, Button, Checkbox, Field, FormField, Icon, Input, Radio, RadioGroup, RouterLink, Skeleton, SmDialog],
  template: `
    <sm-dialog [title]="title" [subtitle]="subtitle">
      @if (info(); as i) {
        <form class="apply" novalidate (submit)="send($event)">
          <div class="step-head">
            <span class="n" aria-hidden="true">1</span>
            <h3 class="step" id="ap-1" i18n="@@jobs.apDetails">Your details</h3>
            <a class="edit" routerLink="/job-profile" (click)="dialog().close()" i18n="@@jobs.apEdit">Edit in profile</a>
          </div>
          <div class="who">
            <strong>{{ i.name }}</strong>
            <span>{{ i.contact }}</span>
          </div>

          <div class="step-head">
            <span class="n" aria-hidden="true">2</span>
            <h3 class="step" id="ap-2" i18n="@@jobs.apCv">CV</h3>
          </div>
          <sm-radio-group class="cvs" labelledBy="ap-2" [formField]="f.cvId">
            @for (cv of cvs(); track cv.id) {
              <sm-radio class="cv" [value]="cv.id">
                <span class="cv-row">
                  <sm-icon name="paperclip" size="sm" />
                  <span class="cv-text">
                    <span class="cv-name">{{ cv.name }}</span>
                    <span class="cv-meta">{{ cv.meta }}</span>
                  </span>
                </span>
              </sm-radio>
            }
          </sm-radio-group>
          <button type="button" class="upload" [disabled]="uploading()" (click)="pick()">
            <sm-icon [name]="uploading() ? 'spinner' : 'plus'" size="xs" />
            <ng-container i18n="@@jobs.apUpload">Upload a new CV (PDF or Word, max 5 MB)</ng-container>
          </button>
          <input
            #file
            class="sm-visually-hidden"
            type="file"
            accept=".pdf,.doc,.docx,application/pdf"
            tabindex="-1"
            aria-hidden="true"
            (change)="chosen($event)"
          />
          @if (uploadError()) {
            <p class="err" role="alert">{{ uploadError() }}</p>
          }

          @if (i.questions.length) {
            <div class="step-head">
              <span class="n" aria-hidden="true">3</span>
              <h3 class="step" i18n="@@jobs.apQs">{{ i.questions.length }} questions from {{ data.job.company }}</h3>
            </div>
            @for (q of i.questions; track q.id; let k = $index) {
              @if (q.kind === 'yes-no') {
                <div class="q">
                  <p class="q-text" [id]="'ap-q' + k">{{ q.text }} <span aria-hidden="true">*</span></p>
                  <sm-radio-group class="yn" [labelledBy]="'ap-q' + k" [formField]="f.answers[k]!">
                    <sm-radio value="Yes" i18n="@@ui.yes">Yes</sm-radio>
                    <sm-radio value="No" i18n="@@ui.no">No</sm-radio>
                  </sm-radio-group>
                  @if (answerError(k); as e) {
                    <p class="err" role="alert">{{ e }}</p>
                  }
                </div>
              } @else {
                <sm-field [label]="q.text" [error]="answerError(k)" required>
                  <sm-input [formField]="f.answers[k]!" />
                </sm-field>
              }
            }
          }

          <sm-checkbox class="consent" [formField]="f.consent">
            <ng-container i18n="@@jobs.apConsent"
              >Share my profile and selected CV with {{ data.job.company }} for this job.</ng-container
            >
          </sm-checkbox>
          @if (consentError()) {
            <p class="err" role="alert">{{ consentError() }}</p>
          }
          @if (failed()) {
            <sm-banner tone="error" i18n="@@jobs.apFailed">Couldn’t send your application. Try again.</sm-banner>
          }
          <div smDialogActions class="actions">
            <button sm-button type="submit" [loading]="busy()" i18n="@@jobs.apSubmit">Submit application</button>
            <button sm-button variant="secondary" type="button" (click)="dialog().close()" i18n="@@ui.cancel">Cancel</button>
          </div>
        </form>
      } @else {
        <div class="loading" aria-busy="true">
          <span class="sm-visually-hidden" role="status" i18n="@@jobs.apLoading">Getting your application ready…</span>
          <sm-skeleton shape="block" />
          <sm-skeleton shape="block" />
        </div>
      }
    </sm-dialog>
  `,
  styleUrl: './jobs-dialogs.scss',
})
export class ApplyDialog {
  protected readonly data = inject<ApplyData>(DIALOG_DATA);
  private readonly api = inject(JOBS_API);
  protected readonly dialog = viewChild.required(SmDialog);
  private readonly fileInput = viewChild<ElementRef<HTMLInputElement>>('file');

  protected readonly title = $localize`:@@jobs.apTitle:Apply to ${this.data.job.title}:title:`;
  protected readonly subtitle = $localize`:@@jobs.apSub:${this.data.job.company}:company: · ${this.data.job.city}:city: · Takes about 1 minute`;

  protected readonly info = signal<ApplyInfo | null>(null);
  protected readonly cvs = signal<ApplyInfo['cvs']>([]);
  protected readonly busy = signal(false);
  protected readonly failed = signal(false);
  protected readonly uploading = signal(false);
  protected readonly uploadError = signal('');

  protected readonly model = signal({ cvId: '', answers: [] as string[], consent: true });
  protected readonly f = form(this.model, (p) => {
    required(p.cvId, { message: $localize`:@@jobs.apCvReq:Pick a CV to send` });
    applyEach(p.answers, (a) => required(a, { message: $localize`:@@jobs.apAnsReq:Answer this to apply` }));
    required(p.consent, { message: $localize`:@@jobs.apConsentReq:Tick this to share your profile` });
  });

  constructor() {
    void firstValueFrom(this.api.applyInfo(this.data.job.id)).then((i) => {
      this.info.set(i);
      this.cvs.set(i.cvs);
      this.model.set({ cvId: i.cvs[0]?.id ?? '', answers: i.questions.map(() => ''), consent: true });
    });
  }

  protected answerError(k: number): string {
    const field = this.f.answers[k];
    if (!field) return '';
    const s = field();
    return s.touched() ? (s.errors()[0]?.message ?? '') : '';
  }

  protected readonly consentError = computed(() => {
    const s = this.f.consent();
    return s.touched() ? (s.errors()[0]?.message ?? '') : '';
  });

  protected pick(): void {
    this.fileInput()?.nativeElement.click();
  }

  protected async chosen(e: Event): Promise<void> {
    const input = e.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    if (!CV_TYPES.includes(file.type) || file.size > CV_MAX) {
      this.uploadError.set($localize`:@@jobs.apCvType:Use a PDF or Word file up to 5 MB.`);
      return;
    }
    this.uploadError.set('');
    this.uploading.set(true);
    try {
      const cv = await firstValueFrom(this.api.uploadCv(file));
      this.cvs.update((l) => [cv, ...l]);
      this.model.update((m) => ({ ...m, cvId: cv.id }));
    } catch {
      this.uploadError.set($localize`:@@jobs.apCvFailed:Couldn’t upload that CV. Try again.`);
    } finally {
      this.uploading.set(false);
    }
  }

  protected async send(e: Event): Promise<void> {
    e.preventDefault();
    if (this.busy()) return;
    await submit(this.f, async () => {
      this.busy.set(true);
      this.failed.set(false);
      try {
        const m = this.model();
        const questions = this.info()?.questions ?? [];
        const answers = Object.fromEntries(questions.map((q, i) => [q.id, m.answers[i] ?? '']));
        const app = await firstValueFrom(
          this.api.apply(this.data.job.id, { cvId: m.cvId, answers, invitationId: this.data.invitationId }),
        );
        this.dialog().close(app);
      } catch {
        this.failed.set(true);
      } finally {
        this.busy.set(false);
      }
      return undefined;
    });
  }
}

/** J10 · Decline invitation (Figma 277:24395). The reason is optional and private. */
@Component({
  selector: 'sm-decline-dialog',
  imports: [Button, Icon, Radio, RadioGroup, SmDialog],
  template: `
    <sm-dialog [title]="title" [subtitle]="subtitle">
      <p class="lead" id="dc-why" i18n="@@jobs.dcWhy">Tell us why (optional, helps us send better jobs)</p>
      <sm-radio-group labelledBy="dc-why" [value]="reason()" (valueChange)="reason.set($event)">
        @for (r of reasons; track r) {
          <sm-radio [value]="r">{{ r }}</sm-radio>
        }
      </sm-radio-group>
      <p class="info">
        <sm-icon name="info" size="sm" />
        <span i18n="@@jobs.dcPrivate">{{ firstName }} only sees that you declined, not your reason.</span>
      </p>
      <div smDialogActions class="actions">
        <button sm-button type="button" [loading]="busy()" (click)="confirm()" i18n="@@jobs.dcConfirm">Decline invitation</button>
        <button sm-button variant="secondary" type="button" (click)="dialog().close()" i18n="@@ui.cancel">Cancel</button>
      </div>
    </sm-dialog>
  `,
  styleUrl: './jobs-dialogs.scss',
})
export class DeclineDialog {
  protected readonly data = inject<Invitation>(DIALOG_DATA);
  private readonly api = inject(JOBS_API);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@jobs.dcTitle:Decline this invitation?`;
  protected readonly subtitle = `${this.data.recruiter.name} · ${this.data.job.company}`;
  protected readonly firstName = this.data.recruiter.name.split(' ')[0] ?? this.data.recruiter.name;
  protected readonly reasons = [
    $localize`:@@jobs.dc1:Not interested in this role`,
    $localize`:@@jobs.dc2:Location doesn’t work for me`,
    $localize`:@@jobs.dc3:Pay is too low`,
    $localize`:@@jobs.dc4:Already accepted another offer`,
    $localize`:@@jobs.dc5:Other`,
  ];
  protected readonly reason = signal<string | null>(this.reasons[0] ?? null);
  protected readonly busy = signal(false);

  protected async confirm(): Promise<void> {
    this.busy.set(true);
    try {
      const inv = await firstValueFrom(this.api.respond(this.data.id, 'decline', this.reason() ?? ''));
      this.dialog().close(inv);
    } finally {
      this.busy.set(false);
    }
  }
}

/** "Suggest another time" on an interview invite (button in J9b; dialog not drawn, A-224). */
@Component({
  selector: 'sm-suggest-dialog',
  imports: [Button, Field, FormField, Input, Radio, RadioGroup, SmDialog],
  template: `
    <sm-dialog [title]="title" [subtitle]="subtitle">
      <p class="lead" id="sg-when" i18n="@@jobs.sgWhen">When works for you?</p>
      <sm-radio-group labelledBy="sg-when" [value]="slot()" (valueChange)="slot.set($event)">
        @for (s of slots; track s) {
          <sm-radio [value]="s">{{ s }}</sm-radio>
        }
      </sm-radio-group>
      <sm-field i18n-label="@@jobs.sgNote" label="Note for the recruiter (optional)">
        <sm-input [formField]="f.note" />
      </sm-field>
      <div smDialogActions class="actions">
        <button sm-button type="button" [loading]="busy()" (click)="send()" i18n="@@jobs.sgSend">Send suggestion</button>
        <button sm-button variant="secondary" type="button" (click)="dialog().close()" i18n="@@ui.cancel">Cancel</button>
      </div>
    </sm-dialog>
  `,
  styleUrl: './jobs-dialogs.scss',
})
export class SuggestDialog {
  protected readonly data = inject<Invitation>(DIALOG_DATA);
  private readonly api = inject(JOBS_API);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@jobs.sgTitle:Suggest another time`;
  protected readonly subtitle = `${this.data.recruiter.name} · ${this.data.job.company}`;
  protected readonly slots = [
    $localize`:@@jobs.sg1:Fri, 11 Oct · Morning (10 AM – 1 PM)`,
    $localize`:@@jobs.sg2:Fri, 11 Oct · Afternoon (2 – 5 PM)`,
    $localize`:@@jobs.sg3:Mon, 14 Oct · Morning (10 AM – 1 PM)`,
  ];
  protected readonly slot = signal<string | null>(this.slots[0] ?? null);
  protected readonly model = signal({ note: '' });
  protected readonly f = form(this.model);
  protected readonly busy = signal(false);

  protected async send(): Promise<void> {
    this.busy.set(true);
    try {
      const note = [this.slot(), this.model().note].filter(Boolean).join(' · ');
      const inv = await firstValueFrom(this.api.respond(this.data.id, 'suggest', note));
      this.dialog().close(inv);
    } finally {
      this.busy.set(false);
    }
  }
}

/** J13 · Withdraw application (Figma 277:29247). */
@Component({
  selector: 'sm-withdraw-dialog',
  imports: [Button, Icon, SmDialog],
  template: `
    <sm-dialog [title]="title" [subtitle]="subtitle">
      <ul class="warn-list">
        <li>
          <sm-icon name="alert" size="sm" />
          <span i18n="@@jobs.wd1">{{ data.job.company }} will be told you’re no longer interested.</span>
        </li>
        @if (data.interview) {
          <li>
            <sm-icon name="alert" size="sm" />
            <span i18n="@@jobs.wd2">Your interview on {{ when }} will be cancelled.</span>
          </li>
        }
        <li>
          <sm-icon name="alert" size="sm" />
          <span i18n="@@jobs.wd3">You can’t reapply to this job for 30 days.</span>
        </li>
      </ul>
      <div smDialogActions class="actions">
        <button sm-button type="button" [loading]="busy()" (click)="confirm()" i18n="@@jobs.wdConfirm">Withdraw</button>
        <button sm-button variant="secondary" type="button" (click)="dialog().close()" i18n="@@jobs.wdKeep">Keep application</button>
      </div>
    </sm-dialog>
  `,
  styleUrl: './jobs-dialogs.scss',
})
export class WithdrawDialog {
  protected readonly data = inject<Application>(DIALOG_DATA);
  private readonly api = inject(JOBS_API);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@jobs.wdTitle:Withdraw your application?`;
  protected readonly subtitle = `${this.data.job.title} · ${this.data.job.company}`;
  protected readonly when = this.data.interview ? eventWhen(this.data.interview.at, false) : '';
  protected readonly busy = signal(false);

  protected async confirm(): Promise<void> {
    this.busy.set(true);
    try {
      this.dialog().close(await firstValueFrom(this.api.withdraw(this.data.id)));
    } finally {
      this.busy.set(false);
    }
  }
}

/** "View my application": what was sent (not drawn; A-224). */
@Component({
  selector: 'sm-application-dialog',
  imports: [Button, Icon, SmDialog],
  template: `
    <sm-dialog [title]="title" [subtitle]="subtitle">
      <dl class="sent">
        <div>
          <dt i18n="@@jobs.vaCv">CV</dt>
          <dd><sm-icon name="paperclip" size="xs" /> {{ data.cv }}</dd>
        </div>
        @for (a of data.answers; track a.q) {
          <div>
            <dt>{{ a.q }}</dt>
            <dd>{{ a.a }}</dd>
          </div>
        }
      </dl>
      <div smDialogActions class="actions">
        <button sm-button variant="secondary" type="button" (click)="dialog().close()" i18n="@@jobs.done">Done</button>
      </div>
    </sm-dialog>
  `,
  styleUrl: './jobs-dialogs.scss',
})
export class ApplicationDialog {
  protected readonly data = inject<Application>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@jobs.vaTitle:Your application`;
  protected readonly subtitle = $localize`:@@jobs.vaSub:${this.data.job.title}:title: · sent ${this.data.appliedOn}:date:`;
}

export interface AlertsData {
  /** Set when coming from J6 "Get alerts for this search". */
  readonly search: string | null;
}

/** Job alerts (header button; Glassdoor-style). Daily or weekly, per saved search (A-226). */
@Component({
  selector: 'sm-alerts-dialog',
  imports: [Button, Radio, RadioGroup, SmDialog, Switch],
  template: `
    <sm-dialog [title]="title">
      @if (settings(); as s) {
        <sm-switch class="is-block" [checked]="s.on" (checkedChange)="patch({ on: $event })">
          <span class="sw-title" i18n="@@jobs.alOn">Email and push me new jobs</span>
        </sm-switch>
        <p class="lead" id="al-freq" i18n="@@jobs.alFreq">How often</p>
        <sm-radio-group labelledBy="al-freq" [value]="s.frequency" (valueChange)="patch({ frequency: $any($event) })">
          <sm-radio value="daily" i18n="@@jobs.alDaily">Daily</sm-radio>
          <sm-radio value="weekly" i18n="@@jobs.alWeekly">Weekly</sm-radio>
        </sm-radio-group>
        <p class="lead" i18n="@@jobs.alSearches">Searches you follow</p>
        <ul class="searches">
          @for (q of s.searches; track q) {
            <li>{{ q }}</li>
          }
        </ul>
      }
      <div smDialogActions class="actions">
        <button sm-button type="button" [loading]="busy()" (click)="saveAll()" i18n="@@jobs.alSave">Save alerts</button>
        <button sm-button variant="secondary" type="button" (click)="dialog().close()" i18n="@@ui.cancel">Cancel</button>
      </div>
    </sm-dialog>
  `,
  styleUrl: './jobs-dialogs.scss',
})
export class AlertsDialog {
  protected readonly data = inject<AlertsData>(DIALOG_DATA);
  private readonly api = inject(JOBS_API);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@jobs.alTitle:Job alerts`;
  protected readonly settings = signal<AlertSettings | null>(null);
  protected readonly busy = signal(false);

  constructor() {
    void firstValueFrom(this.api.alerts()).then((s) => {
      const q = this.data.search;
      this.settings.set(q && !s.searches.includes(q) ? { ...s, on: true, searches: [q, ...s.searches] } : s);
    });
  }

  protected patch(p: Partial<AlertSettings>): void {
    this.settings.update((s) => (s ? { ...s, ...p } : s));
  }

  protected async saveAll(): Promise<void> {
    const s = this.settings();
    if (!s) return;
    this.busy.set(true);
    try {
      this.dialog().close(await firstValueFrom(this.api.setAlerts(s)));
    } finally {
      this.busy.set(false);
    }
  }
}

/** Interview tips (J12 interview card link). */
@Component({
  selector: 'sm-tips-dialog',
  imports: [Button, SmDialog],
  template: `
    <sm-dialog [title]="title">
      <ol class="tips">
        <li i18n="@@jobs.tip1">Test your camera, mic and internet 15 minutes before.</li>
        <li i18n="@@jobs.tip2">Read the job description again and pick 2 examples from your work or studies.</li>
        <li i18n="@@jobs.tip3">Sit somewhere quiet with light on your face.</li>
        <li i18n="@@jobs.tip4">Keep your CV open and a question ready for the recruiter.</li>
      </ol>
      <div smDialogActions class="actions">
        <button sm-button type="button" (click)="dialog().close()" i18n="@@jobs.gotIt">Got it</button>
      </div>
    </sm-dialog>
  `,
  styleUrl: './jobs-dialogs.scss',
})
export class TipsDialog {
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@jobs.tipsTitle:Interview tips`;
}
