import { Component, LOCALE_ID, computed, inject, input, output, signal } from '@angular/core';
import { FilterDef, keysOf } from '../../core/jobs/jobs-filters';
import { Facet, FacetOption, FilterState } from '../../core/jobs/jobs.api';
import { Checkbox } from '../../shared/ui/checkbox/checkbox';
import { Icon } from '../../shared/ui/icon/icon';
import { Switch } from '../../shared/ui/switch/switch';
import { alphabetical } from '../../shared/ui/internal/alphabetical';

const COLLAPSED = 3;

/**
 * Filter sections with live counts (Figma J3 274:22647 quick filter · J4 274:24332 all filters).
 * Options that would give 0 jobs are disabled; Role follows Sector and City follows State.
 */
/** Facets whose options are names, so they read A–Z. */
const NAMED_FACETS = new Set(['state', 'city', 'company', 'sector', 'industry', 'skill', 'skills', 'role']);

@Component({
  selector: 'sm-filters-panel',
  imports: [Checkbox, Icon, Switch],
  template: `
    @for (def of defs(); track def.key) {
      <section class="sec" [attr.aria-labelledby]="'fp-' + def.key + uid">
        <div class="sec-head">
          <h3 class="sec-title" [id]="'fp-' + def.key + uid">{{ def.label }}</h3>
          @if (selectedLabel(def); as s) {
            <span class="sel">{{ s }}</span>
          }
        </div>

        @switch (def.kind) {
          @case ('location') {
            <p class="note" i18n="@@jobs.cityNote">City list depends on the state you pick.</p>
            <label class="select">
              <span class="sm-visually-hidden" i18n="@@jobs.state">State</span>
              <select [value]="state()" (change)="setState($event)">
                <option value="" i18n="@@jobs.anyState">Any state</option>
                @for (o of opts('state'); track o.id) {
                  <option [value]="o.id">{{ o.label }}</option>
                }
              </select>
              <sm-icon name="chevron-down" size="sm" class="caret" />
            </label>
            <ul class="pills" i18n-aria-label="@@jobs.cities" aria-label="Cities">
              @for (o of opts('city'); track o.id) {
                <li>
                  <button
                    type="button"
                    class="pill"
                    [attr.aria-pressed]="has('city', o.id)"
                    [disabled]="!o.count && !has('city', o.id)"
                    (click)="toggle('city', o.id)"
                  >
                    {{ o.label }} · {{ o.count }}
                  </button>
                </li>
              }
            </ul>
            @if (opts('remote')[0]; as r) {
              <sm-switch
                class="is-block"
                [checked]="has('remote', 'yes')"
                (checkedChange)="setFlag('remote', $event)"
              >
                <span i18n="@@jobs.includeRemote">Include remote jobs ({{ r.count }})</span>
              </sm-switch>
            }
          }
          @case ('single') {
            <div class="opts" role="radiogroup" [attr.aria-labelledby]="'fp-' + def.key + uid">
              <label class="opt">
                <input
                  type="radio"
                  [name]="def.key + uid"
                  [checked]="!draft()[def.key]?.length"
                  (change)="setSingle(def.key, null)"
                />
                <span class="o-label" i18n="@@jobs.any">Any</span>
              </label>
              @for (o of opts(def.key); track o.id) {
                <label class="opt" [class.is-off]="!o.count && !has(def.key, o.id)">
                  <input
                    type="radio"
                    [name]="def.key + uid"
                    [checked]="has(def.key, o.id)"
                    [disabled]="!o.count && !has(def.key, o.id)"
                    (change)="setSingle(def.key, o.id)"
                  />
                  <span class="o-label">{{ o.label }}</span>
                  <span class="count">{{ o.count }}</span>
                </label>
              }
            </div>
            @if (def.key === 'pay' && learnership()) {
              <p class="note" i18n="@@jobs.payNote">
                Learnership selected, so stipends (per month) are included alongside salaries (per
                year).
              </p>
            }
          }
          @default {
            @if (def.key === 'role' && sectorNames(); as s) {
              <p class="note" i18n="@@jobs.roleNote">Showing roles in {{ s }}.</p>
            }
            @if (def.searchable) {
              <label class="search">
                <sm-icon name="search" size="sm" />
                <span class="sm-visually-hidden" i18n="@@jobs.searchIn"
                  >Search {{ def.label }}</span
                >
                <input
                  type="search"
                  [placeholder]="searchPlaceholder(def)"
                  [value]="term()[def.key] ?? ''"
                  (input)="setTerm(def.key, $event)"
                />
              </label>
            }
            <ul class="opts">
              @for (o of visible(def); track o.id) {
                <li class="opt-row">
                  <sm-checkbox
                    class="check"
                    [checked]="has(def.key, o.id)"
                    [disabled]="!o.count && !has(def.key, o.id)"
                    (checkedChange)="toggle(def.key, o.id)"
                    >{{ o.label
                    }}<span class="sm-visually-hidden">, {{ o.count }}</span></sm-checkbox
                  >
                  <span class="count" [class.is-off]="!o.count" aria-hidden="true">{{
                    o.count
                  }}</span>
                </li>
              } @empty {
                <li class="none" i18n="@@jobs.noOptions">Nothing matches that.</li>
              }
            </ul>
            @if (
              def.collapsed &&
              !open()[def.key] &&
              filtered(def).length > collapsedCount &&
              !term()[def.key]
            ) {
              <button type="button" class="more" (click)="expand(def.key)" i18n="@@jobs.showAllN">
                Show all {{ filtered(def).length }} {{ def.label.toLowerCase() }}s
              </button>
            }
          }
        }
      </section>
    }
  `,
  styleUrl: './filters-panel.scss',
})
export class FiltersPanel {
  readonly defs = input.required<readonly FilterDef[]>();
  readonly draft = input.required<FilterState>();
  readonly facets = input.required<readonly Facet[]>();
  readonly draftChange = output<FilterState>();
  private readonly locale = inject(LOCALE_ID);

  protected readonly uid = Math.random().toString(36).slice(2, 7);
  protected readonly collapsedCount = COLLAPSED;
  protected readonly term = signal<Record<string, string>>({});
  protected readonly open = signal<Record<string, boolean>>({});

  protected readonly state = computed(() => this.draft()['state']?.[0] ?? '');
  protected readonly learnership = computed(
    () => this.draft()['jobType']?.includes('learnership') ?? false,
  );
  protected readonly sectorNames = computed(() => {
    const s = this.draft()['sector'] ?? [];
    return s.length ? s.join(' and ') : '';
  });

  protected opts(key: string): readonly FacetOption[] {
    const options = this.facets().find((f) => f.key === key)?.options ?? [];
    // Names read A–Z (A-258); pipeline stages, dates and ranges keep their natural order.
    return NAMED_FACETS.has(key) ? alphabetical(options, (o) => o.label, this.locale) : options;
  }

  protected has(key: string, id: string): boolean {
    return this.draft()[key]?.includes(id) ?? false;
  }

  protected filtered(def: FilterDef): readonly FacetOption[] {
    const t = (this.term()[def.key] ?? '').toLowerCase();
    return this.opts(def.key).filter((o) => !t || o.label.toLowerCase().includes(t));
  }

  /** Collapsed lists keep the picked options visible. */
  protected visible(def: FilterDef): readonly FacetOption[] {
    const all = this.filtered(def);
    if (!def.collapsed || this.open()[def.key] || this.term()[def.key]) return all;
    const picked = all.filter((o) => this.has(def.key, o.id));
    const rest = all
      .filter((o) => !this.has(def.key, o.id))
      .slice(0, Math.max(0, COLLAPSED - picked.length));
    return [...picked, ...rest];
  }

  protected selectedLabel(def: FilterDef): string {
    const n = keysOf(def).reduce(
      (t, k) => t + (k === 'state' || k === 'remote' ? 0 : (this.draft()[k]?.length ?? 0)),
      0,
    );
    if (def.kind === 'location') {
      const city = this.draft()['city'] ?? [];
      return city.length === 1
        ? (city[0] ?? '')
        : city.length
          ? $localize`:@@jobs.nSelected:${city.length}:n: selected`
          : '';
    }
    return n ? $localize`:@@jobs.nSelected:${n}:n: selected` : '';
  }

  protected searchPlaceholder(def: FilterDef): string {
    return $localize`:@@jobs.searchKey:Search ${def.label.toLowerCase()}:label:s`;
  }

  protected setTerm(key: string, e: Event): void {
    const v = (e.target as HTMLInputElement).value;
    this.term.update((t) => ({ ...t, [key]: v }));
  }

  protected expand(key: string): void {
    this.open.update((o) => ({ ...o, [key]: true }));
  }

  private emit(next: Record<string, readonly string[]>): void {
    const clean = Object.fromEntries(Object.entries(next).filter(([, v]) => v.length));
    this.draftChange.emit(clean);
  }

  protected toggle(key: string, id: string): void {
    const cur = this.draft()[key] ?? [];
    const next: Record<string, readonly string[]> = {
      ...this.draft(),
      [key]: cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id],
    };
    // Roles outside the chosen sectors no longer apply.
    if (key === 'sector') next['role'] = [];
    this.emit(next);
  }

  protected setSingle(key: string, id: string | null): void {
    this.emit({ ...this.draft(), [key]: id ? [id] : [] });
  }

  protected setFlag(key: string, on: boolean): void {
    this.emit({ ...this.draft(), [key]: on ? ['yes'] : [] });
  }

  protected setState(e: Event): void {
    const v = (e.target as HTMLSelectElement).value;
    this.emit({ ...this.draft(), state: v ? [v] : [], city: [] });
  }
}
