import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, computed, inject, signal, viewChild } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { FilterDef, TabQuery, countActive } from '../../core/jobs/jobs-filters';
import { Facet, FilterState, JobsTab, ListResult } from '../../core/jobs/jobs.api';
import { Button } from '../../shared/ui/button/button';
import { SmDialog } from '../../shared/ui/overlay/dialog';
import { Observable } from 'rxjs';
import { FiltersPanel } from './filters-panel';

export interface AllFiltersData {
  readonly tab: JobsTab;
  readonly defs: readonly FilterDef[];
  readonly query: TabQuery;
  readonly facets: readonly Facet[];
  /** Count-only search with the draft filters (limit 0). */
  readonly preview: (filters: FilterState) => Observable<ListResult<unknown>>;
  readonly noun: string;
}

/**
 * J4 · All filters (Figma 274:24332 desktop drawer · 274:25597 mobile sheet). Every filter for the
 * tab with live counts, and a "Show N jobs" button that updates as you pick.
 */
@Component({
  selector: 'sm-all-filters',
  imports: [Button, FiltersPanel, SmDialog],
  template: `
    <sm-dialog [title]="title">
      @if (active()) {
        <span smDialogLead class="badge" i18n="@@jobs.nSelected">{{ active() }} selected</span>
      }
      <sm-filters-panel [defs]="data.defs" [draft]="draft()" [facets]="facets()" (draftChange)="draft.set($event)" />
      <div smDialogActions class="foot">
        <button type="button" class="clear" (click)="draft.set({})" i18n="@@jobs.clearAll">Clear all</button>
        <button sm-button type="button" [loading]="preview.isLoading()" (click)="dialog().close(draft())">
          {{ showLabel() }}
        </button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .badge {
      justify-self: start;
      padding: var(--sm-space-50) var(--sm-space-250);
      border-radius: var(--sm-radius-full);
      background: var(--sm-color-brand-selected);
      color: var(--sm-color-text-brand);
      font: var(--sm-font-caption-bold);
    }

    .foot {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: var(--sm-space-300);
      padding-block-start: var(--sm-space-300);
      border-block-start: var(--sm-stroke-sm) solid var(--sm-color-border-subtle);
    }

    .clear {
      min-block-size: var(--sm-size-touch-min);
      padding: 0 var(--sm-space-100);
      border: 0;
      border-radius: var(--sm-radius-sm);
      background: none;
      color: var(--sm-color-text-brand);
      font: var(--sm-font-body-sm-semibold);
      cursor: pointer;

      &:focus-visible {
        box-shadow: var(--sm-shadow-focus-ring);
        outline: none;
      }
    }
  `,
})
export class AllFilters {
  protected readonly data = inject<AllFiltersData>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@jobs.allFilters:All filters`;

  protected readonly draft = signal<FilterState>(this.data.query.filters);
  protected readonly preview = rxResource({
    params: () => this.draft(),
    stream: ({ params }) => this.data.preview(params),
  });
  protected readonly facets = computed(() =>
    this.preview.hasValue() ? this.preview.value().facets : this.data.facets,
  );
  protected readonly active = computed(() =>
    this.data.defs.reduce((n, d) => n + countActive(this.draft(), d), 0),
  );
  protected readonly showLabel = computed(() => {
    const n = this.preview.hasValue() ? this.preview.value().total : null;
    return n === null
      ? $localize`:@@jobs.showResults:Show results`
      : $localize`:@@jobs.showN:Show ${n}:n: ${this.data.noun}:noun:`;
  });
}
