import { BackNav } from '../../core/layout/back-nav';
import { CdkConnectedOverlay, CdkOverlayOrigin, ConnectedPosition } from '@angular/cdk/overlay';
import { CdkTrapFocus } from '@angular/cdk/a11y';
import {
  Component,
  ElementRef,
  afterRenderEffect,
  computed,
  effect,
  inject,
  input,
  linkedSignal,
  signal,
  untracked,
  viewChild,
} from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { Router, RouterLink } from '@angular/router';
import { Observable, map } from 'rxjs';
import { Viewport } from '../../core/layout/viewport';
import { FilterDef, JobsFilterStore, SECTOR_ALIASES, TABS, TabQuery, countActive } from '../../core/jobs/jobs-filters';
import {
  Application,
  Facet,
  FilterState,
  Invitation,
  JOBS_API,
  Job,
  JobsTab,
  ListQuery,
  ListResult,
} from '../../core/jobs/jobs.api';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { AllFilters, AllFiltersData } from './all-filters';
import { FiltersPanel } from './filters-panel';
import { JOBS_LINKS, JobActions } from './job-actions';
import { JobCard } from './job-card';
import { JobDetail } from './job-detail';

const PAGE = 20;

interface Row {
  readonly key: string;
  readonly job: Job;
  readonly invite: Invitation | null;
  readonly app: Application | null;
}

/**
 * My Jobs v2 (Figma 272:22353, handoff 282:26513). Five tabs: Available, Matching, Invitations,
 * Bookmarked, Applied. Search, quick filters with live counts (J3), All filters (J4), applied pills
 * (J5), zero results with suggestions (J6), locked Matching (J8), empty tabs (J16–J19), loading
 * (J20) and error (J21). Desktop: list 470 + detail panel; tablet/mobile: list, then a detail page.
 */
@Component({
  selector: 'sm-jobs-page',
  imports: [
    Button,
    CdkConnectedOverlay,
    CdkOverlayOrigin,
    CdkTrapFocus,
    FiltersPanel,
    Icon,
    JobCard,
    JobDetail,
    LearnerShell,
    RouterLink,
    Skeleton,
    StateBlock,
  ],
  templateUrl: './jobs-page.html',
  styleUrl: './jobs-page.scss',
})
export class JobsPage {
  protected readonly nav = inject(BackNav);
  private readonly api = inject(JOBS_API);
  private readonly store = inject(JobsFilterStore);
  private readonly overlay = inject(OverlayService);
  private readonly router = inject(Router);
  protected readonly actions = inject(JobActions);
  protected readonly viewport = inject(Viewport);

  /** Route data. */
  readonly tab = input<JobsTab>('available');
  /** `?job=` selects the job shown in the desktop panel. */
  readonly job = input<string | undefined>();
  /** `?sector=` from "See similar jobs". */
  readonly sector = input<string | undefined>();

  protected readonly links = JOBS_LINKS;
  protected readonly cfg = computed(() => TABS[this.tab()]);
  private readonly tabsNav = viewChild<ElementRef<HTMLElement>>('tabsNav');

  protected readonly tabs: readonly { id: JobsTab; label: string; link: string }[] = [
    { id: 'available', label: $localize`:@@jobs.tabAvailable:Available Jobs`, link: JOBS_LINKS.available },
    { id: 'matching', label: $localize`:@@jobs.tabMatching:Matching Jobs`, link: JOBS_LINKS.matching },
    { id: 'invitations', label: $localize`:@@jobs.tabInvites:Job Invitations`, link: JOBS_LINKS.invitations },
    { id: 'bookmarked', label: $localize`:@@jobs.tabSaved:Bookmarked Jobs`, link: JOBS_LINKS.bookmarked },
    { id: 'applied', label: $localize`:@@jobs.tabApplied:Applied Jobs`, link: JOBS_LINKS.applied },
  ];

  protected readonly summary = rxResource({
    params: () => ({ v: this.actions.changed() }),
    stream: () => this.api.summary(),
  });
  protected readonly sum = computed(() => (this.summary.hasValue() ? this.summary.value() : undefined));
  protected readonly jobsLines = [
    $localize`:@@jobs.muni1:Employers post new roles every week. I’ll keep an eye out.`,
    $localize`:@@jobs.muni2:Hot tip: a full job profile gets 3× more recruiter views.`,
    $localize`:@@jobs.muni3:Your future employer is out there, probably drinking chai right now.`,
  ];

  /** A-261: Matching is never locked; a gentle nudge shows what would sharpen the matches. */
  protected readonly sharpen = computed(() => {
    const s = this.sum();
    return this.tab() === 'matching' && s && s.profilePercent < 100 && s.missing.length ? s : null;
  });

  protected readonly query = computed<TabQuery>(() => {
    this.store.version();
    return this.store.query(this.tab(), this.sum()?.defaultPlace ?? '');
  });
  protected readonly limit = linkedSignal({ source: this.query, computation: () => PAGE });

  protected readonly list = rxResource({
    params: () =>
      !this.sum()
        ? undefined
        : { tab: this.tab(), q: { ...this.query(), limit: this.limit() } as ListQuery, v: this.actions.changed() },
    stream: ({ params }) => this.fetch(params.tab, params.q),
  });
  protected readonly res = computed(() => (this.list.hasValue() ? this.list.value() : undefined));
  /** Keep showing the old list while "Show more" or a refresh loads. */
  protected readonly lastRes = linkedSignal<ListResult<Row> | undefined, ListResult<Row> | undefined>({
    source: this.res,
    computation: (r, prev) => r ?? prev?.value,
  });
  protected readonly state = computed(() => {
    if (this.list.error() || this.summary.error()) return 'error';
    const r = this.lastRes();
    if (!r) return 'loading';
    if (!r.total) return this.filtered() ? 'none' : 'empty';
    return 'ready';
  });

  protected readonly filtered = computed(() => {
    const q = this.query();
    return !!q.q || Object.values(q.filters).some((v) => v.length);
  });

  protected readonly rows = computed(() => this.lastRes()?.items ?? []);
  protected readonly selectedKey = computed(() => this.job() ?? this.rows()[0]?.key ?? null);
  /** A linked job that the current filters hide is loaded on its own so the link still opens it. */
  private readonly linked = rxResource({
    params: () => {
      const id = this.job();
      const jobTab = this.tab() !== 'invitations' && this.tab() !== 'applied';
      return id && jobTab && this.lastRes() && !this.rows().some((r) => r.key === id) ? { id } : undefined;
    },
    stream: ({ params }) => this.api.job(params.id),
  });
  protected readonly selected = computed<Row | null>(() => {
    const hit = this.rows().find((r) => r.key === this.selectedKey());
    if (hit) return hit;
    const l = this.linked.hasValue() ? this.linked.value() : undefined;
    if (l && l.id === this.job()) return { key: l.id, job: l, invite: null, app: null };
    return this.rows()[0] ?? null;
  });

  protected readonly activeCount = computed(() =>
    this.cfg().filters.reduce((n, d) => n + countActive(this.query().filters, d), 0),
  );

  /** J5 removable pills, labelled from the facets. */
  protected readonly pills = computed(() => {
    const f = this.query().filters;
    const facets = this.lastRes()?.facets ?? [];
    return Object.entries(f).flatMap(([key, ids]) =>
      key === 'state'
        ? []
        : ids.map((id) => ({
            key,
            id,
            label:
              key === 'remote'
                ? $localize`:@@jobs.pillRemote:Remote`
                : (facets.find((x) => x.key === key)?.options.find((o) => o.id === id)?.label ?? id),
          })),
    );
  });

  protected readonly resultLine = computed(() => {
    const r = this.lastRes();
    if (!r) return '';
    if (r.note) return r.note;
    const n = r.total;
    if (this.tab() === 'matching') return $localize`:@@jobs.matchedLine:${n}:n: jobs matched to your profile and assessment`;
    const place = this.query().place;
    return place && !this.filtered()
      ? $localize`:@@jobs.inPlace:${n}:n: jobs in ${place}:place:`
      : $localize`:@@jobs.nJobs:${n}:n: jobs`;
  });

  protected readonly noun = computed(() => {
    switch (this.tab()) {
      case 'invitations':
        return $localize`:@@jobs.nounInvites:invitations`;
      case 'applied':
        return $localize`:@@jobs.nounApps:applications`;
      default:
        return $localize`:@@jobs.nounJobs:jobs`;
    }
  });

  /* ---------- Search ---------- */

  protected readonly qDraft = linkedSignal(() => this.query().q);
  protected readonly placeDraft = linkedSignal(() => this.query().place);

  protected search(e: Event): void {
    e.preventDefault();
    this.setQuery({ q: this.qDraft().trim(), place: this.placeDraft().trim() });
  }

  protected setSort(e: Event): void {
    this.setQuery({ sort: (e.target as HTMLSelectElement).value });
  }

  private setQuery(p: Partial<TabQuery>): void {
    this.store.set(this.tab(), { ...this.query(), ...p });
    void this.router.navigate([], { queryParams: { job: null, sector: null }, queryParamsHandling: 'merge', replaceUrl: true });
  }

  /** Picking a city fills the place box with it (Figma J5); picking only a state clears it. */
  protected setFilters(filters: FilterState): void {
    const city = filters['city'] ?? [];
    const loc = city.length || filters['state']?.length;
    const place = city.length ? city.join(', ') : loc ? '' : this.query().place;
    this.setQuery({ filters, place: this.cfg().place ? place : '' });
  }

  protected removePill(key: string, id: string): void {
    const f = { ...this.query().filters, [key]: (this.query().filters[key] ?? []).filter((x) => x !== id) };
    this.setFilters(f);
  }

  protected clearAll(): void {
    this.setQuery({ filters: {}, q: '' });
  }

  protected more(): void {
    this.limit.update((l) => l + PAGE);
  }

  /* ---------- Quick filter popover (J3) ---------- */

  protected readonly quick = signal<FilterDef | null>(null);
  protected readonly quickOrigin = signal<CdkOverlayOrigin | null>(null);
  protected readonly draft = signal<FilterState>({});
  protected readonly preview = rxResource({
    params: () => (this.quick() ? { f: this.draft() } : undefined),
    stream: ({ params }) => this.previewFn(params.f),
  });
  protected readonly quickFacets = computed<readonly Facet[]>(() =>
    this.preview.hasValue() ? this.preview.value().facets : (this.lastRes()?.facets ?? []),
  );
  protected readonly quickTotal = computed(() => (this.preview.hasValue() ? this.preview.value().total : null));
  protected readonly positions: ConnectedPosition[] = [
    { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 8 },
    { originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top', offsetY: 8 },
  ];

  /** Sector and Role are dependent, so they share one popover (Figma J3). */
  protected quickDefs(def: FilterDef): readonly FilterDef[] {
    if (def.key !== 'sector') return [def];
    return this.cfg().filters.filter((d) => d.key === 'sector' || d.key === 'role');
  }

  protected openQuick(def: FilterDef, origin: CdkOverlayOrigin): void {
    if (this.quick()?.key === def.key) {
      this.quick.set(null);
      return;
    }
    this.draft.set(this.query().filters);
    this.quickOrigin.set(origin);
    this.quick.set(def);
  }

  protected closeQuick(apply: boolean): void {
    if (apply) this.setFilters(this.draft());
    this.quick.set(null);
  }

  protected chipLabel(def: FilterDef): string {
    const f = this.query().filters;
    if (def.kind === 'location') {
      const c = f['city'] ?? [];
      if (c.length === 1) return c[0] ?? def.label;
    }
    if (def.kind === 'single' && f[def.key]?.length) {
      const id = f[def.key]?.[0] ?? '';
      return this.lastRes()?.facets.find((x) => x.key === def.key)?.options.find((o) => o.id === id)?.label ?? def.label;
    }
    const n = countActive(f, def);
    return n && def.kind === 'multi' ? `${def.label} · ${n}` : def.label;
  }

  protected activeIn(def: FilterDef): number {
    return countActive(this.query().filters, def);
  }

  protected quickDefsFor(defs: readonly FilterDef[]): readonly FilterDef[] {
    return this.viewport.isMobile() ? defs.slice(0, this.cfg().mobileQuick) : defs;
  }

  /* ---------- All filters (J4) ---------- */

  protected allFilters(): void {
    const ref = this.overlay.drawer<AllFilters, AllFiltersData, FilterState>(AllFilters, {
      data: {
        tab: this.tab(),
        defs: this.cfg().filters,
        query: this.query(),
        facets: this.lastRes()?.facets ?? [],
        preview: (f) => this.previewFn(f),
        noun: this.noun(),
      },
    });
    ref.closed.subscribe((f) => {
      if (f) this.setFilters(f);
    });
  }

  /* ---------- Cards ---------- */

  protected cardLink(r: Row): string | readonly string[] {
    if (this.viewport.isDesktop()) return [];
    switch (this.tab()) {
      case 'invitations':
        return ['/jobs/invitations', r.key];
      case 'applied':
        return ['/jobs/applied', r.key];
      default:
        return ['/jobs/view', r.job.id];
    }
  }

  protected cardQuery(r: Row): Record<string, string> | null {
    return this.viewport.isDesktop() ? { job: r.key } : null;
  }

  protected async toggleSave(job: Job): Promise<void> {
    await this.actions.toggleSave(job);
  }

  constructor() {
    // "See similar jobs" lands with ?sector=.
    effect(() => {
      const raw = this.sector();
      if (!raw) return;
      const s = SECTOR_ALIASES[raw] ?? raw;
      untracked(() => this.store.set('available', { ...this.store.query('available'), filters: { sector: [s] } }));
    });
    // Keep the active tab in view on narrow screens (handoff: "Tab strip scrolls").
    afterRenderEffect(() => {
      this.tab();
      this.tabsNav()
        ?.nativeElement.querySelector('[aria-current="page"]')
        ?.scrollIntoView({ block: 'nearest', inline: 'center' });
    });
  }

  /* ---------- Data ---------- */

  private previewFn(filters: FilterState): Observable<ListResult<Row>> {
    return this.fetch(this.tab(), { ...this.query(), filters, limit: 0 });
  }

  private fetch(tab: JobsTab, q: ListQuery): Observable<ListResult<Row>> {
    if (tab === 'invitations')
      return this.api.invitations(q).pipe(map((r) => this.rowsOf(r, (i) => ({ key: i.id, job: i.job, invite: i, app: null }))));
    if (tab === 'applied')
      return this.api.applications(q).pipe(map((r) => this.rowsOf(r, (a) => ({ key: a.id, job: a.job, invite: null, app: a }))));
    return this.api.jobs(tab, q).pipe(map((r) => this.rowsOf(r, (j) => ({ key: j.id, job: j, invite: null, app: null }))));
  }

  private rowsOf<T>(r: ListResult<T>, f: (t: T) => Row): ListResult<Row> {
    return { ...r, items: r.items.map(f) };
  }

  protected readonly skeletons = [1, 2, 3];

  protected emptyCopy() {
    switch (this.tab()) {
      case 'matching':
        return {
          title: $localize`:@@jobs.e16t:No matching jobs yet`,
          body: $localize`:@@jobs.e16b:We match jobs to your skills, location and preferences. Adding skills or more preferred locations usually brings in matches within a day.`,
          primary: { label: $localize`:@@jobs.e16p:Update job preferences`, link: '/quests/pick-your-arc' },
          secondary: { label: $localize`:@@jobs.browseAvailable:Browse available jobs`, link: JOBS_LINKS.available },
        };
      case 'invitations':
        return {
          title: $localize`:@@jobs.e17t:No invitations yet`,
          body: $localize`:@@jobs.e17b:Employers invite learners whose profiles fit their roles. A complete profile with a CV gets noticed more often.`,
          primary: { label: $localize`:@@jobs.completeProfile:Complete my profile`, link: JOBS_LINKS.profile },
          secondary: { label: $localize`:@@jobs.browseMatching:Browse matching jobs`, link: JOBS_LINKS.matching },
        };
      case 'bookmarked':
        return {
          title: $localize`:@@jobs.e18t:No saved jobs`,
          body: $localize`:@@jobs.e18b:Tap the bookmark on any job to save it here. We will remind you before a saved job closes.`,
          primary: { label: $localize`:@@jobs.browseAvailable:Browse available jobs`, link: JOBS_LINKS.available },
          secondary: null,
        };
      case 'applied':
        return {
          title: $localize`:@@jobs.e19t:No applications yet`,
          body: $localize`:@@jobs.e19b:Jobs you apply to will show here with their status, so you always know where you stand.`,
          primary: { label: $localize`:@@jobs.browseMatching:Browse matching jobs`, link: JOBS_LINKS.matching },
          secondary: { label: $localize`:@@jobs.browseAvailable:Browse available jobs`, link: JOBS_LINKS.available },
        };
      default:
        return {
          title: $localize`:@@jobs.e0t:No open jobs right now`,
          body: $localize`:@@jobs.e0b:New jobs are added every day. Turn on alerts and we’ll tell you first.`,
          primary: null,
          secondary: null,
        };
    }
  }
}
