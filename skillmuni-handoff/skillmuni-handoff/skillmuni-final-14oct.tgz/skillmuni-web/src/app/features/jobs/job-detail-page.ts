import { BackNav } from '../../core/layout/back-nav';
import { Component, computed, inject, input } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { Application, Invitation, JOBS_API, Job } from '../../core/jobs/jobs.api';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { JOBS_LINKS } from './job-actions';
import { JobDetail } from './job-detail';

interface Loaded {
  readonly job: Job;
  readonly invite: Invitation | null;
  readonly app: Application | null;
}

/**
 * J2 mobile (272:24673) and tablet (272:24357) · Job details as its own page with a sticky Apply
 * bar. Also hosts an invitation (J9b) and an application (J12b) on small screens.
 */
@Component({
  selector: 'sm-job-detail-page',
  imports: [Button, Icon, JobDetail, LearnerShell, Skeleton, StateBlock],
  template: `
    <sm-learner-shell pageHeaderOnMobile hideTabsOnMobile>
      <div class="page">
        <header class="head">
          <button type="button" class="round sm-back" i18n-aria-label="@@ui.back" aria-label="Back" (click)="back()">
            <sm-icon name="chevron-left" size="md" />
          </button>
          <h1 class="h1">{{ heading() }}</h1>
        </header>
        @if (res.isLoading()) {
          <div class="sk" aria-busy="true">
            <span class="sm-visually-hidden" role="status" i18n="@@jobs.loadingJob">Loading the job…</span>
            <sm-skeleton shape="block" />
          </div>
        } @else if (res.error()) {
          <sm-state-block
            kind="error"
            i18n-title="@@jobs.jobErrTitle"
            title="Couldn’t load this job"
            i18n-body="@@jobs.jobErrBody"
            body="It may have closed, or your connection dropped. Try again."
          >
            <button sm-button smStateAction (click)="res.reload()" i18n="@@ui.tryAgain">Try again</button>
          </sm-state-block>
        } @else if (data(); as d) {
          <sm-job-detail
            mode="page"
            [job]="d.job"
            [invite]="d.invite"
            [app]="d.app"
            [showMatch]="!!d.job.match"
            [bookmarkedView]="d.job.saved"
          />
        }
      </div>
    </sm-learner-shell>
  `,
  styles: `
    .page {
      display: grid;
      grid-template-columns: minmax(0, 1fr);
      gap: var(--sm-space-400);
      inline-size: 100%;
      max-inline-size: var(--sm-layout-shell-card-max-width);
      margin-inline: auto;
    }

    .head {
      display: flex;
      align-items: center;
      gap: var(--sm-space-350);
    }

    .round {
      display: grid;
      flex: none;
      place-items: center;
      inline-size: var(--sm-size-touch-min);
      block-size: var(--sm-size-touch-min);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-subtle);
      border-radius: var(--sm-radius-full);
      background: var(--sm-color-surface-raised);
      color: var(--sm-color-text-primary);
      cursor: pointer;

      &:focus-visible {
        box-shadow: var(--sm-shadow-focus-ring);
        outline: none;
      }
    }

    .h1 {
      margin: 0;
      color: var(--sm-color-text-heading);
      font: var(--sm-font-heading-lg);
    }

    .sk sm-skeleton {
      min-block-size: calc(var(--sm-size-jobs-list) * 1.2);
    }
  `,
})
export class JobDetailPage {
  private readonly api = inject(JOBS_API);
  private readonly router = inject(Router);
  private readonly nav = inject(BackNav);

  readonly id = input.required<string>();
  /** Route data: which record the id points at. */
  readonly kind = input<'job' | 'invitation' | 'application'>('job');

  protected readonly res = rxResource({
    params: () => ({ id: this.id(), kind: this.kind() }),
    stream: ({ params }) =>
      params.kind === 'invitation'
        ? this.api.invitation(params.id).pipe(map((i): Loaded => ({ job: i.job, invite: i, app: null })))
        : params.kind === 'application'
          ? this.api.application(params.id).pipe(map((a): Loaded => ({ job: a.job, invite: null, app: a })))
          : this.api.job(params.id).pipe(map((j): Loaded => ({ job: j, invite: null, app: null }))),
  });
  protected readonly data = computed(() => (this.res.hasValue() ? this.res.value() : undefined));
  protected readonly heading = computed(() =>
    this.kind() === 'invitation'
      ? $localize`:@@jobs.inviteDetails:Invitation`
      : this.kind() === 'application'
        ? $localize`:@@jobs.appDetails:Application`
        : $localize`:@@jobs.jobDetails:Job details`,
  );

  protected back(): void {
    this.nav.back(this.kind() === 'invitation' ? JOBS_LINKS.invitations : this.kind() === 'application' ? JOBS_LINKS.applied : JOBS_LINKS.available);
  }
}
