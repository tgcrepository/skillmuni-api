import { Component, computed, input, output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Application, Invitation, Job, WorkMode } from '../../core/jobs/jobs.api';
import { Icon } from '../../shared/ui/icon/icon';
import { eventWhen } from '../../shared/util/ics';

export const WORK_MODE: Record<WorkMode, string> = {
  onsite: $localize`:@@jobs.wm.onsite:On-site`,
  hybrid: $localize`:@@jobs.wm.hybrid:Hybrid`,
  remote: $localize`:@@jobs.wm.remote:Remote`,
};

export interface CardBadge {
  readonly text: string;
  readonly tone: 'new' | 'warn' | 'ok' | 'info' | 'accent' | 'muted';
}

/** Application status → badge (handoff "Status models"). */
export function appBadge(a: Application): CardBadge {
  switch (a.status) {
    case 'interview': {
      const day = a.interview ? eventWhen(a.interview.at, false) : '';
      return { text: $localize`:@@jobs.b.interview:Interview · ${day}:date:`, tone: 'accent' };
    }
    case 'shortlisted':
      return { text: $localize`:@@jobs.b.shortlisted:Shortlisted`, tone: 'ok' };
    case 'viewed':
      return { text: $localize`:@@jobs.b.review:Under review`, tone: 'info' };
    case 'offer':
      return { text: $localize`:@@jobs.b.offer:Offer`, tone: 'ok' };
    case 'not-selected':
      return { text: $localize`:@@jobs.b.notSelected:Not selected`, tone: 'muted' };
    case 'withdrawn':
      return { text: $localize`:@@jobs.b.withdrawn:Withdrawn`, tone: 'muted' };
    default:
      return { text: $localize`:@@jobs.b.applied:Applied`, tone: 'ok' };
  }
}

export function jobBadge(j: Job): CardBadge | null {
  if (j.appliedOn) return { text: $localize`:@@jobs.b.applied:Applied`, tone: 'ok' };
  if (j.closed) return { text: $localize`:@@jobs.b.closed:Closed`, tone: 'muted' };
  if (j.closingInDays !== null)
    return { text: $localize`:@@jobs.b.closing:Closing in ${j.closingInDays}:n: days`, tone: 'warn' };
  if (j.isNew) return { text: $localize`:@@jobs.b.new:New`, tone: 'new' };
  return null;
}

export function posted(days: number): string {
  if (days <= 0) return $localize`:@@jobs.postedToday:Posted today`;
  if (days === 1) return $localize`:@@jobs.posted1:Posted 1 day ago`;
  if (days < 7) return $localize`:@@jobs.postedN:Posted ${days}:n: days ago`;
  if (days < 14) return $localize`:@@jobs.postedW:Posted 1 week ago`;
  return $localize`:@@jobs.postedWs:Posted ${Math.floor(days / 7)}:n: weeks ago`;
}

/**
 * One row in the My Jobs list (Figma J1 272:22357 · J7 · J9 · J11 · J12). The title is the link
 * (stretched over the card) so the bookmark can stay a separate button.
 */
@Component({
  selector: 'sm-job-card',
  imports: [Icon, RouterLink],
  template: `
    <article class="card" [class.is-selected]="selected()" [attr.aria-labelledby]="titleId()">
      @if (invite(); as i) {
        <p class="from">
          <span class="mini" aria-hidden="true">{{ i.recruiter.initials }}</span>
          {{ i.recruiter.name }} ·
          @if (i.type === 'interview') {
            <ng-container i18n="@@jobs.interviewInvite">Interview invite · {{ interviewWhen() }}</ng-container>
          } @else {
            <ng-container i18n="@@jobs.invitedApply">Invited you to apply</ng-container>
          }
        </p>
      }
      <div class="top">
        <span class="logo" aria-hidden="true">{{ job().initials }}</span>
        <span class="titles">
          <h3 class="title" [id]="titleId()">
            <a class="link" [routerLink]="link()" [queryParams]="query()" [attr.aria-current]="selected() ? 'true' : null">{{
              job().title
            }}</a>
          </h3>
          <span class="sub">{{ job().company }} · {{ job().place }}</span>
        </span>
        @if (showMatch() && job().match; as m) {
          <span class="match" i18n="@@jobs.matchPct">{{ m.percent }}% match</span>
        }
        @if (!invite() && !app()) {
          <button
            type="button"
            class="save"
            [class.is-on]="job().saved"
            [attr.aria-pressed]="job().saved"
            [attr.aria-label]="saveLabel()"
            (click)="toggleSave.emit(job())"
          >
            <sm-icon [name]="job().saved ? 'bookmark-filled' : 'bookmark'" size="sm" />
          </button>
        }
      </div>
      <ul class="tags">
        <li>{{ workMode[job().workMode] }}</li>
        <li>{{ job().jobTypeLabel }}</li>
        <li>{{ job().pay }}</li>
      </ul>
      @if (showMatch() && job().match; as m) {
        <p class="matches" i18n="@@jobs.matches">Matches: {{ m.skills.join(', ') }}</p>
      }
      <div class="foot">
        <span class="meta" [class.is-warn]="invite()?.status === 'new'">{{ meta() }}</span>
        @if (badge(); as b) {
          <span class="badge" [class]="'badge badge--' + b.tone">{{ b.text }}</span>
        }
      </div>
    </article>
  `,
  styleUrl: './job-card.scss',
})
export class JobCard {
  readonly job = input.required<Job>();
  readonly invite = input<Invitation | null>(null);
  readonly app = input<Application | null>(null);
  readonly selected = input(false);
  readonly showMatch = input(false);
  /** "saved" shows "Saved 2 days ago" instead of the posted date. */
  readonly savedView = input(false);
  readonly link = input.required<string | readonly string[]>();
  readonly query = input<Record<string, string> | null>(null);
  readonly toggleSave = output<Job>();

  protected readonly workMode = WORK_MODE;
  protected readonly titleId = computed(() => `jc-${this.invite()?.id ?? this.app()?.id ?? this.job().id}`);

  protected readonly saveLabel = computed(() =>
    this.job().saved
      ? $localize`:@@jobs.unsaveLabel:Remove ${this.job().title}:title: from saved`
      : $localize`:@@jobs.saveLabel:Save ${this.job().title}:title:`,
  );

  protected readonly interviewWhen = computed(() => {
    const at = this.invite()?.interviewAt;
    return at ? eventWhen(at) : '';
  });

  protected readonly meta = computed(() => {
    const i = this.invite();
    if (i) {
      switch (i.status) {
        case 'new':
          return $localize`:@@jobs.respondBy:Respond by ${i.respondBy}:date: · ${i.daysLeft}:n: days left`;
        case 'accepted':
          return $localize`:@@jobs.accepted:You accepted`;
        case 'declined':
          return $localize`:@@jobs.declined:You declined`;
        default:
          return $localize`:@@jobs.expiredOn:Expired on ${i.respondBy}:date:`;
      }
    }
    const a = this.app();
    if (a) return a.status === 'withdrawn' ? a.updated : $localize`:@@jobs.appliedMeta:Applied ${a.appliedOn}:date: · ${a.updated}:updated:`;
    const j = this.job();
    if (this.savedView()) {
      if (j.appliedOn) return $localize`:@@jobs.youApplied:You applied on ${j.appliedOn}:date:`;
      return j.savedDays ? $localize`:@@jobs.savedAgo:Saved ${j.savedDays}:n: days ago` : $localize`:@@jobs.savedToday:Saved today`;
    }
    return posted(j.postedDays);
  });

  protected readonly badge = computed<CardBadge | null>(() => {
    const i = this.invite();
    if (i) {
      const map: Record<Invitation['status'], CardBadge> = {
        new: { text: $localize`:@@jobs.b.new:New`, tone: 'accent' },
        accepted: { text: $localize`:@@jobs.b.accepted:Accepted`, tone: 'ok' },
        declined: { text: $localize`:@@jobs.b.declined:Declined`, tone: 'muted' },
        expired: { text: $localize`:@@jobs.b.expired:Expired`, tone: 'muted' },
      };
      return map[i.status];
    }
    const a = this.app();
    if (a) return appBadge(a);
    return jobBadge(this.job());
  });
}
