import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

const page = () => import('./jobs-page').then((m) => m.JobsPage);
const detail = () => import('./job-detail-page').then((m) => m.JobDetailPage);
const title = $localize`:@@route.jobs:My Jobs · Skillmuni`;

export const jobsRoutes: Routes = [
  { path: 'jobs', title, canActivate: [requireSession], loadComponent: page, data: { tab: 'available' } },
  { path: 'jobs/matching', title, canActivate: [requireSession], loadComponent: page, data: { tab: 'matching' } },
  { path: 'jobs/invitations', title, canActivate: [requireSession], loadComponent: page, data: { tab: 'invitations' } },
  { path: 'jobs/bookmarked', title, canActivate: [requireSession], loadComponent: page, data: { tab: 'bookmarked' } },
  { path: 'jobs/applied', title, canActivate: [requireSession], loadComponent: page, data: { tab: 'applied' } },
  { path: 'jobs/view/:id', title, canActivate: [requireSession], loadComponent: detail, data: { kind: 'job' } },
  { path: 'jobs/invitations/:id', title, canActivate: [requireSession], loadComponent: detail, data: { kind: 'invitation' } },
  { path: 'jobs/applied/:id', title, canActivate: [requireSession], loadComponent: detail, data: { kind: 'application' } },
];
