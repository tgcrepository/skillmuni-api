import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, inject, viewChild } from '@angular/core';
import { RouterLink } from '@angular/router';
import { PendingQuest } from '../../core/job-profile/job-profile.api';
import { Button } from '../../shared/ui/button/button';
import { MuniTip } from '../../shared/ui/muni/muni-tip';
import { SmDialog } from '../../shared/ui/overlay/dialog';

export interface FinishData {
  readonly pending: readonly PendingQuest[];
  readonly matches: number;
}

/**
 * P6 · Sections to finish (Figma 310:47709). The learner registered on a programme without Career
 * Launchpad, then gained it: only the missing quests are asked, reusing the same quest screens.
 */
@Component({
  selector: 'sm-finish-dialog',
  imports: [Button, MuniTip, RouterLink, SmDialog],
  template: `
    <sm-dialog [title]="title">
      <sm-muni-tip class="tip" i18n="@@jp.finishTip"
        >Your new programme has job matching. I just need {{ data.pending.length }} things from you.</sm-muni-tip
      >
      <ol class="list">
        @for (q of data.pending; track q.title; let first = $first) {
          <li>
            <a class="item" [class.is-first]="first" [routerLink]="'/quests/' + q.slug" (click)="dialog().close()">
              <span class="text">
                <span class="title">{{ q.title }}</span>
                <span class="sub">{{ q.detail }}</span>
              </span>
              <span class="xp" i18n="@@jp.finishXp">+{{ q.xp }} XP</span>
            </a>
          </li>
        }
      </ol>
      <p class="note" i18n="@@jp.finishNote">
        Everything else is already in your profile. Your CV and {{ data.matches }} job matches unlock when these are
        done.
      </p>
      <div smDialogActions>
        @if (data.pending[0]; as first) {
          <a sm-button [routerLink]="'/quests/' + first.slug" (click)="dialog().close()" i18n="@@jp.startNow"
            >Start now</a
          >
        }
        <button sm-button variant="secondary" type="button" (click)="dialog().close()" i18n="@@jp.later">
          Later
        </button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .tip {
      margin-block-end: var(--sm-space-400);
    }

    .list {
      display: grid;
      gap: var(--sm-space-250);
      margin: 0;
      padding: 0;
      list-style: none;
    }

    .item {
      display: flex;
      align-items: center;
      gap: var(--sm-space-300);
      padding: var(--sm-space-300) var(--sm-space-400);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-subtle);
      border-radius: var(--sm-radius-xl);
      background: var(--sm-color-surface-raised);
      color: inherit;
      text-decoration: none;
    }

    .item.is-first {
      border-color: var(--sm-color-border-accent);
    }

    .item:hover {
      background: var(--sm-color-surface-hover);
    }

    .item:focus-visible {
      box-shadow: var(--sm-shadow-focus-ring);
      outline: none;
    }

    .text {
      display: grid;
      flex: 1 1 auto;
    }

    .title {
      color: var(--sm-color-text-heading);
      font: var(--sm-font-body-sm-semibold);
    }

    .sub {
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }

    .xp {
      padding: var(--sm-space-50) var(--sm-space-250);
      border-radius: var(--sm-radius-full);
      background: var(--sm-color-brand-selected);
      color: var(--sm-color-text-brand);
      font: var(--sm-font-caption-bold);
    }

    .note {
      margin: var(--sm-space-400) 0 var(--sm-space-200);
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }
  `,
})
export class FinishDialog {
  protected readonly data = inject<FinishData>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@jp.finishTitle:${this.data.pending.length}:n: quick quests to unlock your CV`;
}
