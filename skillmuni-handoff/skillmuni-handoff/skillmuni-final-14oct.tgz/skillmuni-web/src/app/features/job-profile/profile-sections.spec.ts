import { TestBed } from '@angular/core/testing';
import { JobProfile } from '../../core/job-profile/job-profile.api';
import { ProfileSections } from './profile-sections';

const profile = {
  lookingFor: [
    { label: 'Roles', value: 'Customer support' },
    { label: 'Expected pay', value: '₹3 – 4.5 LPA', private: true },
  ],
  certificates: [
    { id: 'a', title: 'A', issuer: 'x', status: 'verified', eta: null },
    { id: 'b', title: 'B', issuer: 'x', status: 'checking', eta: '48 h' },
    { id: 'c', title: 'C', issuer: 'x', status: 'none', eta: null },
  ],
} as unknown as JobProfile;

interface Api {
  lookingFor(): { label: string }[];
  certificates(): { id: string }[];
}

function create(employer: boolean): Api {
  TestBed.overrideComponent(ProfileSections, { set: { template: '', templateUrl: undefined, imports: [] } });
  const fixture = TestBed.createComponent(ProfileSections);
  fixture.componentRef.setInput('profile', profile);
  fixture.componentRef.setInput('employer', employer);
  return fixture.componentInstance as unknown as Api;
}

describe('ProfileSections', () => {
  it('shows everything to the learner', () => {
    const c = create(false);
    expect(c.lookingFor().map((r) => r.label)).toEqual(['Roles', 'Expected pay']);
    expect(c.certificates().map((r) => r.id)).toEqual(['a', 'b', 'c']);
  });

  it('hides private rows and unproven certificates from employers (P3)', () => {
    const c = create(true);
    expect(c.lookingFor().map((r) => r.label)).toEqual(['Roles']);
    expect(c.certificates().map((r) => r.id)).toEqual(['a', 'b']);
  });
});
