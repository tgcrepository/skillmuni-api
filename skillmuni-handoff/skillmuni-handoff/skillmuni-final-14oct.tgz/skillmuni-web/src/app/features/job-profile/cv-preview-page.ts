import { BackNav } from '../../core/layout/back-nav';
import {
  Component,
  DestroyRef,
  ElementRef,
  OnInit,
  computed,
  effect,
  inject,
  input,
  signal,
  viewChild,
} from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { CvContact, JOB_PROFILE_API, JobProfile } from '../../core/job-profile/job-profile.api';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { Switch } from '../../shared/ui/switch/switch';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { CvDocument, CvOptions, CvTemplate } from './cv-document';
import { ShareSheet } from './share-sheet';

const PREFS_KEY = 'sm_cv_prefs';

/**
 * P2 · Preview my CV (Figma 309:43602 · 309:43902 · 309:44193) and P8 · CV downloaded (310:50311).
 * Pick Creative / Classic (ATS-safe) / Modern, toggle what shows, then download, copy the link or
 * send on WhatsApp. The PDF comes from the browser's print-to-PDF (no PDF service yet — A-206).
 */
@Component({
  selector: 'sm-cv-preview-page',
  imports: [Button, CvDocument, Icon, LearnerShell, RouterLink, Skeleton, StateBlock, Switch],
  templateUrl: './cv-preview-page.html',
  styleUrl: './cv-preview-page.scss',
})
export class CvPreviewPage implements OnInit {
  private readonly api = inject(JOB_PROFILE_API);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);
  private readonly nav = inject(BackNav);
  private readonly destroyRef = inject(DestroyRef);

  /** `?download=1` (from the profile's Download PDF) opens the print dialog once loaded. */
  readonly download = input<string | undefined>();

  protected readonly state = signal<'loading' | 'ready' | 'error'>('loading');
  protected readonly profile = signal<JobProfile | null>(null);
  protected readonly contact = signal<CvContact | null>(null);
  protected readonly template = signal<CvTemplate>(this.prefs().template ?? 'creative');
  protected readonly options = signal<CvOptions>({
    photo: false,
    archetype: true,
    verified: true,
    salary: false,
    ...this.prefs().options,
  });
  protected readonly downloaded = signal(false);
  /** Mobile (309:44193) shows the whole A4 page shrunk to fit, so the sheet is zoomed, not reflowed. */
  protected readonly zoom = signal(1);
  private readonly previewEl = viewChild<ElementRef<HTMLElement>>('previewEl');

  constructor() {
    effect((onCleanup) => {
      const el = this.previewEl()?.nativeElement;
      if (!el || typeof ResizeObserver === 'undefined') return;
      const ro = new ResizeObserver(([entry]) => {
        // Tokens are rem (A-239): resolve against the current root size on every resize.
        const raw = getComputedStyle(el).getPropertyValue('--sm-size-cv-page').trim();
        const root = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
        const page = (parseFloat(raw) || 0) * (raw.endsWith('rem') ? root : 1);
        const w = entry?.contentRect.width ?? page;
        this.zoom.set(page && w < page ? w / page : 1);
      });
      ro.observe(el);
      onCleanup(() => ro.disconnect());
    });
  }

  protected readonly templates: readonly { id: CvTemplate; name: string; sub: string }[] = [
    { id: 'creative', name: $localize`:@@cv.creative:Creative`, sub: $localize`:@@cv.creativeSub:Stand out` },
    { id: 'classic', name: $localize`:@@cv.classic:Classic`, sub: $localize`:@@cv.classicSub:ATS-safe` },
    { id: 'modern', name: $localize`:@@cv.modern:Modern`, sub: $localize`:@@cv.modernSub:Clean & bold` },
  ];

  protected readonly toggles: readonly { key: keyof CvOptions; label: string }[] = [
    { key: 'photo', label: $localize`:@@cv.showPhoto:Show my photo` },
    { key: 'archetype', label: $localize`:@@cv.showArchetype:Show Player Card archetype` },
    { key: 'verified', label: $localize`:@@cv.showVerified:Show ✓ verified badges` },
    { key: 'salary', label: $localize`:@@cv.showSalary:Show expected salary` },
  ];

  protected readonly fileName = computed(() => `${(this.profile()?.name ?? 'My').replace(/\s+/g, '_')}_CV`);

  ngOnInit(): void {
    void this.load();
    const after = () => {
      if (this.printing) {
        this.printing = false;
        document.title = this.savedTitle;
        this.downloaded.set(true);
      }
    };
    window.addEventListener('afterprint', after);
    this.destroyRef.onDestroy(() => window.removeEventListener('afterprint', after));
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      const [p, c] = await Promise.all([
        firstValueFrom(this.api.profile()),
        firstValueFrom(this.api.cvContact()),
      ]);
      this.profile.set(p);
      this.contact.set(c);
      this.state.set('ready');
      if (this.download()) setTimeout(() => this.print(), 300);
    } catch {
      this.state.set('error');
    }
  }

  protected back(): void {
    this.nav.back('/job-profile');
  }

  protected pick(t: CvTemplate): void {
    this.template.set(t);
    this.savePrefs();
  }

  protected setOption(key: keyof CvOptions, on: boolean): void {
    this.options.update((o) => ({ ...o, [key]: on }));
    this.savePrefs();
  }

  private printing = false;
  private savedTitle = '';

  /** Browser print → "Save as PDF". The document title becomes the default file name. */
  protected print(): void {
    this.downloaded.set(false);
    this.savedTitle = document.title;
    document.title = this.fileName();
    this.printing = true;
    window.print();
  }

  protected share(): void {
    this.overlay.adaptive(ShareSheet, { size: 'sm' });
  }

  protected async copyLink(): Promise<void> {
    try {
      const s = await firstValueFrom(this.api.share());
      await navigator.clipboard.writeText(s.url);
      this.toast.show($localize`:@@cv.linkCopied:Link copied. It hides your phone and email.`, { tone: 'success' });
    } catch {
      this.toast.show($localize`:@@jp.copyFailed:Couldn’t copy. Select the link and copy it.`, { tone: 'error' });
    }
  }

  protected async whatsapp(): Promise<void> {
    try {
      const s = await firstValueFrom(this.api.share());
      const text = $localize`:@@jp.waText:Here’s my CV: ${s.url}:url:`;
      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
    } catch {
      this.toast.show($localize`:@@jp.shareFailed:Couldn’t save that. Try again.`, { tone: 'error' });
    }
  }

  private prefs(): { template?: CvTemplate; options?: Partial<CvOptions> } {
    try {
      return JSON.parse(sessionStorage.getItem(PREFS_KEY) ?? '{}') as {
        template?: CvTemplate;
        options?: Partial<CvOptions>;
      };
    } catch {
      return {};
    }
  }

  private savePrefs(): void {
    try {
      sessionStorage.setItem(PREFS_KEY, JSON.stringify({ template: this.template(), options: this.options() }));
    } catch {
      /* private mode */
    }
  }
}
