import { BackNav } from '../../core/layout/back-nav';
import { Component, ElementRef, OnInit, computed, inject, signal, viewChild } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { JOB_PROFILE_API, JobProfile, QuestFill } from '../../core/job-profile/job-profile.api';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { AboutDialog, AboutDialogData } from './about-dialog';
import { CvChangesDialog, CvChangesData } from './cv-changes-dialog';
import { FinishDialog } from './finish-dialog';
import { PlayerCard } from './player-card';
import { ProfileSections } from './profile-sections';
import { ShareSheet } from './share-sheet';

const CV_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
const CV_MAX_BYTES = 5 * 1024 * 1024;
const FINISH_KEY = 'sm_jp_finish_shown';

/**
 * P1 · My Job Profile — Living CV (Figma 308:43440 · 308:43886 · 308:44329; note 310:55447).
 * Player Card, profile strength with quick wins and contact & visibility on the left; the CV-ready
 * bar and every CV section on the right. Every Edit jumps back into the quest that collected it.
 * Also hosts P4 share, P5 new-CV review, P6 sections to finish and P7 fresher.
 */
@Component({
  selector: 'sm-job-profile-page',
  imports: [Button, Icon, LearnerShell, PlayerCard, ProfileSections, RouterLink, Skeleton, StateBlock],
  templateUrl: './job-profile-page.html',
  styleUrl: './job-profile-page.scss',
})
export class JobProfilePage implements OnInit {
  private readonly api = inject(JOB_PROFILE_API);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);
  private readonly nav = inject(BackNav);
  private readonly cvInput = viewChild<ElementRef<HTMLInputElement>>('cvInput');

  protected readonly state = signal<'loading' | 'ready' | 'error' | 'offline'>('loading');
  protected readonly profile = signal<JobProfile | null>(null);
  protected readonly uploading = signal(false);

  protected readonly fresher = computed(() => this.profile()?.work.length === 0);
  protected readonly updated = computed(() => {
    const iso = this.profile()?.updatedAt;
    if (!iso) return '';
    const days = Math.floor((Date.now() - Date.parse(iso)) / 86_400_000);
    return days <= 0
      ? $localize`:@@jp.updatedToday:Updated today`
      : days === 1
        ? $localize`:@@jp.updatedYesterday:Updated yesterday`
        : $localize`:@@jp.updatedDays:Updated ${days}:n: days ago`;
  });

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      const p = await firstValueFrom(this.api.profile());
      this.profile.set(p);
      this.state.set('ready');
      if (p.pending.length && !this.finishShown()) this.openFinish();
    } catch (e) {
      this.state.set(e instanceof ApiError && e.kind === 'offline' ? 'offline' : 'error');
    }
  }

  protected leftLabels(q: QuestFill): string {
    return q.left.map((l) => l.label).join(', ');
  }

  protected back(): void {
    this.nav.back('/launchpad');
  }

  protected share(): void {
    this.overlay.adaptive(ShareSheet, { size: 'sm' });
  }

  protected rewrite(): void {
    const p = this.profile();
    if (!p) return;
    const ref = this.overlay.adaptive<AboutDialog, AboutDialogData, JobProfile>(AboutDialog, {
      data: { text: p.about.text },
      autoFocus: 'textarea',
    });
    ref.closed.subscribe((next) => {
      if (!next) return;
      this.profile.set(next);
      this.toast.show($localize`:@@jp.aboutSaved:About me updated. Your CV too.`, { tone: 'success' });
    });
  }

  /* ---------- P5 · Newer CV ---------- */

  protected chooseCv(): void {
    this.cvInput()?.nativeElement.click();
  }

  protected async cvChosen(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    if (!CV_TYPES.includes(file.type) || file.size > CV_MAX_BYTES) {
      this.toast.show(
        $localize`:@@jp.cvType:Use a PDF or Word file up to 5 MB.`,
        { tone: 'error' },
      );
      return;
    }
    this.uploading.set(true);
    try {
      const changes = await firstValueFrom(this.api.uploadCv(file));
      if (!changes.length) {
        this.toast.show($localize`:@@jp.cvSame:Nothing new in that CV. Your profile is up to date.`, {
          tone: 'success',
        });
        return;
      }
      const ref = this.overlay.adaptive<CvChangesDialog, CvChangesData, JobProfile>(CvChangesDialog, {
        data: { changes },
      });
      ref.closed.subscribe((next) => {
        if (!next) return;
        this.profile.set(next);
        this.toast.show($localize`:@@jp.cvApplied:Profile and CV updated together`, { tone: 'success' });
      });
    } catch {
      this.toast.show($localize`:@@jp.cvFailed:Couldn’t read that CV. Try again.`, { tone: 'error' });
    } finally {
      this.uploading.set(false);
    }
  }

  /* ---------- P6 · Sections to finish ---------- */

  protected openFinish(): void {
    const p = this.profile();
    if (!p) return;
    this.markFinishShown();
    this.overlay.adaptive(FinishDialog, { data: { pending: p.pending, matches: p.strength.jobMatches } });
  }

  private finishShown(): boolean {
    try {
      return sessionStorage.getItem(FINISH_KEY) === '1';
    } catch {
      return false;
    }
  }

  private markFinishShown(): void {
    try {
      sessionStorage.setItem(FINISH_KEY, '1');
    } catch {
      /* private mode */
    }
  }
}
