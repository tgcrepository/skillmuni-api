import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

export const jobProfileRoutes: Routes = [
  {
    path: 'job-profile',
    title: $localize`:@@route.jobProfile:My Job Profile · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./job-profile-page').then((m) => m.JobProfilePage),
  },
  {
    path: 'job-profile/cv',
    title: $localize`:@@route.cvPreview:Preview my CV · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./cv-preview-page').then((m) => m.CvPreviewPage),
  },
  {
    path: 'job-profile/employer',
    title: $localize`:@@route.employerView:Employer view · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./employer-view-page').then((m) => m.EmployerViewPage),
  },
];
