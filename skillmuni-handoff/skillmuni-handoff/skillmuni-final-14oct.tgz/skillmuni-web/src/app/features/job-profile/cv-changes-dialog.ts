import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, computed, inject, signal, viewChild } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { CvChange, JOB_PROFILE_API } from '../../core/job-profile/job-profile.api';
import { Banner } from '../../shared/ui/banner/banner';
import { Button } from '../../shared/ui/button/button';
import { MuniTip } from '../../shared/ui/muni/muni-tip';
import { SmDialog } from '../../shared/ui/overlay/dialog';

export interface CvChangesData {
  readonly changes: readonly CvChange[];
}

const ICON: Record<CvChange['kind'], string> = {
  job: '💼',
  skill: '⚡',
  certificate: '🏅',
  contact: '✉️',
};

/**
 * P5 · New CV uploaded — review changes (Figma 310:46374). A newer CV never overwrites silently:
 * Muni lists only what changed, the learner adds or skips each item, then profile and CV update
 * together. Contact details default to "Keep current" (the record holds the verified value).
 */
@Component({
  selector: 'sm-cv-changes-dialog',
  imports: [Banner, Button, MuniTip, SmDialog],
  template: `
    <sm-dialog [title]="title">
      <sm-muni-tip class="tip" i18n="@@jp.busy">Nice, you have been busy! Pick what to add.</sm-muni-tip>
      <ul class="list">
        @for (c of data.changes; track c.id) {
          <li class="item" [class.is-on]="picked().has(c.id)">
            <span class="icon" aria-hidden="true">{{ icon[c.kind] }}</span>
            <span class="text">
              <span class="title">{{ c.title }}</span>
              <span class="sub">{{ c.detail }}</span>
            </span>
            <button
              type="button"
              class="toggle"
              [class.is-on]="picked().has(c.id)"
              [attr.aria-pressed]="picked().has(c.id)"
              [attr.aria-label]="toggleLabel(c)"
              (click)="toggle(c.id)"
            >
              @if (picked().has(c.id)) {
                <ng-container i18n="@@jp.adding">Adding ✓</ng-container>
              } @else if (c.suggest === 'keep') {
                <ng-container i18n="@@jp.keepCurrent">Keep current</ng-container>
              } @else {
                <ng-container i18n="@@jp.add">Add</ng-container>
              }
            </button>
          </li>
        }
      </ul>
      @if (failed()) {
        <sm-banner tone="error" i18n="@@jp.applyFailed">Couldn’t update your profile. Try again.</sm-banner>
      }
      <div smDialogActions>
        <button sm-button type="button" [loading]="busy()" [disabled]="!picked().size" (click)="apply()">
          {{ applyLabel() }}
        </button>
        <button sm-button variant="secondary" type="button" (click)="dialog().close()" i18n="@@jp.skipAll">
          Skip all
        </button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .tip {
      margin-block-end: var(--sm-space-400);
    }

    .list {
      display: grid;
      gap: var(--sm-space-250);
      margin: 0 0 var(--sm-space-300);
      padding: 0;
      list-style: none;
    }

    .item {
      display: flex;
      align-items: center;
      gap: var(--sm-space-300);
      padding: var(--sm-space-300) var(--sm-space-400);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-subtle);
      border-radius: var(--sm-radius-xl);
      background: var(--sm-color-surface-raised);
    }

    .item.is-on {
      border-color: var(--sm-color-border-accent);
      background: var(--sm-color-accent-subtle);
    }

    .text {
      display: grid;
      flex: 1 1 auto;
      min-inline-size: 0;
    }

    .title {
      color: var(--sm-color-text-heading);
      font: var(--sm-font-body-sm-semibold);
    }

    .sub {
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }

    .toggle {
      flex: none;
      min-block-size: var(--sm-size-control-sm);
      padding-inline: var(--sm-space-300);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-accent);
      border-radius: var(--sm-radius-full);
      background: var(--sm-color-surface-raised);
      color: var(--sm-color-text-accent);
      font: var(--sm-font-caption-bold);
      cursor: pointer;
    }

    .toggle.is-on {
      border-color: transparent;
      background: var(--sm-color-decor-pick-on);
      color: var(--sm-color-text-on-accent);
    }

    .toggle:focus-visible {
      box-shadow: var(--sm-shadow-focus-ring);
      outline: none;
    }
  `,
})
export class CvChangesDialog {
  private readonly api = inject(JOB_PROFILE_API);
  protected readonly data = inject<CvChangesData>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);

  protected readonly icon = ICON;
  protected readonly title = $localize`:@@jp.changesTitle:We found ${this.data.changes.length}:n: updates in your new CV`;
  protected readonly picked = signal<ReadonlySet<string>>(
    new Set(this.data.changes.filter((c) => c.suggest === 'add').map((c) => c.id)),
  );
  protected readonly busy = signal(false);
  protected readonly failed = signal(false);
  protected readonly applyLabel = computed(() =>
    this.picked().size === 1
      ? $localize`:@@jp.addOne:Add 1 update`
      : $localize`:@@jp.addN:Add ${this.picked().size}:n: updates`,
  );

  protected toggle(id: string): void {
    this.picked.update((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  protected toggleLabel(c: CvChange): string {
    return this.picked().has(c.id)
      ? $localize`:@@jp.addingSr:${c.title}:item:, will be added`
      : $localize`:@@jp.addSr:Add ${c.title}:item:`;
  }

  protected async apply(): Promise<void> {
    this.busy.set(true);
    this.failed.set(false);
    try {
      this.dialog().close(await firstValueFrom(this.api.applyChanges([...this.picked()])));
    } catch {
      this.failed.set(true);
    } finally {
      this.busy.set(false);
    }
  }
}
