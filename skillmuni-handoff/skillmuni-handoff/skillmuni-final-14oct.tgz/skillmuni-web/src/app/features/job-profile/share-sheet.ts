import { Component, OnInit, inject, signal, viewChild } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { JOB_PROFILE_API, ShareSettings } from '../../core/job-profile/job-profile.api';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { SmDialog } from '../../shared/ui/overlay/dialog';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { Switch } from '../../shared/ui/switch/switch';
import { ToastService } from '../../shared/ui/toast/toast.service';

const EXPIRY_STEPS = [7, 30, 90];

/**
 * P4 · Share my CV (Figma 310:45052 · sheet 310:45813). Link hides contact by default, expires in
 * 30 days (tap to change: 7 · 30 · 90), shows how many employers viewed it this week.
 */
@Component({
  selector: 'sm-share-sheet',
  imports: [Button, Icon, SmDialog, Skeleton, Switch],
  templateUrl: './share-sheet.html',
  styleUrl: './share-sheet.scss',
})
export class ShareSheet implements OnInit {
  private readonly api = inject(JOB_PROFILE_API);
  private readonly toast = inject(ToastService);
  protected readonly dialog = viewChild.required(SmDialog);

  protected readonly title = $localize`:@@jp.shareTitle:Share your CV`;
  protected readonly settings = signal<ShareSettings | null>(null);
  protected readonly failed = signal(false);
  protected readonly copied = signal(false);

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.failed.set(false);
    try {
      this.settings.set(await firstValueFrom(this.api.share()));
    } catch {
      this.failed.set(true);
    }
  }

  protected shortUrl(url: string): string {
    return url.replace(/^https?:\/\//, '');
  }

  protected async copy(url: string): Promise<void> {
    try {
      await navigator.clipboard.writeText(url);
      this.copied.set(true);
      setTimeout(() => this.copied.set(false), 2500);
    } catch {
      this.toast.show($localize`:@@jp.copyFailed:Couldn’t copy. Select the link and copy it.`, { tone: 'error' });
    }
  }

  protected whatsapp(url: string): string {
    const text = $localize`:@@jp.waText:Here’s my CV: ${url}:url:`;
    return `https://wa.me/?text=${encodeURIComponent(text)}`;
  }

  protected linkedin(url: string): string {
    return `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
  }

  protected mail(url: string): string {
    const subject = $localize`:@@jp.mailSubject:My CV`;
    const body = $localize`:@@jp.mailBody:Hi, here’s my CV: ${url}:url:`;
    return `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  }

  protected async setHide(hideContact: boolean): Promise<void> {
    await this.update({ hideContact });
  }

  protected async cycleExpiry(): Promise<void> {
    const s = this.settings();
    if (!s) return;
    const i = EXPIRY_STEPS.indexOf(s.expiresDays);
    await this.update({ expiresDays: EXPIRY_STEPS[(i + 1) % EXPIRY_STEPS.length] ?? 30 });
  }

  private async update(patch: Partial<Pick<ShareSettings, 'hideContact' | 'expiresDays'>>): Promise<void> {
    const s = this.settings();
    if (!s) return;
    this.settings.set({ ...s, ...patch });
    try {
      this.settings.set(
        await firstValueFrom(
          this.api.updateShare({
            hideContact: patch.hideContact ?? s.hideContact,
            expiresDays: patch.expiresDays ?? s.expiresDays,
          }),
        ),
      );
    } catch {
      this.settings.set(s);
      this.toast.show($localize`:@@jp.shareFailed:Couldn’t save that. Try again.`, { tone: 'error' });
    }
  }
}
