import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, computed, inject, signal, viewChild } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { JOB_PROFILE_API } from '../../core/job-profile/job-profile.api';
import { uniqueId } from '../../shared/ui/internal/unique-id';
import { Banner } from '../../shared/ui/banner/banner';
import { Button } from '../../shared/ui/button/button';
import { SmDialog } from '../../shared/ui/overlay/dialog';

export interface AboutDialogData {
  readonly text: string;
}

const MAX = 400;

/**
 * Rewrite "About me" (not drawn — A-205). Muni writes it from the quest answers; the learner can
 * rewrite it here. Clearing it hands the pen back to Muni.
 */
@Component({
  selector: 'sm-about-dialog',
  imports: [Banner, Button, SmDialog],
  template: `
    <sm-dialog [title]="title">
      <label class="label" [for]="ids.text" i18n="@@jp.aboutLabel">In your own words</label>
      <textarea
        class="text"
        [id]="ids.text"
        rows="6"
        [attr.maxlength]="max"
        [attr.aria-describedby]="ids.help"
        [value]="text()"
        (input)="text.set($any($event.target).value)"
      ></textarea>
      <p class="help" [id]="ids.help">
        <ng-container i18n="@@jp.aboutHelp">2–3 lines on what you’re good at and what you want next. Leave it empty and Muni writes it.</ng-container>
        <span class="count">{{ text().length }}/{{ max }}</span>
      </p>
      @if (failed()) {
        <sm-banner tone="error" i18n="@@jp.aboutFailed">Couldn’t save that. Try again.</sm-banner>
      }
      <div smDialogActions>
        <button sm-button type="button" [loading]="busy()" [disabled]="!changed()" (click)="save()" i18n="@@jp.saveAbout">
          Save
        </button>
        <button sm-button variant="secondary" type="button" (click)="dialog().close()" i18n="@@ui.cancel">Cancel</button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .label {
      display: block;
      margin-block-end: var(--sm-space-200);
      color: var(--sm-color-text-heading);
      font: var(--sm-font-label);
    }

    .text {
      inline-size: 100%;
      padding: var(--sm-space-300) var(--sm-space-400);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-default);
      border-radius: var(--sm-radius-xl);
      background: var(--sm-color-surface-field);
      color: var(--sm-color-text-primary);
      font: var(--sm-font-body);
      resize: vertical;
    }

    .text:focus-visible {
      border-color: var(--sm-color-border-focus);
      box-shadow: var(--sm-shadow-focus-ring);
      outline: none;
    }

    .help {
      display: flex;
      justify-content: space-between;
      gap: var(--sm-space-300);
      margin: var(--sm-space-200) 0 var(--sm-space-300);
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }

    .count {
      flex: none;
      font-variant-numeric: tabular-nums;
    }
  `,
})
export class AboutDialog {
  private readonly api = inject(JOB_PROFILE_API);
  private readonly data = inject<AboutDialogData>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);

  protected readonly title = $localize`:@@jp.rewriteTitle:Rewrite About me`;
  protected readonly ids = { text: uniqueId('about'), help: uniqueId('about-help') };
  protected readonly max = MAX;
  protected readonly text = signal(this.data.text);
  protected readonly changed = computed(() => this.text().trim() !== this.data.text.trim());
  protected readonly busy = signal(false);
  protected readonly failed = signal(false);

  protected async save(): Promise<void> {
    this.busy.set(true);
    this.failed.set(false);
    try {
      this.dialog().close(await firstValueFrom(this.api.saveAbout(this.text())));
    } catch {
      this.failed.set(true);
    } finally {
      this.busy.set(false);
    }
  }
}
