import { BackNav } from '../../core/layout/back-nav';
import { Component, OnInit, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { JOB_PROFILE_API, JobProfile } from '../../core/job-profile/job-profile.api';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { PlayerCard } from './player-card';
import { ProfileSections } from './profile-sections';

/**
 * P3 · Employer view (Figma 310:43756). The same record, read-only: no edit links, no private rows
 * (expected pay), no unproven certificates, and contact details held back until the learner applies.
 */
@Component({
  selector: 'sm-employer-view-page',
  imports: [Button, Icon, LearnerShell, PlayerCard, ProfileSections, RouterLink, Skeleton, StateBlock],
  templateUrl: './employer-view-page.html',
  styleUrls: ['./job-profile-page.scss', './employer-view-page.scss'],
})
export class EmployerViewPage implements OnInit {
  private readonly api = inject(JOB_PROFILE_API);
  private readonly router = inject(Router);
  private readonly nav = inject(BackNav);

  protected readonly state = signal<'loading' | 'ready' | 'error' | 'offline'>('loading');
  protected readonly profile = signal<JobProfile | null>(null);

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      this.profile.set(await firstValueFrom(this.api.profile()));
      this.state.set('ready');
    } catch (e) {
      this.state.set(e instanceof ApiError && e.kind === 'offline' ? 'offline' : 'error');
    }
  }

  protected back(): void {
    this.nav.back('/job-profile');
  }
}
