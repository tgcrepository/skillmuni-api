import { Component, computed, input, output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { JobProfile, QuestRef, SectionId } from '../../core/job-profile/job-profile.api';

/**
 * The CV sections of the Living CV (Figma 308:43440 right column): About me, Work lore (or the
 * fresher nudge, P7), Education, Languages, Skill deck, Certificates & proof, What I'm looking for.
 * `employer` mode (P3) drops every edit control, private rows and unverified "add proof" prompts.
 */
@Component({
  selector: 'sm-profile-sections',
  imports: [RouterLink],
  templateUrl: './profile-sections.html',
  styleUrl: './profile-sections.scss',
})
export class ProfileSections {
  readonly profile = input.required<JobProfile>();
  readonly employer = input(false);
  readonly rewrite = output<void>();

  protected readonly pips = [1, 2, 3];
  protected readonly names = {
    work: $localize`:@@jp.workLoreName:Work lore`,
    education: $localize`:@@jp.educationName:Education`,
    languages: $localize`:@@jp.languagesName:Languages`,
    skills: $localize`:@@jp.skillDeckName:Skill deck`,
    certs: $localize`:@@jp.certsName:Certificates & proof`,
    looking: $localize`:@@jp.lookingForName:What I’m looking for`,
  };

  protected readonly lookingFor = computed(() =>
    this.profile().lookingFor.filter((r) => !this.employer() || !r.private),
  );
  /** Employers only see certificates that have proof or are being checked (P3). */
  protected readonly certificates = computed(() =>
    this.profile().certificates.filter((c) => !this.employer() || c.status !== 'none'),
  );

  protected readonly freshers = [
    { label: $localize`:@@jp.addProject:College project`, kind: 'project' },
    { label: $localize`:@@jp.addVolunteering:Volunteering`, kind: 'volunteering' },
    { label: $localize`:@@jp.addFest:Fest / club role`, kind: 'club' },
    { label: $localize`:@@jp.addFamily:Family business`, kind: 'family' },
  ];

  protected src(id: SectionId): QuestRef {
    return this.profile().sources[id];
  }

  protected from(id: SectionId): string {
    return $localize`:@@jp.fromQuest:From quest · ${this.src(id).name}:quest:`;
  }

  protected editLabel(section: string): string {
    return $localize`:@@jp.editSection:Edit ${section}:section:`;
  }
}
