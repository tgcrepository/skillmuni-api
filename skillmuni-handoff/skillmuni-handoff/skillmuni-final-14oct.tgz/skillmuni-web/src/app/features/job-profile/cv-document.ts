import { Component, computed, input } from '@angular/core';
import { CvContact, JobProfile } from '../../core/job-profile/job-profile.api';

export type CvTemplate = 'creative' | 'classic' | 'modern';

export interface CvOptions {
  readonly photo: boolean;
  readonly archetype: boolean;
  readonly verified: boolean;
  readonly salary: boolean;
}

/**
 * The printable A4 CV (Figma P2 309:43602). Creative = dark sidebar + white page (as drawn).
 * Classic = one column, black on white, no colour or graphics (ATS-safe). Modern = violet header band.
 * Verified items carry a ✓ and the footer links to the public verify page.
 */
@Component({
  selector: 'sm-cv-document',
  templateUrl: './cv-document.html',
  styleUrl: './cv-document.scss',
  host: { '[class]': '"cv cv--" + template()' },
})
export class CvDocument {
  readonly profile = input.required<JobProfile>();
  readonly contact = input.required<CvContact>();
  readonly template = input<CvTemplate>('creative');
  readonly options = input.required<CvOptions>();

  protected readonly dots = [1, 2, 3, 4, 5];
  protected readonly initials = computed(() =>
    this.profile()
      .name.split(/\s+/)
      .map((w) => w.charAt(0))
      .join('')
      .slice(0, 2)
      .toUpperCase(),
  );

  /** Skills sorted signature-first; 1–3 power maps onto 5 dots. */
  protected readonly skills = computed(() =>
    [...this.profile().skills]
      .filter((s) => s.power !== null)
      .sort((a, b) => Number(b.signature) - Number(a.signature) || (b.power ?? 0) - (a.power ?? 0))
      .slice(0, 6)
      .map((s) => ({ name: s.name, level: Math.round(((s.power ?? 0) / 3) * 5) })),
  );

  protected readonly looking = computed(() => {
    const rows = this.profile().lookingFor;
    const get = (label: string) => rows.find((r) => r.label === label)?.value ?? '';
    return [get('Looking for'), get('Roles'), get('Where'), get('Shifts'), get('Can join') && `Can join ${get('Can join').toLowerCase()}`]
      .filter(Boolean)
      .join(' · ');
  });

  protected readonly certificates = computed(() =>
    this.profile().certificates.filter((c) => c.status !== 'none' || c.issuer !== 'Work proof'),
  );

  protected v(proof: string): boolean {
    return this.options().verified && proof === 'verified';
  }
}
