import { Component, computed, input } from '@angular/core';
import { RadarStats } from '../../core/job-profile/job-profile.api';

const AXES: readonly (keyof RadarStats)[] = ['people', 'business', 'data', 'creative', 'tech'];
const SIZE = 200;
const R = 70;
const C = SIZE / 2;

function point(i: number, scale: number): [number, number] {
  const a = -Math.PI / 2 + (i * 2 * Math.PI) / AXES.length;
  return [C + Math.cos(a) * R * scale, C + Math.sin(a) * R * scale];
}

/**
 * Player Card stat pentagon (Figma 308:43440): People · Business · Data · Creative · Tech, 0–100,
 * from the Career Assessment. Screen readers get the five values as text.
 */
@Component({
  selector: 'sm-stat-radar',
  template: `
    <svg [attr.viewBox]="'0 0 ' + size + ' ' + size" role="img" [attr.aria-label]="summary()">
      @for (ring of rings; track ring) {
        <polygon class="grid" [attr.points]="poly(ring)" />
      }
      @for (s of spokes; track $index) {
        <line class="grid" [attr.x1]="c" [attr.y1]="c" [attr.x2]="s[0]" [attr.y2]="s[1]" />
      }
      <polygon class="shape" [attr.points]="shape()" />
      @for (p of dots(); track $index) {
        <circle class="dot" [attr.cx]="p[0]" [attr.cy]="p[1]" r="3.5" />
      }
      @for (l of labels(); track l.key) {
        <text class="label" [attr.x]="l.x" [attr.y]="l.y" [attr.text-anchor]="l.anchor" aria-hidden="true">
          {{ l.text }}
        </text>
      }
    </svg>
  `,
  styles: `
    :host {
      display: block;
    }

    svg {
      display: block;
      inline-size: 100%;
      max-inline-size: var(--sm-size-job-profile-radar);
      margin-inline: auto;
      overflow: visible;
    }

    .grid {
      fill: none;
      stroke: var(--sm-color-border-subtle);
      stroke-width: 1;
    }

    .shape {
      fill: color-mix(in srgb, var(--sm-color-brand-solid) 30%, var(--sm-color-accent-solid) 20%);
      stroke: var(--sm-color-brand-solid);
      stroke-width: 2;
      stroke-linejoin: round;
    }

    .dot {
      fill: var(--sm-color-text-xp);
    }

    .label {
      fill: var(--sm-color-text-secondary);
      font: var(--sm-font-caption-semibold);
    }
  `,
})
export class StatRadar {
  readonly stats = input.required<RadarStats>();
  readonly labelNames = input<Readonly<Record<keyof RadarStats, string>>>({
    people: $localize`:@@jp.people:People`,
    business: $localize`:@@jp.business:Business`,
    data: $localize`:@@jp.data:Data`,
    creative: $localize`:@@jp.creative:Creative`,
    tech: $localize`:@@jp.tech:Tech`,
  });

  protected readonly size = SIZE;
  protected readonly c = C;
  protected readonly rings = [0.33, 0.66, 1];
  protected readonly spokes = AXES.map((_, i) => point(i, 1));

  protected poly(scale: number): string {
    return AXES.map((_, i) => point(i, scale).join(',')).join(' ');
  }

  protected readonly dots = computed(() =>
    AXES.map((k, i) => point(i, Math.max(0.08, this.stats()[k] / 100))),
  );
  protected readonly shape = computed(() => this.dots().map((p) => p.join(',')).join(' '));
  protected readonly labels = computed(() =>
    AXES.map((k, i) => {
      const [x, y] = point(i, 1.32);
      const anchor = Math.abs(x - C) < 4 ? 'middle' : x > C ? 'start' : 'end';
      return { key: k, x, y: y + 4, anchor, text: this.labelNames()[k] };
    }),
  );
  protected readonly summary = computed(() =>
    AXES.map((k) => `${this.labelNames()[k]} ${this.stats()[k]}`).join(', '),
  );
}
