import { Component, input } from '@angular/core';
import { JobProfile } from '../../core/job-profile/job-profile.api';
import { StatRadar } from './stat-radar';

/**
 * "Your Player Card" (Figma 308:43440 left column): name, archetype from the Career Assessment,
 * stat pentagon, 3 signature moves with power pips, and skill / language / trophy counts.
 * Same card in the learner's view and the employer view.
 */
@Component({
  selector: 'sm-player-card',
  imports: [StatRadar],
  templateUrl: './player-card.html',
  styleUrl: './player-card.scss',
})
export class PlayerCard {
  readonly profile = input.required<JobProfile>();
  readonly headingLevel = input<2 | 3>(2);

  protected readonly pips = [1, 2, 3];
}
