import { NgOptimizedImage } from '@angular/common';
import { Typewriter } from '../../shared/ui/muni/typewriter';
import { Directionality } from '@angular/cdk/bidi';
import { Component, computed, inject, input, linkedSignal } from '@angular/core';
import { Notch } from '../../core/assessment/assessment.api';
import { split } from '../../core/assessment/scoring';
import { ASSETS } from '../../shared/assets';

/** Where each notch sits along the beam (Figma 263:21128, 600 × 210). */
const NOTCH_X = [27, 41, 59, 73] as const;
/** Board tilt per notch in degrees: all-in tips further than a lean. */
const TILT = [-9, -4.5, 4.5, 9] as const;

/**
 * Muni's Balance seesaw (Figma B3 263:20783 · B4 263:21804). Pure picture: the accessible control
 * is the notch radio group on the page; clicking a notch circle selects its radio through `for`.
 * Motion (note 268:22368): Muni hops 250 ms, the board tilts 300 ms with an overshoot, coins drop
 * 350 ms staggered. All durations are motion tokens, so reduced motion collapses them to instant.
 */
@Component({
  selector: 'sm-seesaw',
  imports: [NgOptimizedImage, Typewriter],
  template: `
    <div
      class="stage"
      [style.--tilt]="tilt() + 'deg'"
      [style.--pos]="pos() + '%'"
      [class.is-set]="notch() !== null"
    >
      <span class="ground"></span>
      <svg class="fulcrum" viewBox="0 0 72 44" aria-hidden="true">
        <polygon points="36,2 70,42 2,42" />
      </svg>

      <div class="board">
        <span class="bar"></span>
        <span class="pad pad--this"></span>
        <span class="pad pad--that"></span>

        <span class="coins coins--this">
          @for (c of coinsThis(); track $index) {
            <span class="coin" [style.--i]="$index"></span>
          }
        </span>
        <span class="coins coins--that">
          @for (c of coinsThat(); track $index) {
            <span class="coin" [style.--i]="$index"></span>
          }
        </span>

        @for (x of notchX; track $index) {
          <label
            class="notch"
            [class.notch--that]="$index > 1"
            [class.is-on]="notch() === $index"
            [for]="radioIds()[$index]"
            [style.--x]="x + '%'"
          ></label>
        }

        <!-- A-247: three poses stacked; the one for this side fades in at the top of the hop. -->
        <span class="muni" [attr.data-pose]="pose()" [style.--lean]="lean() + 'deg'">
          <span class="figure" [class]="'figure ' + (hop() ? 'hop-a' : 'hop-b')">
            @for (p of poses; track p.id) {
              <img
                class="pose"
                [class.is-on]="pose() === p.id"
                [ngSrc]="p.src"
                alt=""
                width="424"
                height="530"
                priority
              />
            }
          </span>
        </span>
      </div>

      <!-- A-269: the bubble sits on Muni's roomier side so it never runs off a phone screen. -->
      <span class="bubble" [class.bubble--flip]="pos() > 50" smTypewriter>{{ bubble() }}</span>
    </div>
  `,
  styleUrl: './seesaw.scss',
  host: { 'aria-hidden': 'true' },
})
export class Seesaw {
  readonly notch = input<Notch | null>(null);
  readonly bubble = input('');
  /** Ids of the 4 notch radios so the circles can select them. */
  readonly radioIds = input.required<readonly string[]>();

  protected readonly notchX = NOTCH_X;
  private readonly dir = inject(Directionality);
  protected readonly poses = [
    { id: 'center', src: ASSETS.muniPose.center },
    { id: 'left', src: ASSETS.muniPose.left },
    { id: 'right', src: ASSETS.muniPose.right },
  ] as const;

  /**
   * Arms crossed until the learner picks; then he leans and points toward the side he's on
   * ("This" is on the left in LTR, on the right in RTL).
   */
  protected readonly pose = computed<'center' | 'left' | 'right'>(() => {
    const n = this.notch();
    if (n === null) return 'center';
    const thisSide = this.dir.value === 'rtl' ? 'right' : 'left';
    const thatSide = thisSide === 'left' ? 'right' : 'left';
    return n <= 1 ? thisSide : thatSide;
  });
  /** All-in leans further than a gentle lean. */
  protected readonly lean = computed(() => {
    const n = this.notch();
    return n === 0 ? -3 : n === 3 ? 3 : 0;
  });

  protected readonly tilt = computed(() => {
    const n = this.notch();
    return n === null ? 0 : TILT[n];
  });
  protected readonly pos = computed(() => {
    const n = this.notch();
    return n === null ? 50 : NOTCH_X[n];
  });
  protected readonly coinsThis = computed(() => {
    const n = this.notch();
    return Array.from({ length: n === null ? 0 : split(n)[0] });
  });
  protected readonly coinsThat = computed(() => {
    const n = this.notch();
    return Array.from({ length: n === null ? 0 : split(n)[1] });
  });

  /** Flips on every new notch so the hop keyframes restart. */
  protected readonly hop = linkedSignal<Notch | null, boolean>({
    source: this.notch,
    computation: (_n, prev) => !(prev?.value ?? false),
  });
}
