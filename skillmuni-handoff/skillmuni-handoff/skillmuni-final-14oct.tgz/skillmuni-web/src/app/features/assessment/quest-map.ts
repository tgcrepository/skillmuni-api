import { Component, computed, input } from '@angular/core';
import { Answer, Island } from '../../core/assessment/assessment.api';
import { isAnswered } from '../../core/assessment/scoring';

export interface IslandView {
  readonly island: Island;
  readonly answered: number;
  readonly skipped: number;
  readonly size: number;
  readonly state: 'cleared' | 'current' | 'skipped' | 'todo';
}

/** Per-island progress for the quest map (shared by the rail, the strip and the final check). */
export function islandViews(
  islands: readonly Island[],
  answers: readonly Answer[],
  current: number | null,
): IslandView[] {
  return islands.map((island) => {
    const slice = answers.slice(island.from - 1, island.to);
    const answered = slice.filter(isAnswered).length;
    const skipped = slice.filter((a) => a === 'skip').length;
    const size = island.to - island.from + 1;
    const here = current !== null && current >= island.from - 1 && current < island.to;
    const state = here
      ? 'current'
      : answered === size
        ? 'cleared'
        : skipped && answered + skipped === size
          ? 'skipped'
          : 'todo';
    return { island, answered, skipped, size, state };
  });
}

/**
 * Quest map (Figma B3 rail 263:21013; tablet/mobile strip). Four islands of nine pairs: cleared
 * islands get a green ring, Muni's island glows orange, islands with skipped pairs say so (B7).
 */
@Component({
  selector: 'sm-quest-map',
  template: `
    @if (layout() === 'rail') {
      <section class="rail" aria-labelledby="qm-title">
        <h2 class="overline" id="qm-title" i18n="@@ca.questMap">Quest map</h2>
        <p class="count">
          <span class="n">{{ done() }}</span> <span class="of">/ {{ total() }}</span>
          <span class="sm-visually-hidden" i18n="@@ca.pairsDone">pairs done</span>
        </p>
        <span class="bar" aria-hidden="true"><span class="bar-fill" [style.--v]="done() / total()"></span></span>
        <ol class="islands">
          @for (v of views(); track v.island.n) {
            <li class="island" [class]="'island is-' + v.state" [attr.aria-current]="v.state === 'current' ? 'step' : null">
              <span class="ring" aria-hidden="true">{{ v.island.emoji }}</span>
              <span class="text">
                <span class="i-n" i18n="@@ca.islandN">Island {{ v.island.n }}</span>
                <span class="i-name">{{ v.island.name }}</span>
                @switch (v.state) {
                  @case ('cleared') {
                    <span class="chip chip--ok" i18n="@@ca.cleared">✓ Cleared</span>
                  }
                  @case ('current') {
                    <span class="chip chip--here" i18n="@@ca.here">{{ v.answered + v.skipped }}/{{ v.size }} · Muni’s here</span>
                  }
                  @case ('skipped') {
                    <span class="chip chip--skip" i18n="@@ca.skippedN">{{ v.skipped }} skipped</span>
                  }
                  @default {
                    <span class="i-sub" i18n="@@ca.nPairs">{{ v.size }} pairs</span>
                  }
                }
              </span>
            </li>
          }
        </ol>
      </section>
    } @else {
      <div class="strip">
        <ol class="dots" i18n-aria-label="@@ca.questMapSr" aria-label="Quest map">
          @for (v of views(); track v.island.n) {
            <li
              class="dot"
              [class]="'dot is-' + v.state"
              [attr.aria-current]="v.state === 'current' ? 'step' : null"
            >
              <span aria-hidden="true">{{ v.island.emoji }}</span>
              <span class="sm-visually-hidden">{{ v.island.name }}, {{ stateLabel(v) }}</span>
            </li>
          }
        </ol>
        <p class="strip-count">
          <span class="strip-n">{{ done() }}/{{ total() }}</span>
          @if (currentName(); as name) {
            <span class="strip-name">{{ name }}</span>
          }
        </p>
      </div>
    }
  `,
  styleUrl: './quest-map.scss',
})
export class QuestMap {
  readonly islands = input.required<readonly Island[]>();
  readonly answers = input.required<readonly Answer[]>();
  /** Index of the pair on screen; null on the final check and reveal. */
  readonly current = input<number | null>(null);
  readonly layout = input<'rail' | 'strip'>('rail');

  protected readonly views = computed(() => islandViews(this.islands(), this.answers(), this.current()));
  protected readonly done = computed(() => this.answers().filter(isAnswered).length);
  protected readonly total = computed(() => this.answers().length);
  protected readonly currentName = computed(() => this.views().find((v) => v.state === 'current')?.island.name);

  protected stateLabel(v: IslandView): string {
    switch (v.state) {
      case 'cleared':
        return $localize`:@@ca.clearedSr:cleared`;
      case 'current':
        return $localize`:@@ca.currentSr:you are here, ${v.answered + v.skipped}:n: of ${v.size}:size:`;
      case 'skipped':
        return $localize`:@@ca.skippedSr:${v.skipped}:n: skipped`;
      default:
        return $localize`:@@ca.todoSr:not started`;
    }
  }
}
