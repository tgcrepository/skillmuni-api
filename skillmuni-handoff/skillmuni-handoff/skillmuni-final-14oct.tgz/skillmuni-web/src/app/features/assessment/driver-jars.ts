import { Component, computed, input } from '@angular/core';
import { DRIVER_IDS, DriverId, DriverInfo, DriverScores } from '../../core/assessment/assessment.api';
import { DRIVER_MAX } from '../../core/assessment/scoring';

/**
 * The 9 driver jars (Figma B3 rail 263:21060, tablet strip, B8 reveal 264:26446). While playing the
 * jars only show how full they are, labelled "?", so nothing nudges an answer. `open` lifts the
 * lids one by one, names each driver with its coins, and the top 3 glow orange.
 */
@Component({
  selector: 'sm-driver-jars',
  template: `
    <ul
      class="jars"
      [class.jars--strip]="size() === 'sm'"
      [class.is-open]="open()"
      [attr.aria-hidden]="open() ? null : 'true'"
    >
      @for (j of jars(); track j.id) {
        <li class="jar" [class.is-top]="j.top" [style.--i]="$index" [style.--fill]="j.fill">
          <span class="lid"></span>
          <span class="body"><span class="fill"></span></span>
          @if (open() && j.info; as d) {
            <span class="score"
              ><span aria-hidden="true">{{ d.emoji }}</span> {{ j.score }}<span class="sm-visually-hidden">/24</span></span
            >
            <span class="name">{{ short(d) }}</span>
          } @else {
            <span class="q" aria-hidden="true">?</span>
          }
        </li>
      }
    </ul>
  `,
  styleUrl: './driver-jars.scss',
})
export class DriverJars {
  readonly scores = input.required<DriverScores>();
  /** Driver names, only passed once the jars open. */
  readonly drivers = input<readonly DriverInfo[] | null>(null);
  readonly top = input<readonly DriverId[]>([]);
  readonly open = input(false);
  readonly size = input<'md' | 'sm'>('md');

  protected readonly jars = computed(() => {
    const s = this.scores();
    const info = this.drivers();
    return DRIVER_IDS.map((id) => ({
      id,
      score: s[id],
      fill: Math.min(1, s[id] / DRIVER_MAX),
      top: this.open() && this.top().includes(id),
      info: info?.find((d) => d.id === id) ?? null,
    }));
  });

  /** "Material Rewards" → "Material", "Power / Influence" → "Power" (Figma B8 labels). */
  protected short(d: DriverInfo): string {
    return d.name.split(/[\s/]/)[0] ?? d.name;
  }
}
