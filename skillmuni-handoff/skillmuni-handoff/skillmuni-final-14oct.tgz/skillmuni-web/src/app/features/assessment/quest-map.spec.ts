import { ISLANDS } from '../../../mocks/assessment.data';
import { Answer } from '../../core/assessment/assessment.api';
import { islandViews } from './quest-map';

describe('islandViews', () => {
  const all = (fill: Answer): Answer[] => Array.from({ length: 36 }, () => fill);

  it('marks Muni’s island as current and counts its progress', () => {
    const a = all(null);
    for (let i = 0; i < 13; i++) a[i] = 1;
    const v = islandViews(ISLANDS, a, 13);
    expect(v.map((x) => x.state)).toEqual(['cleared', 'current', 'todo', 'todo']);
    expect(v[1]?.answered).toBe(4);
  });

  it('flags islands with skipped pairs on the final check', () => {
    const a = all(2);
    a[11] = 'skip';
    a[26] = 'skip';
    const v = islandViews(ISLANDS, a, null);
    expect(v.map((x) => x.state)).toEqual(['cleared', 'skipped', 'skipped', 'cleared']);
    expect(v[1]?.skipped).toBe(1);
  });
});
