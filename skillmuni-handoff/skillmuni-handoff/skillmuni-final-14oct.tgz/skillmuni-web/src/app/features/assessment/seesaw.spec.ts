import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Notch } from '../../core/assessment/assessment.api';
import { Seesaw } from './seesaw';

@Component({
  imports: [Seesaw],
  template: `<sm-seesaw [notch]="notch()" bubble="Hi" [radioIds]="ids" />`,
})
class Host {
  readonly notch = signal<Notch | null>(null);
  readonly ids = ['a', 'b', 'c', 'd'];
}

/** A-247: Muni's pose follows the side the learner leans to. */
describe('Seesaw poses', () => {
  const pose = (el: HTMLElement) => el.querySelector('.muni')?.getAttribute('data-pose');

  it('arms crossed in the middle, leaning toward the picked side', async () => {
    const fixture = TestBed.createComponent(Host);
    const el = fixture.nativeElement as HTMLElement;
    await fixture.whenStable();
    expect(pose(el)).toBe('center');
    expect(el.querySelectorAll('img.pose')).toHaveLength(3);
    fixture.componentInstance.notch.set(0);
    await fixture.whenStable();
    expect(pose(el)).toBe('left');
    fixture.componentInstance.notch.set(2);
    await fixture.whenStable();
    expect(pose(el)).toBe('right');
    expect(el.querySelectorAll('img.pose.is-on')).toHaveLength(1);
  });
});
