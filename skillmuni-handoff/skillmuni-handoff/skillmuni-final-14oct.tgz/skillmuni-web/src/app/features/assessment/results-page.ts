import { BackNav } from '../../core/layout/back-nav';
import { DatePipe, NgOptimizedImage } from '@angular/common';
import { Component, computed, effect, inject, input, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { rxResource } from '@angular/core/rxjs-interop';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import {
  ASSESSMENT_API,
  AssessmentResult,
  DriverId,
  DriverInfo,
} from '../../core/assessment/assessment.api';
import { DRIVER_MAX, band } from '../../core/assessment/scoring';
import { ASSETS } from '../../shared/assets';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { AssessmentConfirmDialog, ConfirmData } from './assessment-dialogs';
import { ASSESSMENT_FLOW, ASSESSMENT_LINKS } from './assessment-page';
import { DriverRadar } from './driver-radar';
import { Currency } from '../../shared/ui/currency/currency';
import { Typewriter } from '../../shared/ui/muni/typewriter';

/**
 * S1 · Your Career Drivers (Figma 266:21651 · 266:22145 · 266:22630) and S2 · Retake confirm
 * (267:21894). Archetype hero, 9-driver radar, top 3 drivers with change since the last attempt,
 * full breakdown (tap a driver for its meaning), where you'll thrive and what to watch out for.
 */
@Component({
  selector: 'sm-results-page',
  imports: [Typewriter, Currency, 
    Button,
    DatePipe,
    DriverRadar,
    Icon,
    LearnerShell,
    NgOptimizedImage,
    RouterLink,
    Skeleton,
    StateBlock,
  ],
  templateUrl: './results-page.html',
  styleUrl: './results-page.scss',
})
export class ResultsPage {
  protected readonly nav = inject(BackNav);

  /**
   * Corrections #19: Back from the results goes to where the assessment was opened from (the Lobby's
   * first moves, the Career Launchpad, Profile…), never back into the assessment's own intro.
   */
  protected back(): void {
    const prev = this.nav.previousPath(ASSESSMENT_LINKS.report);
    if (prev && !prev.startsWith(ASSESSMENT_FLOW)) {
      this.nav.back(prev);
      return;
    }
    this.nav.up(this.nav.origin(ASSESSMENT_FLOW) ?? ASSESSMENT_LINKS.launchpad);
  }
  private readonly api = inject(ASSESSMENT_API);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);

  /** `?attempt=` shows an earlier attempt. */
  readonly attempt = input<string | undefined>();

  protected readonly links = { ...ASSESSMENT_LINKS, courses: '/stats/learning' };
  protected readonly avatar = ASSETS.muniAvatar;
  protected readonly max = DRIVER_MAX;

  protected readonly res = rxResource({
    params: () => ({ attempt: Number(this.attempt()) || undefined }),
    stream: ({ params }) => this.api.result(params.attempt),
  });
  protected readonly r = computed<AssessmentResult | undefined>(() =>
    this.res.hasValue() ? this.res.value() : undefined,
  );
  protected readonly state = computed(() =>
    this.res.isLoading() ? 'loading' : this.res.error() ? 'error' : 'ready',
  );

  protected readonly compare = signal(false);
  protected readonly open = signal<DriverId | null>(null);

  constructor() {
    // No result yet (never finished): the assessment itself is the right place.
    effect(() => {
      const e = this.res.error();
      if (e instanceof ApiError && e.status === 404) void this.router.navigateByUrl('/assessments/career');
    });
  }

  protected info(r: AssessmentResult, id: DriverId): DriverInfo {
    return (
      r.drivers.find((d) => d.id === id) ?? {
        id,
        name: id,
        emoji: '',
        focus: '',
        definition: '',
        blurb: '',
        strengthZones: '',
        families: '',
      }
    );
  }

  protected readonly top3 = computed(() => this.r()?.ranking.slice(0, 3) ?? []);
  protected readonly dominant = computed(() => {
    const r = this.r();
    return r ? r.archetype.dominant.map((d) => this.info(r, d).name).join(' + ') : '';
  });
  protected readonly prevN = computed(() => {
    const r = this.r();
    return r?.previous ? r.attempt - 1 : null;
  });

  protected delta(r: AssessmentResult, id: DriverId): number | null {
    return r.previous ? r.scores[id] - r.previous[id] : null;
  }

  protected bandText(score: number): string {
    switch (band(score)) {
      case 'high':
        return $localize`:@@ca.bandHigh:A top motivator for you. Roles that feed it will feel energising.`;
      case 'mid':
        return $localize`:@@ca.bandMid:Mid-range for you, so it matters, but it won’t be the deciding factor.`;
      default:
        return $localize`:@@ca.bandLow:Not a big pull for you right now. Roles built around it may feel flat.`;
    }
  }

  protected lowerFirst(s: string): string {
    return s.charAt(0).toLowerCase() + s.slice(1);
  }

  protected toggle(id: DriverId): void {
    this.open.update((o) => (o === id ? null : id));
  }

  protected pickAttempt(e: Event): void {
    const n = (e.target as HTMLSelectElement).value;
    void this.router.navigate([], { queryParams: { attempt: n }, replaceUrl: true });
  }

  protected print(): void {
    window.print();
  }

  protected async share(): Promise<void> {
    const r = this.r();
    if (!r) return;
    const text = $localize`:@@ca.shareText:I’m ${r.archetype.name}:name: on Skillmuni. My top drivers: ${this.top3()
      .map((d) => this.info(r, d).name)
      .join(', ')}:drivers:.`;
    try {
      if (navigator.share) {
        await navigator.share({ text });
        return;
      }
      await navigator.clipboard.writeText(text);
      this.toast.show($localize`:@@ca.shareCopied:Copied. Paste it anywhere.`, { tone: 'success' });
    } catch (e) {
      if ((e as DOMException)?.name !== 'AbortError')
        this.toast.show($localize`:@@ca.shareFailed:Couldn’t share. Try again.`, { tone: 'error' });
    }
  }

  protected retake(): void {
    const ref = this.overlay.adaptive<AssessmentConfirmDialog, ConfirmData, boolean>(AssessmentConfirmDialog, {
      data: { kind: 'retake' },
      size: 'sm',
    });
    ref.closed.subscribe(async (yes) => {
      if (!yes) return;
      try {
        await firstValueFrom(this.api.retake());
        void this.router.navigateByUrl('/assessments/career');
      } catch {
        this.toast.show($localize`:@@ca.saveFailed:Couldn’t reach the server. Try again.`, { tone: 'error' });
      }
    });
  }
}
