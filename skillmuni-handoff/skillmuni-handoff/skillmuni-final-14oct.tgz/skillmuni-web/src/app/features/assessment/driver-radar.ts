import { Component, computed, input } from '@angular/core';
import { DRIVER_IDS, DriverId, DriverInfo, DriverScores } from '../../core/assessment/assessment.api';
import { DRIVER_MAX } from '../../core/assessment/scoring';

const SIZE = 340;
const C = SIZE / 2;
const R = 112;
const RINGS = [6, 12, 18, 24];

/**
 * "All 9 drivers" radar (Figma S1 266:21651): drivers A–I clockwise from the top, 0–24 each.
 * `previous` draws the earlier attempt as a dashed outline when comparing. Screen readers get the
 * nine scores as text instead of the drawing.
 */
@Component({
  selector: 'sm-driver-radar',
  template: `
    <svg [attr.viewBox]="'0 0 ' + size + ' ' + size" role="img" [attr.aria-label]="summary()">
      @for (r of rings; track r) {
        <polygon class="ring" [attr.points]="poly(r)" />
      }
      @for (a of axes(); track a.id) {
        <line class="axis" [attr.x1]="c" [attr.y1]="c" [attr.x2]="a.x" [attr.y2]="a.y" />
      }
      @if (prevPoints(); as pp) {
        <polygon class="prev" [attr.points]="pp" />
      }
      <polygon class="shape" [attr.points]="points()" />
      @for (d of dots(); track d.id) {
        <circle class="dot" [class.is-top]="d.top" [attr.cx]="d.x" [attr.cy]="d.y" r="4" />
      }
      @for (a of axes(); track a.id) {
        <text class="label" [attr.x]="a.lx" [attr.y]="a.ly" [attr.text-anchor]="a.anchor" aria-hidden="true">
          {{ a.emoji }} {{ a.score }}
        </text>
      }
    </svg>
  `,
  styles: `
    :host {
      display: block;
    }

    svg {
      display: block;
      inline-size: 100%;
      max-inline-size: var(--sm-size-assessment-radar);
      margin-inline: auto;
      overflow: visible;
    }

    .ring {
      fill: none;
      stroke: var(--sm-color-border-subtle);
      stroke-width: 1;
    }

    .axis {
      stroke: var(--sm-color-border-subtle);
      stroke-width: 1;
    }

    .shape {
      fill: color-mix(in srgb, var(--sm-color-brand-solid) 22%, transparent);
      stroke: var(--sm-color-brand-solid);
      stroke-width: 2;
      stroke-linejoin: round;
      transform-origin: 50% 50%;
      animation: grow var(--sm-motion-duration-celebrate) var(--sm-motion-easing-spring) both;
    }

    .prev {
      fill: none;
      stroke: var(--sm-color-accent-solid);
      stroke-dasharray: 4 4;
      stroke-width: 1.5;
    }

    .dot {
      fill: var(--sm-color-surface-raised);
      stroke: var(--sm-color-brand-solid);
      stroke-width: 2;
      opacity: 0;

      &.is-top {
        fill: var(--sm-color-brand-solid);
        opacity: 1;
      }
    }

    .label {
      fill: var(--sm-color-text-heading);
      font: var(--sm-font-caption-bold);
    }

    @keyframes grow {
      from {
        opacity: 0;
        transform: scale(0.2);
      }
    }
  `,
})
export class DriverRadar {
  readonly scores = input.required<DriverScores>();
  readonly drivers = input.required<readonly DriverInfo[]>();
  readonly previous = input<DriverScores | null>(null);
  readonly top = input<readonly DriverId[]>([]);

  protected readonly size = SIZE;
  protected readonly c = C;
  protected readonly rings = RINGS;

  private point(i: number, v: number): [number, number] {
    const a = -Math.PI / 2 + (i * 2 * Math.PI) / DRIVER_IDS.length;
    const r = (R * v) / DRIVER_MAX;
    return [C + r * Math.cos(a), C + r * Math.sin(a)];
  }

  protected poly(v: number): string {
    return DRIVER_IDS.map((_, i) => this.point(i, v).map((n) => n.toFixed(1)).join(',')).join(' ');
  }

  private shape(s: DriverScores): string {
    return DRIVER_IDS.map((d, i) => this.point(i, s[d]).map((n) => n.toFixed(1)).join(',')).join(' ');
  }

  protected readonly points = computed(() => this.shape(this.scores()));
  protected readonly prevPoints = computed(() => {
    const p = this.previous();
    return p ? this.shape(p) : null;
  });

  protected readonly dots = computed(() =>
    DRIVER_IDS.map((id, i) => {
      const [x, y] = this.point(i, this.scores()[id]);
      return { id, x, y, top: this.top().includes(id) };
    }),
  );

  protected readonly axes = computed(() =>
    DRIVER_IDS.map((id, i) => {
      const [x, y] = this.point(i, DRIVER_MAX);
      const [lx, ly] = this.point(i, DRIVER_MAX + 5.5);
      const dx = lx - C;
      return {
        id,
        x,
        y,
        lx,
        ly: ly + 4,
        anchor: Math.abs(dx) < 8 ? 'middle' : dx > 0 ? 'start' : 'end',
        emoji: this.drivers().find((d) => d.id === id)?.emoji ?? '',
        score: this.scores()[id],
      };
    }),
  );

  protected readonly summary = computed(() => {
    const parts = DRIVER_IDS.map(
      (id) => `${this.drivers().find((d) => d.id === id)?.name ?? id} ${this.scores()[id]}`,
    ).join(', ');
    return $localize`:@@ca.radarSr:Your 9 drivers out of 24: ${parts}:parts:`;
  });
}
