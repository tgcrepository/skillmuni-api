import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

export const assessmentRoutes: Routes = [
  {
    path: 'assessments/career',
    title: $localize`:@@route.assessment:Career Assessment · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./assessment-page').then((m) => m.AssessmentPage),
  },
  {
    path: 'assessments/career/report',
    title: $localize`:@@route.assessmentReport:Your Career Drivers · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./results-page').then((m) => m.ResultsPage),
  },
];
