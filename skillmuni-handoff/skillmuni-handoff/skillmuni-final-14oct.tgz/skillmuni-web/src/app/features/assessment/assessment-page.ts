import { SoundFx } from '../../core/audio/sound-fx';
import { BackNav } from '../../core/layout/back-nav';
import { FeedbackPrompt } from '../../core/feedback/feedback-prompt';
import { NgOptimizedImage, NgTemplateOutlet } from '@angular/common';
import {
  Component,
  DestroyRef,
  ElementRef,
  OnInit,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Auth } from '../../core/auth/auth';
import {
  ASSESSMENT_API,
  Answer,
  AssessmentResult,
  DriverId,
  DriverInfo,
  Island,
  Notch,
  Pair,
} from '../../core/assessment/assessment.api';
import { isAnswered, minutesLeft, scoreDrivers, split } from '../../core/assessment/scoring';
import { Viewport } from '../../core/layout/viewport';
import { ASSETS } from '../../shared/assets';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { CountUp } from '../../shared/ui/count-up/count-up';
import { Icon } from '../../shared/ui/icon/icon';
import { MuniCharacter } from '../../shared/ui/muni/muni-character';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { Confetti } from '../../shared/ui/quest/confetti';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { ToastService } from '../../shared/ui/toast/toast.service';
import {
  AssessmentConfirmDialog,
  ConfirmData,
  SaveExitData,
  SaveExitDialog,
  SaveExitResult,
  WhyPairsDialog,
} from './assessment-dialogs';
import { DriverJars } from './driver-jars';
import { QuestMap, islandViews } from './quest-map';
import { Seesaw } from './seesaw';
import { Currency } from '../../shared/ui/currency/currency';

type Phase =
  | 'loading'
  | 'error'
  | 'intro'
  | 'resume'
  | 'play'
  | 'island'
  | 'final'
  | 'calculating'
  | 'offline'
  | 'failed'
  | 'reveal';

/** Board settles (hop 250 + tilt 300 + coins 350 staggered), then the next pair slides in. */
const ADVANCE_MS = 1150;
const ADVANCE_REDUCED_MS = 600;
const CALC_STEP_MS = 650;
const BACKUP_KEY = 'sm_ca_backup';

/** Every assessment screen lives under this path (intro, play, results). */
export const ASSESSMENT_FLOW = '/assessments/career';

export const ASSESSMENT_LINKS = {
  launchpad: '/launchpad',
  report: '/assessments/career/report',
  jobs: '/jobs',
} as const;

/**
 * Career Assessment v2 · Option B "Muni's Balance" (Figma 259:19781, note 268:22368).
 * 36 pairs from the Career Drivers Survey 2025 across 4 islands. Each pair is one tap on a 4-notch
 * seesaw (3 coins split 3·0 / 2·1 / 1·2 / 0·3); coins fall into 9 hidden jars that open at the end.
 * B1 intro · B2 resume · B3/B4 pair · B5 island cleared · B6 save & exit · B7 final check ·
 * S4 calculating · S3 offline · B8 the jars open. Answers auto-save after every tap.
 */
@Component({
  selector: 'sm-assessment-page',
  imports: [Currency, 
    Button,
    Confetti,
    CountUp,
    DriverJars,
    Icon,
    LearnerShell,
    MuniCharacter,
    NgOptimizedImage,
    NgTemplateOutlet,
    QuestMap,
    RouterLink,
    Seesaw,
    Skeleton,
    StateBlock,
  ],
  templateUrl: './assessment-page.html',
  styleUrl: './assessment-page.scss',
  host: { '(document:keydown)': 'onKey($event)' },
})
export class AssessmentPage implements OnInit {
  protected readonly nav = inject(BackNav);
  private readonly api = inject(ASSESSMENT_API);
  private readonly feedback = inject(FeedbackPrompt);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);
  private readonly auth = inject(Auth);
  private readonly destroyRef = inject(DestroyRef);
  protected readonly viewport = inject(Viewport);
  private readonly sfx = inject(SoundFx);

  protected readonly links = ASSESSMENT_LINKS;
  protected readonly avatar = ASSETS.muniAvatar;
  protected readonly notches = [0, 1, 2, 3] as const;
  protected readonly radioIds = this.notches.map((n) => `ca-notch-${n}`);

  protected readonly phase = signal<Phase>('loading');
  protected readonly pairs = signal<readonly Pair[]>([]);
  protected readonly islands = signal<readonly Island[]>([]);
  protected readonly answers = signal<Answer[]>([]);
  protected readonly index = signal(0);
  protected readonly xp = signal(0);
  protected readonly earnsXp = signal(true);
  protected readonly remind = signal(true);
  protected readonly cleared = signal<Island | null>(null);
  protected readonly islandXp = signal(0);
  protected readonly result = signal<AssessmentResult | null>(null);
  protected readonly calcStep = signal(0);
  /** A pick is on the board and the next pair is about to slide in. */
  protected readonly settling = signal(false);
  /** Answering a pair picked from the final check returns there. */
  private readonly fromFinal = signal(false);
  protected readonly live = signal('');

  private readonly heading = viewChild<ElementRef<HTMLElement>>('phaseHeading');
  private timer: ReturnType<typeof setTimeout> | null = null;
  private before: Answer = null;
  private readonly seenCheckpoints = new Set<number>();

  protected readonly firstName = computed(() => this.auth.user()?.firstName ?? '');
  protected readonly total = computed(() => this.pairs().length);
  protected readonly pair = computed(() => this.pairs()[this.index()] ?? null);
  protected readonly answer = computed<Answer>(() => this.answers()[this.index()] ?? null);
  protected readonly notch = computed<Notch | null>(() => {
    const a = this.answer();
    return isAnswered(a) ? a : null;
  });
  protected readonly answered = computed(() => this.answers().filter(isAnswered).length);
  protected readonly skipped = computed(() =>
    this.answers().flatMap((a, i) => (a === 'skip' ? [i + 1] : [])),
  );
  protected readonly allAnswered = computed(
    () => this.total() > 0 && this.answered() === this.total(),
  );
  protected readonly scores = computed(() => scoreDrivers(this.pairs(), this.answers()));
  protected readonly minutes = computed(() => minutesLeft(this.total() - this.answered()));
  protected readonly island = computed(
    () => this.islands().find((i) => this.index() + 1 >= i.from && this.index() + 1 <= i.to) ?? null,
  );
  protected readonly views = computed(() => islandViews(this.islands(), this.answers(), null));
  /** Quest map highlights Muni's island only while a pair is on screen. */
  protected readonly mapCurrent = computed(() => {
    const p = this.phase();
    return p === 'play' || p === 'resume' || p === 'intro' ? this.index() : null;
  });
  protected readonly top3 = computed(() => this.result()?.ranking.slice(0, 3) ?? []);

  protected readonly bubble = computed(() => {
    const n = this.notch();
    switch (n) {
      case 0:
        return $localize`:@@ca.bubbleAllThis:All in on This. Got it!`;
      case 1:
        return $localize`:@@ca.bubbleLeanThis:Leaning This. Noted! ⚖️`;
      case 2:
        return $localize`:@@ca.bubbleLeanThat:Leaning That. Noted! ⚖️`;
      case 3:
        return $localize`:@@ca.bubbleAllThat:All in on That. Got it!`;
      default:
        return $localize`:@@ca.bubbleWait:Where do I stand?`;
    }
  });

  protected readonly opts: readonly { n: Notch; strength: string; side: string; key: number }[] = [
    { n: 0, strength: $localize`:@@ca.allIn:All in`, side: $localize`:@@ca.this:This`, key: 1 },
    { n: 1, strength: $localize`:@@ca.lean:Lean`, side: $localize`:@@ca.this:This`, key: 2 },
    { n: 2, strength: $localize`:@@ca.lean:Lean`, side: $localize`:@@ca.that:That`, key: 3 },
    { n: 3, strength: $localize`:@@ca.allIn:All in`, side: $localize`:@@ca.that:That`, key: 4 },
  ];

  protected readonly calcLabels = {
    count: $localize`:@@ca.calc1:Counting coins for all 9 drivers`,
    match: $localize`:@@ca.calc2:Matching your archetype`,
    sort: $localize`:@@ca.calc3:Sorting jobs by fit`,
  };

  /** Coin dots on a card once a notch is picked (Figma B4: ●● on This, ● on That). */
  protected coinRange(n: Notch, side: 'this' | 'that'): number[] {
    return Array.from({ length: split(n)[side === 'this' ? 0 : 1] });
  }

  protected range(from: number, to: number): number[] {
    return Array.from({ length: to - from + 1 }, (_, i) => from + i);
  }

  /** Final-check tile dots: 3 coins, This-coloured first. */
  protected isThat(a: Answer, dot: number): boolean {
    return isAnswered(a) && dot >= split(a)[0];
  }

  protected tileLabel(n: number, a: Answer): string {
    if (!isAnswered(a)) return $localize`:@@ca.tileSkipped:Pair ${n}:n:, not answered yet`;
    const l = this.opts[a];
    if (!l) return '';
    return $localize`:@@ca.tileAnswered:Pair ${n}:n:, ${l.strength}:strength: ${l.side}:side:`;
  }

  protected driverInfo(r: AssessmentResult, id: DriverId): DriverInfo | undefined {
    return r.drivers.find((d) => d.id === id);
  }

  ngOnInit(): void {
    void this.load();
    const online = () => {
      if (this.phase() === 'offline') void this.submit();
    };
    window.addEventListener('online', online);
    this.destroyRef.onDestroy(() => {
      window.removeEventListener('online', online);
      this.clearTimer();
    });
  }

  protected async load(): Promise<void> {
    this.phase.set('loading');
    try {
      const s = await firstValueFrom(this.api.state());
      this.pairs.set(s.pairs);
      this.islands.set(s.islands);
      this.answers.set([...s.answers]);
      this.index.set(Math.min(s.current, s.pairs.length - 1));
      this.xp.set(s.xp);
      this.earnsXp.set(s.earnsXp);
      this.remind.set(s.remind);
      // Islands already passed don't show their checkpoint again.
      for (const i of s.islands) if (s.current >= i.to) this.seenCheckpoints.add(i.n);
      this.phase.set(s.status === 'in-progress' ? 'resume' : 'intro');
    } catch {
      this.phase.set('error');
    }
  }

  /* ---------- Intro / resume ---------- */

  protected start(): void {
    this.go('play');
    this.announcePair();
  }

  /** First pair never reached; skipped pairs wait for the final check. */
  protected readonly resumeAt = computed(() => this.answers().findIndex((a) => a === null));

  protected resume(): void {
    const next = this.resumeAt();
    if (next === -1) {
      if (this.allAnswered()) void this.finish();
      else this.go('final');
      return;
    }
    this.index.set(next);
    this.go('play');
    this.announcePair();
  }

  protected startOver(): void {
    const ref = this.overlay.adaptive<AssessmentConfirmDialog, ConfirmData, boolean>(AssessmentConfirmDialog, {
      data: { kind: 'start-over' },
      size: 'sm',
    });
    ref.closed.subscribe(async (yes) => {
      if (!yes) return;
      try {
        const s = await firstValueFrom(this.api.restart());
        this.answers.set([...s.answers]);
        this.index.set(0);
        this.seenCheckpoints.clear();
        this.start();
      } catch {
        this.toast.show($localize`:@@ca.saveFailed:Couldn’t reach the server. Try again.`, { tone: 'error' });
      }
    });
  }

  protected why(): void {
    this.overlay.adaptive(WhyPairsDialog, { size: 'sm' });
  }

  /* ---------- Playing ---------- */

  protected pick(n: Notch): void {
    if (this.phase() !== 'play') return;
    if (!this.settling()) this.before = this.answer();
    this.sfx.pick(n);
    this.setAnswer(this.index(), n);
    this.live.set(this.bubble());
    this.settling.set(true);
    this.clearTimer();
    this.timer = setTimeout(() => this.advance(), this.reduced() ? ADVANCE_REDUCED_MS : ADVANCE_MS);
  }

  protected skip(): void {
    if (this.phase() !== 'play') return;
    this.clearTimer();
    this.sfx.assessment('skip');
    this.setAnswer(this.index(), 'skip');
    this.live.set($localize`:@@ca.skippedLive:Skipped for now. You can answer it at the end.`);
    this.advance();
  }

  protected undo(): void {
    if (this.phase() !== 'play') return;
    if (this.canUndo()) this.sfx.assessment('undo');
    if (this.settling()) {
      this.clearTimer();
      this.settling.set(false);
      this.setAnswer(this.index(), this.before);
      this.live.set($localize`:@@ca.undone:Undone. Pick again.`);
      return;
    }
    if (this.index() === 0) return;
    this.index.update((i) => i - 1);
    this.save();
    this.announcePair();
  }

  protected readonly canUndo = computed(() => this.settling() || this.index() > 0);

  private advance(): void {
    this.clearTimer();
    // The coin lands in its jar as the next pair slides in.
    if (this.settling()) this.sfx.assessment('drop');
    this.settling.set(false);
    const i = this.index();
    if (this.fromFinal()) {
      this.fromFinal.set(false);
      this.go('final');
      return;
    }
    if (i >= this.total() - 1) {
      if (this.allAnswered()) void this.finish();
      else this.go('final');
      return;
    }
    const passed = this.islands().find((x) => x.to === i + 1);
    this.index.set(i + 1);
    this.save();
    if (passed && passed.n < this.islands().length && !this.seenCheckpoints.has(passed.n)) {
      this.seenCheckpoints.add(passed.n);
      this.cleared.set(passed);
      this.sfx.assessment('island');
      this.go('island');
      return;
    }
    this.announcePair();
  }

  /** B5 → next island. */
  protected sail(): void {
    this.go('play');
    this.announcePair();
  }

  /** B7: jump to any pair; answering it comes back here. */
  protected answerPair(n: number): void {
    this.index.set(n - 1);
    this.fromFinal.set(true);
    this.go('play');
    this.announcePair();
  }

  onKey(e: KeyboardEvent): void {
    if (this.phase() !== 'play' || e.altKey || e.ctrlKey || e.metaKey) return;
    const t = e.target as HTMLElement | null;
    if (t?.closest('input:not([type=radio]), textarea, select, [contenteditable], .cdk-overlay-container')) return;
    const k = Number(e.key);
    if (k >= 1 && k <= 4) {
      e.preventDefault();
      this.pick((k - 1) as Notch);
    }
  }

  private setAnswer(i: number, a: Answer): void {
    this.answers.update((list) => list.map((x, j) => (j === i ? a : x)));
    this.save();
  }

  /** Auto-save after every change; a copy stays on the device for offline submit (S3). */
  private save(): void {
    const answers = this.answers();
    try {
      localStorage.setItem(BACKUP_KEY, JSON.stringify(answers));
    } catch {
      /* private mode */
    }
    this.api.save({ answers, current: this.index() }).subscribe({
      next: (r) => {
        this.xp.set(r.xp);
        if (r.xpEarned) this.islandXp.set(r.xpEarned);
      },
      error: () => {
        /* Kept on the device; the next save or the submit retries. */
      },
    });
  }

  /* ---------- Save & exit ---------- */

  protected saveExit(): void {
    const ref = this.overlay.adaptive<SaveExitDialog, SaveExitData, SaveExitResult>(SaveExitDialog, {
      data: {
        answered: this.answered(),
        next: this.index() + 1,
        island: this.island()?.name ?? '',
        remind: this.remind(),
      },
      size: 'sm',
    });
    ref.closed.subscribe((r) => {
      if (!r) return;
      if (r.remind !== this.remind()) {
        this.remind.set(r.remind);
        this.api.setRemind(r.remind).subscribe({ error: () => undefined });
      }
      if (r.exit) {
        this.clearTimer();
        void this.router.navigateByUrl(this.links.launchpad);
      }
    });
  }

  protected back(): void {
    this.nav.back(this.nav.origin(ASSESSMENT_FLOW) ?? this.links.launchpad);
  }

  /* ---------- Finish ---------- */

  protected async finish(): Promise<void> {
    if (!this.allAnswered()) {
      this.go('final');
      return;
    }
    await this.submit();
  }

  /** S4 calculating runs its 3 steps while the server scores; S3 if the device is offline. */
  protected async submit(): Promise<void> {
    this.go('calculating');
    this.calcStep.set(0);
    const steps = (async () => {
      for (let s = 1; s <= 3; s++) {
        await wait(this.reduced() ? 120 : CALC_STEP_MS);
        this.calcStep.set(s);
        this.sfx.assessment('tick');
      }
    })();
    try {
      const [r] = await Promise.all([firstValueFrom(this.api.submit(this.answers())), steps]);
      this.result.set(r);
      try {
        localStorage.removeItem(BACKUP_KEY);
      } catch {
        /* private mode */
      }
      if (this.earnsXp()) this.xp.update((x) => x + 100);
      this.go('reveal');
      this.sfx.assessment('reveal');
      this.feedback.moment('assessment');
      this.live.set(
        $localize`:@@ca.revealLive:The jars are open. Your archetype is ${r.archetype.name}:name:.`,
      );
    } catch (e) {
      const offline = !navigator.onLine || (e instanceof ApiError && e.kind === 'offline');
      this.go(offline ? 'offline' : 'failed');
    }
  }

  protected retrySubmit(): void {
    void this.submit();
  }

  /* ---------- helpers ---------- */

  private go(p: Phase): void {
    this.settling.set(false);
    this.phase.set(p);
    // New screen: move focus to its heading so screen readers start there.
    setTimeout(() => this.heading()?.nativeElement.focus({ preventScroll: p === 'play' }), 0);
  }

  private announcePair(): void {
    const p = this.pair();
    if (!p) return;
    this.live.set(
      $localize`:@@ca.pairLive:Pair ${p.n}:n: of ${this.total()}:total:. This: ${p.this.text}:a:. That: ${p.that.text}:b:.`,
    );
  }

  private clearTimer(): void {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }

  private reduced(): boolean {
    return globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
  }
}

function wait(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}
