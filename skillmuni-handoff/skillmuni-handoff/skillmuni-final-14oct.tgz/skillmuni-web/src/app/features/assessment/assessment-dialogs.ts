import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, inject, signal, viewChild } from '@angular/core';
import { NgOptimizedImage } from '@angular/common';
import { ASSETS } from '../../shared/assets';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { SmDialog } from '../../shared/ui/overlay/dialog';
import { Switch } from '../../shared/ui/switch/switch';

export interface SaveExitData {
  readonly answered: number;
  readonly next: number;
  readonly island: string;
  readonly remind: boolean;
}

export interface SaveExitResult {
  readonly exit: boolean;
  readonly remind: boolean;
}

/** B6 · Take a break? (Figma 264:23863). Answers are already saved; this only confirms leaving. */
@Component({
  selector: 'sm-save-exit-dialog',
  imports: [Button, Icon, NgOptimizedImage, SmDialog, Switch],
  template: `
    <sm-dialog [title]="title" [subtitle]="subtitle">
      <img smDialogLead class="avatar" [ngSrc]="avatar" alt="" width="56" height="56" />
      <p class="body" i18n="@@ca.breakBody">
        Your {{ data.answered }} answers and jar coins are saved. Come back any time from Career Launchpad and pick up
        at pair {{ data.next }} on {{ data.island }}.
      </p>
      <div class="remind">
        <sm-icon name="bell" size="sm" />
        <sm-switch class="is-block" [checked]="remind()" (checkedChange)="remind.set($event)">
          <span class="r-title" i18n="@@ca.remind">Remind me tomorrow</span>
          <span class="r-sub" i18n="@@ca.remindSub">One nudge at 6 PM. No spam.</span>
        </sm-switch>
      </div>
      <div smDialogActions>
        <button sm-button type="button" (click)="close(false)" i18n="@@ca.keepGoing">Keep going</button>
        <button sm-button variant="secondary" type="button" (click)="close(true)" i18n="@@ca.saveExit">
          Save &amp; exit
        </button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .avatar {
      inline-size: var(--sm-size-control-md);
      block-size: var(--sm-size-control-md);
      border-radius: var(--sm-radius-full);
    }

    .body {
      margin: 0 0 var(--sm-space-400);
      color: var(--sm-color-text-body);
      font: var(--sm-font-body-sm);
    }

    .remind {
      display: flex;
      align-items: center;
      gap: var(--sm-space-300);
      margin-block-end: var(--sm-space-400);
      padding: var(--sm-space-200) var(--sm-space-400);
      border-radius: var(--sm-radius-xl);
      background: var(--sm-color-surface-inset);
      color: var(--sm-color-text-secondary);

      sm-switch {
        flex: 1 1 auto;
      }
    }

    .r-title {
      display: block;
      color: var(--sm-color-text-heading);
      font: var(--sm-font-body-sm-semibold);
    }

    .r-sub {
      display: block;
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }
  `,
})
export class SaveExitDialog {
  protected readonly data = inject<SaveExitData>(DIALOG_DATA);
  private readonly dialog = viewChild.required(SmDialog);
  protected readonly avatar = ASSETS.muniAvatar;
  protected readonly remind = signal(this.data.remind);
  protected readonly title = $localize`:@@ca.breakTitle:Take a break?`;
  protected readonly subtitle = $localize`:@@ca.breakSub:Muni will hold the board steady`;

  protected close(exit: boolean): void {
    this.dialog().close({ exit, remind: this.remind() } satisfies SaveExitResult);
  }
}

/** "Why 36 pairs?" from the intro (not drawn): the survey's own instructions, in plain words. */
@Component({
  selector: 'sm-why-pairs-dialog',
  imports: [Button, SmDialog],
  template: `
    <sm-dialog [title]="title">
      <ul class="list">
        <li i18n="@@ca.why1">Each pair gives you 3 coins to share between two statements: 3–0, 2–1, 1–2 or 0–3.</li>
        <li i18n="@@ca.why2">
          Having to choose brings out your top priorities more clearly than rating each statement on its own.
        </li>
        <li i18n="@@ca.why3">36 pairs is enough for each of the 9 drivers to come up 8 times, so one answer never decides.</li>
        <li i18n="@@ca.why4">There are no right or wrong answers. Go with your first feeling.</li>
      </ul>
      <div smDialogActions>
        <button sm-button type="button" (click)="dialog().close()" i18n="@@ca.gotIt">Got it</button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .list {
      display: grid;
      gap: var(--sm-space-300);
      margin: 0 0 var(--sm-space-400);
      padding-inline-start: var(--sm-space-500);
      color: var(--sm-color-text-body);
      font: var(--sm-font-body-sm);
    }
  `,
})
export class WhyPairsDialog {
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@ca.whyTitle:Why 36 pairs?`;
}

export interface ConfirmData {
  readonly kind: 'start-over' | 'retake';
  readonly earnsXp?: boolean;
}

/** Start over (B2) and S2 · Retake confirm (Figma 267:21894). */
@Component({
  selector: 'sm-assessment-confirm-dialog',
  imports: [Button, Icon, NgOptimizedImage, SmDialog],
  template: `
    <sm-dialog [title]="title" [subtitle]="subtitle">
      <img smDialogLead class="avatar" [ngSrc]="avatar" alt="" width="56" height="56" />
      @if (data.kind === 'retake') {
        <ul class="list">
          <li>
            <sm-icon name="clock" size="sm" />
            <span i18n="@@ca.retake1">Your current result stays in your history, so you can compare.</span>
          </li>
          <li>
            <sm-icon name="target" size="sm" />
            <span i18n="@@ca.retake2">Your Placement Zone and job matches will update to the new result.</span>
          </li>
          <li>
            <sm-icon name="info" size="sm" />
            <span i18n="@@ca.retake3">Retakes don’t earn XP again. Answer honestly, not strategically.</span>
          </li>
        </ul>
      } @else {
        <p class="body" i18n="@@ca.startOverBody">
          Your answers so far will be cleared and the board starts at pair 1. XP you’ve already earned stays.
        </p>
      }
      <div smDialogActions>
        <button sm-button type="button" (click)="dialog().close(true)">{{ confirmLabel }}</button>
        <button sm-button variant="secondary" type="button" (click)="dialog().close(false)">{{ cancelLabel }}</button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .avatar {
      inline-size: var(--sm-size-control-md);
      block-size: var(--sm-size-control-md);
      border-radius: var(--sm-radius-full);
    }

    .list {
      display: grid;
      gap: var(--sm-space-300);
      margin: 0 0 var(--sm-space-400);
      padding: 0;
      list-style: none;

      li {
        display: flex;
        gap: var(--sm-space-250);
        color: var(--sm-color-text-body);
        font: var(--sm-font-body-sm);
      }

      sm-icon {
        flex: none;
        margin-block-start: var(--sm-space-50);
        color: var(--sm-color-text-secondary);
      }
    }

    .body {
      margin: 0 0 var(--sm-space-400);
      color: var(--sm-color-text-body);
      font: var(--sm-font-body-sm);
    }
  `,
})
export class AssessmentConfirmDialog {
  protected readonly data = inject<ConfirmData>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly avatar = ASSETS.muniAvatar;
  protected readonly title =
    this.data.kind === 'retake'
      ? $localize`:@@ca.retakeTitle:Retake the assessment?`
      : $localize`:@@ca.startOverTitle:Start over?`;
  protected readonly subtitle =
    this.data.kind === 'retake' ? $localize`:@@ca.retakeSub:About 6 minutes · all 36 pairs` : '';
  protected readonly confirmLabel =
    this.data.kind === 'retake' ? $localize`:@@ca.retakeNow:Retake now` : $localize`:@@ca.startOver:Start over`;
  protected readonly cancelLabel =
    this.data.kind === 'retake' ? $localize`:@@ca.keepResult:Keep my result` : $localize`:@@ui.cancel:Cancel`;
}
