import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

export const matchesRoutes: Routes = [
  {
    path: 'matches',
    title: $localize`:@@route.matches:My Matches · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./matches-page').then((m) => m.MatchesPage),
  },
];
