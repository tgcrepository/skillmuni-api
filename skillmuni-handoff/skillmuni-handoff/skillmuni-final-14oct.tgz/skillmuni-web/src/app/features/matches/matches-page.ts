import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { Auth } from '../../core/auth/auth';
import { MATCHES_API, MatchBoard, MatchJob, MatchStatus } from '../../core/matches/matches.api';
import { Market } from '../../core/market/market';
import { QuestStore } from '../../core/quests/quest-store';
import { DashboardShell, DashboardUser } from '../../shared/shell/dashboard-shell';
import { Banner } from '../../shared/ui/banner/banner';
import { Button } from '../../shared/ui/button/button';
import { ChipGroup, ChipOption } from '../../shared/ui/chip/chip-group';
import { uniqueId } from '../../shared/ui/internal/unique-id';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { ProgressBar } from '../../shared/ui/progress-bar/progress-bar';
import { Select, SelectOption } from '../../shared/ui/select/select';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { Tag } from '../../shared/ui/tag/tag';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { delayed } from '../../shared/util/delayed';
import { AcceptInvite, AcceptInviteData } from './accept-invite';
import { JobAction, JobCard } from './job-card';

type Filter = 'all' | 'shortlisted' | 'invited' | 'recommended' | 'saved';
type Sort = 'match' | 'distance';
const FIRST = 4;

/**
 * My Matches (Figma 200:38000 desktop · 200:38316 / 200:38493 mobile tabs · 200:38733 tablet ·
 * MM1 loading · MM2 empty · MM3 error · MM4–MM6 accept / applied). Jobs with filters and sort, and
 * industries from Career Compass; tapping an industry filters the jobs.
 */
@Component({
  selector: 'sm-matches-page',
  imports: [
    Banner,
    Button,
    ChipGroup,
    DashboardShell,
    JobCard,
    ProgressBar,
    RouterLink,
    Select,
    Skeleton,
    StateBlock,
    Tag,
  ],
  templateUrl: './matches-page.html',
  styleUrl: './matches-page.scss',
})
export class MatchesPage implements OnInit {
  private readonly api = inject(MATCHES_API);
  private readonly auth = inject(Auth);
  private readonly market = inject(Market);
  private readonly store = inject(QuestStore);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);

  protected readonly board = signal<MatchBoard | null>(null);
  protected readonly loading = signal(true);
  protected readonly failed = signal(false);
  protected readonly showSkeleton = delayed(this.loading);
  protected readonly filter = signal<Filter>('all');
  protected readonly sort = signal<Sort>('match');
  protected readonly industry = signal('');
  protected readonly shown = signal(FIRST);
  protected readonly tab = signal<'jobs' | 'industries'>('jobs');
  protected readonly busy = signal('');
  protected readonly ids = { jobs: uniqueId('mm-jobs'), industries: uniqueId('mm-ind') };

  protected readonly title = $localize`:@@mm.title:My Matches`;
  protected readonly sortOptions: SelectOption[] = [
    { value: 'match', label: $localize`:@@mm.sortMatch:Best match` },
    { value: 'distance', label: $localize`:@@mm.sortDistance:Nearest` },
  ];
  protected readonly sortLabel = $localize`:@@mm.sort:Sort`;

  protected readonly user = computed<DashboardUser | null>(() => {
    const u = this.auth.user();
    const p = this.store.progress();
    if (!u) return null;
    return {
      name: [u.firstName, 'lastName' in u ? (u as { lastName?: string }).lastName : '']
        .filter(Boolean)
        .join(' '),
      level: p?.level ?? 1,
      rank: p?.rank ?? '',
    };
  });

  private readonly counts = computed(() => {
    const jobs = this.board()?.jobs ?? [];
    const by = (s: MatchStatus) => jobs.filter((j) => j.status === s).length;
    return {
      all: jobs.length,
      shortlisted: by('shortlisted'),
      invited: by('invited'),
      recommended: by('recommended'),
      saved: by('saved'),
    };
  });
  protected readonly filters = computed<ChipOption[]>(() => {
    const c = this.counts();
    return [
      { value: 'all', label: $localize`:@@mm.fAll:All ${c.all}:n:` },
      {
        value: 'shortlisted',
        label: $localize`:@@mm.fShort:Shortlisted by employer ${c.shortlisted}:n:`,
      },
      { value: 'invited', label: $localize`:@@mm.fInvited:Invited ${c.invited}:n:` },
      { value: 'recommended', label: $localize`:@@mm.fRec:Recommended ${c.recommended}:n:` },
      { value: 'saved', label: $localize`:@@mm.fSaved:Saved ${c.saved}:n:` },
    ];
  });
  protected readonly filtered = computed<MatchJob[]>(() => {
    const f = this.filter();
    const ind = this.industry();
    const list = (this.board()?.jobs ?? []).filter(
      (j) => (f === 'all' || j.status === f) && (!ind || j.industry === ind),
    );
    return this.sort() === 'distance'
      ? [...list].sort((a, b) => (a.distanceKm ?? 999) - (b.distanceKm ?? 999))
      : [...list].sort((a, b) => b.match - a.match);
  });
  protected readonly visible = computed(() => this.filtered().slice(0, this.shown()));
  protected readonly more = computed(() => this.filtered().length - this.visible().length);
  protected readonly industryName = computed(
    () => this.board()?.industries.find((i) => i.id === this.industry())?.name ?? '',
  );
  protected readonly empty = computed(() => !!this.board() && this.board()?.jobs.length === 0);

  async ngOnInit(): Promise<void> {
    if (!this.store.progress()) void this.store.load().catch(() => undefined);
    await this.load();
  }

  protected async load(): Promise<void> {
    this.loading.set(true);
    this.failed.set(false);
    try {
      this.board.set(await firstValueFrom(this.api.board()));
    } catch {
      this.failed.set(true);
    } finally {
      this.loading.set(false);
    }
  }

  protected setFilter(value: string | string[] | null): void {
    if (typeof value === 'string') {
      this.filter.set(value as Filter);
      this.shown.set(FIRST);
    }
  }

  protected setSort(value: string | string[] | null): void {
    if (typeof value === 'string') this.sort.set(value as Sort);
  }

  protected pickIndustry(id: string): void {
    this.industry.set(id);
    this.filter.set('all');
    this.shown.set(FIRST);
    this.tab.set('jobs');
    setTimeout(() => document.getElementById(this.ids.jobs)?.focus());
  }

  protected clearIndustry(): void {
    this.industry.set('');
  }

  protected compassDate(iso: string): string {
    return new Intl.DateTimeFormat(this.market.config().locale, {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    }).format(new Date(iso));
  }

  protected async act(job: MatchJob, action: JobAction): Promise<void> {
    if (this.busy()) return;
    if (action === 'accept') {
      const when = new Intl.DateTimeFormat(this.market.config().locale, {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit',
      }).format(new Date(job.interviewAt ?? Date.now()));
      const ref = this.overlay.adaptive<AcceptInvite, AcceptInviteData, boolean>(AcceptInvite, {
        data: { when, employer: job.employer },
        size: 'sm',
      });
      const yes = await firstValueFrom(ref.closed);
      if (!yes) return;
    }
    this.busy.set(job.id);
    try {
      if (action === 'accept') {
        await firstValueFrom(this.api.acceptInvite(job.id));
        this.patch(job.id, 'accepted');
        this.toast.show(
          $localize`:@@mm.acceptedToast:Interview accepted. Details sent to you by SMS.`,
        );
      } else if (action === 'apply') {
        await firstValueFrom(this.api.apply(job.id));
        this.patch(job.id, 'applied');
        this.toast.show($localize`:@@mm.appliedToast:Applied to ${job.title}:title:.`);
      } else {
        const saved = action === 'save';
        await firstValueFrom(this.api.save(job.id, saved));
        this.patch(job.id, saved ? 'saved' : 'recommended');
        this.toast.show(
          saved
            ? $localize`:@@mm.savedToast:Saved for later.`
            : $localize`:@@mm.unsavedToast:Removed from saved.`,
        );
      }
    } catch {
      this.toast.show($localize`:@@mm.actFail:That didn’t go through. Try again?`, {
        tone: 'error',
      });
    } finally {
      this.busy.set('');
    }
  }

  protected widen(): void {
    void this.router.navigateByUrl('/quests/pick-your-arc');
  }

  private patch(id: string, status: MatchStatus): void {
    this.board.update((b) =>
      b ? { ...b, jobs: b.jobs.map((j) => (j.id === id ? { ...j, status } : j)) } : b,
    );
  }
}
