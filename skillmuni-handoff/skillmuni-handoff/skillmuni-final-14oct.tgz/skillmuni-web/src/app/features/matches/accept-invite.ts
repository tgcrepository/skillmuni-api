import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, inject, viewChild } from '@angular/core';
import { Button } from '../../shared/ui/button/button';
import { SmDialog } from '../../shared/ui/overlay/dialog';

export interface AcceptInviteData {
  readonly when: string;
  readonly employer: string;
}

/** MM4 · Accept interview — confirm (Figma 204:11784 sheet · 204:12938 modal). Resolves true to accept. */
@Component({
  selector: 'sm-accept-invite',
  imports: [SmDialog, Button],
  template: `
    <sm-dialog centered stacked [title]="title">
      <p class="body" i18n="@@mm.acceptBody">
        {{ data.employer }} will see your Player Card and phone number. You can reschedule or cancel
        up to 24 hours before.
      </p>
      <div smDialogActions>
        <button
          sm-button
          type="button"
          cdkFocusInitial
          (click)="dialog().close(true)"
          i18n="@@mm.acceptCta"
        >
          Accept interview
        </button>
        <button
          sm-button
          variant="secondary"
          type="button"
          (click)="dialog().close(false)"
          i18n="@@mm.notNow"
        >
          Not now
        </button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .body {
      color: var(--sm-color-text-body);
      font: var(--sm-font-body);
      text-align: center;
    }
  `,
})
export class AcceptInvite {
  protected readonly data = inject<AcceptInviteData>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@mm.acceptTitle:Accept the interview on ${this.data.when}:when:?`;
}
