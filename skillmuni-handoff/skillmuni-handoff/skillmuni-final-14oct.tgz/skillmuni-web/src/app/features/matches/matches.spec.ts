import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { MATCHES_API, MatchBoard, MatchJob } from '../../core/matches/matches.api';
import { JobCard } from './job-card';
import { MatchesPage } from './matches-page';

const job = (over: Partial<MatchJob>): MatchJob => ({
  id: 'j',
  title: 'Back Office Executive',
  employer: 'HDFC Bank',
  kind: 'job',
  location: 'Powai',
  distanceKm: 11,
  match: 88,
  pay: '₹2.8 – 3.6 LPA',
  status: 'shortlisted',
  interviewAt: null,
  skills: [{ name: 'Data capturing', evidence: 'verified' }],
  tip: 'Typing test would make Excel Assessed',
  tipKind: 'boost',
  industry: 'finance',
  ...over,
});

@Component({
  imports: [JobCard],
  template: `<sm-job-card [job]="job()" (act)="last = $event" />`,
})
class Host {
  readonly job = signal(job({}));
  last = '';
}

describe('JobCard', () => {
  it('shows the band, evidence and the right action per status', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('[role="img"]')?.getAttribute('aria-label')).toBe('88% match, Strong');
    expect(el.textContent).toContain('Verified');
    [...el.querySelectorAll('button')].find((b) => b.textContent?.includes('Apply'))?.click();
    expect(fixture.componentInstance.last).toBe('apply');

    fixture.componentInstance.job.set(job({ match: 70, status: 'recommended', tipKind: 'gap' }));
    fixture.detectChanges();
    expect(el.textContent).toContain('Fair');
    expect(el.textContent).toContain('Save');

    fixture.componentInstance.job.set(job({ status: 'applied' }));
    fixture.detectChanges();
    expect(el.textContent).toContain('Applied');
    expect([...el.querySelectorAll('button')].some((b) => b.textContent?.includes('Apply'))).toBe(
      false,
    );
  });
});

describe('MatchesPage', () => {
  const board: MatchBoard = {
    total: 3,
    shortlisted: 1,
    invites: 1,
    profileComplete: 100,
    visible: true,
    jobs: [
      job({ id: 'a', status: 'invited', match: 92, industry: 'bpo', distanceKm: 6 }),
      job({ id: 'b', status: 'shortlisted', match: 88, industry: 'finance', distanceKm: 2 }),
      job({ id: 'c', status: 'recommended', match: 81, industry: 'bpo', distanceKm: null }),
    ],
    industries: [],
    compass: null,
  };

  it('filters by status and industry, and sorts by distance', async () => {
    TestBed.configureTestingModule({
      providers: [
        provideRouter([]),
        { provide: MATCHES_API, useValue: { board: () => of(board) } },
      ],
    });
    const fixture = TestBed.createComponent(MatchesPage);
    fixture.detectChanges();
    await fixture.whenStable();
    const page = fixture.componentInstance as unknown as {
      filtered: () => MatchJob[];
      setFilter(v: string): void;
      setSort(v: string): void;
      pickIndustry(id: string): void;
      clearIndustry(): void;
    };
    expect(page.filtered().map((j) => j.id)).toEqual(['a', 'b', 'c']);
    page.setFilter('invited');
    expect(page.filtered().map((j) => j.id)).toEqual(['a']);
    page.setFilter('all');
    page.pickIndustry('bpo');
    expect(page.filtered().map((j) => j.id)).toEqual(['a', 'c']);
    page.clearIndustry();
    page.setSort('distance');
    expect(page.filtered().map((j) => j.id)).toEqual(['b', 'a', 'c']);
  });
});
