import { Component, computed, inject, input, output, signal } from '@angular/core';
import { Market } from '../../core/market/market';
import { MatchJob, MatchSkill } from '../../core/matches/matches.api';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { uniqueId } from '../../shared/ui/internal/unique-id';

export type JobAction = 'accept' | 'apply' | 'save' | 'unsave';

/**
 * One match (Figma M1 job card · MM5/MM6). Match ring (Strong ≥ 85, Good ≥ 78, Fair below), where / pay,
 * why it's listed, key skills with their evidence, one tip (a power-up or a gap) and the next action.
 * "View" opens the match breakdown in place.
 */
@Component({
  selector: 'sm-job-card',
  imports: [Button, Icon],
  template: `
    <article class="card" [attr.aria-labelledby]="ids.title">
      <div class="top">
        <span
          class="ring"
          [class]="'ring ring--' + band()"
          role="img"
          [attr.aria-label]="ringLabel()"
        >
          <span class="pct" aria-hidden="true">{{ job().match }}%</span>
          <span class="band" aria-hidden="true">{{ bandLabel() }}</span>
        </span>
        <div class="head">
          <h3 class="title" [id]="ids.title">{{ job().title }}</h3>
          <p class="meta">{{ where() }}</p>
          <p class="pay">{{ job().pay }}</p>
        </div>
      </div>

      <p class="status" [class]="'status status--' + job().status">{{ statusLabel() }}</p>

      @if (job().skills.length) {
        <p class="label" i18n="@@mm.keySkills">Key matching skills</p>
        <ul class="skills">
          @for (s of job().skills; track s.name) {
            <li class="skill">
              <sm-icon name="check" size="xs" aria-hidden="true" />
              {{ s.name }} <span class="ev">{{ evidence(s) }}</span>
            </li>
          }
        </ul>
      }

      @if (job().tip) {
        <p class="tip" [class.tip--gap]="job().tipKind === 'gap'">
          <span aria-hidden="true">↑</span> {{ job().tip }}
        </p>
      }

      @if (open()) {
        <div class="details" [id]="ids.details">
          <p class="label" i18n="@@mm.why">Why you match</p>
          <ul class="why">
            <li i18n="@@mm.whySkills">
              {{ job().skills.length }} of your skills are on this listing
            </li>
            @if (job().distanceKm !== null) {
              <li i18n="@@mm.whyNear">
                {{ job().distanceKm }} km from where you said you can work
              </li>
            } @else {
              <li i18n="@@mm.whyRemote">Remote, so distance doesn’t matter</li>
            }
            <li>{{ kindLabel() }}</li>
          </ul>
        </div>
      }

      <div class="actions">
        @switch (job().status) {
          @case ('invited') {
            <button
              sm-button
              variant="secondary"
              type="button"
              [attr.aria-expanded]="open()"
              [attr.aria-controls]="ids.details"
              (click)="open.set(!open())"
              i18n="@@mm.viewInvite"
            >
              View invite
            </button>
            <button
              sm-button
              type="button"
              [loading]="busy()"
              (click)="act.emit('accept')"
              i18n="@@mm.accept"
            >
              Accept
            </button>
          }
          @case ('applied') {
            <button
              sm-button
              variant="secondary"
              type="button"
              [attr.aria-expanded]="open()"
              [attr.aria-controls]="ids.details"
              (click)="open.set(!open())"
              i18n="@@mm.viewJob"
            >
              View job
            </button>
            <span class="done"
              ><sm-icon name="check" size="sm" aria-hidden="true" />
              <ng-container i18n="@@mm.applied">Applied</ng-container></span
            >
          }
          @case ('accepted') {
            <span class="done"
              ><sm-icon name="calendar" size="sm" aria-hidden="true" /> {{ interviewLabel() }}</span
            >
          }
          @default {
            <button
              sm-button
              variant="secondary"
              type="button"
              [attr.aria-expanded]="open()"
              [attr.aria-controls]="ids.details"
              (click)="open.set(!open())"
              i18n="@@mm.viewJob"
            >
              View job
            </button>
            @if (job().status === 'recommended' && job().tipKind === 'gap') {
              <button
                sm-button
                type="button"
                [loading]="busy()"
                (click)="act.emit('save')"
                i18n="@@mm.save"
              >
                Save
              </button>
            } @else {
              <button
                sm-button
                type="button"
                [loading]="busy()"
                (click)="act.emit('apply')"
                i18n="@@mm.apply"
              >
                Apply
              </button>
            }
          }
        }
      </div>
    </article>
  `,
  styleUrl: './job-card.scss',
})
export class JobCard {
  private readonly market = inject(Market);
  readonly job = input.required<MatchJob>();
  readonly busy = input(false);
  readonly act = output<JobAction>();

  protected readonly open = signal(false);
  protected readonly ids = { title: uniqueId('job'), details: uniqueId('job-details') };

  protected readonly band = computed(() => {
    const m = this.job().match;
    return m >= 85 ? 'strong' : m >= 78 ? 'good' : 'fair';
  });
  protected readonly bandLabel = computed(() =>
    this.band() === 'strong'
      ? $localize`:@@mm.strong:Strong`
      : this.band() === 'good'
        ? $localize`:@@mm.good:Good`
        : $localize`:@@mm.fair:Fair`,
  );
  protected readonly ringLabel = computed(
    () => $localize`:@@mm.ring:${this.job().match}:pct:% match, ${this.bandLabel()}:band:`,
  );
  protected readonly where = computed(() => {
    const j = this.job();
    return [j.employer, j.location, j.distanceKm !== null ? `${j.distanceKm} km` : '']
      .filter(Boolean)
      .join(' · ');
  });
  protected readonly interviewLabel = computed(() => {
    const at = this.job().interviewAt;
    if (!at) return '';
    const when = new Intl.DateTimeFormat(this.market.config().locale, {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(at));
    return this.job().status === 'accepted'
      ? $localize`:@@mm.interviewOn:Interview · ${when}:when:`
      : $localize`:@@mm.invite:Interview invite · ${when}:when:`;
  });
  protected readonly statusLabel = computed(() => {
    switch (this.job().status) {
      case 'invited':
        return this.interviewLabel();
      case 'shortlisted':
        return $localize`:@@mm.shortlisted:Shortlisted by employer`;
      case 'saved':
        return $localize`:@@mm.saved:Saved`;
      case 'applied':
        return $localize`:@@mm.appliedTag:Applied`;
      case 'accepted':
        return $localize`:@@mm.acceptedTag:Interview accepted`;
      default:
        return $localize`:@@mm.recommended:Recommended for you`;
    }
  });
  protected readonly kindLabel = computed(() => {
    switch (this.job().kind) {
      case 'learnership':
        return $localize`:@@mm.kLearn:Learnership: you earn while you learn`;
      case 'internship':
        return $localize`:@@mm.kIntern:Internship`;
      case 'apprenticeship':
        return $localize`:@@mm.kAppr:Apprenticeship: on-the-job training`;
      case 'course':
        return $localize`:@@mm.kCourse:Course that leads to jobs like this`;
      default:
        return $localize`:@@mm.kJob:Job`;
    }
  });

  protected evidence(s: MatchSkill): string {
    switch (s.evidence) {
      case 'assessed':
        return $localize`:@@mm.evAssessed:Assessed`;
      case 'verified':
        return $localize`:@@mm.evVerified:Verified`;
      case 'declared':
        return $localize`:@@mm.evDeclared:Declared`;
      default:
        return s.note ?? '';
    }
  }
}
