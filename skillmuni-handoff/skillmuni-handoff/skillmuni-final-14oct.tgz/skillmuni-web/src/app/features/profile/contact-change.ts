import { Component, computed, inject, input, output, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { ContactKind, PROFILE_API } from '../../core/profile/profile.api';
import { Button } from '../../shared/ui/button/button';
import { Field } from '../../shared/ui/field/field';
import { Icon } from '../../shared/ui/icon/icon';
import { Input } from '../../shared/ui/input/input';
import { Otp } from '../../shared/ui/otp/otp';

type Step = 'view' | 'enter' | 'code' | 'done';

/**
 * Change mobile or email from Edit profile (A-273): type the new one → code sent to it → enter the
 * code → saved. Nothing changes until the code matches, so a typo can't lock the learner out.
 */
@Component({
  selector: 'sm-contact-change',
  imports: [Button, Field, Icon, Input, Otp],
  template: `
    <div class="row">
      <span class="current">
        <sm-icon [name]="kind() === 'mobile' ? 'phone' : 'mail'" size="sm" />
        <span class="value">{{ shown() || emptyLabel }}</span>
        @if (step() === 'done') {
          <span class="ok" i18n="@@contact.verified">Verified</span>
        }
      </span>
      @if (step() === 'view' || step() === 'done') {
        <button type="button" class="change" (click)="start()">
          @if (shown()) {
            <ng-container i18n="@@profile.change">Change</ng-container>
          } @else {
            <ng-container i18n="@@contact.add">Add</ng-container>
          }
          <span class="sm-visually-hidden">{{ label() }}</span>
        </button>
      }
    </div>

    @if (step() === 'enter') {
      <div class="step">
        <sm-field [label]="newLabel()" [error]="error()">
          <sm-input
            [type]="kind() === 'mobile' ? 'tel' : 'email'"
            [inputmode]="kind() === 'mobile' ? 'numeric' : 'email'"
            [autocomplete]="kind() === 'mobile' ? 'tel-national' : 'email'"
            [value]="draft()"
            (valueChange)="draft.set($event); error.set('')"
          />
        </sm-field>
        <div class="actions">
          <button sm-button variant="secondary" type="button" (click)="cancel()" i18n="@@ui.cancel">
            Cancel
          </button>
          <button sm-button type="button" [loading]="busy()" (click)="send()" i18n="@@contact.sendCode">
            Send code
          </button>
        </div>
      </div>
    }

    @if (step() === 'code') {
      <div class="step">
        <p class="sent" i18n="@@contact.sent">Code sent to {{ sentTo() }}. It’s 6 digits.</p>
        <sm-otp
          [ariaLabel]="codeLabel"
          [value]="code()"
          [status]="error() ? 'error' : 'none'"
          (valueChange)="code.set($event); error.set('')"
          (completed)="verify()"
        />
        @if (error()) {
          <p class="err" role="alert">{{ error() }}</p>
        }
        <div class="actions">
          <button sm-button variant="secondary" type="button" (click)="step.set('enter')" i18n="@@contact.back">
            Change it
          </button>
          <button sm-button type="button" [loading]="busy()" (click)="verify()" i18n="@@contact.verify">
            Verify
          </button>
        </div>
      </div>
    }
  `,
  styles: `
    :host {
      display: grid;
      gap: var(--sm-space-300);
    }

    .row {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: var(--sm-space-200);
      min-block-size: var(--sm-size-touch-min);
      padding-inline: var(--sm-space-300);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-subtle);
      border-radius: var(--sm-radius-xl);
      background: var(--sm-color-surface-inset);
    }

    .current {
      display: inline-flex;
      align-items: center;
      gap: var(--sm-space-200);
      min-inline-size: 0;
      color: var(--sm-color-text-heading);
      font: var(--sm-font-body-sm-semibold);
      overflow-wrap: anywhere;

      sm-icon {
        flex: none;
        color: var(--sm-color-icon-muted);
      }
    }

    .ok {
      color: var(--sm-color-feedback-success-text);
      font: var(--sm-font-caption-semibold);
    }

    .change {
      min-block-size: var(--sm-size-touch-min);
      padding-inline: var(--sm-space-200);
      border: 0;
      background: none;
      color: var(--sm-color-text-brand);
      font: var(--sm-font-caption-semibold);
      cursor: pointer;

      &:focus-visible {
        border-radius: var(--sm-radius-md);
        box-shadow: var(--sm-shadow-focus-ring);
        outline: none;
      }
    }

    .step {
      display: grid;
      gap: var(--sm-space-300);
    }

    .sent,
    .err {
      margin: 0;
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }

    .err {
      color: var(--sm-color-feedback-error-text);
      font: var(--sm-font-caption-semibold);
    }

    .actions {
      display: flex;
      flex-wrap: wrap;
      justify-content: flex-end;
      gap: var(--sm-space-200);
    }
  `,
})
export class ContactChange {
  private readonly api = inject(PROFILE_API);
  readonly kind = input.required<ContactKind>();
  readonly value = input('');
  readonly label = input('');
  /** Fires with the new value once it's verified (and saved). */
  readonly changed = output<string>();

  protected readonly step = signal<Step>('view');
  protected readonly draft = signal('');
  protected readonly code = signal('');
  protected readonly sentTo = signal('');
  protected readonly error = signal('');
  protected readonly busy = signal(false);
  private readonly verified = signal('');
  protected readonly shown = computed(() => this.verified() || this.value());
  protected readonly emptyLabel = $localize`:@@contact.none:Not added`;
  protected readonly codeLabel = $localize`:@@contact.codeLabel:6-digit code`;
  protected readonly newLabel = computed(() =>
    this.kind() === 'mobile'
      ? $localize`:@@contact.newMobile:New mobile number`
      : $localize`:@@contact.newEmail:New email`,
  );

  protected start(): void {
    this.draft.set('');
    this.error.set('');
    this.step.set('enter');
  }

  protected cancel(): void {
    this.step.set(this.verified() ? 'done' : 'view');
  }

  protected async send(): Promise<void> {
    const v = this.draft().trim();
    if (!v) {
      this.error.set(
        this.kind() === 'mobile'
          ? $localize`:@@contact.needMobile:Pop in your new number`
          : $localize`:@@contact.needEmail:Pop in your new email`,
      );
      return;
    }
    this.busy.set(true);
    try {
      const r = await firstValueFrom(this.api.sendContactCode(this.kind(), v));
      this.sentTo.set(r.sentTo);
      this.code.set('');
      this.step.set('code');
    } catch {
      this.error.set(
        this.kind() === 'mobile'
          ? $localize`:@@contact.badMobile:That number doesn’t look right — 10 digits, please`
          : $localize`:@@contact.badEmail:That email doesn’t look right`,
      );
    } finally {
      this.busy.set(false);
    }
  }

  protected async verify(): Promise<void> {
    if (this.busy() || this.code().length < 6) return;
    this.busy.set(true);
    try {
      await firstValueFrom(this.api.verifyContact(this.kind(), this.draft().trim(), this.code()));
      this.verified.set(this.draft().trim());
      this.step.set('done');
      this.changed.emit(this.draft().trim());
    } catch {
      this.error.set($localize`:@@contact.wrongCode:That code didn’t match. Check it and try again.`);
    } finally {
      this.busy.set(false);
    }
  }
}
