import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

export const profileRoutes: Routes = [
  {
    path: 'profile',
    title: $localize`:@@route.profile:My Profile · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./profile-page').then((m) => m.ProfilePage),
  },
];
