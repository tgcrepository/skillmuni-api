import { LevelTrack } from '../../shared/ui/level-track/level-track';
import { levelFor } from '../../core/quests/levels';
import { BackNav } from '../../core/layout/back-nav';
import { CdkMenu, CdkMenuItem, CdkMenuItemCheckbox, CdkMenuTrigger } from '@angular/cdk/menu';
import { AudioPrefs } from '../../core/audio/audio-prefs';
import { LogoutFlow } from '../../shared/shell/logout-dialog';
import { Component, ElementRef, OnInit, computed, inject, signal, viewChild } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Market } from '../../core/market/market';
import { Auth } from '../../core/auth/auth';
import {
  MaskedField,
  PROFILE_API,
  PlayerProfile,
  PrivateField,
  ProfileSaved,
  StrengthTask,
} from '../../core/profile/profile.api';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { BadgeMedal } from '../../shared/ui/badge-medal/badge-medal';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { IconName } from '../../shared/ui/icon/icons';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { FeedbackPrompt } from '../../core/feedback/feedback-prompt';
import { ProfileEdit } from './profile-edit';
import { Currency } from '../../shared/ui/currency/currency';

type LoadState = 'loading' | 'ready' | 'error' | 'offline';

const PHOTO_MAX_BYTES = 5 * 1024 * 1024;
const PHOTO_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const FIELD_ICON: Record<PrivateField, IconName> = {
  id: 'shield',
  mobile: 'phone',
  email: 'mail',
  gender: 'user',
  dob: 'calendar',
};

/** Where the learner goes to earn their career archetype (Career Drivers isn't built yet). */
export const CAREER_DRIVERS_URL = '/assessments/career';
export const CAREER_REPORT_URL = '/assessments/career/report';

/**
 * My Profile v2 · Player ID (Figma 186:6672 desktop · 187:6921 tablet · 187:7249 mobile; note 187:8642).
 * Player ID card (level ring, rank, best skill, XP to next level, locked archetype, share), one stat
 * row, Profile strength as an XP checklist, Badge showcase and Private details (masked until 👁).
 * Log out lives in Settings.
 */
@Component({
  selector: 'sm-profile-page',
  imports: [
    LevelTrack,
    Currency,
    BadgeMedal,
    Button,
    CdkMenu,
    CdkMenuItem,
    CdkMenuItemCheckbox,
    CdkMenuTrigger,
    Icon,
    LearnerShell,
    RouterLink,
    Skeleton,
    StateBlock,
  ],
  templateUrl: './profile-page.html',
  styleUrl: './profile-page.scss',
})
export class ProfilePage implements OnInit {
  /** Rank and level always come from the XP total (one ladder, A-249). */
  protected lvlOf(xp: number) {
    return levelFor(xp);
  }

  private readonly api = inject(PROFILE_API);
  private readonly market = inject(Market);
  private readonly auth = inject(Auth);
  private readonly router = inject(Router);
  private readonly nav = inject(BackNav);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  protected readonly feedback = inject(FeedbackPrompt);
  private readonly photoInput = viewChild<ElementRef<HTMLInputElement>>('photoInput');

  protected readonly reportUrl = CAREER_REPORT_URL;
  protected readonly driversUrl = CAREER_DRIVERS_URL;
  protected readonly state = signal<LoadState>('loading');
  protected readonly profile = signal<PlayerProfile | null>(null);
  protected readonly uploading = signal(false);
  protected readonly revealed = signal<Partial<Record<PrivateField, string>>>({});
  protected readonly revealing = signal<PrivateField | null>(null);

  protected readonly joined = computed(() => {
    const p = this.profile();
    return p
      ? new Intl.DateTimeFormat(this.market.config().locale, {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        }).format(new Date(`${p.joined}T00:00:00`))
      : '';
  });

  /** Ring and bar share one reading: progress within the current level (A-249). */
  protected readonly levelPercent = computed(() => {
    const p = this.profile();
    const span = p ? p.nextLevelXp - p.levelStartXp : 0;
    return p && span > 0 ? Math.min(100, ((p.xp - p.levelStartXp) / span) * 100) : 0;
  });
  protected readonly toNext = computed(() => {
    const p = this.profile();
    return p ? Math.max(0, p.nextLevelXp - p.xp) : 0;
  });

  protected readonly addPhotoLabel = $localize`:@@profile.addPhoto:Add a profile photo`;
  protected readonly changePhotoLabel = $localize`:@@profile.changePhoto:Change your profile photo`;
  protected readonly strengthLabel = computed(
    () =>
      $localize`:@@profile.strengthPct:Profile ${this.profile()?.strength.percent ?? 0}:pct:% complete`,
  );

  protected readonly xpLeft = computed(() =>
    (this.profile()?.strength.tasks ?? []).filter((t) => !t.done).reduce((s, t) => s + t.xp, 0),
  );

  protected readonly stats = computed(() => {
    const p = this.profile();
    if (!p) return [];
    const hours = new Intl.NumberFormat(this.market.config().locale, {
      maximumFractionDigits: 1,
    }).format(p.stats.learningHours);
    return [
      {
        id: 'streak',
        icon: 'flame' as IconName,
        value:
          p.stats.streakDays === 1
            ? $localize`:@@profile.streakDay:1 day`
            : $localize`:@@profile.streakDays:${p.stats.streakDays}:n: days`,
        label: $localize`:@@profile.streak:Streak`,
      },
      {
        id: 'xp',
        icon: 'zap' as IconName,
        value: String(p.xp),
        label: $localize`:@@profile.xp:XP`,
      },
      {
        id: 'badges',
        icon: 'shield' as IconName,
        value: String(p.stats.badges),
        label: $localize`:@@profile.badges:Badges`,
      },
      {
        id: 'time',
        icon: 'clock' as IconName,
        value: $localize`:@@profile.hours:${hours}:h: h`,
        label: $localize`:@@profile.learningTime:Learning time`,
      },
    ];
  });

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      const p = await firstValueFrom(this.api.profile());
      this.profile.set(p);
      this.auth.setPhoto(p.photoUrl ?? null);
      this.state.set('ready');
    } catch (e) {
      this.state.set(e instanceof ApiError && e.kind === 'offline' ? 'offline' : 'error');
    }
  }

  protected back(): void {
    this.nav.back('/home');
  }

  /* ---------- Edit ---------- */

  /** Corrections #22: each Edit opens just its own section. */
  protected edit(section: 'private' | 'card' = 'card'): void {
    const ref = this.overlay.adaptive<ProfileEdit, 'private' | 'card', ProfileSaved | 'refresh'>(
      ProfileEdit,
      {
        data: section,
        ariaLabel:
          section === 'private'
            ? $localize`:@@profile.editPrivateTitle:Edit private details`
            : $localize`:@@profile.editSkillsTitle:Edit your top skills`,
      },
    );
    ref.closed.subscribe((saved) => {
      if (saved === 'refresh') {
        void this.load();
        this.toast.show($localize`:@@profile.contactSaved:Private details updated`);
        return;
      }
      if (!saved) return;
      this.applySaved(saved, $localize`:@@profile.saved:Profile updated`);
    });
  }

  /* ---------- Photo ---------- */

  protected choosePhoto(): void {
    this.photoInput()?.nativeElement.click();
  }

  protected async photoChosen(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    if (!PHOTO_TYPES.includes(file.type)) {
      this.toast.show(
        $localize`:@@profile.photoType:That file isn’t a photo. Use a JPG, PNG or WebP.`,
        {
          tone: 'error',
        },
      );
      return;
    }
    if (file.size > PHOTO_MAX_BYTES) {
      this.toast.show($localize`:@@profile.photoSize:That photo is over 5 MB. Try a smaller one.`, {
        tone: 'error',
      });
      return;
    }
    this.uploading.set(true);
    try {
      const saved = await firstValueFrom(this.api.uploadPhoto(file));
      this.applySaved(saved, $localize`:@@profile.photoSaved:Looking good! Photo added`);
    } catch {
      this.toast.show($localize`:@@profile.photoFailed:Couldn’t upload that photo. Try again.`, {
        tone: 'error',
      });
    } finally {
      this.uploading.set(false);
    }
  }

  private applySaved(saved: ProfileSaved, message: string): void {
    this.profile.set(saved.profile);
    this.auth.setPhoto(saved.profile.photoUrl ?? null);
    this.revealed.set({});
    this.toast.show(
      message,
      saved.xpEarned
        ? { tone: 'reward', xp: $localize`:@@profile.xpEarned:+${saved.xpEarned}:xp: XP` }
        : { tone: 'success' },
    );
  }

  /* ---------- Strength tasks ---------- */

  protected taskAction(t: StrengthTask): 'photo' | 'edit' | 'link' | null {
    if (t.done) return null;
    return t.id === 'photo' ? 'photo' : t.id === 'drivers' ? 'link' : 'edit';
  }

  /* ---------- Share ---------- */

  protected async share(): Promise<void> {
    const p = this.profile();
    if (!p) return;
    const url = `${location.origin}/p/${p.playerId}`;
    const text = $localize`:@@profile.shareText:I’m Level ${p.level}:level: on Skillmuni. Come level up with me!`;
    try {
      if (typeof navigator.share === 'function') {
        await navigator.share({ title: p.name, text, url });
        return;
      }
      await navigator.clipboard.writeText(`${text} ${url}`);
      this.toast.show($localize`:@@profile.linkCopied:Link to your Player ID copied`, {
        tone: 'success',
      });
    } catch (e) {
      // Closing the share sheet isn't an error.
      if (e instanceof DOMException && e.name === 'AbortError') return;
      this.toast.show($localize`:@@profile.shareFailed:Couldn’t share right now. Try again.`, {
        tone: 'error',
      });
    }
  }

  /* ---------- Private details ---------- */

  protected fieldIcon(f: MaskedField): IconName {
    return FIELD_ICON[f.key];
  }

  protected async toggleReveal(f: MaskedField): Promise<void> {
    const shown = this.revealed()[f.key];
    if (shown !== undefined) {
      this.revealed.update((r) =>
        Object.fromEntries(Object.entries(r).filter(([k]) => k !== f.key)),
      );
      return;
    }
    this.revealing.set(f.key);
    try {
      const { value } = await firstValueFrom(this.api.reveal(f.key));
      this.revealed.update((r) => ({ ...r, [f.key]: value }));
    } catch {
      this.toast.show($localize`:@@profile.revealFailed:Couldn’t show that right now. Try again.`, {
        tone: 'error',
      });
    } finally {
      this.revealing.set(null);
    }
  }

  protected revealLabel(f: MaskedField): string {
    return this.revealed()[f.key] !== undefined
      ? $localize`:@@profile.hideField:Hide ${f.label}:field:`
      : $localize`:@@profile.showField:Show ${f.label}:field:`;
  }

  /* ---------- Settings ---------- */

  /** Corrections #40: the Muni check before leaving. */
  private readonly logoutFlow = inject(LogoutFlow);
  protected logout(): void {
    void this.logoutFlow.confirm();
  }

  /** Corrections #32: the sound effects switch moved from the top bar to Settings. */
  protected readonly audio = inject(AudioPrefs);
  protected readonly onLabel = $localize`:@@ui.on:On`;
  protected readonly offLabel = $localize`:@@ui.off:Off`;
  protected toggleSounds(): void {
    this.audio.sounds.update((v) => !v);
  }
}
