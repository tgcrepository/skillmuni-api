import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, OnInit, computed, inject, signal, viewChild } from '@angular/core';
import { form, submit, validate } from '@angular/forms/signals';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Market } from '../../core/market/market';
import { Gender, PROFILE_API, ProfileSaved } from '../../core/profile/profile.api';
import { uniqueId } from '../../shared/ui/internal/unique-id';
import { Banner } from '../../shared/ui/banner/banner';
import { Button } from '../../shared/ui/button/button';
import { ChipGroup, ChipOption } from '../../shared/ui/chip/chip-group';
import { Icon } from '../../shared/ui/icon/icon';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { SmDialog } from '../../shared/ui/overlay/dialog';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { BirthdayPicker, BirthdayPickerData } from '../quests/parts/birthday-picker';
import { ContactChange } from './contact-change';
import { DigiLockerFlow } from '../../shared/identity/digilocker-flow';
import { IDENTITY_API } from '../../core/identity/identity.api';

const MAX_SKILLS = 5;

interface EditModel {
  skills: string[];
  gender: string;
  dob: string;
}

/**
 * Edit profile (not drawn in Profile v2 — A-191). Top skills (up to 5, +10 XP the first time),
 * gender and date of birth; mobile and email change with a code to the new one (A-273); the
 * DigiLocker-linked ID can be re-linked (India, A-272).
 * Resolves with the saved profile (and any XP earned), or nothing when dismissed.
 */
@Component({
  selector: 'sm-profile-edit',
  imports: [SmDialog, Button, ChipGroup, Banner, Icon, Skeleton, ContactChange],
  templateUrl: './profile-edit.html',
  styleUrl: './profile-edit.scss',
})
export class ProfileEdit implements OnInit {
  private readonly api = inject(PROFILE_API);
  private readonly market = inject(Market);
  private readonly overlay = inject(OverlayService);
  protected readonly dialog = viewChild.required(SmDialog);
  private readonly digiFlow = inject(DigiLockerFlow);
  private readonly identity = inject(IDENTITY_API);
  protected readonly contact = signal({ mobile: '', email: '' });
  protected readonly mobileLabel = $localize`:@@profile.mobile:Mobile number`;
  protected readonly emailLabel = $localize`:@@profile.email:Email`;
  protected readonly digi = computed(() => this.market.config().idVerification === 'digilocker');
  protected readonly linkedId = signal('');
  protected readonly linking = signal(false);
  /** A verified contact change is already saved; closing still refreshes the profile. */
  private readonly contactDirty = signal(false);

  protected readonly ids = {
    skills: uniqueId('pe-skills'),
    skillsHelp: uniqueId('pe-skills-help'),
    gender: uniqueId('pe-gender'),
    dob: uniqueId('pe-dob'),
  };
  /**
   * Corrections #22: Edit on a section edits that section only — 'private' (gender, birthday,
   * contact, ID) from Private details, 'card' (top skills) from the Player Card.
   */
  protected readonly section =
    inject<'private' | 'card' | undefined>(DIALOG_DATA, { optional: true }) ?? 'all';
  protected readonly title =
    this.section === 'private'
      ? $localize`:@@profile.editPrivateTitle:Edit private details`
      : this.section === 'card'
        ? $localize`:@@profile.editSkillsTitle:Edit your top skills`
        : $localize`:@@profile.editTitle:Edit profile`;
  protected readonly maxSkills = MAX_SKILLS;

  protected readonly state = signal<'loading' | 'ready' | 'error'>('loading');
  protected readonly busy = signal(false);
  protected readonly failed = signal<'offline' | 'server' | null>(null);
  protected readonly skillOptions = signal<readonly ChipOption[]>([]);
  private readonly hadSkills = signal(false);

  protected readonly model = signal<EditModel>({ skills: [], gender: 'rather-not', dob: '' });
  protected readonly form = form(this.model, (p) => {
    validate(p.skills, ({ value }) =>
      value().length > MAX_SKILLS
        ? {
            kind: 'max',
            message: $localize`:@@profile.skillsMax:Pick up to ${MAX_SKILLS}:max: — your strongest ones.`,
          }
        : undefined,
    );
  });

  protected readonly skillsError = computed(() => this.form.skills().errors()[0]?.message ?? '');
  protected readonly skillCount = computed(
    () =>
      $localize`:@@profile.skillCount:${this.model().skills.length}:n: of ${MAX_SKILLS}:max: picked`,
  );
  protected readonly skillsXp = computed(() => !this.hadSkills() && this.model().skills.length > 0);

  protected readonly genders: readonly ChipOption[] = [
    { value: 'female', label: $localize`:@@q1.female:Female` },
    { value: 'male', label: $localize`:@@q1.male:Male` },
    { value: 'non-binary', label: $localize`:@@q1.nonBinary:Non-binary` },
    { value: 'rather-not', label: $localize`:@@q1.ratherNot:Rather not say` },
  ];

  protected readonly dobText = computed(() => {
    const iso = this.model().dob;
    if (!iso) return '';
    return new Intl.DateTimeFormat(this.market.config().locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(new Date(`${iso}T00:00:00`));
  });

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      const e = await firstValueFrom(this.api.editable());
      this.skillOptions.set(e.skillOptions.map((s) => ({ value: s, label: s })));
      this.hadSkills.set(e.skills.length > 0);
      this.model.set({ skills: [...e.skills], gender: e.gender, dob: e.dob });
      this.contact.set({ mobile: e.mobile, email: e.email });
      if (this.digi()) {
        const id = await firstValueFrom(this.identity.current()).catch(() => null);
        this.linkedId.set(id ? `${this.docLabel(id.doc)} ${id.masked}` : '');
      }
      this.state.set('ready');
    } catch {
      this.state.set('error');
    }
  }

  /** Cancel keeps edits unsaved, but a verified contact or ID change is already in: refresh. */
  protected dismiss(): void {
    this.dialog().close(this.contactDirty() ? 'refresh' : undefined);
  }

  protected contactChanged(): void {
    this.contactDirty.set(true);
  }

  private docLabel(doc: string): string {
    return this.market.config().idTypes.find((t) => t.id === doc)?.label ?? '';
  }

  protected async relink(): Promise<void> {
    const type = this.market.config().idTypes[0];
    if (!type || this.linking()) return;
    this.linking.set(true);
    try {
      const l = await this.digiFlow.link(type.id as 'aadhaar', type.label);
      if (l) {
        this.linkedId.set(`${type.label} ${l.masked}`);
        this.contactDirty.set(true);
      }
    } catch {
      /* the row stays as it was */
    } finally {
      this.linking.set(false);
    }
  }

  protected setSkills(v: string | string[] | null): void {
    this.model.update((m) => ({ ...m, skills: Array.isArray(v) ? v : [] }));
    this.form.skills().markAsTouched();
  }

  protected setGender(v: string | string[] | null): void {
    if (typeof v === 'string') this.model.update((m) => ({ ...m, gender: v }));
  }

  protected pickDob(): void {
    const iso = this.model().dob;
    const ref = this.overlay.adaptive<BirthdayPicker, BirthdayPickerData, Date>(BirthdayPicker, {
      data: { value: iso ? new Date(`${iso}T00:00:00`) : null, today: new Date() },
      size: 'sm',
    });
    ref.closed.subscribe((date) => {
      if (!date) return;
      const p = (n: number) => String(n).padStart(2, '0');
      const value = `${date.getFullYear()}-${p(date.getMonth() + 1)}-${p(date.getDate())}`;
      this.model.update((m) => ({ ...m, dob: value }));
    });
  }

  protected async save(event?: Event): Promise<void> {
    event?.preventDefault();
    if (this.busy()) return;
    await submit(this.form, async () => {
      this.busy.set(true);
      this.failed.set(null);
      try {
        const m = this.model();
        const saved: ProfileSaved = await firstValueFrom(
          this.api.save({ skills: m.skills, gender: m.gender as Gender, dob: m.dob }),
        );
        this.dialog().close(saved);
      } catch (err) {
        this.failed.set(err instanceof ApiError && err.kind === 'offline' ? 'offline' : 'server');
      } finally {
        this.busy.set(false);
      }
      return undefined;
    });
  }
}
