import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { Auth } from '../../core/auth/auth';
import {
  MaskedField,
  PROFILE_API,
  PlayerProfile,
  ProfileApi,
} from '../../core/profile/profile.api';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { ProfilePage } from './profile-page';

const profile: PlayerProfile = {
  playerId: 'SM-1',
  name: 'Yash Pohare',
  initials: 'YP',
  title: 'Explorer',
  joined: '2025-04-01',
  photoUrl: null,
  level: 2,
  xp: 529,
  levelStartXp: 400,
  nextLevelXp: 800,
  batchRank: 12,
  bestSkill: 'Digital Skills',
  archetype: null,
  stats: { streakDays: 1, badges: 4, learningHours: 285.2 },
  strength: {
    percent: 60,
    tasks: [
      { id: 'contact', label: 'Contact', xp: 0, done: true },
      { id: 'photo', label: 'Photo', xp: 5, done: false },
      { id: 'skills', label: 'Skills', xp: 10, done: false },
      { id: 'drivers', label: 'Drivers', xp: 20, done: false },
    ],
  },
  showcase: { pinned: [], next: null },
  privateFields: [{ key: 'mobile', label: 'Mobile number', masked: '•••• 0697', empty: false }],
  skills: [],
};

interface PageApi {
  load(): Promise<void>;
  levelPercent(): number;
  toNext(): number;
  xpLeft(): number;
  stats(): { id: string; value: string }[];
  taskAction(t: PlayerProfile['strength']['tasks'][number]): string | null;
  toggleReveal(f: MaskedField): Promise<void>;
  revealed(): Partial<Record<string, string>>;
  revealLabel(f: MaskedField): string;
  photoChosen(e: Event): Promise<void>;
}

function setup() {
  const api: Partial<ProfileApi> = {
    profile: () => of(profile),
    reveal: vi.fn(() => of({ value: '+91 98765 40697' })),
    uploadPhoto: vi.fn(() => of({ profile, xpEarned: 5 })),
  };
  const toast = { show: vi.fn() };
  TestBed.configureTestingModule({
    providers: [
      provideRouter([]),
      { provide: PROFILE_API, useValue: api },
      { provide: ToastService, useValue: toast },
      {
        provide: Auth,
        useValue: { user: () => ({ id: '1', firstName: 'Yash' }), setPhoto: () => undefined },
      },
    ],
  });
  const page = TestBed.createComponent(ProfilePage).componentInstance as unknown as PageApi;
  return { page, api, toast };
}

const fileEvent = (file: File) => ({ target: { files: [file], value: 'x' } }) as unknown as Event;

describe('ProfilePage', () => {
  it('derives level progress, XP left and stat labels', async () => {
    const { page } = setup();
    await page.load();
    // A-249: within-level progress on the shared ladder: (529 − 400) / 400.
    expect(Math.round(page.levelPercent())).toBe(32);
    expect(page.toNext()).toBe(271);
    expect(page.xpLeft()).toBe(35);
    expect(page.stats()[0]?.value).toBe('1 day');
    const [done, photo, skills, drivers] = profile.strength.tasks;
    expect(done && page.taskAction(done)).toBeNull();
    expect(photo && page.taskAction(photo)).toBe('photo');
    expect(skills && page.taskAction(skills)).toBe('edit');
    expect(drivers && page.taskAction(drivers)).toBe('link');
  });

  it('reveals a private field from the server and masks it again', async () => {
    const { page, api } = setup();
    await page.load();
    const f = profile.privateFields[0];
    if (!f) throw new Error('no field');
    expect(page.revealLabel(f)).toBe('Show Mobile number');
    await page.toggleReveal(f);
    expect(api.reveal).toHaveBeenCalledWith('mobile');
    expect(page.revealed()['mobile']).toBe('+91 98765 40697');
    expect(page.revealLabel(f)).toBe('Hide Mobile number');
    await page.toggleReveal(f);
    expect(page.revealed()['mobile']).toBeUndefined();
  });

  it('rejects non-images and photos over 5 MB before uploading', async () => {
    const { page, api, toast } = setup();
    await page.load();
    await page.photoChosen(fileEvent(new File(['x'], 'cv.pdf', { type: 'application/pdf' })));
    const big = new File([new Uint8Array(5 * 1024 * 1024 + 1)], 'big.jpg', { type: 'image/jpeg' });
    await page.photoChosen(fileEvent(big));
    expect(api.uploadPhoto).not.toHaveBeenCalled();
    expect(toast.show).toHaveBeenCalledTimes(2);

    await page.photoChosen(fileEvent(new File(['x'], 'me.png', { type: 'image/png' })));
    expect(api.uploadPhoto).toHaveBeenCalledTimes(1);
    expect(toast.show).toHaveBeenLastCalledWith('Looking good! Photo added', {
      tone: 'reward',
      xp: '+5 XP',
    });
  });
});
