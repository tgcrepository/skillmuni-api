import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of, throwError } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { PROGRAMME_API, Programme } from '../../core/programme/programme.api';
import { QuestStore } from '../../core/quests/quest-store';
import { ProgrammePage } from './programme-page';

const programme: Programme = {
  code: 'SKM-MUM-26-0417',
  name: 'Customer Support Associate',
  partner: 'NSQF Level 4',
  centre: 'Andheri West, Mumbai',
  batchStarts: '2026-10-12',
  duration: '3 months',
  stipend: '₹5,000 / month',
  marksFrom: '12',
  minEnglish: 50,
  minMaths: 50,
  eligibility: 'Class 12 · 50%+',
};

interface PageApi {
  setCode(v: string): void;
  checkCode(): Promise<void>;
  codeState(): string;
  verified(): boolean;
  english: { set(v: string): void };
  maths: { set(v: string): void };
  attempted: { set(v: boolean): void };
  counter(): string;
  scoreIssues(): Record<'english' | 'maths', { error: string; warn: string; ok: string }>;
  bankErrors(): Record<string, string>;
  setBank(k: string, v: unknown): void;
}

function setup(check: () => unknown) {
  TestBed.configureTestingModule({
    providers: [
      provideRouter([]),
      { provide: PROGRAMME_API, useValue: { check, ifsc: () => of({}), submit: () => of({}) } },
      {
        provide: QuestStore,
        useValue: {
          progress: () => null,
          load: () => Promise.resolve(),
          hud: () => null,
          loadAnswers: () => Promise.resolve({}),
        },
      },
    ],
  });
  const fixture = TestBed.createComponent(ProgrammePage);
  return fixture.componentInstance as unknown as PageApi;
}

describe('ProgrammePage', () => {
  it('maps 404 to not-found and 429 to locked', async () => {
    let status = 404;
    const page = setup(() =>
      throwError(() => new ApiError(status === 429 ? 'rate-limited' : 'not-found', status, 'x')),
    );
    page.setCode('nope');
    await page.checkCode();
    expect(page.codeState()).toBe('not-found');
    status = 429;
    page.setCode('nope2');
    await page.checkCode();
    expect(page.codeState()).toBe('locked');
  });

  it('separates blocking errors from soft warnings in the counter', async () => {
    const page = setup(() => of(programme));
    expect(page.counter()).toBe('Enter your code to continue');
    page.setCode('skm-mum-26-0417');
    await page.checkCode();
    expect(page.verified()).toBe(true);

    page.english.set('72');
    page.maths.set('44');
    expect(page.scoreIssues().maths.warn).toContain('Below the 50%');
    expect(page.scoreIssues().english.ok).toContain('Above');

    page.attempted.set(true);
    expect(page.bankErrors()['account']).toBeTruthy();
    expect(page.counter()).toMatch(/to fix · 1 to check$/);

    page.setBank('account', '50100123456789');
    page.setBank('confirm', '50100123456780');
    expect(page.bankErrors()['confirm']).toBe('Account numbers don’t match.');
  });
});
