import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Viewport } from '../../core/layout/viewport';
import { Market } from '../../core/market/market';
import {
  PROGRAMME_API,
  Proficiency,
  Programme,
  ProgrammeSubmission,
} from '../../core/programme/programme.api';
import { QuestStore, nextRankName } from '../../core/quests/quest-store';
import { QuestShell } from '../../shared/shell/quest-shell';
import { Banner } from '../../shared/ui/banner/banner';
import { Button } from '../../shared/ui/button/button';
import { Checkbox } from '../../shared/ui/checkbox/checkbox';
import { ChipGroup, ChipOption } from '../../shared/ui/chip/chip-group';
import { Field } from '../../shared/ui/field/field';
import { Input } from '../../shared/ui/input/input';
import { uniqueId } from '../../shared/ui/internal/unique-id';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { QuestCard } from '../../shared/ui/quest/quest-card';
import {
  QuestComplete,
  QuestCompleteData,
  QuestCompleteResult,
} from '../../shared/ui/quest/quest-complete';
import { Select, SelectOption } from '../../shared/ui/select/select';
import { Tag } from '../../shared/ui/tag/tag';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { str } from '../quests/parts/part-utils';

type CodeState = 'idle' | 'checking' | 'verified' | 'not-found' | 'locked' | 'offline';
type BankKey = 'holder' | 'account' | 'confirm' | 'routing' | 'upi' | 'consent';

const IFSC = /^[A-Z]{4}0[A-Z0-9]{6}$/;
const UPI = /^[\w.-]{2,}@[a-z]{2,}$/i;
const XP = 100;

/** South African banks with universal branch codes (A-142). */
const ZA_BANKS: readonly { name: string; code: string }[] = [
  { name: 'Absa', code: '632005' },
  { name: 'Capitec', code: '470010' },
  { name: 'FNB', code: '250655' },
  { name: 'Nedbank', code: '198765' },
  { name: 'Standard Bank', code: '051001' },
  { name: 'TymeBank', code: '678910' },
];

/**
 * Bonus quest — programme code + subject scores + stipend bank details (Figma section 13:
 * P1 empty 200:39153 · P2 verified 200:39282 · P3 bank errors 200:39611 · P4 not found 200:39933 ·
 * P5 unlocked 200:41906). India per Figma; South Africa swaps IFSC / UPI for bank + branch code.
 */
@Component({
  selector: 'sm-programme-page',
  imports: [Banner, Button, Checkbox, ChipGroup, Field, Input, QuestCard, QuestShell, Select, Tag],
  templateUrl: './programme-page.html',
  styleUrl: './programme-page.scss',
})
export class ProgrammePage implements OnInit {
  private readonly api = inject(PROGRAMME_API);
  private readonly market = inject(Market);
  protected readonly store = inject(QuestStore);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;

  private readonly viewport = inject(Viewport);
  /** The pinned mobile bar has room for "Skip" plus a short label only. */
  protected readonly primaryLabel = computed(() =>
    this.viewport.size() === 'mobile'
      ? $localize`:@@pg.primaryShort:Unlock it`
      : $localize`:@@pg.primary:Unlock my programme`,
  );
  protected readonly isIndia = computed(() => this.market.code() === 'IN');
  protected readonly ids = {
    marks: uniqueId('pg-marks'),
    prof: uniqueId('pg-prof'),
    type: uniqueId('pg-type'),
    summary: uniqueId('pg-summary'),
  };

  // ── Code ──
  protected readonly code = signal('');
  protected readonly codeState = signal<CodeState>('idle');
  protected readonly programme = signal<Programme | null>(null);

  // ── Scores ──
  protected readonly marksFrom = signal<'10' | '12'>('12');
  protected readonly english = signal('');
  protected readonly maths = signal('');
  protected readonly gradeMode = signal(false);
  protected readonly boardYear = signal('');
  protected readonly proficiency = signal<Record<string, Proficiency>>({});

  // ── Bank ──
  protected readonly bank = signal({
    holder: '',
    type: 'savings' as 'savings' | 'current' | 'cheque',
    account: '',
    confirm: '',
    routing: '',
    upi: '',
    consent: false,
  });
  protected readonly showAccount = signal(false);
  protected readonly branch = signal<{
    state: 'idle' | 'checking' | 'found' | 'missing';
    text: string;
  }>({
    state: 'idle',
    text: '',
  });
  private readonly touched = signal<Partial<Record<BankKey | 'english' | 'maths', boolean>>>({});
  protected readonly attempted = signal(false);
  protected readonly busy = signal(false);

  protected readonly subjects = [
    { key: 'eng_speaking', label: $localize`:@@pg.engSpeak:English · speaking` },
    { key: 'eng_rw', label: $localize`:@@pg.engRw:English · reading & writing` },
    { key: 'maths', label: $localize`:@@pg.mathsNum:Maths & numbers` },
    { key: 'computer', label: $localize`:@@pg.computer:Computer basics` },
  ];
  protected readonly levels: ChipOption[] = [
    { value: 'basic', label: $localize`:@@pg.basic:Basic` },
    { value: 'okay', label: $localize`:@@pg.okay:Okay` },
    { value: 'good', label: $localize`:@@pg.good:Good` },
    { value: 'pro', label: $localize`:@@pg.pro:Pro` },
  ];
  protected readonly marksOptions: ChipOption[] = [
    { value: '10', label: $localize`:@@pg.class10:Class 10` },
    { value: '12', label: $localize`:@@pg.class12:Class 12` },
  ];
  protected readonly typeOptions = computed<ChipOption[]>(() =>
    this.isIndia()
      ? [
          { value: 'savings', label: $localize`:@@pg.savings:Savings` },
          { value: 'current', label: $localize`:@@pg.current:Current` },
        ]
      : [
          { value: 'savings', label: $localize`:@@pg.savings:Savings` },
          { value: 'cheque', label: $localize`:@@pg.cheque:Cheque / current` },
        ],
  );
  protected readonly zaBanks: SelectOption[] = ZA_BANKS.map((b) => ({
    value: b.code,
    label: `${b.name} · ${b.code}`,
  }));
  protected readonly labels = {
    code: $localize`:@@pg.codeLabel:Programme / project code`,
    english: $localize`:@@pg.english:English`,
    maths: $localize`:@@pg.maths:Maths`,
    holder: $localize`:@@pg.holder:Account holder name`,
    account: $localize`:@@pg.account:Bank account number`,
    confirm: $localize`:@@pg.confirm:Re-enter account number`,
    ifsc: $localize`:@@pg.ifsc:IFSC code`,
    upi: $localize`:@@pg.upi:UPI ID`,
    bank: $localize`:@@pg.bankName:Bank and branch code`,
    boardYear: $localize`:@@pg.boardYear:Board · year`,
    show: $localize`:@@pg.show:Show account number`,
    hide: $localize`:@@pg.hide:Hide account number`,
  };

  protected readonly lookingUp = $localize`:@@pg.lookingUp:Looking up your branch…`;
  protected readonly ifscHelper = $localize`:@@pg.ifscHelper:11 characters, on your passbook or a cheque.`;

  protected readonly verified = computed(
    () => this.codeState() === 'verified' && !!this.programme(),
  );
  protected readonly needsBank = computed(() => !!this.programme()?.stipend);
  protected readonly codeError = computed(() => {
    switch (this.codeState()) {
      case 'not-found':
        return $localize`:@@pg.notFound:We couldn’t find this code. Check it or ask your coordinator.`;
      case 'locked':
        return $localize`:@@pg.locked:Too many tries. Ask your coordinator, or try again in 30 minutes.`;
      case 'offline':
        return $localize`:@@pg.offline:You’re offline. Reconnect and check the code again.`;
      default:
        return '';
    }
  });

  /** Score problems: blocking errors, and soft warnings (below the minimum still joins, Figma P3). */
  protected readonly scoreIssues = computed(() => {
    const p = this.programme();
    const out: Record<'english' | 'maths', { error: string; warn: string; ok: string }> = {
      english: { error: '', warn: '', ok: '' },
      maths: { error: '', warn: '', ok: '' },
    };
    if (!p) return out;
    const check = (key: 'english' | 'maths', value: string, min: number) => {
      const show = this.attempted() || this.touched()[key];
      if (!value.trim()) {
        if (show) out[key].error = $localize`:@@pg.scoreReq:Add your mark`;
        return;
      }
      if (this.gradeMode()) {
        out[key].ok = $localize`:@@pg.gradeNote:We’ll convert your grade for the coordinator.`;
        return;
      }
      const n = Number(value);
      if (!(n >= 0 && n <= 100)) {
        if (show) out[key].error = $localize`:@@pctRange:Percentages go from 0 to 100`;
        return;
      }
      if (n < min)
        out[key].warn =
          key === 'maths'
            ? $localize`:@@pg.belowMaths:Below the ${min}:min:% this programme needs. You can still join with a free 2-week Maths bridge module.`
            : $localize`:@@pg.belowEng:Below the ${min}:min:% this programme needs. You can still join with a free English bridge module.`;
      else out[key].ok = $localize`:@@pg.above:Above the ${min}:min:% minimum`;
    };
    check('english', this.english(), p.minEnglish);
    check('maths', this.maths(), p.minMaths);
    return out;
  });

  protected readonly bankErrors = computed(() => {
    const e: Partial<Record<BankKey, string>> = {};
    if (!this.needsBank()) return e;
    const b = this.bank();
    const t = this.touched();
    const show = (k: BankKey) => this.attempted() || !!t[k];
    const digits = b.account.replace(/\s/g, '');
    const range = this.isIndia() ? [9, 18] : [7, 11];
    if (show('holder') && !b.holder.trim())
      e.holder = $localize`:@@pg.holderReq:Add the name exactly as your bank has it`;
    if (show('account')) {
      if (!digits) e.account = $localize`:@@pg.accountReq:Add your account number`;
      else if (
        !/^\d+$/.test(digits) ||
        digits.length < (range[0] ?? 0) ||
        digits.length > (range[1] ?? 99)
      )
        e.account = $localize`:@@pg.accountLen:Account numbers are ${range[0]}:min:–${range[1]}:max: digits.`;
    }
    if (show('confirm') && digits && b.confirm.replace(/\s/g, '') !== digits)
      e.confirm = $localize`:@@pg.mismatch:Account numbers don’t match.`;
    if (show('routing')) {
      if (this.isIndia()) {
        const code = b.routing.trim().toUpperCase();
        if (!IFSC.test(code))
          e.routing = $localize`:@@pg.ifscLen:IFSC has 11 characters, like HDFC0000240.`;
        else if (this.branch().state === 'missing')
          e.routing = $localize`:@@pg.ifscMissing:We couldn’t find this IFSC. Check your passbook or a cheque.`;
      } else if (!b.routing) e.routing = $localize`:@@pg.bankReq:Pick your bank`;
    }
    if (show('upi') && b.upi && !UPI.test(b.upi.trim()))
      e.upi = $localize`:@@pg.upiBad:UPI IDs look like name@bank.`;
    if (this.attempted() && !b.consent)
      e.consent = $localize`:@@pg.consentReq:Tick this to confirm the account is yours.`;
    return e;
  });

  protected readonly fixCount = computed(() => {
    const s = this.scoreIssues();
    return (
      Object.keys(this.bankErrors()).length + (s.english.error ? 1 : 0) + (s.maths.error ? 1 : 0)
    );
  });
  protected readonly checkCount = computed(() => {
    const s = this.scoreIssues();
    return (s.english.warn ? 1 : 0) + (s.maths.warn ? 1 : 0);
  });

  protected readonly counter = computed(() => {
    if (!this.verified()) return $localize`:@@pg.enterCode:Enter your code to continue`;
    const fix = this.fixCount();
    const check = this.checkCount();
    if (!fix && !check) return $localize`:@@pg.allSet:All set`;
    if (!fix) return $localize`:@@pg.toCheck:${check}:n: to check`;
    return check
      ? $localize`:@@pg.toFixCheck:${fix}:fix: to fix · ${check}:check: to check`
      : $localize`:@@pg.toFix:${fix}:n: to fix`;
  });

  protected readonly loot = computed(() => ({
    badge: $localize`:@@pg.badge:Programme Badge`,
    reward: $localize`:@@pg.reward:+100 bonus XP and your programme dashboard unlocks`,
    rewardShort: $localize`:@@pg.rewardShort:+100 XP · programme dashboard`,
    progress: this.verified() ? (this.fixCount() ? 60 : 90) : 0,
  }));
  protected readonly muni = computed(() =>
    this.verified()
      ? $localize`:@@pg.muniFound:Found it! ${this.programme()?.name}:name:, nice pick.`
      : this.codeState() === 'not-found'
        ? $localize`:@@pg.muniMissing:Hmm, that code isn’t ringing a bell. Double-check it?`
        : $localize`:@@pg.muniStart:Got a code? Pop it in and let’s find your programme!`,
  );

  async ngOnInit(): Promise<void> {
    if (!this.store.progress()) void this.store.load().catch(() => undefined);
    try {
      const q3 = await this.store.loadAnswers('big-brain-stuff');
      const board = str(q3['board']);
      const year = str(q3['year']);
      this.boardYear.set([board, year].filter(Boolean).join(' · '));
      const q1 = await this.store.loadAnswers('who-dis');
      const name = [str(q1['firstName']), str(q1['lastName'])].filter(Boolean).join(' ');
      if (name) this.bank.update((b) => ({ ...b, holder: name }));
    } catch {
      /* fields stay editable */
    }
  }

  // ── Code ──

  protected setCode(value: string): void {
    this.code.set(value.toUpperCase());
    if (this.codeState() !== 'locked') this.codeState.set('idle');
  }

  protected async checkCode(): Promise<void> {
    const code = this.code().trim();
    if (!code || this.codeState() === 'checking' || this.codeState() === 'locked') return;
    this.codeState.set('checking');
    try {
      const p = await firstValueFrom(this.api.check(code));
      this.programme.set(p);
      this.marksFrom.set(p.marksFrom);
      this.codeState.set('verified');
    } catch (err) {
      this.programme.set(null);
      const status =
        err instanceof ApiError ? err.status : err instanceof HttpErrorResponse ? err.status : 0;
      this.codeState.set(status === 429 ? 'locked' : status === 0 ? 'offline' : 'not-found');
      setTimeout(() => this.host.querySelector<HTMLInputElement>('.code-row input')?.focus());
    }
  }

  protected changeCode(): void {
    this.programme.set(null);
    this.codeState.set('idle');
    setTimeout(() => this.host.querySelector<HTMLInputElement>('.code-row input')?.focus());
  }

  // ── Scores ──

  protected setMarksFrom(v: string | string[] | null): void {
    if (v === '10' || v === '12') this.marksFrom.set(v);
  }

  protected setProf(key: string, v: string | string[] | null): void {
    if (typeof v === 'string') this.proficiency.update((p) => ({ ...p, [key]: v as Proficiency }));
  }

  protected skillCheck(): void {
    this.toast.show(
      $localize`:@@pg.skillCheckSoon:Skill checks are coming soon. Self-rate for now.`,
    );
  }

  protected touch(key: BankKey | 'english' | 'maths'): void {
    this.touched.update((t) => ({ ...t, [key]: true }));
  }

  // ── Bank ──

  protected setBank<K extends keyof ReturnType<typeof this.bank>>(
    key: K,
    value: ReturnType<typeof this.bank>[K],
  ): void {
    this.bank.update((b) => ({ ...b, [key]: value }));
    if (key === 'routing') this.branch.set({ state: 'idle', text: '' });
  }

  protected setType(v: string | string[] | null): void {
    if (v === 'savings' || v === 'current' || v === 'cheque') this.setBank('type', v);
  }

  protected setZaBank(v: string | string[] | null): void {
    if (typeof v !== 'string') return;
    this.setBank('routing', v);
    this.touch('routing');
  }

  /** Paste is blocked on the re-entry field so it's typed twice (Figma P2). */
  protected blockPaste(event: ClipboardEvent): void {
    event.preventDefault();
    this.toast.show($localize`:@@pg.noPaste:Type it again so we know it’s right.`);
  }

  protected async lookupIfsc(): Promise<void> {
    this.touch('routing');
    const code = this.bank().routing.trim().toUpperCase();
    if (!IFSC.test(code)) return;
    this.branch.set({ state: 'checking', text: '' });
    try {
      const b = await firstValueFrom(this.api.ifsc(code));
      this.branch.set({ state: 'found', text: `${b.bank} · ${b.branch}` });
    } catch {
      this.branch.set({ state: 'missing', text: '' });
    }
  }

  protected batchDate(iso: string): string {
    return new Intl.DateTimeFormat(this.market.config().locale, {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    }).format(new Date(iso));
  }

  protected maskedTail(): string {
    return this.bank().account.replace(/\s/g, '').slice(-2);
  }

  // ── Submit ──

  protected skip(): void {
    void this.router.navigateByUrl('/home');
  }

  protected async submit(): Promise<void> {
    if (!this.verified() || this.busy()) return;
    this.attempted.set(true);
    if (this.fixCount()) {
      setTimeout(() =>
        this.host
          .querySelector<HTMLElement>(
            '[aria-invalid="true"], .is-invalid input, .sm-field--error input',
          )
          ?.focus(),
      );
      return;
    }
    const p = this.programme();
    if (!p) return;
    const b = this.bank();
    const body: ProgrammeSubmission = {
      code: p.code,
      marksFrom: this.marksFrom(),
      english: this.english().trim(),
      maths: this.maths().trim(),
      proficiency: this.proficiency(),
      bank: this.needsBank()
        ? {
            holder: b.holder.trim(),
            type: b.type,
            account: b.account.replace(/\s/g, ''),
            routing: b.routing.trim().toUpperCase(),
            upi: b.upi.trim(),
          }
        : null,
    };
    const before = this.store.progress();
    this.busy.set(true);
    try {
      const result = await firstValueFrom(this.api.submit(body));
      this.store.progress.set(result.progress);
      this.celebrate(p, result.xpEarned, before?.xp ?? 0, result.accountTail);
    } catch {
      this.toast.show(
        $localize`:@@pg.submitFail:Couldn’t unlock it just now. Your answers are kept, try again.`,
        {
          tone: 'error',
        },
      );
    } finally {
      this.busy.set(false);
    }
  }

  private celebrate(p: Programme, xp: number, xpBefore: number, tail: string): void {
    const prog = this.store.progress();
    const when = new Intl.DateTimeFormat(this.market.config().locale, {
      day: 'numeric',
      month: 'short',
    }).format(new Date(p.batchStarts));
    const currency = this.isIndia() ? '₹1' : 'R1';
    const data: QuestCompleteData = {
      quest: 8,
      eyebrow: $localize`:@@pg.cleared:Bonus quest: cleared`,
      levelUp: $localize`:@@pg.pill:Bonus quest · Programme unlocked`,
      title: [$localize`:@@pg.doneA:Programme`, $localize`:@@pg.doneB:unlocked!`],
      body: $localize`:@@pg.doneBody:You’re in ${p.name}:name:. Batch starts ${when}:date: at ${p.centre}:centre:, and your coordinator will WhatsApp you soon.`,
      xpEarned: xp,
      rank: prog?.rank ?? '',
      level: prog?.level ?? 1,
      xpBefore,
      xpTarget: prog?.target ?? 800,
      nextRank: nextRankName(prog?.xp ?? 0),
      reviewLabel: $localize`:@@pg.view:View programme`,
      primaryLabel: $localize`:@@pg.home:Take me home`,
      ...(this.needsBank()
        ? {
            bonus: {
              eyebrow: $localize`:@@pg.bankCheck:Bank check in progress`,
              title: $localize`:@@pg.sent:We’ve sent ${currency}:amount: to your account ••${tail}:tail:`,
              meta: $localize`:@@pg.sentMeta:Confirmed within 24 hrs. We’ll ping you.`,
              mark: this.isIndia() ? '₹' : 'R',
              tone: 'success' as const,
            },
          }
        : {}),
    };
    const ref = this.overlay.modal<QuestComplete, QuestCompleteData, QuestCompleteResult>(
      QuestComplete,
      {
        data,
        size: 'md',
      },
    );
    ref.closed.subscribe((choice) => {
      if (choice === 'continue') void this.router.navigateByUrl('/home');
    });
  }
}

export const PROGRAMME_XP = XP;
