import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

export const programmeRoutes: Routes = [
  {
    path: 'programme',
    title: $localize`:@@route.programme:Unlock your programme · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./programme-page').then((m) => m.ProgrammePage),
  },
];
