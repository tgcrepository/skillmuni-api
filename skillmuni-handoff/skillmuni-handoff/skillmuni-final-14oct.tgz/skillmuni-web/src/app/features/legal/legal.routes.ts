import { Routes } from '@angular/router';

export const legalRoutes: Routes = [
  { path: 'legal', pathMatch: 'full', redirectTo: 'legal/terms' },
  {
    path: 'legal/:doc',
    title: $localize`:@@route.legal:Privacy Policy & Terms · Skillmuni`,
    loadComponent: () => import('./legal-page').then((m) => m.LegalPage),
  },
];
