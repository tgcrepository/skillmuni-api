import { DIALOG_DATA, DialogRef } from '@angular/cdk/dialog';
import { Component, inject } from '@angular/core';
import { Viewport } from '../../core/layout/viewport';
import { Button } from '../../shared/ui/button/button';
import { SmDialog } from '../../shared/ui/overlay/dialog';
import { requestClose } from '../../shared/ui/overlay/overlay.service';
import { LegalView } from './legal-view';
import { LegalDoc } from './legal.types';

/**
 * The policy over the signup form (A-289), full screen (corrections #3): read it without losing what
 * you typed. Tablet/desktop get the page layout with the sticky jump list; phones the collapsible one.
 */
@Component({
  selector: 'sm-legal-drawer',
  imports: [Button, LegalView, SmDialog],
  template: `
    <sm-dialog i18n-title="@@legal.title" title="Privacy Policy &amp; Terms">
      <sm-legal-view [embedded]="viewport.isMobile()" [doc]="doc" />
      <div smDialogActions class="actions">
        <button sm-button type="button" (click)="close()" i18n="@@legal.gotIt">Got it</button>
      </div>
    </sm-dialog>
  `,
  styles: `
    :host {
      display: contents;
    }

    .actions {
      display: flex;
      justify-content: center;
      padding-block-start: var(--sm-space-300);
    }

    .actions button {
      inline-size: min(100%, 24rem);
    }
  `,
})
export class LegalDrawer {
  private readonly ref = inject(DialogRef);
  protected readonly viewport = inject(Viewport);
  protected readonly doc = inject<LegalDoc | undefined>(DIALOG_DATA) ?? 'terms';

  protected close(): void {
    requestClose(this.ref);
  }
}
