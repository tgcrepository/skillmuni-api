export type LegalDoc = 'terms' | 'privacy';

export interface LegalSection {
  readonly id: string;
  readonly title: string;
  readonly paragraphs: readonly string[];
  readonly list?: readonly string[];
}

/** The document the copy comes from (Terms of Use & Privacy Policy v1.0, 2025). */
export const LEGAL_VERSION = '1.0';
export const LEGAL_YEAR = '2025';
export const LEGAL_CONTACT = 'Skillmuni@thegamificationcompany.com';
