import { Component, ElementRef, booleanAttribute, computed, inject, input, model } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { Icon } from '../../shared/ui/icon/icon';
import { MuniTalk } from '../../shared/ui/muni/muni-talk';
import { TabItem, Tabs } from '../../shared/ui/tabs/tabs';
import { uniqueId } from '../../shared/ui/internal/unique-id';
import { PRIVACY_POLICY, TERMS_OF_USE } from './legal-content';
import { LEGAL_CONTACT, LEGAL_VERSION, LEGAL_YEAR, LegalDoc } from './legal.types';

/**
 * Terms of Use + Privacy Policy (A-289), styled like the rest of Skillmuni: tabs for the two documents,
 * a jump list, numbered section cards. Used full page (/legal/…) and inside the signup drawer, so the
 * form is never lost. Copy comes word for word from the v1.0 document.
 */
@Component({
  selector: 'sm-legal-view',
  imports: [Icon, MuniTalk, NgTemplateOutlet, Tabs],
  templateUrl: './legal-view.html',
  styleUrl: './legal-view.scss',
  host: { class: 'sm-legal-view', '[class.is-embedded]': 'embedded()' },
})
export class LegalView {
  private readonly host = inject(ElementRef<HTMLElement>).nativeElement as HTMLElement;

  readonly doc = model<LegalDoc>('terms');
  /** Inside a drawer: headings drop a level and the jump list sits on top. */
  readonly embedded = input(false, { transform: booleanAttribute });

  protected readonly ids = uniqueId('legal');
  protected readonly contact = LEGAL_CONTACT;
  protected readonly versionLine = $localize`:@@legal.version:Version ${LEGAL_VERSION}:version: · ${LEGAL_YEAR}:year:`;
  protected readonly tabs: readonly TabItem[] = [
    { value: 'terms', label: $localize`:@@legal.tabTerms:Terms of Use` },
    { value: 'privacy', label: $localize`:@@legal.tabPrivacy:Privacy Policy` },
  ];
  protected readonly sections = computed(() =>
    this.doc() === 'privacy' ? PRIVACY_POLICY : TERMS_OF_USE,
  );
  protected readonly muniSay = computed(() =>
    this.doc() === 'privacy'
      ? $localize`:@@legal.muniPrivacy:This is how we look after your data. Tap a heading to jump straight to it.`
      : $localize`:@@legal.muniTerms:The house rules, in full. Tap a heading to jump straight to it.`,
  );
  protected readonly muniLines: readonly string[] = [
    $localize`:@@legal.muni2:Questions? The contact email is right at the end of the Privacy Policy.`,
    $localize`:@@legal.muni3:Long read, I know. Grab a chai and scroll at your pace.`,
  ];

  protected sectionId(id: string): string {
    return `${this.ids}-${this.doc()}-${id}`;
  }

  /** Jump without touching the URL, so it also works inside the drawer's own scroller. */
  protected jump(event: Event, id: string): void {
    event.preventDefault();
    const target = this.host.querySelector<HTMLElement>(`#${CSS.escape(this.sectionId(id))}`);
    if (!target) return;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    target.focus({ preventScroll: true });
  }
}
