import { TestBed } from '@angular/core/testing';
import { PRIVACY_POLICY, TERMS_OF_USE } from './legal-content';
import { LegalView } from './legal-view';

describe('LegalView (A-289)', () => {
  it('carries the whole document without drafting brackets', () => {
    const all = [...TERMS_OF_USE, ...PRIVACY_POLICY].flatMap((s) => [
      s.title,
      ...s.paragraphs,
      ...(s.list ?? []),
    ]);
    expect(TERMS_OF_USE.length).toBe(9);
    expect(PRIVACY_POLICY.length).toBe(11);
    expect(all.some((t) => /[[\]]/.test(t))).toBe(false);
    expect(all.join(' ')).toContain('Pune, in the state of Maharashtra');
  });

  it('switches documents and lists every section in the jump list', async () => {
    const fixture = TestBed.createComponent(LegalView);
    fixture.componentRef.setInput('doc', 'privacy');
    await fixture.whenStable();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelectorAll('.toc-link').length).toBe(PRIVACY_POLICY.length);
    expect(el.querySelectorAll('section.section').length).toBe(PRIVACY_POLICY.length);
    expect(el.querySelector('.mail')?.getAttribute('href')).toBe(
      'mailto:Skillmuni@thegamificationcompany.com',
    );
    fixture.componentRef.setInput('doc', 'terms');
    await fixture.whenStable();
    expect(el.querySelectorAll('section.section').length).toBe(TERMS_OF_USE.length);
  });
});
