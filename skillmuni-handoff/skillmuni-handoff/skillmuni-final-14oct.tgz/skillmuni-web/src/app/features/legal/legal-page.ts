import { Component, inject, input, linkedSignal } from '@angular/core';
import { Router } from '@angular/router';
import { BackNav } from '../../core/layout/back-nav';
import { BrandLogo } from '../../shared/shell/brand-logo';
import { PageBackground } from '../../shared/shell/page-background';
import { Icon } from '../../shared/ui/icon/icon';
import { LegalView } from './legal-view';
import { LegalDoc } from './legal.types';

/** /legal/terms · /legal/privacy (A-289). Public: readable before and after signing in. */
@Component({
  selector: 'sm-legal-page',
  imports: [BrandLogo, Icon, LegalView, PageBackground],
  template: `
    <sm-page-background />
    <main class="page" id="main">
      <header class="bar">
        <button type="button" class="back sm-back" (click)="nav.back('/signup')">
          <sm-icon name="chevron-left" size="sm" />
          <span i18n="@@ui.back">Back</span>
        </button>
        <sm-brand-logo size="sm" />
      </header>
      <div class="head">
        <span class="rule" aria-hidden="true"></span>
        <h1 class="h1" i18n="@@legal.title">Privacy Policy &amp; Terms</h1>
        <span class="rule rule-end" aria-hidden="true"></span>
      </div>
      <sm-legal-view [doc]="current()" (docChange)="show($event)" />
    </main>
  `,
  styleUrl: './legal-page.scss',
})
export class LegalPage {
  protected readonly nav = inject(BackNav);
  private readonly router = inject(Router);

  /** Route param (`terms` | `privacy`). */
  readonly doc = input<string>('terms');
  protected readonly current = linkedSignal<LegalDoc>(() =>
    this.doc() === 'privacy' ? 'privacy' : 'terms',
  );

  protected show(doc: LegalDoc): void {
    this.current.set(doc);
    void this.router.navigate(['/legal', doc], { replaceUrl: true });
  }
}
