import { Component, computed } from '@angular/core';
import manifest from '../../../../styles/tokens/tokens.manifest.json';

interface Group {
  readonly id: string;
  readonly title: string;
  readonly tokens: readonly string[];
}

const pick = (prefix: string, exclude?: RegExp): string[] =>
  manifest.tokens.filter((t) => t.startsWith(prefix) && !(exclude && exclude.test(t)));

/**
 * Dev-only page (route `_dev/tokens`, not registered in production builds).
 * Renders every semantic token straight from the generated manifest so Figma ↔ code can be compared.
 */
@Component({
  selector: 'sm-tokens-preview',
  templateUrl: './tokens-preview.html',
  styleUrl: './tokens-preview.scss',
})
export class TokensPreview {
  protected readonly total = manifest.count;

  protected readonly colorGroups = computed<Group[]>(() =>
    [
      'bg',
      'surface',
      'text',
      'border',
      'brand',
      'accent',
      'feedback',
      'icon',
      'effect',
      'rank',
    ].map((g) => ({
      id: g,
      title: g,
      tokens: pick(`--sm-color-${g}-`),
    })),
  );

  protected readonly typeStyles = pick('--sm-font-').map((t) => ({
    token: t,
    className: t.replace('--sm-font-', 'sm-text-'),
  }));
  protected readonly spacing = pick('--sm-space-');
  protected readonly radii = pick('--sm-radius-', /full/);
  protected readonly shadows = pick('--sm-shadow-');
  protected readonly gradients = pick('--sm-gradient-');
  protected readonly motion = pick('--sm-motion-duration-');

  protected cssVar(token: string): string {
    return `var(${token})`;
  }
}
