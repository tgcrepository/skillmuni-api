import { Component, inject, signal } from '@angular/core';
import { Market, MarketCode } from '../../../core/market/market';
import { OfflineQueue } from '../../../core/network/offline-queue';
import { PermissionPrimer, PrimerResult } from '../../../core/permissions/permission-primer';
import { Session } from '../../../core/session/session';
import { QuestShell } from '../../../shared/shell/quest-shell';
import { Button } from '../../../shared/ui/button/button';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { QuestCard } from '../../../shared/ui/quest/quest-card';
import { Skeleton } from '../../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../../shared/ui/state-block/state-block';
import { ToastService } from '../../../shared/ui/toast/toast.service';

/**
 * Dev-only route `_dev/states` (not in production builds): the quest shell wired to the Phase 5
 * cross-cutting services, used by the Playwright offline and session-expiry flows.
 */
@Component({
  selector: 'sm-states-preview',
  imports: [QuestShell, QuestCard, Field, Input, Button, StateBlock, Skeleton],
  template: `
    <sm-quest-shell
      [quest]="1"
      [progress]="{ completed: 0, partsDone: 0 }"
      [hud]="{ level: 1, rank: 'Rookie', xp: 90, target: 400 }"
      [loot]="{
        badge: 'Main Character Badge',
        reward: '+50 XP, and the Hit Me Up quest unlocks',
        rewardShort: '+50 XP · unlocks Hit Me Up',
        progress: 10,
      }"
      muni="Hey! Let’s start with your name. Easy XP, no cap."
      (exit)="toast.show('Progress saved. Pick up anytime.')"
    >
      <sm-quest-card
        eyebrow="Quest 1 of 8 · Who dis? · Part 1 of 3"
        subtitle="Use the name on your ID, it goes on your certificates."
        [steps]="steps"
        [counter]="queue.pending().length ? 'Saved on this device' : '1 more to go'"
        [busy]="saving()"
        (next)="save()"
      >
        <h1 smQuestTitle>First up, what should we <em>call you?</em></h1>
        <sm-field label="First name" required><sm-input [(value)]="name" /></sm-field>

        <section class="dev" aria-label="Dev controls">
          <p class="dev-title">
            Dev controls · {{ market.config().name }} {{ market.config().dialCode }}
          </p>
          <div class="dev-row">
            <button sm-button variant="secondary" type="button" (click)="session.expire()">
              Expire session
            </button>
            <button sm-button variant="secondary" type="button" (click)="prime('camera')">
              Camera primer
            </button>
            <button sm-button variant="secondary" type="button" (click)="prime('notifications')">
              Notifications primer
            </button>
            <button sm-button variant="secondary" type="button" (click)="toggleMarket()">
              Switch market
            </button>
          </div>
          @if (primer()) {
            <p class="dev-result" role="status">Primer result: {{ primer() }}</p>
          }
          <div class="dev-row" aria-busy="true">
            <span class="sm-visually-hidden">Loading…</span>
            <sm-skeleton width="40%" />
            <sm-skeleton />
            <sm-skeleton shape="pill" width="60%" />
          </div>
          <sm-state-block
            title="Couldn’t load your matches"
            body="Check your connection and try again. Your profile is safe."
          >
            <button sm-button smStateAction type="button">Try again</button>
          </sm-state-block>
        </section>
      </sm-quest-card>
    </sm-quest-shell>
  `,
  styles: `
    .dev {
      display: grid;
      gap: var(--sm-space-400);
      padding-block-start: var(--sm-space-600);
      border-block-start: var(--sm-stroke-sm) dashed var(--sm-color-border-subtle);
    }

    .dev-title,
    .dev-result {
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption-semibold);
    }

    .dev-row {
      display: flex;
      flex-wrap: wrap;
      gap: var(--sm-space-300);
    }
  `,
})
export class StatesPreview {
  protected readonly session = inject(Session);
  protected readonly queue = inject(OfflineQueue);
  protected readonly market = inject(Market);
  protected readonly toast = inject(ToastService);
  private readonly primers = inject(PermissionPrimer);

  protected readonly name = signal('Nkosazana');
  protected readonly saving = signal(false);
  protected readonly primer = signal<PrimerResult | null>(null);
  protected readonly steps = [
    { label: 'Your name', short: 'Name', answered: 1, total: 2 },
    { label: 'ID & birthday', short: 'ID & bday', answered: 0, total: 2, xp: '+20 XP' },
    { label: 'The tea', answered: 0, total: 3, xp: '+20 XP' },
  ];

  constructor() {
    this.session.start();
    this.session.resumeLabel.set('Who Dis?');
  }

  protected async save(): Promise<void> {
    this.saving.set(true);
    try {
      const outcome = await this.queue.save({
        key: 'quest-1/part-1',
        method: 'PUT',
        path: 'drafts/quest-1-part-1',
        body: { firstName: this.name() },
      });
      if (outcome === 'saved') this.toast.reward('Part 1 done', '+20 XP');
    } finally {
      this.saving.set(false);
    }
  }

  protected async prime(kind: 'camera' | 'notifications'): Promise<void> {
    this.primer.set(await this.primers.ask(kind));
  }

  protected toggleMarket(): void {
    const next: MarketCode = this.market.code() === 'IN' ? 'ZA' : 'IN';
    this.market.set(next);
  }
}
