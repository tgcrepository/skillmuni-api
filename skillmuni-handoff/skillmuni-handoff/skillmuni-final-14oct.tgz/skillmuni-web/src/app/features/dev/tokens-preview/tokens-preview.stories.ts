import type { Meta, StoryObj } from '@storybook/angular-vite';
import { TokensPreview } from './tokens-preview';

const meta: Meta<TokensPreview> = {
  title: 'Foundations/Tokens',
  component: TokensPreview,
  parameters: { layout: 'fullscreen' },
};
export default meta;

export const AllTokens: StoryObj<TokensPreview> = {};
