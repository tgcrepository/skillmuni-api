import { MarketCode } from '../../../core/market/market';

export type LevelKind = 'school' | 'vocational' | 'degree' | 'none';

export interface EducationLevel {
  readonly value: string;
  readonly title: string;
  readonly description: string;
  readonly kind: LevelKind;
}

/** Figma Q3 part 1 option cards (India). South Africa uses NQF-friendly names (A-105). */
export const LEVELS: Readonly<Record<MarketCode, readonly EducationLevel[]>> = {
  IN: [
    {
      value: '10th',
      title: $localize`:@@edu.10:10th`,
      description: $localize`:@@edu.10d:Class 10 · SSLC / Matric`,
      kind: 'school',
    },
    {
      value: '12th',
      title: $localize`:@@edu.12:12th`,
      description: $localize`:@@edu.12d:Class 12 · PUC / HSC`,
      kind: 'school',
    },
    {
      value: 'iti',
      title: $localize`:@@edu.iti:ITI`,
      description: $localize`:@@edu.itid:Trade certificate`,
      kind: 'vocational',
    },
    {
      value: 'diploma',
      title: $localize`:@@edu.dip:Diploma`,
      description: $localize`:@@edu.dipd:Polytechnic`,
      kind: 'vocational',
    },
    {
      value: 'graduate',
      title: $localize`:@@edu.grad:Graduate`,
      description: $localize`:@@edu.gradd:BA, BCom, BTech…`,
      kind: 'degree',
    },
    {
      value: 'postgraduate',
      title: $localize`:@@edu.pg:Postgraduate`,
      description: $localize`:@@edu.pgd:MA, MBA, MTech…`,
      kind: 'degree',
    },
    {
      value: 'phd',
      title: $localize`:@@edu.phd:PhD`,
      description: $localize`:@@edu.phdd:Doctorate`,
      kind: 'degree',
    },
    {
      value: 'none',
      title: $localize`:@@edu.none:No formal education`,
      description: $localize`:@@edu.noned:That's okay too`,
      kind: 'none',
    },
  ],
  ZA: [
    {
      value: 'grade9',
      title: $localize`:@@edu.za9:Grade 9`,
      description: $localize`:@@edu.za9d:GETC · NQF 1`,
      kind: 'school',
    },
    {
      value: 'matric',
      title: $localize`:@@edu.zam:Matric`,
      description: $localize`:@@edu.zamd:NSC · NQF 4`,
      kind: 'school',
    },
    {
      value: 'tvet',
      title: $localize`:@@edu.tvet:TVET certificate`,
      description: $localize`:@@edu.tvetd:NC(V) · N1–N6`,
      kind: 'vocational',
    },
    {
      value: 'diploma',
      title: $localize`:@@edu.dip:Diploma`,
      description: $localize`:@@edu.zadipd:Higher certificate / diploma`,
      kind: 'vocational',
    },
    {
      value: 'graduate',
      title: $localize`:@@edu.zabach:Bachelor's degree`,
      description: $localize`:@@edu.zabachd:BA, BCom, BSc…`,
      kind: 'degree',
    },
    {
      value: 'postgraduate',
      title: $localize`:@@edu.zahons:Honours / Master's`,
      description: $localize`:@@edu.zahonsd:NQF 8–9`,
      kind: 'degree',
    },
    {
      value: 'phd',
      title: $localize`:@@edu.phd:PhD`,
      description: $localize`:@@edu.phdd:Doctorate`,
      kind: 'degree',
    },
    {
      value: 'none',
      title: $localize`:@@edu.none:No formal education`,
      description: $localize`:@@edu.noned:That's okay too`,
      kind: 'none',
    },
  ],
};

export const DEGREES: Readonly<Record<string, readonly string[]>> = {
  graduate: [
    'B.Tech / B.E.',
    'B.Sc',
    'B.Com',
    'BA',
    'BBA',
    'BCA',
    'B.Pharm',
    'MBBS',
    'LLB',
    'BCom (SA)',
    'BSc (SA)',
  ],
  postgraduate: ['M.Tech / M.E.', 'MBA', 'M.Sc', 'M.Com', 'MA', 'MCA', 'Honours', "Master's"],
  phd: ['PhD'],
  diploma: [
    'Diploma in Engineering',
    'Diploma in Computer Applications',
    'Higher Certificate',
    'National Diploma',
  ],
  iti: ['Electrician', 'Fitter', 'Welder', 'COPA', 'Mechanic (Motor Vehicle)', 'Plumber'],
  tvet: [
    'NC(V) Office Administration',
    'NC(V) Information Technology',
    'N4 Business Management',
    'N6 Engineering',
  ],
};

export const BRANCHES = [
  'Computer Science',
  'Information Technology',
  'Electronics',
  'Mechanical',
  'Civil',
  'Electrical',
  'Accounting & Finance',
  'Marketing',
  'Human Resources',
  'Economics',
  'English',
  'Psychology',
  'Other',
];

export const BOARDS: Readonly<Record<MarketCode, readonly string[]>> = {
  IN: ['CBSE', 'ICSE / ISC', 'State board', 'NIOS', 'IB', 'Other'],
  ZA: ['NSC (DBE)', 'IEB', 'SACAI', 'Other'],
};

export const COLLEGES: Readonly<Record<MarketCode, readonly string[]>> = {
  IN: [
    'RV College of Engineering, Bengaluru',
    'RVS College of Arts & Science, Coimbatore',
    'RV College of Architecture, Bengaluru',
    "St. Xavier's College, Mumbai",
    'Christ University, Bengaluru',
    'Delhi University',
    'Anna University, Chennai',
    'Pune University (SPPU)',
    'IIT Bombay',
    'Loyola College, Chennai',
    'Presidency University, Kolkata',
  ],
  ZA: [
    'University of Johannesburg',
    'University of the Witwatersrand',
    'University of Pretoria',
    'University of Cape Town',
    'Tshwane University of Technology',
    'UNISA',
    'Durban University of Technology',
    'Ekurhuleni East TVET College',
  ],
};

export type ScoreKind = 'percentage' | 'cgpa' | 'grade';

export function yearsBack(from: number, count: number): string[] {
  return Array.from({ length: count }, (_, i) => String(from - i));
}

export function yearsAhead(from: number, count: number): string[] {
  return Array.from({ length: count }, (_, i) => String(from + i));
}

/** Q3 part 3: an extra (lower) level or a course. Courses can repeat; school levels can't (Figma §7). */
export interface TimelineEntry {
  readonly id: string;
  /** A LEVELS value (e.g. "12th", "matric") or COURSE. */
  readonly level: string;
  readonly board: string;
  readonly stream: string;
  /** Course name (courses only). */
  readonly name: string;
  readonly institute: string;
  readonly year: string;
  readonly score: string;
  /** EDUCATION entries: a LEVELS value (graduate, diploma…) and the degree / specialisation. */
  readonly qual?: string;
  readonly degree?: string;
  readonly branch?: string;
}

export const COURSE = 'course';
/** Another qualification at any level (a second degree, a diploma…). Repeats like courses (A-244). */
export const EDUCATION = 'education';
export const MAX_TIMELINE = 6;

/** School levels in order, lowest first, per market. */
const SCHOOL_ORDER: Readonly<Record<MarketCode, readonly string[]>> = {
  IN: ['10th', '12th'],
  ZA: ['grade9', 'matric'],
};

export const STREAMS: readonly string[] = [
  'Science (PCM)',
  'Science (PCB)',
  'Commerce',
  'Arts / Humanities',
  'Vocational',
];

/** Which entries the learner can add under their highest level. Highest school level excludes itself. */
export function timelineLevels(market: MarketCode, highest: string): string[] {
  const order = SCHOOL_ORDER[market];
  const at = order.indexOf(highest);
  const school = at >= 0 ? order.slice(0, at) : highest === 'none' || !highest ? [] : [...order];
  return [EDUCATION, ...school.reverse(), COURSE];
}
