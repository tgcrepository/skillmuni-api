import { MarketCode } from '../../../core/market/market';

/** Q6 Pick Your Arc options (Figma 200:34528 India; South Africa per the layer names / A-134). */
export interface ArcOption {
  readonly value: string;
  readonly label: string;
}

const o = (value: string, label: string): ArcOption => ({ value, label });

export const LOOKING_FOR: Readonly<Record<MarketCode, readonly ArcOption[]>> = {
  IN: [
    o('full_time', $localize`:@@arc.ft:Full-time job`),
    o('part_time', $localize`:@@arc.pt:Part-time job`),
    o('internship', $localize`:@@arc.in:Internship`),
    o('apprenticeship', $localize`:@@arc.naps:Apprenticeship (NAPS)`),
    o('freelance', $localize`:@@arc.fl:Freelance / gig`),
    o('short_course', $localize`:@@arc.sc:Short course`),
  ],
  ZA: [
    o('full_time', $localize`:@@arc.ft:Full-time job`),
    o('part_time', $localize`:@@arc.pt:Part-time job`),
    o('internship', $localize`:@@arc.in:Internship`),
    o('learnership', $localize`:@@arc.learnership:Learnership`),
    o('freelance', $localize`:@@arc.fl:Freelance / gig`),
    o('short_course', $localize`:@@arc.sc:Short course`),
  ],
};

export const SHIFTS: readonly ArcOption[] = [
  o('day', $localize`:@@arc.day:Day`),
  o('night', $localize`:@@arc.night:Night (US/UK shift)`),
  o('rotational', $localize`:@@arc.rot:Rotational`),
  o('weekends', $localize`:@@arc.wknd:Weekends`),
];

export const NOTICE: Readonly<Record<MarketCode, readonly ArcOption[]>> = {
  IN: [
    o('immediate', $localize`:@@arc.imm:Immediate joiner`),
    o('15', $localize`:@@arc.15:15 days`),
    o('30', $localize`:@@arc.30:30 days`),
    o('60', $localize`:@@arc.60:60 days`),
    o('90', $localize`:@@arc.90:90 days`),
  ],
  ZA: [
    o('immediate', $localize`:@@arc.now:Start right away`),
    o('7', $localize`:@@arc.1w:1 week`),
    o('14', $localize`:@@arc.2w:2 weeks`),
    o('30', $localize`:@@arc.1m:1 month`),
    o('60', $localize`:@@arc.2m:2 months +`),
  ],
};

/** Expected salary: India yearly CTC in LPA, South Africa monthly in rand (optional either way). */
export const SALARY: Readonly<Record<MarketCode, readonly ArcOption[]>> = {
  IN: [
    o('0-2', '₹0 – 2 LPA'),
    o('2-3', '₹2 – 3 LPA'),
    o('3-4.5', '₹3 – 4.5 LPA'),
    o('4.5-6', '₹4.5 – 6 LPA'),
    o('6-10', '₹6 – 10 LPA'),
    o('10+', '₹10 LPA +'),
  ],
  ZA: [
    o('0-5k', 'R0 – R5 000 / month'),
    o('5-8k', 'R5 000 – R8 000 / month'),
    o('8-12k', 'R8 000 – R12 000 / month'),
    o('12-20k', 'R12 000 – R20 000 / month'),
    o('20k+', 'R20 000 + / month'),
  ],
};

export const SALARY_NOTE: Readonly<Record<MarketCode, string>> = {
  IN: $localize`:@@arc.salaryIn:Yearly CTC. Only shared with employers you apply to.`,
  ZA: $localize`:@@arc.salaryZa:Monthly, before tax. Only shared with employers you apply to.`,
};

export const RADIUS_KM = 25;

/** Popular roles to suggest when the CV / Quest 5 gave us none. */
export const POPULAR_ROLES: readonly string[] = [
  'Customer support executive',
  'BPO · voice process',
  'Data entry operator',
  'Tele-sales executive',
  'Retail associate',
  'Delivery partner',
];
