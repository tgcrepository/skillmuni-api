import { QuestDef } from '../../core/quests/quest-catalog';
import { QuestAnswers } from '../../core/quests/quest.api';

export interface PartDef {
  readonly key: string;
  readonly label: string;
  /** Mobile stepper label (A-53). */
  readonly short?: string;
  /** Muni's line in the bubble / tip for this part. */
  readonly muni: (firstName: string, answers: QuestAnswers) => string;
  /** Heading with the highlighted (Arcane) words in the middle. */
  readonly title: (firstName: string, answers: QuestAnswers) => TitleParts;
  readonly subtitle: string | ((answers: QuestAnswers) => string);
  /** Optional parts get "Skip for now" and no XP when skipped. */
  readonly optional?: boolean;
  /** Primary label on the last part; defaults to "Lock it in". */
  readonly finishLabel?: string;
  /** This part ends the quest early for these answers (Q3: "No formal education" skips 2–3). */
  readonly endsQuest?: (answers: QuestAnswers) => boolean;
}

export interface TitleParts {
  readonly pre: string;
  readonly em: string;
  readonly post?: string;
}

export interface QuestScreenDef {
  readonly slug: string;
  readonly parts: readonly PartDef[];
  /** Q4: a live Player Card replaces the loot card, and the quest ends with the card reveal. */
  readonly playerCard?: boolean;
  /** Eyebrow pill instead of "+50 XP when you’re done" (Q4 part 1: "Unlocks your Player Card"). */
  readonly promise?: string;
  /** Completion modal title, second part highlighted (Q5: "Lore saved. You levelled up!"). */
  readonly completeTitle?: (levelledUp: boolean) => readonly [string, string];
  /** Completion modal secondary button (Q5: "Double-check my lore"). */
  readonly reviewLabel?: string;
  /** Q8: publish the profile and open My Matches instead of the badge modal. */
  readonly toMatches?: boolean;
  /** Loot card override (Q8: "Level 3 · Trailblazer"). */
  readonly loot?: { readonly badge: string; readonly reward: string };
}

/**
 * Per-quest part labels and Muni lines (Figma Q1–Q8 frames). Titles live in the part templates because
 * they carry the highlighted words.
 */
export const QUEST_SCREENS: Readonly<Record<string, QuestScreenDef>> = {
  'who-dis': {
    slug: 'who-dis',
    parts: [
      {
        key: 'name',
        label: $localize`:@@q1.p1:Your name`,
        short: $localize`:@@q1.p1s:Name`,
        muni: () => $localize`:@@q1.m1:Hey! Let’s start with your name. Easy XP, no cap.`,
        title: () => ({
          pre: $localize`:@@q1.t1a:First up, what should we `,
          em: $localize`:@@q1.t1b:call you?`,
        }),
        subtitle: $localize`:@@q1.s1:Use the name on your ID, it goes on your certificates. Takes like 20 seconds, fr.`,
      },
      {
        key: 'id',
        label: $localize`:@@q1.p2:ID & birthday`,
        short: $localize`:@@q1.p2s:ID & bday`,
        muni: (n) =>
          $localize`:@@q1.m2:Big brain move, ${n}:name:: your ID keeps your certificates legit. One more part and the badge is yours!`,
        title: (n) => ({
          pre: $localize`:@@q1.t2a:Okay `,
          em: n,
          post: $localize`:@@q1.t2b:, now the official bits`,
        }),
        subtitle: $localize`:@@q1.s2:We need these to check it’s really you. Encrypted and never shared, pinky promise.`,
      },
      {
        key: 'tea',
        label: $localize`:@@q1.p3:The tea`,
        muni: (n) =>
          $localize`:@@q1.m3:${n}:name:, you’re cooking! A couple more taps and the Main Character Badge is yours.`,
        title: (n) => ({
          pre: $localize`:@@q1.t3a:Okay `,
          em: n,
          post: $localize`:@@q1.t3b:, spill the tea`,
        }),
        subtitle: $localize`:@@q1.s3:Just tap what fits. Takes like a minute, and you can switch it up anytime.`,
      },
    ],
  },
  'hit-me-up': {
    slug: 'hit-me-up',
    parts: [
      {
        key: 'digits',
        label: $localize`:@@q2.p1:Your digits`,
        short: $localize`:@@q2.p1s:Digits`,
        muni: (n) =>
          $localize`:@@q2.m1:Quick one, ${n}:name:: we’ll text you a 6-digit code to make sure it’s really you.`,
        title: (n) => ({ pre: $localize`:@@q2.t1a:Drop your digits, `, em: n }),
        subtitle: $localize`:@@q2.s1:We’ll use these for your login and course updates. No spam, pinky promise.`,
      },
      {
        key: 'backup',
        label: $localize`:@@q2.p2:Backup contact`,
        short: $localize`:@@q2.p2s:Backup`,
        optional: true,
        muni: () =>
          $localize`:@@q2.m2:No pressure fr. Skip it and add one later from your profile.`,
        title: () => ({
          pre: $localize`:@@q2.t2a:Got a `,
          em: $localize`:@@q2.t2b:ride-or-die?`,
          post: $localize`:@@q2.t2c: Add a backup contact`,
        }),
        subtitle: $localize`:@@q2.s2:Totally optional. We’ll only reach them if we can’t reach you.`,
      },
      {
        key: 'spot',
        label: $localize`:@@q2.p3:Your spot`,
        short: $localize`:@@q2.p3s:Spot`,
        muni: () => $localize`:@@q2.m3:Pop in your PIN or postal code and I’ll fill in the rest.`,
        title: () => ({
          pre: $localize`:@@q2.t3a:Where do we send the `,
          em: $localize`:@@q2.t3b:good stuff?`,
        }),
        subtitle: $localize`:@@q2.s3:Start with your code and we’ll fill in the rest. Certificates and merch drops land here.`,
      },
    ],
  },
  'big-brain-stuff': {
    slug: 'big-brain-stuff',
    parts: [
      {
        key: 'level',
        label: $localize`:@@q3.p1:Your level`,
        short: $localize`:@@q3.p1s:Level`,
        muni: () =>
          $localize`:@@q3.m1:Pick the highest one you’ve done or are doing right now. I’ll only ask what fits.`,
        title: () => ({
          pre: $localize`:@@q3.t1a:What’s your `,
          em: $localize`:@@q3.t1b:highest level`,
          post: $localize`:@@q3.t1c: so far?`,
        }),
        subtitle: $localize`:@@q3.s1:Pick the highest one you’ve finished or are doing right now. We’ll only ask what fits.`,
        endsQuest: (a) => a['level'] === 'none',
      },
      {
        key: 'details',
        label: $localize`:@@q3.p2:The details`,
        short: $localize`:@@q3.p2s:Details`,
        muni: () =>
          $localize`:@@q3.m2:Can’t find your college? Add it and I’ll remember it for the next person.`,
        title: (_n, a) =>
          a['status'] === 'studying'
            ? {
                pre: '',
                em: $localize`:@@q3.t2s:Still studying?`,
                post: $localize`:@@q3.t2s2: Tell us where`,
              }
            : a['level'] === 'none'
              ? { pre: $localize`:@@q3.t2na:All good, `, em: $localize`:@@q3.t2nb:no stress` }
              : {
                  pre: $localize`:@@q3.t2a:Tell us about your `,
                  em: levelNoun(String(a['level'] ?? '')),
                },
        subtitle: (a) =>
          a['level'] === 'none'
            ? $localize`:@@q3.s2n:Skills and experience count just as much. Hit next and keep going.`
            : a['status'] === 'studying'
              ? $localize`:@@q3.s2s:Your score is optional until you finish.`
              : $localize`:@@q3.s2:Start typing and pick from the list, it’s faster.`,
      },
      {
        key: 'timeline',
        label: $localize`:@@q3.p3:Timeline · optional`,
        short: $localize`:@@q3.p3s:Timeline`,
        muni: () =>
          $localize`:@@q3.m3:Got your 10th too? Add it if you like. Totally optional, no pressure.`,
        title: () => ({
          pre: $localize`:@@q3.t3a:Your education `,
          em: $localize`:@@q3.t3b:timeline`,
        }),
        subtitle: $localize`:@@q3.s3:Adding your 12th and 10th is optional, but it helps us match you better.`,
      },
    ],
  },
  'your-flex-era': {
    slug: 'your-flex-era',
    playerCard: true,
    promise: $localize`:@@q4.promise:Unlocks your Player Card`,
    parts: [
      {
        key: 'deck',
        label: $localize`:@@q4.p1:Skill deck`,
        short: $localize`:@@q4.p1s:Deck`,
        muni: (_n, a) =>
          hasCvSkills(a)
            ? $localize`:@@q4.m1cv:Levels are my best guess from your CV. You know yourself better than I do!`
            : $localize`:@@q4.m1:Be honest with the power level. Nobody’s a Pro at everything, and that’s the point.`,
        title: () => ({
          pre: $localize`:@@q4.t1a:Build your `,
          em: $localize`:@@q4.t1b:skill deck`,
        }),
        subtitle: (a) =>
          hasCvSkills(a)
            ? $localize`:@@q4.s1cv:We matched skills from your CV to our skill list. Confirm each level, pin your top 3, then power them up.`
            : $localize`:@@q4.s1:Tap cards to add them to your deck, then set how good you are. Your top 3 become your signature moves.`,
      },
      {
        key: 'passport',
        label: $localize`:@@q4.p2:Language passport`,
        short: $localize`:@@q4.p2s:Languages`,
        muni: () =>
          $localize`:@@q4.m2:Every language is a stamp. Tell me how well you speak, read and write each one.`,
        title: () => ({
          pre: $localize`:@@q4.t2a:Your language `,
          em: $localize`:@@q4.t2b:passport`,
        }),
        subtitle: $localize`:@@q4.s2:Stamp every language you know. Tell us how well you speak, read and write each.`,
      },
      {
        key: 'trophies',
        label: $localize`:@@q4.p3:Trophy shelf (optional)`,
        short: $localize`:@@q4.p3s:Trophies`,
        optional: true,
        finishLabel: $localize`:@@q4.reveal:Reveal my card`,
        muni: () =>
          $localize`:@@q4.m3:Add a link and I’ll check it, you get a verified tick. Recruiters love that.`,
        title: () => ({
          pre: $localize`:@@q4.t3a:Show off your `,
          em: $localize`:@@q4.t3b:trophy shelf`,
        }),
        subtitle: $localize`:@@q4.s3:Certificates and courses you’ve finished. Totally optional, but trophies with a link get a verified tick.`,
      },
    ],
  },
  'work-lore': {
    slug: 'work-lore',
    completeTitle: (up) =>
      up
        ? [$localize`:@@q5.doneA:Lore saved.`, $localize`:@@q5.doneB:You levelled up!`]
        : [$localize`:@@q5.doneA:Lore saved.`, $localize`:@@q5.doneC:Badge unlocked!`],
    reviewLabel: $localize`:@@q5.review:Double-check my lore`,
    parts: [
      {
        key: 'types',
        label: $localize`:@@q5.p1:Work types`,
        short: $localize`:@@q5.p1s:Types`,
        finishLabel: $localize`:@@q5.finish:Finish quest`,
        endsQuest: (a) =>
          a['fresher'] === true && !(Array.isArray(a['starters']) && a['starters'].length > 0),
        muni: (_n, a) =>
          a['fresher'] === true
            ? $localize`:@@q5.m1f:Everyone starts somewhere. Finish this and I’ll show you courses that lead to a first job.`
            : $localize`:@@q5.m1:Freelance, tuition, helping at the family shop, it all counts. Pick every one that fits.`,
        title: () => ({
          pre: $localize`:@@q5.t1a:What kind of `,
          em: $localize`:@@q5.t1b:work lore`,
          post: $localize`:@@q5.t1c: do you have?`,
        }),
        subtitle: (a) =>
          a['fresher'] === true
            ? $localize`:@@q5.s1f:No job yet is completely fine. A project, a fest role or some tuition you gave also count, but they’re optional.`
            : $localize`:@@q5.s1:Pick everything that applies. Internships, gigs, tuition and the family shop all count.`,
      },
      {
        key: 'chapter',
        label: $localize`:@@q5.p2:Chapters`,
        short: $localize`:@@q5.p2s:Chapters`,
        muni: () =>
          $localize`:@@q5.m2:Numbers make your story hit harder. “Cut report time by 90%” beats “made reports”.`,
        title: () => ({
          pre: $localize`:@@q5.t2a:Chapter 1: `,
          em: $localize`:@@q5.newChapter:what was it?`,
        }),
        subtitle: $localize`:@@q5.s2:Only four things are needed. Add what you did and the skills you used, it makes your story pop.`,
      },
      {
        key: 'timeline',
        label: $localize`:@@q5.p3:Your timeline`,
        short: $localize`:@@q5.p3s:Timeline`,
        muni: () =>
          $localize`:@@q5.m3:Gaps are normal. Side gigs count. Check the dates and lock it in.`,
        title: () => ({ pre: $localize`:@@q5.t3a:Your lore `, em: $localize`:@@q5.t3b:timeline` }),
        subtitle: (a) =>
          Array.isArray(a['chapters']) && a['chapters'].some((c: { fromCv?: boolean }) => c.fromCv)
            ? $localize`:@@q5.s3cv:We built this from your CV. Check the dates, fix anything off, then lock it in.`
            : $localize`:@@q5.s3:Your story so far. Edit anything, add more, then lock it in.`,
      },
    ],
  },
  'pick-your-arc': {
    slug: 'pick-your-arc',
    parts: [
      {
        key: 'arc',
        label: $localize`:@@q6.p1:Your arc`,
        finishLabel: $localize`:@@q5.finish:Finish quest`,
        muni: () =>
          $localize`:@@q6.m1:Tell me what you’re after and I’ll only show jobs and programmes that fit.`,
        title: () => ({
          pre: $localize`:@@q6.t1a:What’s your `,
          em: $localize`:@@q6.t1b:next arc?`,
        }),
        subtitle: $localize`:@@q6.s1:Tell us what you want next so we only show jobs and programmes that fit. Suggestions come from your CV.`,
      },
    ],
  },
  'drop-the-receipts': {
    slug: 'drop-the-receipts',
    parts: [
      {
        key: 'receipts',
        label: $localize`:@@q7.p1:Receipts`,
        finishLabel: $localize`:@@q5.finish:Finish quest`,
        muni: () =>
          $localize`:@@q7.m1:Each receipt powers up your matches. Your certificates are quick wins!`,
        title: () => ({ pre: $localize`:@@q7.t1a:Drop the `, em: $localize`:@@q7.t1b:receipts` }),
        subtitle: $localize`:@@q7.s1:Proof turns “I said so” into “verified”. Verified items count more when employers match you.`,
      },
    ],
  },
  'vibe-check': {
    slug: 'vibe-check',
    toMatches: true,
    loot: {
      badge: $localize`:@@q8.lootBadge:Your profile, live`,
      reward: $localize`:@@q8.lootReward:+50 XP and your Player Card goes live`,
    },
    parts: [
      {
        key: 'vibe',
        label: $localize`:@@q8.p1:Vibe check`,
        finishLabel: $localize`:@@q8.send:Send it`,
        muni: () => $localize`:@@q8.m1:Jobs near you already fit. Ready to be found?`,
        title: () => ({ pre: $localize`:@@q8.t1a:One last `, em: $localize`:@@q8.t1b:look` }),
        subtitle: $localize`:@@q8.s1:Check it all, choose who can see you, then send it. You can change anything later from your profile.`,
      },
    ],
  },
};

function levelNoun(level: string): string {
  if (level === '10th' || level === '12th' || level === 'grade9' || level === 'matric') {
    return $localize`:@@q3.nounSchool:schooling`;
  }
  if (level === 'iti' || level === 'tvet' || level === 'diploma')
    return $localize`:@@q3.nounCourse:course`;
  return $localize`:@@q3.nounDegree:degree`;
}

export function screenFor(quest: QuestDef): QuestScreenDef | null {
  return QUEST_SCREENS[quest.slug] ?? null;
}

function hasCvSkills(answers: QuestAnswers): boolean {
  const skills = answers['skills'];
  return Array.isArray(skills) && skills.some((k: { source?: string }) => k.source === 'cv');
}
