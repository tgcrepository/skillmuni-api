import {
  ESCO_CATEGORIES,
  ESCO_GROUP_IDS,
  ESCO_GROUP_LABELS,
  ESCO_SKILL_ROWS,
  EscoGroupId,
} from './esco-skills.generated';

/**
 * Q4 skill taxonomy = the ESCO v1.2.1 skills sheet (A-285): 956 skills in ESCO's groups and
 * categories (Transversal T1–T6, Skills S1–S8, Knowledge by ISCED-F field). Tabs follow the ESCO
 * groups; each skill also maps to one of six card families, which drive card colour, the Player
 * Card radar and class title. Loaded once, searched locally.
 */
export type SkillCategory = 'tech' | 'data' | 'creative' | 'business' | 'people' | 'trades';
export type SkillLevel = 1 | 2 | 3;
export type SkillSource = 'cv' | 'suggested' | 'search' | 'custom';

export type EscoKind = 'skill' | 'tool' | 'knowledge';

export interface SkillDef {
  readonly id: string;
  readonly name: string;
  /** Card family (colour, radar). */
  readonly category: SkillCategory;
  /** ESCO group, e.g. S5 "Working with computers". */
  readonly group: EscoGroupId;
  /** ESCO category, e.g. "Programming languages". */
  readonly escoCategory: string;
  readonly kind: EscoKind;
  readonly synonyms?: readonly string[];
}

export interface EscoGroup {
  readonly id: EscoGroupId;
  readonly label: string;
}

/** ESCO groups in ESCO order (Transversal → Skills → Knowledge). */
export const ESCO_GROUPS: readonly EscoGroup[] = ESCO_GROUP_IDS.map((id) => ({
  id,
  label: ESCO_GROUP_LABELS[id],
}));

/** One card in the learner's deck. `level` 0 = added but not set yet (Figma §1 "level missing"). */
export interface DeckSkill {
  readonly id: string;
  readonly name: string;
  readonly category: SkillCategory | 'custom';
  readonly level: SkillLevel | 0;
  readonly source: SkillSource;
  /** ESCO concept URI when the skill came from ESCO search (A-245). */
  readonly esco?: string;
}

export const DECK_MIN = 3;
/** Generous ceiling so a long career fits (A-287); was 15. */
export const DECK_MAX = 50;
export const SIGNATURES = 3;
export const CUSTOM_MAX = 40;

export interface CategoryInfo {
  readonly id: SkillCategory;
  readonly label: string;
  readonly classTitle: string;
}

export const CATEGORIES: readonly CategoryInfo[] = [
  {
    id: 'tech',
    label: $localize`:@@skill.cat.tech:Tech`,
    classTitle: $localize`:@@class.tech:Code Crafter`,
  },
  {
    id: 'data',
    label: $localize`:@@skill.cat.data:Data`,
    classTitle: $localize`:@@class.data:Data Detective`,
  },
  {
    id: 'creative',
    label: $localize`:@@skill.cat.creative:Creative`,
    classTitle: $localize`:@@class.creative:Vibe Designer`,
  },
  {
    id: 'business',
    label: $localize`:@@skill.cat.business:Business`,
    classTitle: $localize`:@@class.business:Hustle Boss`,
  },
  {
    id: 'people',
    label: $localize`:@@skill.cat.people:People`,
    classTitle: $localize`:@@class.people:Crowd Whisperer`,
  },
  {
    id: 'trades',
    label: $localize`:@@skill.cat.trades:Trades`,
    classTitle: $localize`:@@class.trades:Master Maker`,
  },
];

export const ALL_ROUNDER = $localize`:@@class.allRounder:All-Rounder`;
export const CUSTOM_LABEL = $localize`:@@skill.cat.custom:Custom`;

export const LEVEL_INFO: readonly { level: SkillLevel; name: string; hint: string }[] = [
  {
    level: 1,
    name: $localize`:@@skill.l1:Just started`,
    hint: $localize`:@@skill.l1h:I know the basics`,
  },
  {
    level: 2,
    name: $localize`:@@skill.l2:Getting there`,
    hint: $localize`:@@skill.l2h:I use it regularly`,
  },
  {
    level: 3,
    name: $localize`:@@skill.l3:Confident`,
    hint: $localize`:@@skill.l3h:I could teach it`,
  },
];

const KINDS: readonly EscoKind[] = ['skill', 'tool', 'knowledge'];

/** Everyday names people type for ESCO labels. */
const SYNONYMS: Readonly<Record<string, readonly string[]>> = {
  'microsoft-excel': ['excel', 'spreadsheets', 'ms excel'],
  'amazon-web-services-aws': ['aws', 'cloud'],
  'social-media-marketing': ['social media', 'instagram'],
  'customer-service': ['customer care', 'support'],
  'data-entry': ['typing', 'data capturing'],
  'verbal-communication': ['communication', 'speaking'],
  'javascript': ['js'],
  'cplusplus': ['cpp'],
};

export const SKILLS: readonly SkillDef[] = ESCO_SKILL_ROWS.map(([id, name, g, c, k]) => {
  const [escoCategory = '', family = 'people'] = ESCO_CATEGORIES[c] ?? [];
  return {
    id,
    name,
    category: family as SkillCategory,
    group: ESCO_GROUP_IDS[g] ?? 'T1',
    escoCategory,
    kind: KINDS[k] ?? 'skill',
    synonyms: SYNONYMS[id],
  };
});

const BY_ID = new Map(SKILLS.map((k) => [k.id, k]));

export function skillById(id: string): SkillDef | undefined {
  return BY_ID.get(id);
}

function norm(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9+#]+/g, ' ')
    .trim();
}

/** Name and synonym match, name-prefix first ("Excel" → MS Excel, "ML" → Machine learning). */
export function searchSkills(query: string): SkillDef[] {
  const q = norm(query);
  if (!q) return [];
  const scored = SKILLS.map((k) => {
    const name = norm(k.name);
    const syn = (k.synonyms ?? []).map(norm);
    const score = name.startsWith(q)
      ? 3
      : name.split(' ').some((w) => w.startsWith(q))
        ? 2
        : syn.some((x) => x.startsWith(q) || x === q)
          ? 1
          : 0;
    return { k, score };
  });
  return scored
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score || a.k.name.localeCompare(b.k.name))
    .map((x) => x.k);
}

/** Close spelling for "Did you mean" (shared prefix of 4+ letters). */
export function nearMatch(query: string): SkillDef | undefined {
  const q = norm(query);
  if (q.length < 4) return undefined;
  return SKILLS.find((k) => norm(k.name).includes(q.slice(0, 4)));
}

/** Degree / branch → skills to suggest (Figma spec "Suggestions": Quest 3 answers). */
const BY_BRANCH: Readonly<Record<string, readonly string[]>> = {
  'Computer Science': ['python', 'sql', 'javascript', 'java', 'amazon-web-services-aws'],
  'Information Technology': ['python', 'sql', 'javascript', 'linux-administration', 'it-support'],
  Electronics: ['cplusplus', 'python', 'electrical-installation', 'manual-testing'],
  Mechanical: ['mechanical-troubleshooting', 'welding', 'project-management', 'microsoft-excel'],
  Civil: ['project-management', 'microsoft-excel', 'carpentry'],
  Electrical: ['electrical-installation', 'solar-panel-installation', 'microsoft-excel'],
  'Accounting & Finance': ['accounting', 'microsoft-excel', 'tally', 'financial-reporting'],
  Marketing: ['digital-marketing', 'social-media-marketing', 'canva', 'sales'],
  'Human Resources': ['verbal-communication', 'conflict-resolution', 'teamwork'],
  Economics: ['microsoft-excel', 'data-analysis', 'finance-principles'],
  English: ['written-communication', 'verbal-communication', 'public-speaking'],
  Psychology: ['active-listening', 'verbal-communication', 'empathy'],
};

const POPULAR = [
  'verbal-communication',
  'customer-service',
  'microsoft-excel',
  'teamwork',
  'problem-solving',
  'canva',
  'sales',
  'digital-marketing',
  'time-management',
  'data-entry',
  'leadership',
  'digital-literacy',
];

/** "For you": education-based picks, then popular ones. CV skills are already in the deck. */
export function suggestions(branch: string): SkillDef[] {
  const ids = [...(BY_BRANCH[branch] ?? []), ...POPULAR];
  return [...new Set(ids)].map((id) => BY_ID.get(id)).filter((k): k is SkillDef => !!k);
}

export function inCategory(category: SkillCategory): SkillDef[] {
  return SKILLS.filter((k) => k.category === category);
}

/** Skills in one ESCO group (a deck tab), A–Z. */
export function inGroup(group: EscoGroupId): SkillDef[] {
  return SKILLS.filter((k) => k.group === group).sort((a, b) => a.name.localeCompare(b.name));
}

/** Custom skill check (Figma §4): ≤ 40 characters and not on the blocked list. */
const BLOCKED = /\b(sex|porn|drugs?|fuck|shit|bitch|kill)\b/i;
export function customSkillProblem(name: string): string {
  const n = name.trim();
  if (!n) return '';
  if (n.length > CUSTOM_MAX || BLOCKED.test(n))
    return $localize`:@@skill.customBad:Keep custom skills under 40 characters and family-friendly.`;
  return '';
}

export interface PlayerStats {
  /** 0–1 per category, in CATEGORIES order. */
  readonly radar: readonly { id: SkillCategory; label: string; value: number }[];
  readonly classTitle: string;
  readonly strongest: string;
  readonly ready: boolean;
}

/**
 * Player Card logic (Figma §8): radar = Σ levels in category ÷ (3 × 5), capped at 1. Class = top category;
 * two within 10% → All-Rounder. Empty until 3 skills.
 */
export function playerStats(deck: readonly DeckSkill[]): PlayerStats {
  const radar = CATEGORIES.map((c) => ({
    id: c.id,
    label: c.label,
    value: Math.min(
      1,
      deck.filter((k) => k.category === c.id).reduce((sum, k) => sum + k.level, 0) / 15,
    ),
  }));
  const ready = deck.length >= DECK_MIN;
  const sorted = [...radar].sort((a, b) => b.value - a.value);
  const [top, second] = sorted;
  if (!ready || !top || top.value === 0)
    return { radar, classTitle: '', strongest: '', ready: false };
  const tie = !!second && second.value > 0 && top.value - second.value <= 0.1;
  const cat = CATEGORIES.find((c) => c.id === top.id);
  return {
    radar,
    ready,
    classTitle: tie ? ALL_ROUNDER : (cat?.classTitle ?? ''),
    strongest: tie
      ? $localize`:@@player.balanced:Balanced across ${top.label.toLowerCase()}:a: & ${second.label.toLowerCase()}:b:`
      : $localize`:@@player.strongest:${top.label}:cat: is your strongest stat`,
  };
}
