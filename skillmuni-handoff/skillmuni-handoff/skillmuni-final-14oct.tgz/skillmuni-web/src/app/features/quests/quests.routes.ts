import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

export const questRoutes: Routes = [
  {
    path: 'quests/:slug',
    title: $localize`:@@route.quest:Quest · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./quest-page').then((m) => m.QuestPage),
  },
];
