import type { Meta, StoryObj } from '@storybook/angular-vite';
import { applicationConfig } from '@storybook/angular-vite';
import { QuestStore } from '../../../core/quests/quest-store';
import { ToastHost } from '../../../shared/ui/toast/toast-host';
import { QuestPartContext } from '../quest-part';
import { Q3Timeline } from './q3-timeline';

const highest = {
  level: 'graduate',
  status: 'completed',
  degree: 'B.Tech / B.E.',
  branch: 'Computer Science',
  institute: 'RV College of Engineering, Bengaluru',
  year: '2021',
  scoreKind: 'cgpa',
  score: '8.2',
};

const twelfth = {
  id: 'e1',
  level: '12th',
  board: 'CBSE',
  stream: 'Science (PCM)',
  name: '',
  institute: 'Delhi Public School, Bengaluru',
  year: '2017',
  score: '88',
};

/** Figma 200:21058 · States §7. Saves are stubbed; XP toasts and Undo still show. */
const meta: Meta<Q3Timeline> = {
  title: 'Quests/Q3 Timeline',
  component: Q3Timeline,
  decorators: [
    applicationConfig({
      providers: [{ provide: QuestStore, useValue: { saveBonus: () => Promise.resolve('saved') } }],
    }),
  ],
  render: (args) => ({
    props: args,
    moduleMetadata: { imports: [ToastHost] },
    template: `<sm-toast-host /><div style="max-inline-size: 52rem"><sm-q3-timeline [context]="context" /></div>`,
  }),
  parameters: { figma: { node: '200:21058' } },
};
export default meta;
type Story = StoryObj<Q3Timeline & { context: QuestPartContext }>;

export const WithTwelfth: Story = {
  args: { context: { firstName: 'Yash', answers: { ...highest, timeline: [twelfth] } } },
};

export const NothingExtra: Story = {
  args: { context: { firstName: 'Yash', answers: highest } },
};

export const MaxReached: Story = {
  args: {
    context: {
      firstName: 'Yash',
      answers: {
        ...highest,
        timeline: [
          twelfth,
          { ...twelfth, id: 'e2', level: '10th', stream: '' },
          ...['a', 'b', 'c'].map((id) => ({
            ...twelfth,
            id,
            level: 'course',
            name: 'Digital Marketing',
            board: '',
            stream: '',
            score: '',
          })),
        ],
      },
    },
  },
};
