import {
  Component,
  ElementRef,
  OnInit,
  computed,
  forwardRef,
  inject,
  input,
  signal,
} from '@angular/core';
import { Market } from '../../../core/market/market';
import { QuestStore } from '../../../core/quests/quest-store';
import { Banner } from '../../../shared/ui/banner/banner';
import { Button } from '../../../shared/ui/button/button';
import { ChipGroup, ChipOption } from '../../../shared/ui/chip/chip-group';
import { Icon } from '../../../shared/ui/icon/icon';
import { Tag } from '../../../shared/ui/tag/tag';
import { ToastService } from '../../../shared/ui/toast/toast.service';
import { DeckSkill } from '../data/skills';
import {
  Chapter,
  ChapterType,
  GAP_REASONS,
  Gap,
  MAX_CHAPTERS,
  chapterMonths,
  durationLabel,
  findGaps,
  findOverlaps,
  sortChapters,
  totalMonths,
  typeTitle,
} from '../data/work';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { ChapterForm } from './chapter-form';

const SLUG = 'work-lore';
const PART = 3;
const UNDO_MS = 6000;

type Row = { kind: 'chapter'; chapter: Chapter } | { kind: 'gap'; gap: Gap };

/**
 * Q5 · Part 3 — Your lore timeline (Figma 200:31683 imported from CV · tablet 200:32859 · mobile
 * 200:33961 · States §5). Current chapters first, then newest end date. Gap cards for 3+ empty months
 * (reason optional and private), overlaps flagged as info, total experience = union of dates.
 * Edit expands the chapter form in place; delete confirms inline, then Undo. Max 10 chapters.
 */
@Component({
  selector: 'sm-q5-timeline',
  imports: [Banner, Button, ChipGroup, ChapterForm, Icon, Tag],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q5Timeline) }],
  templateUrl: './q5-timeline.html',
  styleUrl: './q5-timeline.scss',
})
export class Q5Timeline implements QuestPart, OnInit {
  private readonly market = inject(Market);
  private readonly store = inject(QuestStore);
  private readonly toast = inject(ToastService);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  private readonly today = new Date();

  readonly context = input.required<QuestPartContext>();

  protected readonly chapters = signal<readonly Chapter[]>([]);
  protected readonly gapReasons = signal<Readonly<Record<string, string>>>({});
  protected readonly deck = signal<readonly DeckSkill[]>([]);
  /** Chapter id being edited, 'new' while adding, '' otherwise. */
  protected readonly editing = signal('');
  protected readonly confirming = signal('');
  protected readonly reasonOptions: ChipOption[] = GAP_REASONS.map((r) => ({
    value: r.value,
    label: r.label,
  }));
  protected readonly max = MAX_CHAPTERS;
  protected readonly editLabel = $localize`:@@q3t.edit:Edit`;
  protected readonly deleteLabel = $localize`:@@q5t.delete:Delete`;

  protected readonly rows = computed<Row[]>(() => {
    const sorted = sortChapters(this.chapters(), this.today);
    const gaps = findGaps(this.chapters(), this.today);
    const rows: Row[] = [];
    for (const g of gaps.filter((x) => x.after === '')) rows.push({ kind: 'gap', gap: g });
    for (const ch of sorted) {
      rows.push({ kind: 'chapter', chapter: ch });
      // A gap sits under the chapter that ended it (the later one), before the earlier chapter.
      for (const g of gaps.filter((x) => x.after === ch.id)) rows.push({ kind: 'gap', gap: g });
    }
    return rows;
  });
  protected readonly experience = computed(() => totalMonths(this.chapters(), this.today));
  protected readonly gapCount = computed(() => findGaps(this.chapters(), this.today).length);
  protected readonly overlaps = computed(() => findOverlaps(this.chapters(), this.today));
  protected readonly full = computed(() => this.chapters().length >= MAX_CHAPTERS);
  protected readonly types = computed<ChapterType[]>(() => {
    const a = this.context().answers;
    const picked = Array.isArray(a['workTypes']) ? (a['workTypes'] as ChapterType[]) : [];
    const starters = Array.isArray(a['starters']) ? (a['starters'] as ChapterType[]) : [];
    const all: ChapterType[] = [
      'full_time',
      'internship',
      'part_time',
      'freelance',
      'family_business',
      'volunteering',
      'apprenticeship',
    ];
    return [...new Set([...picked, ...starters])].length
      ? [...new Set([...picked, ...starters])]
      : all;
  });
  protected readonly fromCv = computed(() => this.chapters().some((c) => c.fromCv));

  /** Nothing to count: reviewing is the job here. */
  readonly total = 0;
  readonly answered = signal(0).asReadonly();
  readonly blocked = computed(() => !!this.editing());
  readonly hint = computed(() =>
    this.editing()
      ? $localize`:@@q3t.hintForm:Save or cancel the entry first`
      : $localize`:@@q5t.last:Last part`,
  );

  async ngOnInit(): Promise<void> {
    const a = this.context().answers;
    this.chapters.set(Array.isArray(a['chapters']) ? (a['chapters'] as Chapter[]) : []);
    const reasons = a['gapReasons'];
    this.gapReasons.set(
      reasons && typeof reasons === 'object' ? (reasons as Record<string, string>) : {},
    );
    this.syncBonus();
    try {
      const q4 = await this.store.loadAnswers('your-flex-era');
      this.deck.set(Array.isArray(q4['skills']) ? (q4['skills'] as DeckSkill[]) : []);
    } catch {
      /* skills stay as ids */
    }
  }

  // ── Display ──────────────────────────────────────────────────────────────

  protected month(value: string): string {
    const [y, m] = value.split('-').map(Number);
    if (!y || !m) return '';
    return new Intl.DateTimeFormat(this.market.config().locale, {
      month: 'short',
      year: 'numeric',
    }).format(new Date(y, m - 1, 1));
  }

  protected dates(ch: Chapter): string {
    const end = ch.current ? $localize`:@@ch.present:Present` : this.month(ch.end);
    return `${this.month(ch.start)} – ${end}`;
  }

  protected duration(ch: Chapter): string {
    return durationLabel(chapterMonths(ch, this.today));
  }

  protected totalLabel(): string {
    return durationLabel(this.experience());
  }

  protected typeLabel(ch: Chapter): string {
    return ch.typeUnsure ? `${typeTitle(ch.type)}?` : typeTitle(ch.type);
  }

  protected modeLabel(ch: Chapter): string {
    switch (ch.mode) {
      case 'onsite':
        return $localize`:@@ch.onsite:On-site`;
      case 'hybrid':
        return $localize`:@@ch.hybrid:Hybrid`;
      case 'remote':
        return $localize`:@@ch.remote:Remote`;
      default:
        return '';
    }
  }

  protected skillName(id: string): string {
    return (
      this.deck().find((k) => k.id === id)?.name ?? id.replace(/^custom-/, '').replace(/-/g, ' ')
    );
  }

  protected gapTitle(g: Gap): string {
    const span = g.end
      ? `${this.month(g.start)} – ${this.month(g.end)}`
      : $localize`:@@q5t.gapNow:${this.month(g.start)}:start: – now`;
    return $localize`:@@q5t.gap:${durationLabel(g.months)}:d: gap · ${span}:span:`;
  }

  protected gapKey(g: Gap): string {
    return g.start;
  }

  protected overlapNote(o: { a: Chapter; b: Chapter; months: number }): string {
    return $localize`:@@q5t.overlap:${o.a.company}:a: and ${o.b.company}:b: overlap by ${durationLabel(o.months)}:d:. That’s allowed, side gigs are real.`;
  }

  // ── Actions ──────────────────────────────────────────────────────────────

  protected add(): void {
    this.confirming.set('');
    this.editing.set('new');
  }

  protected edit(ch: Chapter): void {
    this.confirming.set('');
    this.editing.set(ch.id);
  }

  protected cancel(): void {
    const was = this.editing();
    this.editing.set('');
    this.focusLater(was === 'new' ? '.add' : `[data-chapter="${was}"] .edit`);
  }

  protected saveChapter(ch: Chapter): void {
    const isNew = this.editing() === 'new';
    const saved = { ...ch, id: isNew ? `ch${Date.now().toString(36)}` : this.editing() };
    this.commit(
      isNew
        ? [...this.chapters(), saved]
        : this.chapters().map((c) => (c.id === saved.id ? saved : c)),
    );
    this.editing.set('');
    this.toast.show(
      isNew
        ? $localize`:@@q5t.added:${saved.role}:role: added to your lore`
        : $localize`:@@q5t.saved:Chapter saved`,
    );
    this.focusLater(`[data-chapter="${saved.id}"] .edit`);
  }

  protected askDelete(ch: Chapter): void {
    this.editing.set('');
    this.confirming.set(ch.id);
    this.focusLater(`[data-chapter="${ch.id}"] .keep`);
  }

  protected keep(ch: Chapter): void {
    this.confirming.set('');
    this.focusLater(`[data-chapter="${ch.id}"] .delete`);
  }

  protected remove(ch: Chapter): void {
    const before = this.chapters();
    this.confirming.set('');
    this.commit(before.filter((c) => c.id !== ch.id));
    this.toast.show($localize`:@@q5t.deleted:Chapter deleted`, {
      duration: UNDO_MS,
      action: { label: $localize`:@@q3t.undo:Undo`, run: () => this.commit(before) },
    });
    this.focusLater('.add, .chapter .edit');
  }

  protected setReason(g: Gap, value: string | string[] | null): void {
    const reason = typeof value === 'string' ? value : '';
    this.gapReasons.update((r) => ({ ...r, [this.gapKey(g)]: reason }));
  }

  protected clearReason(g: Gap): void {
    const key = this.gapKey(g);
    this.gapReasons.update((r) => Object.fromEntries(Object.entries(r).filter(([k]) => k !== key)));
  }

  validate(): boolean {
    return !this.editing();
  }

  value() {
    return { chapters: this.chapters(), gapReasons: this.gapReasons() };
  }

  private commit(next: readonly Chapter[]): void {
    this.chapters.set(next);
    this.syncBonus();
  }

  /** Saves straight away (offline-safe). No in-between XP (A-168). */
  private syncBonus(): void {
    void this.store.saveBonus(SLUG, PART, { chapters: this.chapters() }, 0);
  }

  private focusLater(selector: string): void {
    setTimeout(() => this.host.querySelector<HTMLElement>(selector)?.focus());
  }
}
