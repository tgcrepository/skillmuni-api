import {
  Component,
  DestroyRef,
  OnInit,
  computed,
  forwardRef,
  inject,
  input,
  signal,
} from '@angular/core';
import { Router } from '@angular/router';
import { FLEX_API } from '../../../core/flex/flex.api';
import { Market } from '../../../core/market/market';
import { QuestStore } from '../../../core/quests/quest-store';
import { QuestAnswers } from '../../../core/quests/quest.api';
import { Icon } from '../../../shared/ui/icon/icon';
import { Tag } from '../../../shared/ui/tag/tag';
import { ToastService } from '../../../shared/ui/toast/toast.service';
import { LEVELS } from '../data/education';
import { TROPHY_ACCEPT, TROPHY_FILE_MAX, Trophy } from '../data/flex';
import { TimelineEntry } from '../data/education';
import { Chapter, typeTitle } from '../data/work';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { str } from './part-utils';

type ReceiptStatus = 'verified' | 'checking' | 'missing';

interface Receipt {
  readonly key: string;
  readonly title: string;
  /** Quest the claim came from ("Big Brain Stuff"). */
  readonly source: string;
  readonly status: ReceiptStatus;
  readonly detail: string;
  readonly ask: string;
  readonly fileName: string;
}

interface Proof {
  readonly status: 'checking' | 'verified';
  readonly fileName: string;
  readonly at: string;
}

/**
 * Q7 — Drop the Receipts (Figma 200:35090 · tablet 200:35285 · mobile 200:35438). One proof per claim from
 * earlier quests (education, timeline, trophies, work chapters). Verified items count as Verified (1.0)
 * instead of Declared (0.8) in matching. Uploads go to "Checking"; DigiLocker / link-checked trophies are
 * already verified. ID documents only confirm identity and are never shown to employers.
 */
@Component({
  selector: 'sm-q7-receipts',
  imports: [Icon, Tag],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q7Receipts) }],
  templateUrl: './q7-receipts.html',
  styleUrl: './q7-receipts.scss',
})
export class Q7Receipts implements QuestPart, OnInit {
  private readonly api = inject(FLEX_API);
  private readonly market = inject(Market);
  private readonly store = inject(QuestStore);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);
  readonly context = input.required<QuestPartContext>();

  private readonly earlier = signal<Readonly<Record<string, QuestAnswers>>>({});
  protected readonly proofs = signal<Readonly<Record<string, Proof>>>({});
  protected readonly uploading = signal('');
  protected readonly open = signal('');
  protected readonly accept = TROPHY_ACCEPT;
  protected readonly isIndia = computed(() => this.market.code() === 'IN');

  protected readonly receipts = computed<Receipt[]>(() => {
    const e = this.earlier();
    const proofs = this.proofs();
    const list: Omit<Receipt, 'status' | 'detail' | 'fileName'>[] = [];
    const brain = $localize`:@@quest.3.name:Big Brain Stuff`;
    const flex = $localize`:@@quest.4.name:Your Flex Era`;
    const lore = $localize`:@@quest.5.name:Work Lore`;
    const certAsk = $localize`:@@q7.askCert:Upload the certificate or marksheet`;

    const q3 = e['big-brain-stuff'] ?? {};
    const level = LEVELS[this.market.code()].find((l) => l.value === str(q3['level']));
    if (level && level.kind !== 'none') {
      const name = [str(q3['degree']) || level.title, str(q3['board'])].filter(Boolean).join(' · ');
      list.push({
        key: 'edu',
        title: $localize`:@@q7.eduCert:${name}:name: certificate`,
        source: brain,
        ask: certAsk,
      });
    }
    const timeline = Array.isArray(q3['timeline']) ? (q3['timeline'] as TimelineEntry[]) : [];
    for (const t of timeline) {
      const name =
        t.name || LEVELS[this.market.code()].find((l) => l.value === t.level)?.title || t.level;
      list.push({
        key: `tl-${t.id}`,
        title: $localize`:@@q7.marksheet:${name}:name: marksheet`,
        source: brain,
        ask: certAsk,
      });
    }
    const trophies = Array.isArray(e['your-flex-era']?.['trophies'])
      ? (e['your-flex-era']?.['trophies'] as Trophy[])
      : [];
    for (const t of trophies)
      list.push({ key: `tr-${t.id}`, title: t.name, source: flex, ask: certAsk });
    const chapters = Array.isArray(e['work-lore']?.['chapters'])
      ? (e['work-lore']?.['chapters'] as Chapter[])
      : [];
    for (const c of chapters)
      list.push({
        key: `ch-${c.id}`,
        title: `${c.company} ${typeTitle(c.type).toLowerCase()}`,
        source: lore,
        ask: $localize`:@@q7.askWork:Add a letter, payslip or a reference’s work email`,
      });

    const trophyById = new Map(trophies.map((t) => [`tr-${t.id}`, t]));
    const rank: Record<ReceiptStatus, number> = { verified: 0, checking: 1, missing: 2 };
    return list
      .map((r): Receipt => {
        const trophy = trophyById.get(r.key);
        const proof = proofs[r.key];
        if (trophy?.verified)
          return {
            ...r,
            status: 'verified',
            detail:
              trophy.source === 'digilocker'
                ? $localize`:@@q7.viaDigilocker:Verified · imported from DigiLocker`
                : $localize`:@@q7.viaLink:Verified · credential link checked`,
            fileName: trophy.fileName,
          };
        if (proof?.status === 'verified')
          return {
            ...r,
            status: 'verified',
            detail: $localize`:@@q7.checked:Verified · checked against your upload on ${proof.at}:date:`,
            fileName: proof.fileName,
          };
        if (proof?.status === 'checking')
          return {
            ...r,
            status: 'checking',
            detail: $localize`:@@q7.checking:Checking · usually under 48 hours`,
            fileName: proof.fileName,
          };
        return { ...r, status: 'missing', detail: r.ask, fileName: '' };
      })
      .sort((a, b) => rank[a.status] - rank[b.status]);
  });
  protected readonly counts = computed(() => {
    const r = this.receipts();
    return {
      verified: r.filter((x) => x.status === 'verified').length,
      checking: r.filter((x) => x.status === 'checking').length,
      missing: r.filter((x) => x.status === 'missing').length,
    };
  });

  /** All optional: verifying powers up matches but never blocks finishing. */
  /** Corrections #15: uploading at least one proof pays the step XP; the quest bonus comes either way. */
  readonly earnsXp = computed(() => Object.keys(this.proofs()).length > 0);
  readonly xpHint = $localize`:@@q7.proofXpHint:Upload at least one proof to earn +20 XP`;
  readonly total = 0;
  readonly answered = signal(0).asReadonly();
  readonly hint = computed(() => $localize`:@@q7.oneMore:1 more quest`);

  async ngOnInit(): Promise<void> {
    const saved = this.context().answers['receipts'];
    this.proofs.set(saved && typeof saved === 'object' ? (saved as Record<string, Proof>) : {});
    const slugs = ['big-brain-stuff', 'your-flex-era', 'work-lore'];
    const loaded = await Promise.all(slugs.map((s) => this.store.loadAnswers(s).catch(() => ({}))));
    this.earlier.set(Object.fromEntries(slugs.map((s, i) => [s, loaded[i] ?? {}])));
  }

  protected powerUp(r: Receipt): string {
    return $localize`:@@q7.powerUp:Power-up: ${r.title}:item: now counts as Verified in job matches`;
  }

  protected toggle(r: Receipt): void {
    this.open.update((k) => (k === r.key ? '' : r.key));
  }

  protected pick(r: Receipt, event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    if (!/\.(pdf|jpe?g|png)$/i.test(file.name) || file.size > TROPHY_FILE_MAX) {
      this.toast.show($localize`:@@q7.badFile:Use a PDF, JPG or PNG under 5 MB.`, {
        tone: 'error',
      });
      return;
    }
    this.uploading.set(r.key);
    const sub = this.api.upload(file).subscribe({
      next: (e) => {
        if (e.kind !== 'done') return;
        const at = new Intl.DateTimeFormat(this.market.config().locale, {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        }).format(new Date());
        this.proofs.update((p) => ({
          ...p,
          [r.key]: { status: 'checking', fileName: file.name, at },
        }));
        this.uploading.set('');
        this.toast.show($localize`:@@q7.uploaded:${r.title}:item: uploaded. We’ll check it.`);
      },
      error: () => {
        this.uploading.set('');
        this.toast.show($localize`:@@trophy.uploadFail:Upload failed. Try again?`, {
          tone: 'error',
        });
      },
    });
    this.destroyRef.onDestroy(() => sub.unsubscribe());
  }

  /** "Got a newer CV?" → the CV upload, which suggests updates quest by quest. */
  protected newCv(): void {
    void this.router.navigateByUrl('/onboarding/cv');
  }

  validate(): boolean {
    return !this.uploading();
  }

  value() {
    return { receipts: this.proofs() };
  }
}
