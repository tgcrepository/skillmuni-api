import { DIALOG_DATA, DialogRef } from '@angular/cdk/dialog';
import { Component, DestroyRef, ElementRef, computed, inject, signal } from '@angular/core';
import { Subscription } from 'rxjs';
import { FLEX_API } from '../../../core/flex/flex.api';
import { Market } from '../../../core/market/market';
import { Button } from '../../../shared/ui/button/button';
import { ChipGroup, ChipOption } from '../../../shared/ui/chip/chip-group';
import { Field } from '../../../shared/ui/field/field';
import { Icon } from '../../../shared/ui/icon/icon';
import { Input } from '../../../shared/ui/input/input';
import { SmDialog } from '../../../shared/ui/overlay/dialog';
import { guardClose, requestClose } from '../../../shared/ui/overlay/overlay.service';
import { Select, SelectOption } from '../../../shared/ui/select/select';
import { Switch } from '../../../shared/ui/switch/switch';
import { Tag } from '../../../shared/ui/tag/tag';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import {
  ISSUERS,
  TROPHY_ACCEPT,
  TROPHY_FILE_MAX,
  TROPHY_SUGGESTIONS,
  Trophy,
  monthLabel,
} from '../data/flex';
import { DeckSkill, skillById } from '../data/skills';

export interface TrophyDialogData {
  readonly trophy?: Trophy;
  readonly deck: readonly DeckSkill[];
  readonly slotsLeft: number;
}

export interface TrophyDialogResult {
  readonly trophy: Trophy;
  /** Linked skills that weren't in the deck yet (added at level 1 = "Just started"). */
  readonly newSkills: readonly DeckSkill[];
}

type LinkState = 'idle' | 'checking' | 'verified' | 'unverified' | 'failed';
type FileState =
  | { readonly kind: 'none' }
  | { readonly kind: 'uploading'; readonly name: string; readonly percent: number }
  | { readonly kind: 'done'; readonly name: string; readonly size: string }
  | { readonly kind: 'error'; readonly message: string };

const opts = (list: readonly string[]): SelectOption[] => list.map((v) => ({ value: v, label: v }));

/**
 * Q4 · Add a trophy (Figma 200:26340 modal · 200:29110 full screen on mobile · States §7).
 * Needed: certificate name (suggestions auto-fill the issuer) + issuer. Optional: dates, credential link
 * (checked server-side for the learner's name → Verified; never blocks saving), ID, file (PDF/JPG/PNG ≤ 5 MB),
 * and the skills it proves. Closing with changes asks "Discard this trophy?".
 */
@Component({
  selector: 'sm-trophy-dialog',
  imports: [SmDialog, Field, Input, Select, Switch, ChipGroup, Button, Tag, Icon],
  templateUrl: './trophy-dialog.html',
  styleUrl: './trophy-dialog.scss',
})
export class TrophyDialog {
  private readonly data = inject<TrophyDialogData>(DIALOG_DATA);
  private readonly ref = inject<DialogRef<TrophyDialogResult>>(DialogRef);
  private readonly api = inject(FLEX_API);
  private readonly market = inject(Market);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  private readonly now = new Date();
  private uploadSub: Subscription | undefined;

  protected readonly editing = !!this.data.trophy;
  protected readonly title = this.editing
    ? $localize`:@@trophy.editTitle:Edit trophy`
    : $localize`:@@trophy.addTitle:Add a trophy`;
  protected readonly subtitle = $localize`:@@trophy.sub:Only the name and issuer are needed. The rest makes it more legit.`;
  protected readonly needed = $localize`:@@ui.needed:Needed`;
  protected readonly optional = $localize`:@@ui.optional:Optional`;
  protected readonly accept = TROPHY_ACCEPT;
  protected readonly pickedHelp = $localize`:@@trophy.picked:Picked from suggestions`;
  protected readonly noExpiryPh = $localize`:@@trophy.noExpiryPh:Doesn’t expire`;
  protected readonly selectPh = $localize`:@@trophy.monthPh:Pick a month`;
  protected readonly removeFileLabel = $localize`:@@trophy.removeFile:Remove`;
  protected readonly saveLabel = this.editing
    ? $localize`:@@trophy.saveEdit:Save changes`
    : $localize`:@@trophy.save:Put it on the shelf`;
  protected readonly skillsId = uniqueId('trophy-skills');

  protected readonly model = signal({
    name: this.data.trophy?.name ?? '',
    issuer: this.data.trophy?.issuer ?? '',
    issuedOn: this.data.trophy?.issuedOn ?? '',
    expiresOn: this.data.trophy?.expiresOn ?? '',
    noExpiry: this.data.trophy?.noExpiry ?? false,
    credentialUrl: this.data.trophy?.credentialUrl ?? '',
    credentialId: this.data.trophy?.credentialId ?? '',
    skills: [...(this.data.trophy?.linkedSkills ?? [])],
  });
  private readonly initial = JSON.stringify(this.model());
  protected readonly fromSuggestion = signal(false);
  protected readonly issuerAuto = signal(false);
  protected readonly link = signal<LinkState>(this.data.trophy?.verified ? 'verified' : 'idle');
  protected readonly file = signal<FileState>(
    this.data.trophy?.fileName
      ? { kind: 'done', name: this.data.trophy.fileName, size: '' }
      : { kind: 'none' },
  );
  protected readonly attempted = signal(false);
  protected readonly linkHelp = computed(() => {
    switch (this.link()) {
      case 'checking':
        return $localize`:@@trophy.checking:Checking the link…`;
      case 'verified':
        return $localize`:@@trophy.verified:Link checked: your name is on it. Verified tick unlocked.`;
      case 'unverified':
      case 'failed':
        return $localize`:@@trophy.unverified:We couldn’t confirm your name on this page. You can still save it, it just won’t get the verified tick.`;
      default:
        return '';
    }
  });
  protected readonly confirmDiscard = signal(false);

  protected readonly nameOptions = opts(TROPHY_SUGGESTIONS.map((t) => t.name));
  protected readonly issuerOptions = opts(ISSUERS);
  protected readonly issuedOptions = computed(() => this.months(-15 * 12, 0));
  protected readonly expiryOptions = computed(() => this.months(-5 * 12, 10 * 12));

  /** Deck skills first, then ones this certificate usually proves ("+ Tableau"). */
  protected readonly skillOptions = computed<ChipOption[]>(() => {
    const deck = this.data.deck.map((k) => ({ value: k.id, label: k.name }));
    const suggested = TROPHY_SUGGESTIONS.find((t) => t.name === this.model().name)?.skills ?? [];
    const extra = suggested
      .filter((id) => !this.data.deck.some((k) => k.id === id))
      .map((id) => ({ value: id, label: `+ ${skillById(id)?.name ?? id}` }));
    return [...extra, ...deck];
  });
  protected readonly newSkillIds = computed(() =>
    this.model().skills.filter((id) => !this.data.deck.some((k) => k.id === id)),
  );
  protected readonly tooMany = computed(() => this.newSkillIds().length > this.data.slotsLeft);
  protected readonly slotsNote = computed(() =>
    this.data.slotsLeft === 1
      ? $localize`:@@trophy.slots1:Skills not in your deck get added when you save (you have 1 slot left).`
      : $localize`:@@trophy.slotsN:Skills not in your deck get added when you save (you have ${this.data.slotsLeft}:n: slots left).`,
  );

  protected readonly errors = computed(() => {
    const e: Record<string, string> = {};
    if (!this.attempted()) return e;
    const m = this.model();
    if (!m.name.trim()) e['name'] = $localize`:@@trophy.nameNeeded:What’s the certificate called?`;
    if (!m.issuer.trim()) e['issuer'] = $localize`:@@trophy.issuerNeeded:Who gave it to you?`;
    if (m.credentialUrl && !/^https?:\/\/|^[\w-]+(\.[\w-]+)+\//i.test(m.credentialUrl.trim()))
      e['url'] =
        $localize`:@@trophy.urlBad:That doesn’t look like a link. Try coursera.org/verify/…`;
    if (m.issuedOn && m.expiresOn && !m.noExpiry && m.expiresOn < m.issuedOn)
      e['expires'] = $localize`:@@trophy.expiresBefore:It can’t expire before it was issued.`;
    if (this.tooMany())
      e['skills'] =
        $localize`:@@trophy.tooMany:Your deck only has room for ${this.data.slotsLeft}:n: more. Unpick a new one.`;
    if (this.file().kind === 'uploading')
      e['file'] = $localize`:@@trophy.wait:Wait for the upload to finish.`;
    return e;
  });

  constructor() {
    guardClose(this.ref, () => this.allowDismiss());
    inject(DestroyRef).onDestroy(() => this.uploadSub?.unsubscribe());
  }

  protected set(
    key: 'name' | 'issuer' | 'issuedOn' | 'expiresOn' | 'credentialUrl' | 'credentialId',
    value: string | string[] | null,
  ): void {
    const v = typeof value === 'string' ? value : '';
    this.model.update((m) => ({ ...m, [key]: v }));
    if (key === 'name') this.pickName(v);
    if (key === 'issuer') this.issuerAuto.set(false);
    if (key === 'credentialUrl') this.link.set('idle');
  }

  protected setNoExpiry(on: boolean): void {
    this.model.update((m) => ({ ...m, noExpiry: on, expiresOn: on ? '' : m.expiresOn }));
  }

  protected setSkills(value: string | string[] | null): void {
    this.model.update((m) => ({ ...m, skills: Array.isArray(value) ? value : [] }));
  }

  /** Server-side check for the learner's name on the page; a warning at worst, never a blocker. */
  protected checkLink(): void {
    const url = this.model().credentialUrl.trim();
    if (!url || this.link() !== 'idle') return;
    this.link.set('checking');
    this.api.checkLink(url).subscribe({
      next: (r) => this.link.set(r.verified ? 'verified' : 'unverified'),
      error: () => this.link.set('failed'),
    });
  }

  protected pickFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    const picked = input.files?.[0];
    input.value = '';
    if (!picked) return;
    const okType = /\.(pdf|jpe?g|png)$/i.test(picked.name);
    if (!okType || picked.size > TROPHY_FILE_MAX) {
      this.file.set({
        kind: 'error',
        message: $localize`:@@trophy.fileBad:${picked.name}:file: is ${this.mb(picked.size)}:size:. Use a PDF, JPG or PNG under 5 MB.`,
      });
      return;
    }
    this.file.set({ kind: 'uploading', name: picked.name, percent: 0 });
    this.uploadSub?.unsubscribe();
    this.uploadSub = this.api.upload(picked).subscribe({
      next: (e) =>
        this.file.set(
          e.kind === 'progress'
            ? { kind: 'uploading', name: picked.name, percent: e.percent }
            : { kind: 'done', name: picked.name, size: this.mb(picked.size) },
        ),
      error: () =>
        this.file.set({
          kind: 'error',
          message: $localize`:@@trophy.uploadFail:Upload failed. Try again?`,
        }),
    });
  }

  protected removeFile(): void {
    this.uploadSub?.unsubscribe();
    this.file.set({ kind: 'none' });
  }

  protected save(): void {
    this.attempted.set(true);
    if (Object.keys(this.errors()).length) {
      setTimeout(() =>
        this.host
          .querySelector<HTMLElement>(
            '[aria-invalid="true"], .is-invalid input, .is-invalid button',
          )
          ?.focus(),
      );
      return;
    }
    const m = this.model();
    const f = this.file();
    const trophy: Trophy = {
      id: this.data.trophy?.id ?? `t${Date.now().toString(36)}`,
      name: m.name.trim(),
      issuer: m.issuer.trim(),
      issuedOn: m.issuedOn,
      expiresOn: m.noExpiry ? '' : m.expiresOn,
      noExpiry: m.noExpiry,
      credentialUrl: m.credentialUrl.trim(),
      credentialId: m.credentialId.trim(),
      fileName: f.kind === 'done' ? f.name : '',
      verified: this.link() === 'verified' || this.data.trophy?.source === 'digilocker',
      linkedSkills: m.skills,
      source: this.data.trophy?.source ?? 'manual',
    };
    const newSkills: DeckSkill[] = this.newSkillIds().map((id) => {
      const def = skillById(id);
      return {
        id,
        name: def?.name ?? id,
        category: def?.category ?? 'custom',
        level: 1,
        source: 'suggested',
      };
    });
    requestClose(this.ref, { trophy, newSkills });
  }

  protected cancel(): void {
    requestClose(this.ref);
  }

  protected keepEditing(): void {
    this.confirmDiscard.set(false);
    setTimeout(() => this.host.querySelector<HTMLElement>('input')?.focus());
  }

  protected discard(): void {
    guardClose(this.ref, () => true);
    requestClose(this.ref);
  }

  protected monthText(value: string): string {
    return monthLabel(value, this.market.config().locale);
  }

  private allowDismiss(): boolean {
    const dirty = JSON.stringify(this.model()) !== this.initial || this.file().kind === 'done';
    if (!dirty || this.confirmDiscard()) return !dirty;
    this.confirmDiscard.set(true);
    setTimeout(() => this.host.querySelector<HTMLElement>('.discard .keep')?.focus());
    return false;
  }

  private pickName(name: string): void {
    const match = TROPHY_SUGGESTIONS.find((t) => t.name === name);
    this.fromSuggestion.set(!!match);
    if (!match) return;
    this.issuerAuto.set(true);
    this.model.update((m) => ({
      ...m,
      issuer: match.issuer,
      skills: [
        ...new Set([
          ...m.skills,
          ...match.skills.filter((id) => this.data.deck.some((k) => k.id === id)),
        ]),
      ],
    }));
  }

  private months(from: number, to: number): SelectOption[] {
    const out: SelectOption[] = [];
    const y = this.now.getFullYear();
    const mo = this.now.getMonth();
    for (let i = to; i >= from; i--) {
      const d = new Date(y, mo + i, 1);
      const value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      out.push({ value, label: this.monthText(value) });
    }
    return out;
  }

  private mb(bytes: number): string {
    return bytes >= 1024 * 1024
      ? `${(bytes / 1024 / 1024).toFixed(1)} MB`
      : `${Math.ceil(bytes / 1024)} KB`;
  }
}
