/** Q5 Work Lore data and timeline maths (Figma spec 200:29868, States 200:29906). */

export type WorkType =
  | 'full_time'
  | 'internship'
  | 'part_time'
  | 'freelance'
  | 'family_business'
  | 'volunteering'
  | 'apprenticeship';

/** Fresher starter chapters (Figma 200:30862 "Got something like this?"). */
export type StarterType = 'project' | 'club' | 'side_hustle';
export type ChapterType = WorkType | StarterType;
export type WorkMode = 'onsite' | 'hybrid' | 'remote';

export const FRESHER = 'fresher';
export const MAX_CHAPTERS = 10;
export const DESCRIPTION_MAX = 300;
export const DESCRIPTION_WARN = 270;
export const CHAPTER_SKILLS_MAX = 5;
export const NAME_MAX = 60;
export const GAP_MONTHS = 3;
export const FIRST_YEAR = 1980;

export interface Chapter {
  readonly id: string;
  readonly type: ChapterType | '';
  readonly role: string;
  readonly company: string;
  /** YYYY-MM */
  readonly start: string;
  /** YYYY-MM, empty while current. */
  readonly end: string;
  readonly current: boolean;
  readonly mode: WorkMode | '';
  /** Quest 4 deck skill ids (≤ 5). */
  readonly skills: readonly string[];
  readonly description: string;
  readonly fromCv?: boolean;
  /** The CV didn't say which type; the learner should confirm (Figma 200:31683 "Part-time?"). */
  readonly typeUnsure?: boolean;
}

export interface TypeInfo {
  readonly value: ChapterType;
  readonly code: string;
  readonly title: string;
  readonly description: string;
}

export const WORK_TYPES: readonly TypeInfo[] = [
  {
    value: 'full_time',
    code: 'FT',
    title: $localize`:@@work.ft:Full-time job`,
    description: $localize`:@@work.ftd:Salaried, 30+ hrs a week`,
  },
  {
    value: 'internship',
    code: 'IN',
    title: $localize`:@@work.in:Internship`,
    description: $localize`:@@work.ind:Paid or unpaid`,
  },
  {
    value: 'part_time',
    code: 'PT',
    title: $localize`:@@work.pt:Part-time`,
    description: $localize`:@@work.ptd:Weekends, evenings, shifts`,
  },
  {
    value: 'freelance',
    code: 'FL',
    title: $localize`:@@work.fl:Freelance / gigs`,
    description: $localize`:@@work.fld:Clients, delivery, tuition`,
  },
  {
    value: 'family_business',
    code: 'FB',
    title: $localize`:@@work.fb:Family business`,
    description: $localize`:@@work.fbd:Shop, farm, family firm`,
  },
  {
    value: 'volunteering',
    code: 'VO',
    title: $localize`:@@work.vo:Volunteering / NGO`,
    description: $localize`:@@work.vod:Unpaid, for a cause`,
  },
  {
    value: 'apprenticeship',
    code: 'AP',
    title: $localize`:@@work.ap:Apprenticeship`,
    description: $localize`:@@work.apd:Trade or NAPS/NATS`,
  },
];

export const STARTERS: readonly TypeInfo[] = [
  {
    value: 'project',
    code: 'PR',
    title: $localize`:@@work.pr:A college project`,
    description: $localize`:@@work.prd:Final-year project, hackathon, research`,
  },
  {
    value: 'club',
    code: 'CL',
    title: $localize`:@@work.cl:A club or fest role`,
    description: $localize`:@@work.cld:Organiser, lead, volunteer`,
  },
  {
    value: 'side_hustle',
    code: 'TU',
    title: $localize`:@@work.tu:Tuition or a side hustle`,
    description: $localize`:@@work.tud:Home tuition, reselling, content`,
  },
];

export function typeTitle(type: ChapterType | ''): string {
  return [...WORK_TYPES, ...STARTERS].find((t) => t.value === type)?.title ?? '';
}

interface NamedEntry {
  readonly name: string;
  readonly synonyms?: readonly string[];
  readonly meta?: string;
}

const r = (name: string, ...synonyms: string[]): NamedEntry => ({ name, synonyms });

export const ROLES: readonly NamedEntry[] = [
  r('Software Engineer', 'sde', 'developer', 'programmer'),
  r('Data Analyst', 'analytics', 'mis'),
  r('Data Analyst Intern', 'analytics intern'),
  r('Data Analytics Intern'),
  r('Data Annotation Specialist', 'labelling'),
  r('Sales Executive', 'sales rep', 'bde'),
  r('Business Development Executive', 'bde', 'bd'),
  r('Customer Support Executive', 'customer care', 'csr'),
  r('Call Centre Agent', 'call center', 'bpo', 'telecaller'),
  r('Cashier', 'billing'),
  r('Retail Associate', 'store associate', 'sales associate'),
  r('Store Manager'),
  r('Delivery Partner', 'delivery boy', 'rider'),
  r('Graphic Designer', 'designer'),
  r('Freelance Graphic Designer'),
  r('Content Writer', 'copywriter'),
  r('Social Media Manager', 'smm'),
  r('Digital Marketing Intern', 'marketing intern'),
  r('Accountant', 'accounts executive'),
  r('Teacher', 'tutor', 'faculty'),
  r('Home Tutor', 'tuition'),
  r('Electrician'),
  r('Mechanic', 'technician'),
  r('Nurse'),
  r('HR Executive', 'recruiter', 'human resources'),
  r('Operations Executive', 'ops'),
  r('Tea Taster'),
  r('Event Volunteer'),
  r('Shop Assistant', 'helper'),
];

const c = (name: string, meta: string): NamedEntry => ({ name, meta });

export const COMPANIES: readonly NamedEntry[] = [
  c('Swiggy', 'Bengaluru · Food tech'),
  c('Zomato', 'Gurugram · Food tech'),
  c('Infosys', 'Bengaluru · IT services'),
  c('Tata Consultancy Services', 'Mumbai · IT services'),
  c('Wipro', 'Bengaluru · IT services'),
  c('Flipkart', 'Bengaluru · E-commerce'),
  c('Reliance Retail', 'Mumbai · Retail'),
  c('HDFC Bank', 'Mumbai · Banking'),
  c('Teleperformance', 'Johannesburg · BPO'),
  c('Shoprite', 'Cape Town · Retail'),
  c('Pick n Pay', 'Cape Town · Retail'),
  c('Capitec', 'Stellenbosch · Banking'),
  c('Self-employed', 'Freelance'),
];

function norm(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

/** Suggestions from 2 letters; name prefix first, then word starts, then synonyms ("SDE" → Software Engineer). */
export function lookup(list: readonly NamedEntry[], query: string): NamedEntry[] {
  const q = norm(query);
  if (q.length < 2) return [];
  const score = (e: NamedEntry): number => {
    const n = norm(e.name);
    if (n.startsWith(q)) return 3;
    if (n.split(' ').some((w) => w.startsWith(q)) || n.includes(q)) return 2;
    if ((e.synonyms ?? []).some((s) => norm(s).startsWith(q))) return 1;
    return 0;
  };
  return list
    .map((e) => ({ e, s: score(e) }))
    .filter((x) => x.s > 0)
    .sort((a, b) => b.s - a.s || a.e.name.localeCompare(b.e.name))
    .map((x) => x.e);
}

// ── Months ──────────────────────────────────────────────────────────────────

/** "2026-03" → months since year 0 (2026 * 12 + 2). */
export function monthIndex(value: string): number {
  const [y, m] = value.split('-').map(Number);
  return y && m ? y * 12 + (m - 1) : NaN;
}

export function fromIndex(index: number): string {
  const y = Math.floor(index / 12);
  const m = (index % 12) + 1;
  return `${y}-${String(m).padStart(2, '0')}`;
}

export function thisMonth(today: Date): string {
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
}

/** End of a chapter as a month index; current chapters run to this month. */
function endIndex(ch: Chapter, today: Date): number {
  return ch.current ? monthIndex(thisMonth(today)) : monthIndex(ch.end);
}

/** "Under a month" · "7 mos" · "1 yr 4 mos" (Figma §3 duration chip). */
export function durationLabel(months: number): string {
  if (months <= 0) return $localize`:@@work.underMonth:Under a month`;
  const y = Math.floor(months / 12);
  const m = months % 12;
  const yr = y ? (y === 1 ? $localize`:@@work.yr1:1 yr` : $localize`:@@work.yrs:${y}:n: yrs`) : '';
  const mo = m ? (m === 1 ? $localize`:@@work.mo1:1 mo` : $localize`:@@work.mos:${m}:n: mos`) : '';
  return [yr, mo].filter(Boolean).join(' ');
}

export function chapterMonths(ch: Chapter, today: Date): number {
  const s = monthIndex(ch.start);
  const e = endIndex(ch, today);
  // Inclusive months (Jan–Jun = 6); the same month counts as "Under a month".
  if (!Number.isFinite(s) || !Number.isFinite(e) || e <= s) return 0;
  return e - s + 1;
}

/** Union of date ranges, never double-counted (Figma spec "Total experience"). */
export function totalMonths(chapters: readonly Chapter[], today: Date): number {
  const ranges = chapters
    .map((ch) => [monthIndex(ch.start), endIndex(ch, today)] as const)
    .filter(([s, e]) => Number.isFinite(s) && Number.isFinite(e) && e >= s)
    .sort((a, b) => a[0] - b[0]);
  let total = 0;
  let cur: [number, number] | null = null;
  for (const [s, e] of ranges) {
    if (!cur || s > cur[1] + 1) {
      if (cur) total += cur[1] - cur[0] + 1;
      cur = [s, e];
    } else cur[1] = Math.max(cur[1], e);
  }
  if (cur) total += cur[1] - cur[0] + 1;
  return total;
}

/** Current chapters first, then the newest end date (Figma §5). */
export function sortChapters(chapters: readonly Chapter[], today: Date): Chapter[] {
  return [...chapters].sort(
    (a, b) =>
      Number(b.current) - Number(a.current) ||
      endIndex(b, today) - endIndex(a, today) ||
      monthIndex(b.start) - monthIndex(a.start),
  );
}

export interface Gap {
  /** First empty month, YYYY-MM. */
  readonly start: string;
  /** Last empty month, YYYY-MM, or '' when the gap runs to now. */
  readonly end: string;
  readonly months: number;
  /** Chapter id the gap card sits after in the newest-first list (the later chapter), or '' for the top. */
  readonly after: string;
}

/** 3+ empty months between chapters, or since the last one ended (Figma §5). Overlaps are ignored. */
export function findGaps(chapters: readonly Chapter[], today: Date): Gap[] {
  const now = monthIndex(thisMonth(today));
  const byStart = [...chapters]
    .filter((ch) => Number.isFinite(monthIndex(ch.start)))
    .sort((a, b) => monthIndex(a.start) - monthIndex(b.start));
  const gaps: Gap[] = [];
  let coveredTo = -Infinity;
  for (const ch of byStart) {
    const s = monthIndex(ch.start);
    if (Number.isFinite(coveredTo) && s - coveredTo - 1 >= GAP_MONTHS)
      gaps.push({
        start: fromIndex(coveredTo + 1),
        end: fromIndex(s - 1),
        months: s - coveredTo - 1,
        after: ch.id,
      });
    coveredTo = Math.max(coveredTo, endIndex(ch, today));
  }
  if (Number.isFinite(coveredTo) && now - coveredTo >= GAP_MONTHS)
    gaps.push({ start: fromIndex(coveredTo + 1), end: '', months: now - coveredTo, after: '' });
  return gaps;
}

export interface Overlap {
  readonly a: Chapter;
  readonly b: Chapter;
  readonly months: number;
}

/** Overlapping chapters (info only, side gigs are real). */
export function findOverlaps(chapters: readonly Chapter[], today: Date): Overlap[] {
  const out: Overlap[] = [];
  for (let i = 0; i < chapters.length; i++)
    for (let j = i + 1; j < chapters.length; j++) {
      const a = chapters[i];
      const b = chapters[j];
      if (!a || !b) continue;
      const months =
        Math.min(endIndex(a, today), endIndex(b, today)) -
        Math.max(monthIndex(a.start), monthIndex(b.start)) +
        1;
      if (months > 0) out.push({ a, b, months });
    }
  return out;
}

export const GAP_REASONS: readonly { value: string; label: string }[] = [
  { value: 'studying', label: $localize`:@@gap.studying:Studying` },
  { value: 'travelling', label: $localize`:@@gap.travelling:Travelling` },
  { value: 'job_hunting', label: $localize`:@@gap.hunting:Job hunting` },
  { value: 'family', label: $localize`:@@gap.family:Family or health` },
  { value: 'private', label: $localize`:@@gap.private:Prefer not to say` },
];

export const DESCRIPTION_PROMPTS: readonly { label: string; starter: string }[] = [
  { label: $localize`:@@work.p1:What did you own?`, starter: $localize`:@@work.p1s:I owned ` },
  { label: $localize`:@@work.p2:A number you moved`, starter: $localize`:@@work.p2s:I moved ` },
  {
    label: $localize`:@@work.p3:A tool you got good at`,
    starter: $localize`:@@work.p3s:I got good at `,
  },
  { label: $localize`:@@work.p4:Something you fixed`, starter: $localize`:@@work.p4s:I fixed ` },
];
