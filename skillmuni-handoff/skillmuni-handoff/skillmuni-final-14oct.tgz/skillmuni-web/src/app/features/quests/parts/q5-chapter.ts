import {
  Component,
  DestroyRef,
  Injector,
  afterNextRender,
  OnInit,
  computed,
  effect,
  forwardRef,
  inject,
  input,
  signal,
  untracked,
  viewChildren,
} from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { QuestStore } from '../../../core/quests/quest-store';
import { Banner } from '../../../shared/ui/banner/banner';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { Pill } from '../../../shared/ui/pill/pill';
import { TabItem, Tabs } from '../../../shared/ui/tabs/tabs';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import { DeckSkill } from '../data/skills';
import { Chapter, ChapterType, STARTERS, typeTitle } from '../data/work';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { ChapterForm } from './chapter-form';
import { LeaveChapter, LeaveChapterData, LeaveChapterResult } from './leave-chapter';

const SLUG = 'work-lore';
/** Chapters is Part 2 of Work Lore. */
const PART = 2;
const AUTOSAVE_MS = 1500;
const MINUTE = 60_000;

/**
 * Q5 · Part 2 — Chapters (Figma 200:31127 · 200:31391 · mobile 200:33652 / 200:33749).
 * A-246: one chapter per kind of work picked in Part 1. With two or more kinds, each gets its own tab
 * and its own form (all kept alive, so switching never loses typing); a tick marks the ready ones.
 * The quest card's primary saves them all ("Save chapters") and opens the timeline; a tab that fails
 * validation is brought forward. Kinds already covered by a chapter (from the CV, or coming back) are
 * optional. Drafts autosave per kind.
 */
@Component({
  selector: 'sm-q5-chapter',
  imports: [ChapterForm, Banner, Pill, Tabs],
  host: { '(window:beforeunload)': 'onUnload($event)' },
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q5Chapter) }],
  template: `
    @if (existing().length) {
      <sm-banner tone="info" i18n="@@q5.haveChapters"
        >You already have {{ existing().length }} in your lore. Add another here, or go to the
        timeline to check them.</sm-banner
      >
    }
    @if (multi()) {
      <p class="intro" i18n="@@q5.tabsIntro">
        You picked {{ kinds().length }} kinds of work, so each gets its own chapter. Fill one, then
        hop to the next tab.
      </p>
      <sm-tabs
        [tabs]="tabItems()"
        [value]="active()"
        (valueChange)="active.set($event)"
        [controls]="panelId + '-' + active()"
        i18n-ariaLabel="@@q5.tabsLabel"
        ariaLabel="Your chapters, one per kind of work"
      />
    }
    @if (savedLabel(); as saved) {
      <sm-pill class="saved" tone="success" size="s" role="status">{{ saved }}</sm-pill>
    }
    @if (ready()) {
      @for (k of formKinds(); track k) {
        <div
          class="panel"
          [id]="multi() ? panelId + '-' + k : null"
          [attr.role]="multi() ? 'tabpanel' : null"
          [attr.aria-label]="multi() ? tabTitle(k) : null"
          [hidden]="multi() && active() !== k"
        >
          @if (covered(k)) {
            <p class="covered" i18n="@@q5.covered">
              You already have a {{ tabTitle(k) }} chapter. Add another one here if you like.
            </p>
          }
          <sm-chapter-form embedded [chapter]="draftFor(k)" [types]="typesFor(k)" [deck]="deck()" />
        </div>
      }
    }
  `,
  styles: `
    :host {
      display: grid;
      grid-template-columns: minmax(0, 1fr);
      gap: var(--sm-space-500);
    }

    .intro,
    .covered {
      margin: 0;
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }

    .panel {
      display: grid;
      gap: var(--sm-space-400);
    }

    .panel[hidden] {
      display: none;
    }

    .saved {
      justify-self: start;
    }
  `,
})
export class Q5Chapter implements QuestPart, OnInit {
  private readonly store = inject(QuestStore);
  private readonly overlay = inject(OverlayService);
  private readonly formList = viewChildren(ChapterForm);
  private readonly injector = inject(Injector);
  readonly context = input.required<QuestPartContext>();

  protected readonly panelId = uniqueId('q5-chapter-panel');
  protected readonly deck = signal<readonly DeckSkill[]>([]);
  protected readonly ready = signal(false);
  protected readonly existing = computed<readonly Chapter[]>(() => {
    const saved = this.context().answers['chapters'];
    return Array.isArray(saved) ? (saved as Chapter[]) : [];
  });
  protected readonly types = computed<ChapterType[]>(() => {
    const a = this.context().answers;
    if (a['fresher'] === true) {
      const starters = Array.isArray(a['starters']) ? (a['starters'] as ChapterType[]) : [];
      return starters.length ? starters : STARTERS.map((s) => s.value);
    }
    return Array.isArray(a['workTypes']) ? (a['workTypes'] as ChapterType[]) : [];
  });

  /** Kinds that get a tab: Part 1 picks (freshers: only the starters they ticked). */
  protected readonly kinds = computed<ChapterType[]>(() => {
    const a = this.context().answers;
    if (a['fresher'] === true && !(Array.isArray(a['starters']) && a['starters'].length)) return [];
    return [...new Set(this.types())];
  });
  protected readonly multi = computed(() => this.kinds().length > 1);
  /** One form per kind, or a single form choosing among all of them. */
  protected readonly formKinds = computed<string[]>(() => (this.multi() ? this.kinds() : ['']));
  protected readonly active = signal('');

  /** Half-filled chapters saved by autosave / Save & exit (Figma §6: nothing typed is lost). */
  private readonly drafts = computed<Readonly<Record<string, Chapter>>>(() => {
    const a = this.context().answers;
    const many = a['chapterDrafts'];
    if (many && typeof many === 'object') return many as Record<string, Chapter>;
    const one = a['chapterDraft'];
    if (one && typeof one === 'object') {
      const c = one as Chapter;
      return { [this.multi() ? c.type : '']: c };
    }
    return {};
  });
  protected draftFor(kind: string): Chapter | null {
    return this.drafts()[kind] ?? null;
  }

  /** A tab's form offers just its own kind; the single form offers every pick. */
  protected typesFor(kind: string): ChapterType[] {
    return this.multi() ? [kind as ChapterType] : this.types();
  }

  protected covered(kind: string): boolean {
    return !!kind && this.existing().some((c) => c.type === kind);
  }

  protected tabTitle(kind: string): string {
    return typeTitle(kind as ChapterType);
  }

  private form(kind: string): ChapterForm | undefined {
    return this.formList()[this.formKinds().indexOf(kind)];
  }

  /** A form must be saved when it's been touched, or its kind has no chapter yet. */
  private required(kind: string): boolean {
    const f = this.form(kind);
    return !!f?.dirty() || !this.covered(kind);
  }

  protected readonly tabItems = computed<TabItem[]>(() =>
    this.kinds().map((k) => {
      const f = this.form(k);
      const done = (f?.filled() ?? 0) >= 4 || (this.covered(k) && !f?.dirty());
      return { value: k, label: done ? `✓ ${typeTitle(k)}` : typeTitle(k) };
    }),
  );

  private committed = false;

  // ── Autosave (Figma States §6 "Draft saved · just now") ──
  private readonly savedAt = signal<number | null>(null);
  private readonly now = signal(Date.now());
  protected readonly savedLabel = computed(() => {
    const at = this.savedAt();
    if (at === null) return '';
    const mins = Math.floor((this.now() - at) / MINUTE);
    return mins < 1
      ? $localize`:@@q5.savedNow:Draft saved · just now`
      : $localize`:@@q5.savedAgo:Draft saved · ${mins}:n: min ago`;
  });

  private dirtyDrafts(): Record<string, Chapter> | null {
    const out: Record<string, Chapter> = {};
    this.formKinds().forEach((k, i) => {
      const f = this.formList()[i];
      if (f?.dirty()) out[k] = f.value();
    });
    return Object.keys(out).length ? out : null;
  }

  constructor() {
    let timer: ReturnType<typeof setTimeout> | undefined;
    effect(() => {
      const forms = this.formList();
      const snaps = forms.map((f) => f.snapshot());
      if (!forms.length || !snaps.length || !forms.some((f) => f.dirty()) || this.committed) return;
      clearTimeout(timer);
      timer = setTimeout(
        () =>
          untracked(async () => {
            const drafts = this.dirtyDrafts();
            if (this.committed || !drafts) return;
            try {
              await this.store.savePart(
                SLUG,
                PART,
                { chapterDrafts: drafts, chapterDraft: null },
                false,
              );
              this.savedAt.set(Date.now());
            } catch {
              /* the leave prompt and Save & exit still keep it */
            }
          }),
        AUTOSAVE_MS,
      );
    });
    // The first kind still to fill opens first.
    effect(() => {
      const kinds = this.kinds();
      if (!kinds.length || kinds.includes(this.active() as ChapterType)) return;
      untracked(() => this.active.set(kinds.find((k) => !this.covered(k)) ?? kinds[0] ?? ''));
    });
    const tick = setInterval(() => this.now.set(Date.now()), MINUTE / 2);
    inject(DestroyRef).onDestroy(() => {
      clearTimeout(timer);
      clearInterval(tick);
    });
  }

  private get unsaved(): boolean {
    return !this.committed && !this.skip() && this.formList().some((f) => f.dirty());
  }

  async confirmLeave(): Promise<'save' | 'discard' | 'stay' | null> {
    if (!this.unsaved) return null;
    const filled = this.formList()
      .filter((f) => f.dirty())
      .reduce((n, f) => n + f.touchedFields(), 0);
    const ref = this.overlay.adaptive<LeaveChapter, LeaveChapterData, LeaveChapterResult>(
      LeaveChapter,
      { data: { filled }, size: 'sm' },
    );
    return (await firstValueFrom(ref.closed)) ?? 'stay';
  }

  discardValue() {
    return { chapterDraft: null, chapterDrafts: null };
  }

  /** Closing the tab: the browser's own "Leave site?" prompt (drafts are also autosaved). */
  protected onUnload(event: BeforeUnloadEvent): void {
    if (this.unsaved) event.preventDefault();
  }

  /** Every kind already has a chapter and nothing new was typed: straight to the timeline. */
  private readonly skip = computed(
    () =>
      this.existing().length > 0 &&
      this.formKinds().every((k) => !this.form(k)?.dirty() && (!k || this.covered(k))),
  );

  private readonly requiredKinds = computed(() => this.formKinds().filter((k) => this.required(k)));

  readonly total = 4;
  readonly answered = computed(() => {
    if (!this.multi()) return this.formList()[0]?.filled() ?? 0;
    return this.form(this.active())?.filled() ?? 0;
  });
  readonly hint = computed(() => {
    if (this.skip()) return $localize`:@@q5.toTimeline:Check your timeline next`;
    if (this.multi()) {
      const req = this.requiredKinds();
      const done = req.filter((k) => (this.form(k)?.filled() ?? 0) >= 4).length;
      return done === req.length
        ? $localize`:@@q5.allReady:All chapters ready to save`
        : $localize`:@@q5.chaptersReady:${done}:done: of ${req.length}:total: chapters ready`;
    }
    const left = 4 - this.answered();
    return left <= 0 ? $localize`:@@q5.ready:Ready to save` : '';
  });
  readonly primaryLabel = computed(() =>
    this.skip()
      ? ''
      : this.multi()
        ? $localize`:@@ch.saveAll:Save chapters`
        : $localize`:@@ch.save:Save chapter`,
  );
  readonly heading = computed(() => {
    const kinds = this.formKinds();
    const at = this.multi() ? Math.max(0, kinds.indexOf(this.active())) : 0;
    const f = this.formList()[at];
    return {
      pre: $localize`:@@q5.chapterN:Chapter ${this.existing().length + at + 1}:n:: `,
      em: f?.role() || $localize`:@@q5.newChapter:what was it?`,
    };
  });

  async ngOnInit(): Promise<void> {
    try {
      const q4 = await this.store.loadAnswers('your-flex-era');
      this.deck.set(Array.isArray(q4['skills']) ? (q4['skills'] as DeckSkill[]) : []);
    } catch {
      /* skills are optional */
    }
    this.ready.set(true);
  }

  validate(): boolean {
    if (this.skip()) return true;
    let firstBad = '';
    for (const k of this.requiredKinds()) {
      const ok = this.form(k)?.validate() ?? false;
      if (!ok && !firstBad) firstBad = k;
    }
    if (firstBad && this.multi()) {
      this.active.set(firstBad);
      afterNextRender(() => this.form(firstBad)?.focusSummary(), { injector: this.injector });
    }
    this.committed = !firstBad;
    return this.committed;
  }

  /** After a passing validate() the chapters join the lore; otherwise they're kept as drafts. */
  value() {
    if (this.skip() || !this.formList().length)
      return { chapters: this.existing(), chapterDraft: null, chapterDrafts: null };
    if (this.committed) {
      const added = this.requiredKinds()
        .map((k) => this.form(k)?.value())
        .filter((c): c is Chapter => !!c);
      return { chapters: [...this.existing(), ...added], chapterDraft: null, chapterDrafts: null };
    }
    return { chapters: this.existing(), chapterDraft: null, chapterDrafts: this.dirtyDrafts() };
  }
}
