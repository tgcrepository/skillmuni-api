/** Message to show under a field: only after it was touched or a Next was attempted. */
export function shownError(
  state: { touched(): boolean; errors(): readonly { message?: string }[] },
  attempted: boolean,
): string {
  return state.touched() || attempted ? (state.errors()[0]?.message ?? '') : '';
}

export function isFilled(value: unknown): boolean {
  if (Array.isArray(value)) return value.length > 0;
  return value !== null && value !== undefined && String(value).trim() !== '';
}

export function str(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

/** The learner's home language name from Quest 1, whichever way they answered it (A-243). */
export function homeLanguageOf(a: Record<string, unknown>): string {
  const h = str(a['homeLanguage']);
  if (h === 'lang-other') return str(a['homeLanguageOther']);
  if (h === 'lang-self-describe') return str(a['homeLanguageText']).trim();
  return h;
}
