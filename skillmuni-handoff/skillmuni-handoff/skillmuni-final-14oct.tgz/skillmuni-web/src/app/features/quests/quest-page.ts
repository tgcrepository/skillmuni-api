import {
  Component,
  DestroyRef,
  OnInit,
  computed,
  effect,
  inject,
  input,
  signal,
  untracked,
  viewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../../core/auth/auth';
import { QUESTS, QuestDef, questXp } from '../../core/quests/quest-catalog';
import { QuestStore, nextRankName } from '../../core/quests/quest-store';
import { STEP_XP, levelFor } from '../../core/quests/levels';
import { XpFx } from '../../shared/ui/xp-fx/xp-fx';
import { DOCUMENT } from '@angular/common';
import { BackNav } from '../../core/layout/back-nav';
import { Viewport } from '../../core/layout/viewport';
import { QuestAnswers } from '../../core/quests/quest.api';
import { Session } from '../../core/session/session';
import { QuestShell } from '../../shared/shell/quest-shell';
import { delayed } from '../../shared/util/delayed';
import { Button } from '../../shared/ui/button/button';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { QuestCard } from '../../shared/ui/quest/quest-card';
import {
  QuestComplete,
  QuestCompleteData,
  QuestCompleteResult,
} from '../../shared/ui/quest/quest-complete';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { ToastService } from '../../shared/ui/toast/toast.service';

import { Q1Id } from './parts/q1-id';
import { Q1Name } from './parts/q1-name';
import { Q1Tea } from './parts/q1-tea';
import { Q2Backup } from './parts/q2-backup';
import { Q2Digits } from './parts/q2-digits';
import { Q2Spot } from './parts/q2-spot';
import { Q3Details } from './parts/q3-details';
import { Q3Level } from './parts/q3-level';
import { Q3Timeline } from './parts/q3-timeline';
import { Q4Deck } from './parts/q4-deck';
import { Q4Passport } from './parts/q4-passport';
import { Q4Trophies } from './parts/q4-trophies';
import { Q5Chapter } from './parts/q5-chapter';
import { Q5Timeline } from './parts/q5-timeline';
import { Q5Types } from './parts/q5-types';
import { Q6Arc } from './parts/q6-arc';
import { Q7Receipts } from './parts/q7-receipts';
import { Q8Vibe } from './parts/q8-vibe';
import { MATCHES_API, VisibilitySettings } from '../../core/matches/matches.api';
import { firstValueFrom } from 'rxjs';
import { DeckSkill, SIGNATURES, playerStats } from './data/skills';
import { PlayerCard, PlayerCardData } from './player-card/player-card';
import {
  PlayerCardReveal,
  PlayerCardRevealData,
  PlayerCardRevealResult,
} from './player-card/player-card-reveal';
import { QUEST_SCREENS, QuestScreenDef } from './quest-defs';
import { QUEST_PART, QuestPartContext } from './quest-part';
import { FeedbackPrompt } from '../../core/feedback/feedback-prompt';

/**
 * One quest, part by part, inside the Quest shell (Figma Q1–Q8 frames). Owns the card chrome — eyebrow,
 * title, stepper, counter, footer — and the flow: save each part (offline-safe), +XP toast, completion
 * modal, Save & exit (200:44079), locked quests. Parts own their questions (QUEST_PART).
 */
/** Quiet time after the last keystroke before a draft is saved (A-241). */
const AUTOSAVE_MS = 1000;

/** Screen names for "Save & back to …" (A-252). */
const RETURN_NAMES: Readonly<Record<string, string>> = {
  '/job-profile': $localize`:@@ret.jobProfile:Job Profile`,
  '/profile': $localize`:@@ret.profile:Profile`,
  '/jobs': $localize`:@@ret.jobs:My Jobs`,
  '/hire-fest': $localize`:@@ret.fest:Hire Fest`,
  '/launchpad': $localize`:@@ret.launchpad:Career Launchpad`,
  '/home': $localize`:@@ret.home:the Lobby`,
};

@Component({
  selector: 'sm-quest-page',
  imports: [
    QuestShell,
    QuestCard,
    Skeleton,
    StateBlock,
    Button,
    Q1Name,
    Q1Id,
    Q1Tea,
    Q2Digits,
    Q2Backup,
    Q2Spot,
    Q3Level,
    Q3Details,
    Q3Timeline,
    Q4Deck,
    Q4Passport,
    Q4Trophies,
    Q5Types,
    Q5Chapter,
    Q5Timeline,
    Q6Arc,
    Q7Receipts,
    Q8Vibe,
    PlayerCard,
  ],
  templateUrl: './quest-page.html',
  styleUrl: './quest-page.scss',
})
export class QuestPage implements OnInit {
  private readonly router = inject(Router);
  private readonly feedback = inject(FeedbackPrompt);
  private readonly viewport = inject(Viewport);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly auth = inject(Auth);
  private readonly session = inject(Session);
  protected readonly store = inject(QuestStore);
  private readonly matches = inject(MATCHES_API);
  private readonly partRef = viewChild(QUEST_PART);

  /** Route param and `?part=` (1-based), bound by the router. */
  readonly slug = input.required<string>();
  readonly part = input<string | undefined>(undefined);
  /** Query param: where to go when the learner finishes or leaves (e.g. back to an institute claim, V3). */
  readonly returnTo = input<string | undefined>(undefined);
  /**
   * `?edit=1` (A-286): one section opened from Job Profile / Profile to change it. Opens that part
   * directly (even if the quest isn't the learner's current one), already filled in, with Save and
   * Cancel back to where they came from. No autosave and no XP: nothing changes until Save.
   */
  readonly edit = input<string | undefined>(undefined);
  protected readonly editing = computed(() => this.edit() === '1');
  protected readonly saveLabel = $localize`:@@quest.editSave:Save changes`;
  protected readonly goBackLabel = $localize`:@@questCard.back:Go back`;
  protected readonly cancelLabel = $localize`:@@quest.editCancel:Cancel`;
  protected readonly editEyebrow = computed(() => {
    const q = this.quest();
    const def = this.partDef();
    return q && def ? $localize`:@@quest.editEyebrow:Editing · ${q.name}:quest: · ${def.label}:part:` : '';
  });
  protected readonly editMuni = $localize`:@@quest.editMuni:Change what you need, then hit Save. Your profile and CV update straight away.`;
  /**
   * Where Back / Save return to when the quest was opened to edit something (A-252): an explicit
   * `?returnTo=` (institute claim), or the platform screen the learner came from (Profile, Job
   * Profile, My Jobs…). Null during first-time registration.
   */
  private readonly backNav = inject(BackNav);
  private readonly xpFx = inject(XpFx);
  private readonly doc = inject(DOCUMENT);
  private readonly cameFrom = this.backNav.previousPath(
    (inject(Router).getCurrentNavigation()?.finalUrl?.toString() ?? '').split(/[?#]/)[0] ||
      undefined,
  );
  protected readonly exitUrl = computed(() => {
    const url = this.returnTo();
    if (url && /^\/claim\/[\w-]+$/.test(url)) return url;
    const from = this.cameFrom;
    return from &&
      !/^\/(quests|start|welcome-back|onboarding|login|signup|programme|matches)\b/.test(from)
      ? from
      : null;
  });
  private readonly isClaim = computed(() => !!this.exitUrl()?.startsWith('/claim/'));
  /** "Save & back to Job Profile" in the header when editing from the platform. */
  protected readonly exitLabel = computed(() => {
    const url = this.exitUrl();
    if (!url || this.isClaim()) return '';
    const name = Object.entries(RETURN_NAMES).find(([p]) => url.startsWith(p))?.[1];
    return name
      ? $localize`:@@quest.saveBackTo:Save & back to ${name}:screen:`
      : $localize`:@@quest.saveBack:Save & go back`;
  });

  protected readonly loading = signal(true);
  protected readonly failed = signal(false);
  protected readonly busy = signal(false);
  protected readonly showSkeleton = delayed(this.loading);
  protected readonly answers = signal<QuestAnswers>({});
  protected readonly nextLabel = $localize`:@@questCard.next:Next part`;
  protected readonly lockLabel = $localize`:@@quest.lockIt:Lock it in`;
  protected readonly skipLabel = $localize`:@@quest.skip:Skip for now`;
  protected readonly skippedLabel = $localize`:@@quest.skipped:Skipped`;

  protected readonly quest = computed<QuestDef | null>(
    () => QUESTS.find((q) => q.slug === this.slug()) ?? null,
  );
  protected readonly screen = computed<QuestScreenDef | null>(
    () => QUEST_SCREENS[this.slug()] ?? null,
  );
  protected readonly partIndex = computed(() => {
    const parts = this.screen()?.parts.length ?? 1;
    const asked = Number(this.part());
    return Number.isInteger(asked) && asked >= 1 && asked <= parts ? asked - 1 : 0;
  });
  protected readonly partDef = computed(() => this.screen()?.parts[this.partIndex()] ?? null);
  /** Last part, or a part whose live answers end the quest early (`endsQuest`). */
  protected readonly isLast = computed(() => {
    if (this.partIndex() === (this.screen()?.parts.length ?? 1) - 1) return true;
    const ends = this.partDef()?.endsQuest;
    return !!ends?.({ ...this.answers(), ...(this.partRef()?.value() ?? {}) });
  });
  protected readonly firstName = computed(
    () =>
      str(this.answers()['nickname']) ||
      str(this.answers()['firstName']) ||
      this.auth.user()?.firstName ||
      '',
  );
  protected readonly context = computed<QuestPartContext>(() => ({
    answers: this.answers(),
    firstName: this.firstName(),
  }));
  protected readonly title = computed(
    () =>
      this.partRef()?.heading?.() ??
      this.partDef()?.title(this.firstName(), this.answers()) ??
      null,
  );
  protected readonly primaryLabel = computed(() => {
    const own = this.partRef()?.primaryLabel?.();
    if (own) return own;
    return this.isLast() ? (this.partDef()?.finishLabel ?? this.lockLabel) : this.nextLabel;
  });
  protected readonly subtitle = computed(() => {
    const sub = this.partDef()?.subtitle;
    return typeof sub === 'function' ? sub(this.answers()) : (sub ?? '');
  });

  /** Saved answers plus what the open part holds right now (drives the live Player Card). */
  protected readonly liveAnswers = computed<QuestAnswers>(() => ({
    ...this.answers(),
    ...(this.partRef()?.value() ?? {}),
  }));
  protected readonly playerCard = computed<PlayerCardData>(() => {
    const a = this.liveAnswers();
    const deck = Array.isArray(a['skills']) ? (a['skills'] as DeckSkill[]) : [];
    const q1 = this.store.answers('who-dis');
    const name =
      [str(q1['firstName']) || this.firstName(), str(q1['lastName'])].filter(Boolean).join(' ') ||
      this.firstName();
    return {
      name,
      stats: playerStats(deck),
      signatures: deck.filter((k) => k.level).slice(0, SIGNATURES),
      skills: deck.length,
      languages: Array.isArray(a['languages']) ? a['languages'].length : 0,
      trophies: Array.isArray(a['trophies']) ? a['trophies'].length : 0,
    };
  });

  protected readonly answered = computed(() => this.partRef()?.answered() ?? 0);
  protected readonly total = computed(() => this.partRef()?.total ?? 0);
  /** Single-part quests (Q6–Q8, Figma v2) have no stepper. */
  protected readonly steps = computed(() =>
    (this.screen()?.parts.length === 1 ? [] : (this.screen()?.parts ?? [])).map((p, i) => ({
      label: p.label,
      short: p.short,
      answered: i < this.partIndex() ? 1 : i === this.partIndex() ? this.answered() : 0,
      total: i === this.partIndex() ? this.total() : 1,
      // A-168: XP only for finishing the whole quest, so parts carry no XP label.
      xp: this.answers()[`${p.key}Skipped`] ? this.skippedLabel : undefined,
    })),
  );
  protected readonly eyebrow = computed(() => {
    const q = this.quest();
    const parts = this.screen()?.parts.length ?? 1;
    if (!q) return '';
    return parts === 1
      ? $localize`:@@quest.eyebrowSingle:Quest ${q.id}:n: of ${QUESTS.length}:total: · ${q.name}:name:`
      : $localize`:@@quest.eyebrow:Quest ${q.id}:n: of ${QUESTS.length}:total: · ${q.name}:name: · Part ${this.partIndex() + 1}:part: of ${parts}:parts:`;
  });
  protected readonly xpPromise = computed(() => {
    const promise = this.screen()?.promise;
    return promise && this.partIndex() === 0
      ? promise
      : $localize`:@@quest.xpPromiseSteps:+${STEP_XP}:step: XP a step · +${this.quest()?.xp ?? 0}:xp: when you’re done`;
  });
  /** What the primary pays right now: +20 for a new step, +20 +50 on the last one (A-249). */
  protected readonly primaryXp = computed(() => {
    const q = this.quest();
    const p = this.store.progress();
    if (!q || !p || q.id !== p.completed + 1) return '';
    const earns = this.partRef()?.earnsXp?.() ?? true;
    const step = this.partIndex() + 1 > p.partsDone && earns ? STEP_XP : 0;
    const total = step + (this.isLast() ? q.xp : 0);
    return total ? `+${total} XP` : '';
  });
  protected readonly blocked = computed(() => this.partRef()?.blocked?.() ?? false);
  protected readonly counter = computed(() => {
    // Corrections #8/#9/#11/#15: say how to earn the step XP when the part doesn't pay yet.
    const part = this.partRef();
    const p = this.store.progress();
    const q = this.quest();
    const unpaid =
      !!q && !!p && q.id === p.completed + 1 && this.partIndex() + 1 > p.partsDone && !this.editing();
    if (unpaid && part?.earnsXp && !part.earnsXp() && part.xpHint) return part.xpHint;
    const hint = part?.hint?.();
    if (hint) return hint;
    const left = this.total() - this.answered();
    return left <= 0
      ? $localize`:@@quest.allSet:All set, lock it in`
      : $localize`:@@quest.left:${left}:n: more to go`;
  });
  protected readonly loot = computed(() => {
    const q = this.quest();
    const next = q ? this.store.nextQuest(q.id) : null;
    const parts = this.screen()?.parts.length ?? 1;
    const within = this.total() ? this.answered() / this.total() : 0;
    const own = this.screen()?.loot;
    if (own)
      return {
        badge: own.badge,
        reward: own.reward,
        rewardShort: own.reward,
        progress: Math.round(((this.partIndex() + within) / parts) * 100),
      };
    return {
      badge: q?.badge ?? '',
      reward: next
        ? $localize`:@@loot.rewardNext:+${q?.xp}:xp: XP, and the ${next.name}:next: quest unlocks`
        : $localize`:@@loot.rewardLast:+${q?.xp}:xp: XP and your Skillmuni profile`,
      rewardShort: next
        ? $localize`:@@loot.rewardShort:+${q?.xp}:xp: XP · unlocks ${next.short}:next:`
        : $localize`:@@loot.rewardShortLast:+${q?.xp}:xp: XP`,
      progress: Math.round(((this.partIndex() + within) / parts) * 100),
    };
  });
  protected readonly shellProgress = computed(() => ({
    completed: this.store.progress()?.completed ?? 0,
    partsDone: this.partIndex(),
  }));

  /* ---------- Autosave (A-241) ---------- */

  /** Shown in the header: "Saving…" → "Progress saved", so learners know they can leave anytime. */
  protected readonly saveState = signal<'idle' | 'saving' | 'saved'>('idle');
  private lastSaved = '';
  private lastPart: unknown = null;
  private saveTimer: ReturnType<typeof setTimeout> | undefined;

  /** Save the current part as a draft (not done) when it changed since the last save. */
  private async autosave(): Promise<void> {
    clearTimeout(this.saveTimer);
    const part = this.partRef();
    const q = this.quest();
    if (!part || !q || this.loading() || this.editing()) return;
    const values = part.value();
    const snap = JSON.stringify(values);
    if (snap === this.lastSaved) return;
    this.lastSaved = snap;
    this.saveState.set('saving');
    await this.store.savePart(q.slug, this.partIndex() + 1, values, false);
    this.saveState.set('saved');
  }

  constructor() {
    effect(() => {
      const name = this.quest()?.name;
      if (name) untracked(() => this.session.resumeLabel.set(name));
    });
    // Every change is kept ~1 s after the learner pauses; leaving the tab saves at once.
    effect(() => {
      const part = this.partRef();
      if (!part) return;
      const snap = JSON.stringify(part.value());
      untracked(() => {
        if (part !== this.lastPart) {
          this.lastPart = part; // a part just rendered with its saved answers: nothing new yet
          this.lastSaved = snap;
          return;
        }
        if (snap === this.lastSaved) return;
        clearTimeout(this.saveTimer);
        this.saveTimer = setTimeout(() => void this.autosave(), AUTOSAVE_MS);
      });
    });
    const flush = () => {
      if (document.visibilityState === 'hidden') void this.autosave();
    };
    document.addEventListener('visibilitychange', flush);
    window.addEventListener('pagehide', flush);
    inject(DestroyRef).onDestroy(() => {
      clearTimeout(this.saveTimer);
      document.removeEventListener('visibilitychange', flush);
      window.removeEventListener('pagehide', flush);
    });
  }

  async ngOnInit(): Promise<void> {
    await this.load();
  }

  protected async load(): Promise<void> {
    const q = this.quest();
    if (!q) {
      await this.router.navigateByUrl('/welcome-back');
      return;
    }
    this.loading.set(true);
    this.failed.set(false);
    try {
      if (!this.store.progress()) await this.store.load();
      if (!this.store.isOpen(q) && !this.editing()) {
        const open = QUESTS.find((x) => x.id === (this.store.progress()?.completed ?? 0) + 1);
        this.toast.show(
          $localize`:@@quest.locked:Finish ${open?.name}:quest: first to unlock ${q.name}:locked:.`,
        );
        await this.router.navigate(['/quests', open?.slug ?? QUESTS[0]?.slug ?? 'who-dis'], {
          replaceUrl: true,
        });
        return;
      }
      this.answers.set(await this.store.loadAnswers(q.slug));
      if (
        !this.editing() &&
        this.part() === undefined &&
        q.id === (this.store.progress()?.completed ?? 0) + 1
      ) {
        const resumeAt = Math.min(
          this.store.progress()?.partsDone ?? 0,
          (this.screen()?.parts.length ?? 1) - 1,
        );
        if (resumeAt > 0) await this.goToPart(resumeAt, true);
      }
    } catch {
      this.failed.set(true);
    } finally {
      this.loading.set(false);
    }
  }

  protected async next(): Promise<void> {
    if (this.editing()) return this.saveEdit();
    const part = this.partRef();
    const q = this.quest();
    const def = this.partDef();
    if (!part || !q || !def || this.busy()) return;
    if (!part.validate()) return;
    // Where the learner pressed: the +20 burst starts here and flies into the XP HUD (A-263).
    const origin = this.doc.activeElement;
    this.busy.set(true);
    try {
      const values = { ...part.value(), [`${def.key}Skipped`]: false };
      this.answers.update((a) => ({ ...a, ...values }));
      const before = this.store.progress()?.xp ?? 0;
      let paid = false;
      try {
        // Optional parts pay their step XP only when something was added (corrections #8–#15).
        const earns = part.earnsXp?.() ?? true;
        await this.store.savePart(q.slug, this.partIndex() + 1, values, true, earns);
        const gained = (this.store.progress()?.xp ?? 0) - before;
        paid = gained > 0;
        // The toast says it in words; the burst is the feel of it.
        if (paid) this.xpFx.burst(gained, origin, { announce: false });
      } catch {
        this.toast.show(
          $localize`:@@quest.saveFail:Couldn’t save this part. Your answers are still here, try again.`,
          { tone: 'error' },
        );
        return;
      }
      if (!this.isLast()) {
        this.toast.show(
          paid
            ? $localize`:@@quest.partDoneXp:+${STEP_XP}:xp: XP · ${def.label}:part: locked in`
            : $localize`:@@quest.partDone:${def.label}:part: locked in`,
        );
        await this.goToPart(this.partIndex() + 1);
      } else {
        await this.finish(q);
      }
    } finally {
      this.busy.set(false);
    }
  }

  /** A-286: save just this section and go back to the screen it was opened from. */
  private async saveEdit(): Promise<void> {
    const part = this.partRef();
    const q = this.quest();
    const def = this.partDef();
    if (!part || !q || !def || this.busy()) return;
    if (!part.validate()) return;
    this.busy.set(true);
    try {
      const values = { ...part.value(), [`${def.key}Skipped`]: false };
      await this.store.savePart(q.slug, this.partIndex() + 1, values, true, false);
      this.toast.show($localize`:@@quest.editSaved:${def.label}:part: saved. Your profile is up to date.`, {
        tone: 'success',
      });
      await this.backTo(this.exitUrl() ?? '/job-profile');
    } catch {
      this.toast.show(
        $localize`:@@quest.saveFail:Couldn’t save this part. Your answers are still here, try again.`,
        { tone: 'error' },
      );
    } finally {
      this.busy.set(false);
    }
  }

  protected cancelEdit(): void {
    void this.backTo(this.exitUrl() ?? '/job-profile');
  }

  /** Optional part: move on without answers or XP (Figma Q2 part 2 "Skip for now"). */
  protected async skip(): Promise<void> {
    const q = this.quest();
    const def = this.partDef();
    if (!q || !def || this.busy()) return;
    this.busy.set(true);
    try {
      const values = { [`${def.key}Skipped`]: true };
      this.answers.update((a) => ({ ...a, ...values }));
      await this.store.savePart(q.slug, this.partIndex() + 1, values, true, false);
      this.toast.show($localize`:@@quest.skippedToast:Skipped. Add it anytime from your profile.`);
      if (this.isLast()) await this.finish(q);
      else await this.goToPart(this.partIndex() + 1);
    } finally {
      this.busy.set(false);
    }
  }

  /** Asks the part first when it holds unsaved work (Q5 chapter: Save draft / Ditch it). */
  private async canLeave(): Promise<boolean> {
    const part = this.partRef();
    const q = this.quest();
    const choice = (await part?.confirmLeave?.()) ?? null;
    if (choice === null) return true;
    if (choice === 'stay') return false;
    if (part && q) {
      const values = choice === 'save' ? part.value() : (part.discardValue?.() ?? {});
      this.answers.update((a) => ({ ...a, ...values }));
      await this.store.savePart(q.slug, this.partIndex() + 1, values, false);
    }
    return true;
  }

  /** Stepper: jump back to a finished part (asks first if this part has unsaved work). */
  protected async jumpTo(index: number): Promise<void> {
    if (index >= this.partIndex() || !(await this.canLeave())) return;
    this.keepDraft();
    await this.goToPart(index);
  }

  /** Going back keeps what's typed in this part, so coming forward again doesn't lose it. */
  private keepDraft(): void {
    const part = this.partRef();
    const q = this.quest();
    if (!part || !q || part.confirmLeave) return;
    const values = part.value();
    this.answers.update((a) => ({ ...a, ...values }));
    void this.store.savePart(q.slug, this.partIndex() + 1, values, false);
  }

  protected async back(): Promise<void> {
    if (!(await this.canLeave())) return;
    if (this.partIndex() > 0) {
      this.keepDraft();
      await this.goToPart(this.partIndex() - 1);
      return;
    }
    const exit = this.exitUrl();
    if (exit) {
      await this.router.navigateByUrl(exit);
      return;
    }
    // A-293: part 1 steps back into the last part of the previous quest, not out to the intro.
    const q = this.quest();
    const prev = q ? QUESTS.find((x) => x.id === q.id - 1) : undefined;
    if (prev) {
      this.keepDraft();
      await this.router.navigate(['/quests', prev.slug], { queryParams: { part: prev.parts } });
    } else await this.router.navigateByUrl('/welcome-back');
  }

  /**
   * Return to the platform screen the quest was opened from by popping history (A-260), so that
   * screen's own Back then goes where it did before (Job Profile → Launchpad, not → the quest).
   */
  private backTo(url: string): Promise<void> {
    this.backNav.up(url);
    return Promise.resolve();
  }

  /** Figma 200:44079: autosave (no confirmation) → R1 → "Progress saved. Pick up anytime." */
  protected async saveAndExit(): Promise<void> {
    const part = this.partRef();
    const q = this.quest();
    // Wait for the save: signing out next must not race the answers to the server.
    if (part && q) {
      try {
        await this.store.savePart(q.slug, this.partIndex() + 1, part.value(), false);
      } catch {
        /* kept in the offline queue */
      }
    }
    const back = this.exitUrl();
    if (back) {
      await this.backTo(back);
      return;
    }
    // A-252: during registration, Save & exit signs the learner out; logging back in resumes here.
    try {
      await firstValueFrom(this.auth.logout());
    } catch {
      /* signed out locally either way */
    }
    this.toast.show(
      $localize`:@@quest.savedLoggedOut:Progress saved. Log in anytime to pick up where you left off.`,
    );
    await this.router.navigateByUrl('/login');
  }

  protected async openQuest(id: number): Promise<void> {
    const q = QUESTS.find((x) => x.id === id);
    if (!q || !this.store.isOpen(q) || !(await this.canLeave())) return;
    await this.router.navigate(['/quests', q.slug]);
  }

  protected async goToPart(index: number, replace = false): Promise<void> {
    await this.router.navigate([], {
      queryParams: { part: index + 1 },
      queryParamsHandling: 'merge',
      replaceUrl: replace,
    });
  }

  private async finish(q: QuestDef): Promise<void> {
    this.feedback.moment('quest');
    const before = this.store.progress();
    if (this.screen()?.toMatches) {
      const a = this.answers();
      const settings: VisibilitySettings = {
        discoverable: a['discoverable'] !== false,
        invites: a['invites'] !== false,
      };
      // Double-tap safe: next() holds `busy` until this resolves (Figma SB1 203:11503).
      try {
        await firstValueFrom(this.matches.publish(settings));
      } catch {
        this.toast.show(
          $localize`:@@q8.sendFail:Couldn’t send it. Check your connection and try again.`,
          {
            tone: 'error',
          },
        );
        return;
      }
    }
    const result = await this.store.complete(q.slug);
    // Editing a pre-filled quest from an institute claim (V3): no badge moment, straight back.
    const back = this.exitUrl();
    if (back) {
      this.toast.show(
        this.isClaim()
          ? $localize`:@@quest.savedForClaim:Saved. Tap Looks right when it’s good.`
          : $localize`:@@quest.savedForProfile:Saved. Your profile is up to date.`,
      );
      await this.backTo(back);
      return;
    }
    const next = this.store.nextQuest(q.id);
    if (this.screen()?.playerCard) {
      this.revealCard(q, result.xpEarned, next, before?.xp ?? 0, result.progress);
      return;
    }
    const levelledUp = !!before && result.progress.level > before.level;
    const data: QuestCompleteData = {
      quest: q.id,
      eyebrow: $localize`:@@quest.doneEyebrow:Quest ${q.id}:n: of ${QUESTS.length}:total:: done and dusted`,
      body: $localize`:@@quest.doneBody:${q.badge}:badge: unlocked. Your answers are saved.`,
      xpEarned: result.xpEarned,
      // A level-up shows the new rank and target (Figma Q5 200:31873 "Level 2 · Pathfinder unlocked").
      rank: levelledUp ? result.progress.rank : (before?.rank ?? result.progress.rank),
      level: levelledUp ? result.progress.level : (before?.level ?? result.progress.level),
      xpBefore: before?.xp ?? 0,
      xpTarget: levelledUp ? result.progress.target : (before?.target ?? result.progress.target),
      nextRank: nextRankName(levelledUp ? result.progress.xp : (before?.xp ?? 0)),
      ...(levelledUp
        ? {
            levelUp: $localize`:@@complete.levelUp:Level ${result.progress.level}:n: · ${result.progress.rank}:rank: unlocked`,
          }
        : {}),
      ...(this.screen()?.completeTitle
        ? { title: this.screen()?.completeTitle?.(levelledUp) }
        : {}),
      ...(this.screen()?.reviewLabel ? { reviewLabel: this.screen()?.reviewLabel } : {}),
      // Figma RG (200:41599): registered, then the programme-code bonus quest.
      ...(this.screen()?.toMatches
        ? {
            eyebrow: $localize`:@@rg.eyebrow:All ${QUESTS.length}:n: quests: done and dusted`,
            title: [
              $localize`:@@rg.titleA:Yippee! You’re`,
              $localize`:@@rg.titleB:officially registered!`,
            ] as const,
            body: $localize`:@@rg.body:All ${QUESTS.length}:n: quests cleared, ${this.firstName()}:name:. Your Player Card is live and jobs already match you.`,
            bonus: {
              eyebrow: $localize`:@@rg.bonusEyebrow:Bonus quest · +100 XP`,
              title: $localize`:@@rg.bonusTitle:Got a programme or project code?`,
              meta: $localize`:@@rg.bonusMeta:From your college, NGO or employer`,
              mark: '#',
            },
            reviewLabel: $localize`:@@rg.code2:I have a programme code`,
            primaryLabel: $localize`:@@rg.home:Take me home`,
          }
        : {}),
      ...(next
        ? {
            next: {
              quest: next.id,
              name: next.name,
              meta: $localize`:@@quest.nextMeta:2 mins · +${questXp(next)}:xp: XP`,
            },
          }
        : {}),
    };
    const ref = this.overlay.modal<QuestComplete, QuestCompleteData, QuestCompleteResult>(
      QuestComplete,
      { data, size: 'md' },
    );
    ref.closed.subscribe((choice) => {
      const back = this.exitUrl();
      if (back) {
        void this.backTo(back);
        return;
      }
      if (this.screen()?.toMatches) {
        // Registered (A-158): main path is the homescreen; a programme code is the side door.
        void this.router.navigateByUrl(choice === 'review' ? '/programme' : '/home');
        return;
      }
      if (choice === 'continue' && next) void this.router.navigate(['/quests', next.slug]);
      else if (choice === 'review') void this.goToPart(0);
      else void this.router.navigateByUrl('/welcome-back');
    });
  }

  /** Q4 ends with the Player Card reveal instead of the badge modal (Figma 200:26727). */
  private revealCard(
    q: QuestDef,
    xp: number,
    next: QuestDef | null,
    xpBefore: number,
    after: { level: number; rank: string },
  ): void {
    const levelledUp = levelFor(xpBefore).level < after.level;
    const data: PlayerCardRevealData = {
      eyebrow: $localize`:@@reveal.eyebrow:Quest ${q.id}:n: of ${QUESTS.length}:total: · ${q.name}:name: complete`,
      card: this.playerCard(),
      quest: q.id,
      badge: q.badge,
      xpEarned: xp,
      xpBefore,
      ...(levelledUp
        ? {
            levelUp: $localize`:@@complete.levelUp:Level ${after.level}:n: · ${after.rank}:rank: unlocked`,
          }
        : {}),
      ...(next ? { nextLabel: $localize`:@@reveal.next:Next: ${next.name}:name:` } : {}),
    };
    const ref = this.overlay.modal<PlayerCardReveal, PlayerCardRevealData, PlayerCardRevealResult>(
      PlayerCardReveal,
      { data, size: this.viewport.isDesktop() ? 'lg' : 'md' },
    );
    ref.closed.subscribe((choice) => {
      this.toast.reward($localize`:@@reveal.toast:${q.badge}:badge: unlocked`, `+${xp} XP`);
      const back = this.exitUrl();
      if (back) {
        void this.backTo(back);
        return;
      }
      if (choice === 'continue' && next) void this.router.navigate(['/quests', next.slug]);
      else if (choice === 'edit') void this.goToPart(0);
      else void this.router.navigateByUrl('/welcome-back');
    });
  }
}

function str(v: unknown): string {
  return typeof v === 'string' ? v : '';
}
