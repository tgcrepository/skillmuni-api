import { Component, signal, viewChild } from '@angular/core';
import { DigiLockerFlow } from '../../../shared/identity/digilocker-flow';
import { TestBed } from '@angular/core/testing';
import { Market, birthdayFromSaId } from '../../../core/market/market';
import { ageOn, maskBirthday, parseBirthday } from './birthday';
import { Q1Id } from './q1-id';
import { Q1Name } from './q1-name';
import { Q1Tea } from './q1-tea';

@Component({
  imports: [Q1Name, Q1Id, Q1Tea],
  template: `
    @switch (which()) {
      @case ('name') {
        <sm-q1-name [context]="{ answers: {}, firstName: 'Yash' }" />
      }
      @case ('id') {
        <sm-q1-id [context]="{ answers: {}, firstName: 'Yash' }" />
      }
      @case ('tea') {
        <sm-q1-tea [context]="{ answers: {}, firstName: 'Yash' }" />
      }
    }
  `,
})
class Host {
  readonly which = signal<'name' | 'id' | 'tea'>('name');
  readonly name = viewChild(Q1Name);
  readonly id = viewChild(Q1Id);
  readonly tea = viewChild(Q1Tea);
}

function setup(which: 'name' | 'id' | 'tea') {
  const fixture = TestBed.createComponent(Host);
  fixture.componentInstance.which.set(which);
  fixture.detectChanges();
  return { fixture, host: fixture.componentInstance, el: fixture.nativeElement as HTMLElement };
}

function type(el: HTMLElement, selector: string, value: string) {
  const input = el.querySelector<HTMLInputElement>(selector)!;
  input.value = value;
  input.dispatchEvent(new Event('input'));
}

describe('birthday helpers', () => {
  it('masks, parses and ages', () => {
    expect(maskBirthday('12041998')).toBe('12 / 04 / 1998');
    expect(parseBirthday('31 / 02 / 2000')).toBeNull();
    expect(ageOn(parseBirthday('12 / 04 / 1998')!, new Date(2026, 9, 4))).toBe(28);
    expect(birthdayFromSaId('9804125308087', new Date(2026, 9, 4))?.getFullYear()).toBe(1998);
  });
});

describe('Q1 parts', () => {
  it('Name: first name pre-filled; last name needed', () => {
    const { fixture, host, el } = setup('name');
    expect(el.querySelector<HTMLInputElement>('input[autocomplete="given-name"]')!.value).toBe(
      'Yash',
    );
    expect(host.name()!.validate()).toBe(false);
    fixture.detectChanges();
    expect(el.textContent).toContain('Needed for your records.');
    type(el, 'input[autocomplete="family-name"]', 'Verma');
    expect(host.name()!.validate()).toBe(true);
    expect(host.name()!.answered()).toBe(2);
  });

  it('ID & bday (IN): no ID number field; DigiLocker link fills the verified birthday (A-272)', async () => {
    const flow = TestBed.inject(DigiLockerFlow);
    vi.spyOn(flow, 'link').mockResolvedValue({
      doc: 'aadhaar',
      masked: 'XXXX XXXX 4821',
      last4: '4821',
      birthday: '1998-04-12',
      name: 'Yash Pohare',
      verifiedAt: '2026-10-10T10:00:00Z',
    });
    const { fixture, host, el } = setup('id');
    expect(el.querySelector('input[autocomplete="off"]')).toBeNull();
    expect(host.id()!.validate()).toBe(false);
    fixture.detectChanges();
    expect(el.textContent).toContain('Link your ID with DigiLocker to carry on');
    [...el.querySelectorAll<HTMLButtonElement>('button')]
      .find((b) => b.textContent?.includes('Link with DigiLocker'))!
      .click();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(el.textContent).toContain('XXXX XXXX 4821');
    const v = host.id()!.value();
    expect(v['birthday']).toBe('12 / 04 / 1998');
    expect(v['idLast4']).toBe('4821');
    expect(v['idNumber']).toBe('');
    expect(host.id()!.validate()).toBe(true);
  });

  it('ID & bday (ZA): a valid SA ID fills the birthday', () => {
    TestBed.inject(Market).set('ZA');
    const { fixture, host, el } = setup('id');
    type(el, 'input[autocomplete="off"]', '8001015009087');
    fixture.detectChanges();
    expect(el.textContent).toContain('Auto-filled from your ID');
    expect(host.id()!.value()['birthday']).toBe('01 / 01 / 1980');
  });

  it('The tea: disability "Yes" asks what kind (needed) and keeps details only for Yes', () => {
    const { fixture, host, el } = setup('tea');
    el.querySelector<HTMLInputElement>('input[value="Hindi"]')!.click();
    el.querySelector<HTMLInputElement>('input[value="yes"]')!.click();
    fixture.detectChanges();
    expect(el.textContent).toContain('What kind? Pick all that apply');
    expect(el.textContent).toContain('UDID or disability certificate number');
    expect(host.tea()!.validate()).toBe(false);
    fixture.detectChanges();
    expect(el.textContent).toContain('Pick at least one');
    el.querySelector<HTMLInputElement>('input[value="hearing"]')!.click();
    fixture.detectChanges();
    expect(host.tea()!.validate()).toBe(true);
    expect(host.tea()!.value()['disabilityTypes']).toEqual(['hearing']);
    el.querySelector<HTMLInputElement>('input[value="no"]')!.click();
    fixture.detectChanges();
    expect(host.tea()!.value()['disabilityTypes']).toEqual([]);
  });

  it('The tea: home language needed; race only in ZA', () => {
    const { fixture, host, el } = setup('tea');
    expect(el.textContent).not.toContain('Race');
    expect(host.tea()!.validate()).toBe(false);
    fixture.detectChanges();
    expect(el.textContent).toContain('Pick your home language');
    el.querySelector<HTMLInputElement>('input[value="Hindi"]')!.click();
    fixture.detectChanges();
    expect(host.tea()!.validate()).toBe(true);
  });
});
