import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, ElementRef, computed, inject, signal, viewChild } from '@angular/core';
import { Market } from '../../../core/market/market';
import { Button } from '../../../shared/ui/button/button';
import { SmDialog } from '../../../shared/ui/overlay/dialog';
import { MAX_AGE, MIN_AGE, ageOn } from './birthday';

export interface BirthdayPickerData {
  readonly value: Date | null;
  readonly today: Date;
}

type Stage = 'year' | 'month' | 'day';

/** Fun season tags per month (decorative, aria-hidden). */
const SEASON = ['❄️', '💘', '🌸', '🌼', '☀️', '🌦️', '🌧️', '🌈', '🍂', '🪔', '🍁', '🎄'];
const DECADE = 10;

/**
 * Birthday picker (A-166): year → month → day, three quick taps instead of typing a date.
 * Decade tabs keep the year grid short; Muni reacts with the age as soon as a year is picked; the day grid
 * is a real calendar. Arrow keys move inside each grid; the breadcrumb jumps back a step.
 */
@Component({
  selector: 'sm-birthday-picker',
  imports: [SmDialog, Button],
  templateUrl: './birthday-picker.html',
  styleUrl: './birthday-picker.scss',
})
export class BirthdayPicker {
  private readonly data = inject<BirthdayPickerData>(DIALOG_DATA);
  private readonly market = inject(Market);
  protected readonly dialog = viewChild.required(SmDialog);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;

  private readonly today = this.data.today;
  /** Youngest allowed birth year … oldest. */
  private readonly maxYear = this.today.getFullYear() - MIN_AGE;
  private readonly minYear = this.today.getFullYear() - MAX_AGE;

  protected readonly title = $localize`:@@bday.title:When’s your birthday?`;
  protected readonly year = signal<number | null>(this.data.value?.getFullYear() ?? null);
  protected readonly month = signal<number | null>(this.data.value?.getMonth() ?? null);
  protected readonly day = signal<number | null>(this.data.value?.getDate() ?? null);
  protected readonly stage = signal<Stage>(this.data.value ? 'day' : 'year');

  protected readonly decades = computed(() => {
    const out: number[] = [];
    for (
      let d = Math.floor(this.maxYear / DECADE) * DECADE;
      d >= Math.floor(this.minYear / DECADE) * DECADE;
      d -= DECADE
    )
      out.push(d);
    return out;
  });
  protected readonly decade = signal(
    Math.floor((this.data.value?.getFullYear() ?? this.today.getFullYear() - 22) / DECADE) * DECADE,
  );
  protected readonly years = computed(() =>
    Array.from({ length: DECADE }, (_, i) => this.decade() + i).map((y) => ({
      y,
      disabled: y > this.maxYear || y < this.minYear,
    })),
  );

  private readonly locale = computed(() => this.market.config().locale);
  protected readonly months = computed(() => {
    const fmt = new Intl.DateTimeFormat(this.locale(), { month: 'short' });
    const long = new Intl.DateTimeFormat(this.locale(), { month: 'long' });
    return Array.from({ length: 12 }, (_, m) => {
      const d = new Date(2000, m, 1);
      return { m, short: fmt.format(d), long: long.format(d), season: SEASON[m] ?? '' };
    });
  });
  protected readonly monthShort = computed(() => {
    const m = this.month();
    return m === null ? '' : (this.months()[m]?.short ?? '');
  });
  protected readonly weekdays = computed(() => {
    const fmt = new Intl.DateTimeFormat(this.locale(), { weekday: 'narrow' });
    // Monday-first (both markets).
    return Array.from({ length: 7 }, (_, i) => fmt.format(new Date(2024, 0, 1 + i)));
  });
  protected readonly cells = computed(() => {
    const y = this.year();
    const m = this.month();
    if (y === null || m === null) return [];
    const first = new Date(y, m, 1);
    const offset = (first.getDay() + 6) % 7;
    const count = new Date(y, m + 1, 0).getDate();
    const fmt = new Intl.DateTimeFormat(this.locale(), {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    return [
      ...Array.from({ length: offset }, () => null),
      ...Array.from({ length: count }, (_, i) => {
        const date = new Date(y, m, i + 1);
        return { d: i + 1, label: fmt.format(date), disabled: ageOn(date, this.today) < MIN_AGE };
      }),
    ];
  });

  protected readonly picked = computed(() => {
    const [y, m, d] = [this.year(), this.month(), this.day()];
    return y !== null && m !== null && d !== null ? new Date(y, m, d) : null;
  });
  protected readonly muni = computed(() => {
    const date = this.picked();
    if (date) {
      const age = ageOn(date, this.today);
      const birthdayToday =
        date.getDate() === this.today.getDate() && date.getMonth() === this.today.getMonth();
      return birthdayToday
        ? $localize`:@@bday.today:Wait, it’s your birthday today?! Happy ${age}:age:! 🎂`
        : $localize`:@@bday.age:${age}:age: and ready to level up. Love it.`;
    }
    const y = this.year();
    if (y !== null) {
      const turning = this.today.getFullYear() - y;
      return $localize`:@@bday.turning:${y}:year:, so you’re turning ${turning}:age: this year. Now the month?`;
    }
    return $localize`:@@bday.start:Pick your birth year to start. Three taps and done!`;
  });
  protected readonly yearLabel = $localize`:@@bday.year:Year`;
  protected readonly monthLabel = $localize`:@@bday.month:Month`;
  protected readonly dayLabel = $localize`:@@bday.day:Day`;

  protected setDecade(d: number): void {
    this.decade.set(d);
  }

  protected pickYear(y: number): void {
    this.year.set(y);
    this.clampDay();
    this.go(this.month() === null ? 'month' : this.day() === null ? 'day' : 'day');
  }

  protected pickMonth(m: number): void {
    this.month.set(m);
    this.clampDay();
    this.go('day');
  }

  protected pickDay(d: number): void {
    this.day.set(d);
    setTimeout(() => this.host.querySelector<HTMLElement>('.confirm')?.focus());
  }

  protected go(stage: Stage): void {
    this.stage.set(stage);
    setTimeout(() =>
      this.host
        .querySelector<HTMLElement>('.grid [aria-pressed="true"], .grid button:not([disabled])')
        ?.focus(),
    );
  }

  protected confirm(): void {
    const date = this.picked();
    if (date) this.dialog().close(date);
  }

  /** Arrow keys move focus inside the current grid (cols = CSS columns). */
  protected onGridKey(event: KeyboardEvent, cols: number): void {
    const step = { ArrowRight: 1, ArrowLeft: -1, ArrowDown: cols, ArrowUp: -cols }[event.key] ?? 0;
    if (!step) return;
    const buttons = [
      ...(event.currentTarget as HTMLElement).querySelectorAll<HTMLButtonElement>(
        'button:not([disabled])',
      ),
    ];
    const i = buttons.indexOf(event.target as HTMLButtonElement);
    const next = buttons[Math.min(buttons.length - 1, Math.max(0, i + step))];
    if (next) {
      event.preventDefault();
      next.focus();
    }
  }

  private clampDay(): void {
    const [y, m, d] = [this.year(), this.month(), this.day()];
    if (y === null || m === null || d === null) return;
    const last = new Date(y, m + 1, 0).getDate();
    if (d > last) this.day.set(last);
  }
}
