import {
  Component,
  ElementRef,
  OnInit,
  computed,
  forwardRef,
  inject,
  input,
  signal,
} from '@angular/core';
import { OptionCardItem, OptionCards } from '../../../shared/ui/option-card/option-cards';
import { Tag } from '../../../shared/ui/tag/tag';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import { FRESHER, STARTERS, WORK_TYPES } from '../data/work';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';

/**
 * Q5 · Part 1 — Work types (Figma 200:30621 · fresher 200:30862 · States §1). Multi-select type cards;
 * "Not yet, I’m a fresher" is exclusive. Freshers can add an optional starter chapter (college project,
 * club or fest role, tuition / side hustle); with none, the quest finishes here.
 */
@Component({
  selector: 'sm-q5-types',
  imports: [OptionCards, Tag],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q5Types) }],
  template: `
    <section class="q">
      <h2 class="q-title" [id]="ids.types">
        <ng-container i18n="@@q5.pickAll">Pick all that apply</ng-container>
        <sm-tag tone="danger" i18n="@@ui.needed">Needed</sm-tag>
        <span class="q-help" i18n="@@q5.many">You can pick more than one</span>
      </h2>
      <sm-option-cards
        class="types"
        [class.is-fresher]="fresher()"
        [labelledBy]="ids.types"
        [items]="typeItems"
        [value]="picked()"
        (valueChange)="setTypes($event)"
        [invalid]="!!error()"
      />
      @if (error()) {
        <p class="error" role="alert">{{ error() }}</p>
      }
      @if (fresher()) {
        <p class="q-help" i18n="@@q5.fresherNote">
          Picking “Not yet” clears the others. Pick any other type to switch back.
        </p>
      }
      <p class="sm-visually-hidden" aria-live="polite">{{ announce() }}</p>
    </section>

    @if (fresher()) {
      <section class="q">
        <h2 class="q-title" [id]="ids.starters">
          <ng-container i18n="@@q5.gotSomething">Got something like this?</ng-container>
          <sm-tag i18n="@@ui.optional">Optional</sm-tag>
          <span class="q-help" i18n="@@q5.addsChapter">Adds a chapter to your lore</span>
        </h2>
        <sm-option-cards
          class="starters"
          [labelledBy]="ids.starters"
          [items]="starterItems"
          [value]="starters()"
          (valueChange)="starters.set($event)"
        />
      </section>
    }
  `,
  styles: `
    :host {
      display: grid;
      grid-template-columns: minmax(0, 1fr);
      gap: var(--sm-space-600);
    }

    .q {
      display: grid;
      gap: var(--sm-space-300);
    }

    .q-title {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: var(--sm-space-200);
      color: var(--sm-color-text-primary);
      font: var(--sm-font-label);
    }

    .q-help {
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }

    .error {
      color: var(--sm-color-feedback-error-text);
      font: var(--sm-font-caption);
    }

    /* Dimmed by fresher (Figma §1): 40% but still tappable, picking one switches back. */
    .types.is-fresher ::ng-deep .card:not(.is-selected) {
      opacity: 0.4;
    }
  `,
})
export class Q5Types implements QuestPart, OnInit {
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  readonly context = input.required<QuestPartContext>();

  protected readonly ids = { types: uniqueId('q5-types'), starters: uniqueId('q5-starters') };
  protected readonly typeItems: readonly OptionCardItem[] = [
    ...WORK_TYPES.map((t) => ({
      value: t.value,
      code: t.code,
      title: t.title,
      description: t.description,
    })),
    {
      value: FRESHER,
      title: $localize`:@@q5.fresher:Not yet, I’m a fresher`,
      description: $localize`:@@q5.fresherD:Totally fine, skip ahead`,
      optOut: true,
    },
  ];
  protected readonly starterItems: readonly OptionCardItem[] = STARTERS.map((t) => ({
    value: t.value,
    code: t.code,
    title: `+ ${t.title}`,
    description: t.description,
  }));

  protected readonly picked = signal<string[]>([]);
  protected readonly starters = signal<string[]>([]);
  protected readonly announce = signal('');
  private readonly attempted = signal(false);
  protected readonly fresher = computed(() => this.picked().includes(FRESHER));
  protected readonly error = computed(() =>
    this.attempted() && !this.picked().length
      ? $localize`:@@q5.pickOne:Pick at least one type, or “Not yet, I’m a fresher”.`
      : '',
  );

  readonly total = 1;
  readonly answered = computed(() => (this.picked().length ? 1 : 0));
  readonly hint = computed(() => {
    if (this.fresher())
      return this.starters().length ? '' : $localize`:@@q5.nothingElse:Nothing else needed`;
    const n = this.picked().length;
    return n ? $localize`:@@q5.picked:${n}:n: picked` : '';
  });
  readonly heading = computed(() =>
    this.fresher()
      ? { pre: $localize`:@@q5.t1fa:Fresher? Your lore `, em: $localize`:@@q5.t1fb:starts here` }
      : null,
  );

  ngOnInit(): void {
    const a = this.context().answers;
    const types = Array.isArray(a['workTypes']) ? (a['workTypes'] as string[]) : [];
    this.picked.set(a['fresher'] === true ? [FRESHER] : types);
    this.starters.set(Array.isArray(a['starters']) ? (a['starters'] as string[]) : []);
  }

  protected setTypes(next: string[]): void {
    const was = this.fresher();
    this.picked.set(next);
    const now = next.includes(FRESHER);
    if (was && !now) {
      const added = this.typeItems.find((t) => next.includes(t.value))?.title ?? '';
      this.announce.set($localize`:@@q5.switched:Fresher unticked. ${added}:type: added.`);
      this.starters.set([]);
    } else if (!was && now) {
      this.announce.set($localize`:@@q5.fresherOn:Fresher picked. Other types cleared.`);
    }
  }

  validate(): boolean {
    this.attempted.set(true);
    if (!this.picked().length) {
      setTimeout(() => this.host.querySelector<HTMLInputElement>('.types input')?.focus());
      return false;
    }
    return true;
  }

  value() {
    const fresher = this.fresher();
    return {
      fresher,
      workTypes: fresher ? [] : this.picked(),
      starters: fresher ? this.starters() : [],
    };
  }
}
