import { PlayerCardData } from './player-card';

const W = 1080;
const H = 1350;

/** Reads a design token so the image matches the theme (no hard-coded colours). */
function token(name: string): string {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

/**
 * Player Card as a 1080×1350 PNG (Figma spec: shareable image; name + class + signatures only, no contact
 * info). Drawn on a canvas with the theme's tokens.
 */
export async function renderPlayerCard(data: PlayerCardData): Promise<Blob | null> {
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  const font = token('--sm-ref-font-family-poppins') || 'sans-serif';
  const heading = font;

  ctx.fillStyle = token('--sm-color-surface-panel');
  ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = token('--sm-color-border-accent');
  ctx.lineWidth = 8;
  ctx.strokeRect(24, 24, W - 48, H - 48);

  ctx.fillStyle = token('--sm-color-text-brand');
  ctx.font = `700 34px ${font}`;
  ctx.fillText('YOUR PLAYER CARD', 90, 130);
  ctx.fillStyle = token('--sm-color-text-heading');
  ctx.font = `700 72px ${heading}`;
  ctx.fillText(data.name, 90, 230);
  ctx.fillStyle = token('--sm-color-text-brand');
  ctx.font = `700 48px ${heading}`;
  ctx.fillText(data.stats.classTitle, 90, 300);
  ctx.fillStyle = token('--sm-color-text-secondary');
  ctx.font = `400 32px ${font}`;
  ctx.fillText(data.stats.strongest, 90, 350);

  // Radar
  const cx = W / 2;
  const cy = 640;
  const r = 220;
  const n = data.stats.radar.length;
  const at = (i: number, rr: number): [number, number] => {
    const a = (Math.PI * 2 * i) / n - Math.PI / 2;
    return [cx + rr * Math.cos(a), cy + rr * Math.sin(a)];
  };
  ctx.strokeStyle = token('--sm-color-border-subtle');
  ctx.lineWidth = 2;
  for (const scale of [0.33, 0.66, 1]) {
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const [x, y] = at(i, r * scale);
      if (i) ctx.lineTo(x, y);
      else ctx.moveTo(x, y);
    }
    ctx.closePath();
    ctx.stroke();
  }
  ctx.font = `600 30px ${font}`;
  ctx.textAlign = 'center';
  data.stats.radar.forEach((axis, i) => {
    const [x, y] = at(i, r + 50);
    ctx.fillStyle = token('--sm-color-text-secondary');
    ctx.fillText(axis.label, x, y + 10);
  });
  ctx.beginPath();
  data.stats.radar.forEach((axis, i) => {
    const [x, y] = at(i, r * Math.max(axis.value, 0.06));
    if (i) ctx.lineTo(x, y);
    else ctx.moveTo(x, y);
  });
  ctx.closePath();
  ctx.fillStyle = token('--sm-color-decor-cat-tech-tint');
  ctx.fill();
  ctx.strokeStyle = token('--sm-color-decor-cat-tech');
  ctx.lineWidth = 4;
  ctx.stroke();

  // Signature moves
  ctx.textAlign = 'start';
  ctx.fillStyle = token('--sm-color-text-brand');
  ctx.font = `700 30px ${font}`;
  ctx.fillText('SIGNATURE MOVES', 90, 980);
  data.signatures.slice(0, 3).forEach((s, i) => {
    const y = 1040 + i * 80;
    ctx.fillStyle = token('--sm-color-surface-inset-strong');
    ctx.fillRect(90, y - 48, W - 180, 66);
    ctx.fillStyle = token('--sm-color-text-heading');
    ctx.font = `600 36px ${font}`;
    ctx.fillText(`${i + 1}  ${s.name}`, 120, y);
    ctx.fillStyle = token('--sm-color-decor-cat-tech');
    for (let p = 0; p < 3; p++) {
      if (p < s.level) ctx.fillRect(W - 200 + p * 28, y - 10 - p * 10, 18, 18 + p * 10);
    }
  });
  return new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
}

/** Native share sheet with the image when supported, otherwise download it. */
export async function sharePlayerCard(
  data: PlayerCardData,
): Promise<'shared' | 'downloaded' | 'failed'> {
  const blob = await renderPlayerCard(data);
  if (!blob) return 'failed';
  const file = new File([blob], 'skillmuni-player-card.png', { type: 'image/png' });
  const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
  if (nav.share && nav.canShare?.({ files: [file] })) {
    try {
      await nav.share({ files: [file], title: data.stats.classTitle });
      return 'shared';
    } catch {
      /* cancelled → fall through to download */
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = file.name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return 'downloaded';
}
