import { Component, signal, viewChild } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { QuestStore } from '../../../core/quests/quest-store';
import { QuestAnswers } from '../../../core/quests/quest.api';
import { COURSE, TimelineEntry, timelineLevels, EDUCATION } from '../data/education';
import { Q3Details } from './q3-details';
import { Q3Level } from './q3-level';
import { Q3Timeline } from './q3-timeline';

type Which = 'level' | 'details' | 'timeline';

@Component({
  imports: [Q3Level, Q3Details, Q3Timeline],
  template: `
    @switch (which()) {
      @case ('level') {
        <sm-q3-level [context]="{ answers: answers(), firstName: 'Yash' }" />
      }
      @case ('details') {
        <sm-q3-details [context]="{ answers: answers(), firstName: 'Yash' }" />
      }
      @case ('timeline') {
        <sm-q3-timeline [context]="{ answers: answers(), firstName: 'Yash' }" />
      }
    }
  `,
})
class Host {
  readonly which = signal<Which>('level');
  readonly answers = signal<QuestAnswers>({});
  readonly level = viewChild(Q3Level);
  readonly details = viewChild(Q3Details);
  readonly timeline = viewChild(Q3Timeline);
}

const GRADUATE: QuestAnswers = {
  level: 'graduate',
  status: 'completed',
  degree: 'B.Tech / B.E.',
  branch: 'Computer Science',
  institute: 'RV College of Engineering, Bengaluru',
  year: '2021',
  scoreKind: 'cgpa',
  score: '8.2',
};

function setup(which: Which, answers: QuestAnswers = {}) {
  const saveBonus = vi.fn().mockResolvedValue('saved');
  TestBed.configureTestingModule({ providers: [{ provide: QuestStore, useValue: { saveBonus } }] });
  const fixture = TestBed.createComponent(Host);
  fixture.componentInstance.which.set(which);
  fixture.componentInstance.answers.set(answers);
  fixture.detectChanges();
  return {
    fixture,
    host: fixture.componentInstance,
    el: fixture.nativeElement as HTMLElement,
    saveBonus,
  };
}

const entry = (level: string, id = level): TimelineEntry => ({
  id,
  level,
  board: 'CBSE',
  stream: '',
  name: level === COURSE ? 'Digital Marketing' : '',
  institute: 'DPS',
  year: '2017',
  score: '',
});

describe('education timeline helpers', () => {
  it('offers another education, lower school levels and courses (A-244)', () => {
    expect(timelineLevels('IN', 'graduate')).toEqual([EDUCATION, '12th', '10th', COURSE]);
    expect(timelineLevels('IN', '12th')).toEqual([EDUCATION, '10th', COURSE]);
    expect(timelineLevels('IN', '10th')).toEqual([EDUCATION, COURSE]);
    expect(timelineLevels('ZA', 'graduate')).toEqual([EDUCATION, 'matric', 'grade9', COURSE]);
    expect(timelineLevels('IN', 'none')).toEqual([EDUCATION, COURSE]);
  });
});

describe('Q3 parts', () => {
  it('level: needs a pick, then returns level and status', () => {
    const { fixture, host, el } = setup('level');
    const part = host.level();
    expect(part?.validate()).toBe(false);
    fixture.detectChanges();
    expect(el.textContent).toContain('Pick your highest level');
    el.querySelector<HTMLInputElement>('input[value="graduate"]')?.click();
    fixture.detectChanges();
    expect(part?.validate()).toBe(true);
    expect(part?.value()).toEqual({ level: 'graduate', status: 'completed' });
  });

  it('details: flags missing fields and an out-of-range CGPA', () => {
    const { host } = setup('details', { ...GRADUATE, score: '12', institute: '' });
    const part = host.details();
    expect(part?.validate()).toBe(false);
    const errors = (part as unknown as { errors: () => Record<string, string> }).errors();
    expect(errors['institute']).toBeTruthy();
    expect(errors['score']).toBe('CGPA is out of 10');
  });

  it('details: no formal education has nothing to fill', () => {
    const { host } = setup('details', { level: 'none' });
    expect(host.details()?.validate()).toBe(true);
  });

  it('timeline: adds a 12th (no in-between XP, A-168), then removes it', async () => {
    const { fixture, host, el, saveBonus } = setup('timeline', GRADUATE);
    const part = host.timeline();
    expect(el.textContent).toContain('B.Tech / B.E. · Computer Science');
    expect(el.textContent).toContain('Only your highest level is here');
    expect(part?.validate()).toBe(true);

    const add = [...el.querySelectorAll<HTMLButtonElement>('button.add')];
    expect(add.map((b) => b.textContent?.trim())).toEqual([
      'Add education',
      'Add your 12th',
      'Add your 10th',
      'Add a diploma or certificate course',
    ]);
    add[1]?.click();
    fixture.detectChanges();
    expect(part?.validate()).toBe(false);
    expect(part?.blocked?.()).toBe(true);

    const t = part as unknown as {
      set(key: string, value: string): void;
      save(): void;
      remove(e: TimelineEntry): void;
    };
    t.save();
    fixture.detectChanges();
    expect(el.textContent).toContain('Needed to match you right');
    t.set('board', 'CBSE');
    t.set('stream', 'Science (PCM)');
    t.set('institute', 'Delhi Public School');
    t.set('year', '2017');
    t.set('score', '101');
    t.save();
    fixture.detectChanges();
    expect(el.textContent).toContain('Percentages go up to 100.');
    t.set('score', '88');
    t.save();
    fixture.detectChanges();

    expect(el.textContent).toContain('CBSE · Science (PCM)');
    expect(saveBonus).toHaveBeenLastCalledWith('big-brain-stuff', 3, expect.anything(), 0);
    const saved = part?.value()['timeline'] as TimelineEntry[];
    expect(saved).toHaveLength(1);
    expect(el.querySelectorAll('button.add')).toHaveLength(3);

    t.remove(saved[0] as TimelineEntry);
    fixture.detectChanges();
    expect(saveBonus).toHaveBeenLastCalledWith('big-brain-stuff', 3, { timeline: [] }, 0);
    expect(el.textContent).not.toContain('CBSE · Science (PCM)');
  });

  it('timeline: stops at 6 entries including the highest', () => {
    const courses = Array.from({ length: 5 }, (_, i) => entry(COURSE, `c${i}`));
    const { el } = setup('timeline', { ...GRADUATE, timeline: courses });
    expect(el.textContent).toContain('that’s the max');
    expect(el.querySelectorAll('button.add')).toHaveLength(0);
  });
});
