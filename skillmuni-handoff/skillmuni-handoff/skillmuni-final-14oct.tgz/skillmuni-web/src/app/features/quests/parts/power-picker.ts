import { DIALOG_DATA } from '@angular/cdk/dialog';
import {
  Component,
  booleanAttribute,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { PowerMeter } from '../../../shared/ui/hud/power-meter';
import { SmDialog } from '../../../shared/ui/overlay/dialog';
import { Checkbox } from '../../../shared/ui/checkbox/checkbox';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import { LEVEL_INFO, SkillLevel } from '../data/skills';

/**
 * Q4 power-level picker (Figma §2, 200:24911 popover · 200:28488 mobile sheet). Three plain-word levels as a
 * radio group, "Make it a signature move ★", and "Remove from deck" for a skill already in the deck.
 * Keys 1 / 2 / 3 pick; Esc closes (the host handles Esc — the skill stays, level still missing).
 */
@Component({
  selector: 'sm-power-picker',
  imports: [PowerMeter, Checkbox],
  template: `
    <p class="title" [id]="titleId">{{ title() }}</p>
    <div class="levels" role="radiogroup" [attr.aria-labelledby]="titleId">
      @for (l of levels; track l.level) {
        <button
          type="button"
          role="radio"
          class="level"
          [class.is-selected]="level() === l.level"
          [attr.aria-checked]="level() === l.level"
          [attr.aria-keyshortcuts]="'' + l.level"
          (click)="pick.emit(l.level)"
        >
          <sm-power-meter [level]="l.level" />
          <span class="text">
            <span class="name">{{ l.name }}</span>
            <span class="hint">{{ l.hint }}</span>
          </span>
          <kbd class="key" aria-hidden="true">{{ l.level }}</kbd>
        </button>
      }
    </div>
    <sm-checkbox
      class="signature"
      [checked]="signature()"
      [disabled]="!canSign() && !signature()"
      (checkedChange)="toggleSignature.emit($event)"
      i18n="@@skill.makeSignature"
      >Make it a signature move ★</sm-checkbox
    >
    @if (!canSign() && !signature()) {
      <p class="note" i18n="@@skill.signaturesFull">You have 3 signature moves. Unpin one first.</p>
    }
    @if (inDeck()) {
      <button type="button" class="remove" (click)="remove.emit()" i18n="@@skill.removeFromDeck">
        Remove from deck
      </button>
    }
  `,
  styleUrl: './power-picker.scss',
  host: { class: 'sm-power-picker', '(keydown)': 'onKey($event)' },
})
export class PowerPicker {
  readonly skill = input.required<string>();
  readonly level = input<SkillLevel | 0>(0);
  readonly signature = input(false, { transform: booleanAttribute });
  readonly canSign = input(true, { transform: booleanAttribute });
  /** Opened from a card already set up: "Python is in your deck" + Remove. */
  readonly inDeck = input(false, { transform: booleanAttribute });
  readonly pick = output<SkillLevel>();
  readonly toggleSignature = output<boolean>();
  readonly remove = output<void>();

  protected readonly levels = LEVEL_INFO;
  protected readonly titleId = uniqueId('power');
  protected readonly title = computed(() =>
    this.inDeck()
      ? $localize`:@@skill.inDeckTitle:${this.skill()}:skill: is in your deck`
      : $localize`:@@skill.howGood:How good are you at ${this.skill()}:skill:?`,
  );

  protected onKey(event: KeyboardEvent): void {
    const n = Number(event.key);
    if (n === 1 || n === 2 || n === 3) {
      event.preventDefault();
      this.pick.emit(n);
    }
  }
}

/** Data for the mobile bottom sheet; the deck owns the state, the sheet calls back. */
export interface PowerSheetData {
  readonly skill: string;
  readonly level: () => SkillLevel | 0;
  readonly signature: () => boolean;
  readonly canSign: () => boolean;
  readonly inDeck: boolean;
  readonly pick: (level: SkillLevel) => void;
  readonly toggleSignature: (on: boolean) => void;
  readonly remove: () => void;
}

/** Mobile: the same picker in a bottom sheet (Figma 200:28488, 64 px rows). */
@Component({
  selector: 'sm-power-sheet',
  imports: [SmDialog, PowerPicker],
  template: `
    <sm-dialog [title]="data.skill">
      <sm-power-picker
        class="sheet"
        [skill]="data.skill"
        [level]="level()"
        [signature]="signature()"
        [canSign]="data.canSign()"
        [inDeck]="data.inDeck"
        (pick)="choose($event)"
        (toggleSignature)="sign($event)"
        (remove)="data.remove()"
      />
    </sm-dialog>
  `,
})
export class PowerSheet {
  protected readonly data = inject<PowerSheetData>(DIALOG_DATA);
  protected readonly level = signal(this.data.level());
  protected readonly signature = signal(this.data.signature());

  protected choose(level: SkillLevel): void {
    this.level.set(level);
    this.data.pick(level);
  }

  protected sign(on: boolean): void {
    this.signature.set(on);
    this.data.toggleSignature(on);
  }
}
