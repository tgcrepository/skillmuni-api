import { Component, OnInit, computed, forwardRef, inject, input, signal } from '@angular/core';
import { Router } from '@angular/router';
import { MATCHES_API, MatchPreview } from '../../../core/matches/matches.api';
import { Market } from '../../../core/market/market';
import { QuestStore } from '../../../core/quests/quest-store';
import { QuestAnswers } from '../../../core/quests/quest.api';
import { QUESTS } from '../../../core/quests/quest-catalog';
import { Icon } from '../../../shared/ui/icon/icon';
import { Skeleton } from '../../../shared/ui/skeleton/skeleton';
import { Switch } from '../../../shared/ui/switch/switch';
import { LOOKING_FOR, NOTICE } from '../data/arc';
import { LEVELS } from '../data/education';
import { LanguageStamp, Trophy } from '../data/flex';
import { DeckSkill } from '../data/skills';
import { Chapter, durationLabel, totalMonths } from '../data/work';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { str } from './part-utils';

interface ReviewRow {
  readonly slug: string;
  readonly name: string;
  readonly summary: string;
  readonly warning: string;
}

/**
 * Q8 — Vibe Check (Figma 200:35577 · tablet 200:35784 · mobile 200:35949 · sending SB1 203:11503).
 * Review every quest (amber when something is unconfirmed, Edit jumps back), choose who can see you,
 * see the live match count, then "Send it" publishes the profile and opens My Matches.
 */
@Component({
  selector: 'sm-q8-vibe',
  imports: [Icon, Skeleton, Switch],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q8Vibe) }],
  templateUrl: './q8-vibe.html',
  styleUrl: './q8-vibe.scss',
})
export class Q8Vibe implements QuestPart, OnInit {
  private readonly market = inject(Market);
  private readonly store = inject(QuestStore);
  private readonly matches = inject(MATCHES_API);
  private readonly router = inject(Router);
  private readonly today = new Date();
  readonly context = input.required<QuestPartContext>();

  private readonly all = signal<Readonly<Record<string, QuestAnswers>>>({});
  protected readonly loaded = signal(false);
  protected readonly preview = signal<MatchPreview | null>(null);
  protected readonly previewFailed = signal(false);
  protected readonly settings = signal({ discoverable: true, invites: true });
  protected readonly editLabel = $localize`:@@q3t.edit:Edit`;
  protected readonly law = computed(() => (this.market.code() === 'ZA' ? 'POPIA' : 'DPDP Act'));

  protected readonly rows = computed<ReviewRow[]>(() => {
    const a = this.all();
    const get = (slug: string) => a[slug] ?? {};
    const list = <T>(slug: string, key: string) =>
      Array.isArray(get(slug)[key]) ? (get(slug)[key] as T[]) : [];
    const code = this.market.code();
    const q1 = get('who-dis');
    const q2 = get('hit-me-up');
    const q3 = get('big-brain-stuff');
    const level = LEVELS[code].find((l) => l.value === str(q3['level']));
    const deck = list<DeckSkill>('your-flex-era', 'skills');
    const langs = list<LanguageStamp>('your-flex-era', 'languages');
    const trophies = list<Trophy>('your-flex-era', 'trophies');
    const chapters = list<Chapter>('work-lore', 'chapters');
    const q6 = get('pick-your-arc');
    const receipts = (get('drop-the-receipts')['receipts'] ?? {}) as Record<
      string,
      { status: string }
    >;
    const unset = deck.filter((k) => !k.level).length;
    const unsure = chapters.filter((c) => c.typeUnsure).length;
    const looking = (q6['lookingFor'] as string[] | undefined) ?? [];
    const notice = NOTICE[code].find((n) => n.value === q6['notice'])?.label ?? '';
    const verified =
      trophies.filter((t) => t.verified).length +
      Object.values(receipts).filter((r) => r.status === 'verified').length;
    const checking = Object.values(receipts).filter((r) => r.status === 'checking').length;

    const summaries: Record<string, [string, string]> = {
      'who-dis': [[str(q1['firstName']), str(q1['lastName'])].filter(Boolean).join(' '), ''],
      'hit-me-up': [
        [str(q2['phone']), [str(q2['city']), str(q2['postal'])].filter(Boolean).join(' ')]
          .filter(Boolean)
          .join(' · '),
        '',
      ],
      'big-brain-stuff': [
        level?.kind === 'none'
          ? (level?.title ?? '')
          : [str(q3['degree']) || level?.title || '', str(q3['year'])].filter(Boolean).join(' '),
        '',
      ],
      'your-flex-era': [
        $localize`:@@q8.flex:${deck.length}:skills: skills · ${langs.length}:langs: languages`,
        unset ? $localize`:@@q8.unset:${unset}:n: skill level unconfirmed` : '',
      ],
      'work-lore': [
        get('work-lore')['fresher'] === true && !chapters.length
          ? $localize`:@@q8.fresher:Fresher, starting fresh`
          : $localize`:@@q8.lore:${chapters.length}:n: chapters · ${durationLabel(totalMonths(chapters, this.today))}:d:`,
        unsure ? $localize`:@@q8.unsure:${unsure}:n: chapter type to confirm` : '',
      ],
      'pick-your-arc': [
        [
          looking.map((v) => LOOKING_FOR[code].find((o) => o.value === v)?.label ?? v).join(', '),
          notice,
        ]
          .filter(Boolean)
          .join(' · '),
        '',
      ],
      'drop-the-receipts': [
        $localize`:@@q8.receipts:${verified}:v: verified · ${checking}:c: checking`,
        '',
      ],
    };
    return QUESTS.filter((q) => q.slug in summaries).map((q) => ({
      slug: q.slug,
      name: q.name,
      summary: summaries[q.slug]?.[0] || $localize`:@@q8.nothing:Nothing yet`,
      warning: summaries[q.slug]?.[1] ?? '',
    }));
  });
  protected readonly warnings = computed(() => this.rows().filter((r) => r.warning).length);

  readonly total = 0;
  readonly answered = signal(0).asReadonly();
  readonly hint = computed(() =>
    this.warnings()
      ? $localize`:@@q8.fixFirst:${this.warnings()}:n: thing to check, or send as is`
      : '',
  );

  async ngOnInit(): Promise<void> {
    const a = this.context().answers;
    this.settings.set({
      discoverable: a['discoverable'] !== false,
      invites: a['invites'] !== false,
    });
    const slugs = QUESTS.filter((q) => q.id < 8).map((q) => q.slug);
    const loaded = await Promise.all(slugs.map((s) => this.store.loadAnswers(s).catch(() => ({}))));
    this.all.set(Object.fromEntries(slugs.map((s, i) => [s, loaded[i] ?? {}])));
    this.loaded.set(true);
    this.matches.preview().subscribe({
      next: (p) => this.preview.set(p),
      error: () => this.previewFailed.set(true),
    });
  }

  protected set(key: 'discoverable' | 'invites', on: boolean): void {
    this.settings.update((s) => ({ ...s, [key]: on }));
  }

  protected edit(slug: string): void {
    void this.router.navigate(['/quests', slug], { queryParams: { part: 1 } });
  }

  validate(): boolean {
    return true;
  }

  value() {
    return this.settings();
  }
}
