import { Component, booleanAttribute, computed, input } from '@angular/core';
import { PowerMeter } from '../../../shared/ui/hud/power-meter';
import { Tag } from '../../../shared/ui/tag/tag';
import { DeckSkill, PlayerStats } from '../data/skills';

export interface PlayerCardData {
  readonly name: string;
  readonly stats: PlayerStats;
  readonly signatures: readonly DeckSkill[];
  readonly skills: number;
  readonly languages: number;
  readonly trophies: number;
}

const SIZE = 260;
const CENTER = SIZE / 2;
const RADIUS = 78;
const LABEL_RADIUS = 96;

/**
 * Figma: Q4 "Your Player Card" (rail 200:24911, reveal 200:26727, States §8). Name + class title, a skill
 * radar (SVG, with a text equivalent), three signature moves and counts. Empty until 3 skills.
 * `live` shows the "Live" tag in the rail; the reveal uses "New".
 */
@Component({
  selector: 'sm-player-card',
  imports: [PowerMeter, Tag],
  template: `
    <header class="head">
      <p class="eyebrow" i18n="@@player.eyebrow">Your Player Card</p>
      @if (live()) {
        <sm-tag tone="success" i18n="@@player.live">Live</sm-tag>
      } @else {
        <sm-tag tone="success" i18n="@@player.new">New</sm-tag>
      }
    </header>

    <div class="who">
      <span class="avatar" aria-hidden="true">{{ initial() }}</span>
      <div>
        <p class="name">{{ data().name }}</p>
        @if (data().stats.ready) {
          <p class="class">{{ data().stats.classTitle }}</p>
          <p class="strongest">{{ data().stats.strongest }}</p>
        } @else {
          <p class="class class--empty" i18n="@@player.classLocked">Class unlocks at 3 skills</p>
        }
      </div>
    </div>

    <figure class="radar">
      <svg [attr.viewBox]="viewBox" aria-hidden="true" focusable="false">
        @for (ring of rings; track ring) {
          <polygon class="ring" [attr.points]="ringPoints(ring)" />
        }
        @for (axis of axes(); track axis.id) {
          <line
            class="axis"
            [attr.x1]="center"
            [attr.y1]="center"
            [attr.x2]="axis.x"
            [attr.y2]="axis.y"
          />
          <text
            class="axis-label"
            [attr.x]="axis.lx"
            [attr.y]="axis.ly"
            [attr.text-anchor]="axis.anchor"
          >
            {{ axis.label }}
          </text>
        }
        @if (data().stats.ready) {
          <path class="shape" [attr.d]="shape()" />
          @for (p of points(); track p.id) {
            <circle class="point" [attr.cx]="p.x" [attr.cy]="p.y" r="2.5" />
          }
        }
      </svg>
      <figcaption class="sm-visually-hidden">{{ radarText() }}</figcaption>
      @if (!data().stats.ready) {
        <p class="radar-empty" i18n="@@player.radarEmpty">Add skills to shape your radar</p>
      }
    </figure>

    <section class="moves">
      <h3 class="moves-title" i18n="@@player.signatures">Signature moves</h3>
      <ol class="moves-list">
        @for (skill of slots(); track $index) {
          <li class="move" [class.is-empty]="!skill">
            <span class="rank" [class.rank--first]="$index === 0" aria-hidden="true">{{
              $index + 1
            }}</span>
            @if (skill) {
              <span class="move-name">{{ skill.name }}</span>
              <sm-power-meter [level]="skill.level" />
            } @else {
              <span class="move-name move-name--empty" i18n="@@player.emptySlot">Empty slot</span>
            }
          </li>
        }
      </ol>
    </section>

    <dl class="counts">
      <div>
        <dt i18n="@@player.skills">Skills</dt>
        <dd>{{ data().skills }}</dd>
      </div>
      <div>
        <dt i18n="@@player.languages">Languages</dt>
        <dd>{{ data().languages }}</dd>
      </div>
      <div>
        <dt i18n="@@player.trophies">Trophies</dt>
        <dd>{{ data().trophies }}</dd>
      </div>
    </dl>
  `,
  styleUrl: './player-card.scss',
  host: {
    class: 'sm-player-card',
    role: 'group',
    'i18n-aria-label': '@@player.aria',
    'aria-label': 'Your Player Card',
    '[class.is-live]': 'live()',
  },
})
export class PlayerCard {
  readonly data = input.required<PlayerCardData>();
  readonly live = input(false, { transform: booleanAttribute });

  protected readonly viewBox = `0 0 ${SIZE} ${SIZE}`;
  protected readonly center = CENTER;
  protected readonly rings = [0.33, 0.66, 1];

  protected readonly initial = computed(
    () => this.data().name.trim().charAt(0).toUpperCase() || '?',
  );
  protected readonly slots = computed(() =>
    [0, 1, 2].map((i) => this.data().signatures[i] ?? null),
  );

  protected readonly axes = computed(() => {
    const radar = this.data().stats.radar;
    return radar.map((r, i) => {
      const [x, y] = this.at(i, radar.length, RADIUS);
      const [lx, ly] = this.at(i, radar.length, LABEL_RADIUS);
      const anchor = Math.abs(lx - CENTER) < 4 ? 'middle' : lx > CENTER ? 'start' : 'end';
      return { id: r.id, label: r.label, x, y, lx, ly: ly + 3, anchor };
    });
  });

  protected readonly points = computed(() => {
    const radar = this.data().stats.radar;
    return radar.map((r, i) => {
      const [x, y] = this.at(i, radar.length, RADIUS * Math.max(r.value, 0.06));
      return { id: r.id, x, y };
    });
  });

  protected readonly shape = computed(
    () =>
      this.points()
        .map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
        .join(' ') + ' Z',
  );

  /** Text equivalent of the radar (Figma spec: "Tech 95%, Data 80%…"). */
  protected readonly radarText = computed(() =>
    this.data()
      .stats.radar.map((r) => `${r.label} ${Math.round(r.value * 100)}%`)
      .join(', '),
  );

  protected ringPoints(scale: number): string {
    const n = this.data().stats.radar.length;
    return Array.from({ length: n }, (_, i) => this.at(i, n, RADIUS * scale).join(',')).join(' ');
  }

  private at(i: number, n: number, r: number): [number, number] {
    const angle = (Math.PI * 2 * i) / n - Math.PI / 2;
    return [CENTER + r * Math.cos(angle), CENTER + r * Math.sin(angle)];
  }
}
