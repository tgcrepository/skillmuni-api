import {
  Component,
  ElementRef,
  OnInit,
  computed,
  forwardRef,
  inject,
  input,
  signal,
} from '@angular/core';
import { Market } from '../../../core/market/market';
import { QuestStore } from '../../../core/quests/quest-store';
import { Banner } from '../../../shared/ui/banner/banner';
import { Checkbox } from '../../../shared/ui/checkbox/checkbox';
import { ChipGroup, ChipOption } from '../../../shared/ui/chip/chip-group';
import { Icon } from '../../../shared/ui/icon/icon';
import { IconButton } from '../../../shared/ui/icon-button/icon-button';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import { Select, SelectOption } from '../../../shared/ui/select/select';
import { Tag } from '../../../shared/ui/tag/tag';
import { FLUENCIES, Fluency, LanguageStamp, SCRIPTS, stampProblem } from '../data/flex';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { homeLanguageOf } from './part-utils';
import { ESCO_LANGUAGES } from '../data/esco-skills.generated';

const blank = (name: string, extra: Partial<LanguageStamp> = {}): LanguageStamp => ({
  name,
  fluency: '',
  speak: true,
  read: false,
  write: false,
  motherTongue: false,
  fromCv: false,
  ...extra,
});

/**
 * Q4 · Part 2 — Language passport (Figma 200:25862 · tablet 200:27652 · mobile 200:28809 · States §6).
 * Every language is a stamp: fluency (Basic / Conversational / Fluent / Native = CEFR A2/B1/C1/C2) plus at
 * least one of Speak / Read / Write. The Quest 1 home language arrives pre-stamped and can't be removed.
 */
@Component({
  selector: 'sm-q4-passport',
  imports: [Banner, Checkbox, ChipGroup, Icon, IconButton, Select, Tag],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q4Passport) }],
  templateUrl: './q4-passport.html',
  styleUrl: './q4-passport.scss',
})
export class Q4Passport implements QuestPart, OnInit {
  private readonly market = inject(Market);
  private readonly store = inject(QuestStore);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  readonly context = input.required<QuestPartContext>();

  protected readonly stamps = signal<readonly LanguageStamp[]>([]);
  protected readonly adding = signal(false);
  protected readonly duplicate = signal('');
  private readonly attempted = signal(false);
  protected readonly fluencies: readonly ChipOption[] = FLUENCIES.map((f) => ({
    value: f.value,
    label: f.label,
  }));
  protected readonly scripts = SCRIPTS;
  protected readonly removeLabel = $localize`:@@q4p.remove:Remove`;
  protected readonly abilities = [
    { key: 'speak', label: $localize`:@@q4p.speak:Speak` },
    { key: 'read', label: $localize`:@@q4p.read:Read` },
    { key: 'write', label: $localize`:@@q4p.write:Write` },
  ] as const;
  protected readonly ids = { add: uniqueId('q4-add') };

  /**
   * A-285: languages come from the ESCO language group. Anything not on it can still be typed in
   * ("Not listed? Type it in"), so nobody is blocked while the list grows.
   */
  protected readonly options = computed<SelectOption[]>(() =>
    ESCO_LANGUAGES.map((l) => ({ value: l, label: SCRIPTS[l] ? `${l} · ${SCRIPTS[l]}` : l })),
  );
  protected readonly problems = computed(() =>
    this.attempted() ? this.stamps().map(stampProblem) : this.stamps().map(() => ''),
  );

  /** No "N of M" in the stepper: one valid stamp is enough (the hint explains what's missing). */
  readonly total = 0;
  readonly answered = computed(() => (this.stamps().some((s) => !stampProblem(s)) ? 1 : 0));
  readonly hint = computed(() => {
    if (!this.stamps().length) return $localize`:@@q4p.hintEmpty:Add at least one language`;
    const open = this.stamps().find((s) => stampProblem(s) === 'fluency');
    return open ? $localize`:@@q4p.hint:Pick a level for ${open.name}:lang:` : '';
  });

  async ngOnInit(): Promise<void> {
    const saved = this.context().answers['languages'];
    this.stamps.set(Array.isArray(saved) ? (saved as LanguageStamp[]) : []);
    if (this.stamps().some((s) => s.motherTongue)) return;
    // Mother tongue from Quest 1 arrives pre-stamped, first, as Native (Figma §6).
    try {
      const q1 = await this.store.loadAnswers('who-dis');
      const home = homeLanguageOf(q1);
      if (!home) return;
      const mother = blank(home, {
        motherTongue: true,
        fluency: 'native',
        read: true,
        write: true,
      });
      this.stamps.update((list) => {
        const existing = list.find((s) => s.name.toLowerCase() === home.toLowerCase());
        const rest = list.filter((s) => s !== existing);
        return [existing ? { ...existing, motherTongue: true } : mother, ...rest];
      });
    } catch {
      /* the learner adds it themselves */
    }
  }

  protected label(stamp: LanguageStamp): string {
    return this.scripts[stamp.name] ?? stamp.name;
  }

  protected setFluency(index: number, value: string | string[] | null): void {
    if (typeof value !== 'string') return;
    this.patch(index, { fluency: value as Fluency });
  }

  protected setAbility(index: number, key: 'speak' | 'read' | 'write', on: boolean): void {
    this.patch(index, { [key]: on });
  }

  protected startAdd(): void {
    this.adding.set(true);
    this.duplicate.set('');
    setTimeout(() => this.host.querySelector<HTMLElement>('.add-row button')?.focus());
  }

  protected add(name: string | string[] | null): void {
    if (typeof name !== 'string' || !name.trim()) return;
    if (this.stamps().some((s) => s.name.toLowerCase() === name.toLowerCase())) {
      this.duplicate.set(name);
      return;
    }
    this.stamps.update((list) => [...list, blank(name)]);
    this.adding.set(false);
    this.duplicate.set('');
    setTimeout(() =>
      this.host.querySelector<HTMLElement>(`.stamp:last-of-type .sm-chip-group input`)?.focus(),
    );
  }

  protected remove(index: number): void {
    this.stamps.update((list) => list.filter((_, i) => i !== index));
    setTimeout(() => this.host.querySelector<HTMLElement>('.add-lang')?.focus());
  }

  protected editDuplicate(): void {
    const index = this.stamps().findIndex(
      (s) => s.name.toLowerCase() === this.duplicate().toLowerCase(),
    );
    this.adding.set(false);
    this.duplicate.set('');
    setTimeout(() =>
      this.host
        .querySelectorAll<HTMLElement>('.stamp')
        [index]?.querySelector<HTMLElement>('input')
        ?.focus(),
    );
  }

  validate(): boolean {
    this.attempted.set(true);
    const bad = this.stamps().findIndex((s) => !!stampProblem(s));
    if (bad >= 0 || !this.stamps().length) {
      setTimeout(() =>
        (bad >= 0
          ? this.host
              .querySelectorAll<HTMLElement>('.stamp')
              [bad]?.querySelector<HTMLElement>('input')
          : this.host.querySelector<HTMLElement>('.add-lang')
        )?.focus(),
      );
      return false;
    }
    return true;
  }

  value() {
    return { languages: this.stamps() };
  }

  private patch(index: number, change: Partial<LanguageStamp>): void {
    this.stamps.update((list) => list.map((s, i) => (i === index ? { ...s, ...change } : s)));
  }
}
