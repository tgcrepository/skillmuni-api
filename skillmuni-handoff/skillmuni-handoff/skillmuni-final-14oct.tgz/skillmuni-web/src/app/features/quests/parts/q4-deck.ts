import { CdkDrag, CdkDragDrop, CdkDropList, moveItemInArray } from '@angular/cdk/drag-drop';
import { A11yModule } from '@angular/cdk/a11y';
import { CdkConnectedOverlay, ConnectedPosition } from '@angular/cdk/overlay';
import { DOCUMENT } from '@angular/common';
import { rxResource } from '@angular/core/rxjs-interop';
import { ESCO_API, EscoSkillType, escoDisplay } from '../../../core/skills/esco.api';
import {
  Component,
  ElementRef,
  OnInit,
  computed,
  forwardRef,
  inject,
  input,
  signal,
} from '@angular/core';
import { QuestStore } from '../../../core/quests/quest-store';
import { Icon } from '../../../shared/ui/icon/icon';
import { SkillChip } from '../../../shared/ui/hud/skill-chip';
import { PowerMeter } from '../../../shared/ui/hud/power-meter';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { TabItem, Tabs } from '../../../shared/ui/tabs/tabs';
import { ToastService } from '../../../shared/ui/toast/toast.service';
import {
  CATEGORIES,
  CUSTOM_LABEL,
  ESCO_GROUPS,
  DECK_MAX,
  DECK_MIN,
  DeckSkill,
  SIGNATURES,
  SkillDef,
  SkillLevel,
  SkillSource,
  customSkillProblem,
  inGroup,
  nearMatch,
  skillById,
  searchSkills,
  suggestions,
} from '../data/skills';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { PowerPicker, PowerSheet, PowerSheetData } from './power-picker';
import { str } from './part-utils';

const FOR_YOU = 'for-you';
const FIRST = 8;
const STEP = 12;
const UNDO_MS = 6000;
const SEARCH_DEBOUNCE = 200;

/** A card in the grid: a taxonomy skill, or a deck-only one (custom / CV leftovers). */
interface CardItem {
  readonly id: string;
  readonly name: string;
  readonly category: DeckSkill['category'];
  /** ESCO category shown on the card, e.g. "Programming languages" (A-285). */
  readonly escoCategory?: string;
  /** Set for ESCO search results (A-245): the concept URI is the id. */
  readonly escoType?: EscoSkillType;
}

/**
 * Q4 · Part 1 — Skill deck (Figma 200:24639 pre-filled · 200:24911 search + power level · 200:25315 see more
 * + almost full · States §1–§5). Cards are checkboxes; tapping one adds it and opens the power-level
 * picker (popover on tablet / desktop, bottom sheet on mobile). 3–15 skills, each with a level; the first
 * three are signature moves (drag to reorder, or "Make it a signature move" from the keyboard).
 */
@Component({
  selector: 'sm-q4-deck',
  imports: [
    A11yModule,
    CdkConnectedOverlay,
    CdkDrag,
    CdkDropList,
    Icon,
    PowerMeter,
    PowerPicker,
    SkillChip,
    Tabs,
  ],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q4Deck) }],
  templateUrl: './q4-deck.html',
  styleUrl: './q4-deck.scss',
  host: { '(document:keydown)': 'onDocKey($event)' },
})
export class Q4Deck implements QuestPart, OnInit {
  private readonly store = inject(QuestStore);
  private readonly overlays = inject(OverlayService);
  private readonly toast = inject(ToastService);
  protected readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;

  readonly context = input.required<QuestPartContext>();

  protected readonly deck = signal<readonly DeckSkill[]>([]);
  protected readonly tab = signal(FOR_YOU);
  protected readonly shown = signal(FIRST);
  protected readonly query = signal('');
  protected readonly typed = signal('');
  protected readonly notice = signal('');
  private readonly branch = signal('');
  private searchTimer: ReturnType<typeof setTimeout> | undefined;

  /** Desktop / tablet popover target; null when closed. */
  protected readonly picking = signal<{ id: string; origin: HTMLElement; isNew: boolean } | null>(
    null,
  );
  protected readonly positions: ConnectedPosition[] = [
    { originX: 'end', originY: 'top', overlayX: 'start', overlayY: 'top', offsetX: 8 },
    { originX: 'start', originY: 'top', overlayX: 'end', overlayY: 'top', offsetX: -8 },
    { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 8 },
    { originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom', offsetY: -8 },
  ];

  protected readonly ids = {
    deck: uniqueId('q4-deck'),
    grid: uniqueId('q4-grid'),
    search: uniqueId('q4-search'),
  };
  protected readonly max = DECK_MAX;
  protected readonly customLabel = CUSTOM_LABEL;
  protected readonly categoryLabel = (c: DeckSkill['category']): string =>
    c === 'custom' ? CUSTOM_LABEL : (CATEGORIES.find((x) => x.id === c)?.label ?? '');

  protected readonly inDeck = computed(() => new Map(this.deck().map((k) => [k.id, k])));
  protected readonly full = computed(() => this.deck().length >= DECK_MAX);
  protected readonly slotsLeft = computed(() => DECK_MAX - this.deck().length);
  protected readonly signatureCount = computed(() => Math.min(SIGNATURES, this.deck().length));
  protected readonly cvCount = computed(() => this.deck().filter((k) => k.source === 'cv').length);

  protected readonly tabs = computed<readonly TabItem[]>(() => [
    { value: FOR_YOU, label: $localize`:@@q4.forYou:✦ For you` },
    // A-285: one tab per ESCO group, in ESCO order.
    ...ESCO_GROUPS.map((g) => ({
      value: g.id,
      label: `${g.label} · ${inGroup(g.id).length}`,
    })),
  ]);

  /** Search runs against ESCO (A-245); our curated list is the offline fallback. */
  private readonly esco = inject(ESCO_API);
  private readonly lang = (inject(DOCUMENT).documentElement.lang || 'en').slice(0, 2);
  protected readonly escoRes = rxResource({
    params: () => {
      const q = this.query().trim();
      return q ? { q } : undefined;
    },
    stream: ({ params }) => this.esco.search(params.q, this.lang),
  });
  protected readonly escoDown = computed(() => !!this.escoRes.error());
  protected readonly escoLoading = computed(
    () => this.escoRes.isLoading() && !this.escoRes.hasValue(),
  );
  protected readonly results = computed<CardItem[]>(() => {
    if (this.escoRes.error()) return searchSkills(this.query());
    if (!this.escoRes.hasValue()) return [];
    return (this.escoRes.value()?.results ?? []).map((r) => ({
      id: r.uri,
      name: escoDisplay(r.label),
      category: r.category,
      escoCategory: r.escoCategory,
      escoType: r.type,
    }));
  });
  protected readonly escoTypeLabel = (t: EscoSkillType): string =>
    t === 'knowledge'
      ? $localize`:@@q4.escoKnowledge:Knowledge`
      : t === 'transversal'
        ? $localize`:@@q4.escoTransversal:Life skill`
        : $localize`:@@q4.escoSkill:Skill`;
  protected readonly searching = computed(() => this.query().trim().length > 0);
  protected readonly exact = computed(() =>
    this.results().some((k) => k.name.toLowerCase() === this.query().trim().toLowerCase()),
  );
  protected readonly near = computed(() =>
    this.results().length || this.escoLoading() ? undefined : nearMatch(this.query()),
  );
  protected readonly customProblem = computed(() => customSkillProblem(this.query()));

  private readonly tabItems = computed<CardItem[]>(() => {
    if (this.tab() === FOR_YOU) {
      const picks: SkillDef[] = suggestions(this.branch());
      const deckOnly = this.deck()
        .filter((k) => !picks.some((p) => p.id === k.id))
        .map((k) => ({ ...k, escoCategory: skillById(k.id)?.escoCategory }));
      return [...deckOnly, ...picks];
    }
    return inGroup(this.tab() as SkillDef['group']);
  });
  protected readonly cards = computed<CardItem[]>(() =>
    this.searching() ? this.results() : this.tabItems().slice(0, this.shown()),
  );
  protected readonly more = computed(() =>
    this.searching() ? 0 : Math.max(0, this.tabItems().length - this.shown()),
  );
  protected readonly canCollapse = computed(
    () => !this.searching() && this.shown() > FIRST && this.more() === 0,
  );

  protected readonly pickingSkill = computed(() => {
    const p = this.picking();
    return p ? (this.inDeck().get(p.id) ?? null) : null;
  });

  private readonly missingLevel = computed(() => this.deck().find((k) => !k.level) ?? null);

  readonly total = DECK_MIN;
  readonly answered = computed(() =>
    Math.min(DECK_MIN, this.deck().filter((k) => k.level > 0).length),
  );
  readonly blocked = computed(() => this.deck().length < DECK_MIN || !!this.missingLevel());
  readonly hint = computed(() => {
    const missing = this.missingLevel();
    if (missing)
      return $localize`:@@q4.setLevelHint:Set ${missing.name}:skill:’s level to continue`;
    const left = DECK_MIN - this.deck().length;
    if (left > 0)
      return left === 1
        ? $localize`:@@q4.addOne:Add 1 more skill`
        : $localize`:@@q4.addMore:Add ${left}:n: more skills`;
    return '';
  });

  async ngOnInit(): Promise<void> {
    const saved = this.context().answers['skills'];
    this.deck.set(Array.isArray(saved) ? (saved as DeckSkill[]) : []);
    // Suggestions use the Quest 3 branch / degree (Figma spec "For you").
    try {
      const q3 = await this.store.loadAnswers('big-brain-stuff');
      this.branch.set(str(q3['branch']));
    } catch {
      /* suggestions fall back to popular skills */
    }
  }

  // ── Cards ────────────────────────────────────────────────────────────────

  protected cardLabel(item: CardItem): string {
    const k = this.inDeck().get(item.id);
    const state = !k
      ? $localize`:@@q4.notInDeck:not in deck`
      : k.level
        ? $localize`:@@q4.inDeckLevel:in deck, level ${k.level}:level: of 3`
        : $localize`:@@q4.inDeckNoLevel:in deck, level not set`;
    return `${item.name}, ${this.categoryLabel(item.category)}, ${state}`;
  }

  protected tapCard(item: CardItem, event: Event): void {
    const origin = event.currentTarget as HTMLElement;
    const existing = this.inDeck().get(item.id);
    if (existing) {
      this.openPicker(item.id, origin, !existing.level);
      return;
    }
    if (this.full()) {
      this.notice.set(
        $localize`:@@q4.fullSwap:Deck full (15/15). Swap one out to add ${item.name}:skill:.`,
      );
      return;
    }
    const source: SkillSource = this.searching()
      ? 'search'
      : item.category === 'custom'
        ? 'custom'
        : 'suggested';
    this.add({
      id: item.id,
      name: item.name,
      category: item.category,
      level: 0,
      source,
      ...(item.escoType ? { esco: item.id } : {}),
    });
    this.openPicker(item.id, origin, true);
  }

  protected addCustom(): void {
    const name = this.query().trim();
    if (!name || this.customProblem()) return;
    const dup = this.deck().find((k) => k.name.toLowerCase() === name.toLowerCase());
    if (dup) {
      this.notice.set($localize`:@@q4.duplicate:“${dup.name}:skill:” is already in your deck.`);
      return;
    }
    if (this.full()) {
      this.notice.set(
        $localize`:@@q4.fullSwap:Deck full (15/15). Swap one out to add ${name}:skill:.`,
      );
      return;
    }
    const id = `custom-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
    this.add({ id, name, category: 'custom', level: 0, source: 'custom' });
    this.clearSearch();
    setTimeout(() => {
      const chip = this.host.querySelector<HTMLElement>(`[data-skill="${id}"] .main`);
      if (chip) this.openPicker(id, chip, true);
    });
  }

  protected useNear(skill: SkillDef, event: Event): void {
    this.tapCard(skill, event);
  }

  // ── Deck ─────────────────────────────────────────────────────────────────

  protected chipKind(skill: DeckSkill, index: number): 'signature' | 'unset' | 'default' {
    if (!skill.level) return 'unset';
    return index < SIGNATURES ? 'signature' : 'default';
  }

  protected editChip(skill: DeckSkill): void {
    const chip = this.host.querySelector<HTMLElement>(`[data-skill="${skill.id}"] .main`);
    if (chip) this.openPicker(skill.id, chip, !skill.level);
  }

  protected drop(event: CdkDragDrop<readonly DeckSkill[]>): void {
    const list = [...this.deck()];
    moveItemInArray(list, event.previousIndex, event.currentIndex);
    this.deck.set(list);
  }

  protected remove(skill: DeckSkill): void {
    const before = this.deck();
    this.closePicker(false);
    this.deck.set(before.filter((k) => k.id !== skill.id));
    this.notice.set('');
    this.toast.show($localize`:@@q4.removed:${skill.name}:skill: removed from your deck`, {
      duration: UNDO_MS,
      action: { label: $localize`:@@q3t.undo:Undo`, run: () => this.deck.set(before) },
    });
    setTimeout(() => this.host.querySelector<HTMLElement>('.search input, .search-input')?.focus());
  }

  // ── Picker ───────────────────────────────────────────────────────────────

  protected setLevel(level: SkillLevel): void {
    const id = this.picking()?.id ?? this.sheetId;
    if (!id) return;
    this.deck.update((d) => d.map((k) => (k.id === id ? { ...k, level } : k)));
    if (this.picking()) this.closePicker(true);
  }

  protected setSignature(on: boolean): void {
    const id = this.picking()?.id ?? this.sheetId;
    if (!id) return;
    this.deck.update((d) => {
      const list = [...d];
      const from = list.findIndex((k) => k.id === id);
      const item = list[from];
      if (!item || on === from < SIGNATURES) return d;
      list.splice(from, 1);
      // Pin: becomes signature 3 (the old 3rd drops to 4th). Unpin: first slot after the signatures.
      list.splice(on ? SIGNATURES - 1 : Math.min(SIGNATURES, list.length), 0, item);
      return list;
    });
  }

  protected isSignature(id: string): boolean {
    return this.deck().findIndex((k) => k.id === id) < SIGNATURES;
  }

  protected closePicker(returnFocus: boolean): void {
    const p = this.picking();
    this.picking.set(null);
    if (p && returnFocus) setTimeout(() => p.origin.focus());
  }

  private sheetId = '';

  private openPicker(id: string, origin: HTMLElement, isNew: boolean): void {
    this.notice.set('');
    if (!this.overlays.isMobile()) {
      this.picking.set({ id, origin, isNew });
      return;
    }
    const skill = this.inDeck().get(id);
    if (!skill) return;
    this.sheetId = id;
    const data: PowerSheetData = {
      skill: skill.name,
      level: () => this.inDeck().get(id)?.level ?? 0,
      signature: () => this.isSignature(id),
      canSign: () => true,
      inDeck: !isNew,
      pick: (level) => {
        this.setLevel(level);
        ref.close();
      },
      toggleSignature: (on) => this.setSignature(on),
      remove: () => {
        ref.close();
        this.remove(skill);
      },
    };
    const ref = this.overlays.sheet(PowerSheet, { data });
    ref.closed.subscribe(() => {
      this.sheetId = '';
      setTimeout(() => origin.focus());
    });
  }

  // ── Search, tabs, see more ───────────────────────────────────────────────

  protected onType(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.typed.set(value);
    clearTimeout(this.searchTimer);
    this.searchTimer = setTimeout(() => this.query.set(value), SEARCH_DEBOUNCE);
  }

  protected clearSearch(): void {
    clearTimeout(this.searchTimer);
    this.typed.set('');
    this.query.set('');
    this.host.querySelector<HTMLInputElement>('.search-input')?.focus();
  }

  protected setTab(value: string): void {
    this.tab.set(value);
    this.shown.set(FIRST);
  }

  protected seeMore(): void {
    this.shown.update((n) => n + STEP);
  }

  protected showLess(): void {
    this.shown.set(FIRST);
    this.host.querySelector<HTMLElement>('sm-tabs')?.scrollIntoView({ block: 'nearest' });
    this.host.querySelector<HTMLElement>('sm-tabs [aria-selected="true"]')?.focus();
  }

  /** "/" focuses search (Figma §4), unless the learner is typing somewhere. */
  protected onDocKey(event: KeyboardEvent): void {
    if (event.key !== '/' || event.defaultPrevented) return;
    const target = event.target as HTMLElement;
    if (target.closest('input, textarea, [contenteditable="true"]')) return;
    event.preventDefault();
    this.host.querySelector<HTMLInputElement>('.search-input')?.focus();
  }

  protected onPickerKey(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      event.preventDefault();
      this.closePicker(true);
    }
  }

  // ── QuestPart ────────────────────────────────────────────────────────────

  validate(): boolean {
    if (this.blocked()) {
      const missing = this.missingLevel();
      if (missing) {
        const chip = this.host.querySelector<HTMLElement>(`[data-skill="${missing.id}"] .main`);
        if (chip) this.openPicker(missing.id, chip, true);
      }
      return false;
    }
    return true;
  }

  value() {
    return { skills: this.deck() };
  }

  private add(skill: DeckSkill): void {
    this.deck.update((d) => [...d, skill]);
  }
}
