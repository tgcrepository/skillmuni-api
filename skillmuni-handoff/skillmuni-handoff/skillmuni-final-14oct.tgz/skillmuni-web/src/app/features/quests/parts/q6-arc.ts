import {
  Component,
  ElementRef,
  OnInit,
  computed,
  forwardRef,
  inject,
  input,
  signal,
} from '@angular/core';
import { Market } from '../../../core/market/market';
import { QuestStore } from '../../../core/quests/quest-store';
import { Banner } from '../../../shared/ui/banner/banner';
import { ChipGroup, ChipOption } from '../../../shared/ui/chip/chip-group';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import { Select } from '../../../shared/ui/select/select';
import { Tag } from '../../../shared/ui/tag/tag';
import {
  LOOKING_FOR,
  NOTICE,
  POPULAR_ROLES,
  RADIUS_KM,
  SALARY,
  SALARY_NOTE,
  SHIFTS,
} from '../data/arc';
import { Chapter } from '../data/work';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { str } from './part-utils';

const ROLE_MAX = 60;
const ROLES_MAX = 8;

/**
 * Q6 — Pick Your Arc (Figma 200:34528 · tablet 200:34748 · mobile 200:34926). One screen: what you're
 * looking for, roles (suggested from the CV / Work Lore), where (near your Quest 2 address within 25 km,
 * your state / province, relocating, remote), shifts, notice period (needed) and expected salary (optional).
 */
@Component({
  selector: 'sm-q6-arc',
  imports: [Banner, ChipGroup, Field, Input, Select, Tag],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q6Arc) }],
  templateUrl: './q6-arc.html',
  styleUrls: ['./q2-spot.scss', './q6-arc.scss'],
})
export class Q6Arc implements QuestPart, OnInit {
  private readonly market = inject(Market);
  private readonly store = inject(QuestStore);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  readonly context = input.required<QuestPartContext>();

  protected readonly ids = {
    looking: uniqueId('arc-looking'),
    roles: uniqueId('arc-roles'),
    where: uniqueId('arc-where'),
    shifts: uniqueId('arc-shifts'),
    notice: uniqueId('arc-notice'),
  };
  protected readonly needed = $localize`:@@ui.needed:Needed`;
  protected readonly optional = $localize`:@@ui.optional:Optional`;
  protected readonly salaryLabel = $localize`:@@arc.salary:Expected salary`;
  protected readonly roleLabel = $localize`:@@arc.addRoleLabel:Add a role`;
  protected readonly addRoleChip = $localize`:@@arc.addRole:+ Add a role`;

  protected readonly model = signal({
    lookingFor: [] as string[],
    roles: [] as string[],
    where: [] as string[],
    shifts: [] as string[],
    notice: '',
    salary: '',
  });
  protected readonly suggestedRoles = signal<string[]>([]);
  protected readonly cvRoles = signal(false);
  protected readonly place = signal({ near: '', region: '' });
  protected readonly addingRole = signal(false);
  protected readonly newRole = signal('');
  private readonly attempted = signal(false);

  protected readonly lookingOptions = computed<ChipOption[]>(() => [
    ...LOOKING_FOR[this.market.code()],
  ]);
  protected readonly shiftOptions: ChipOption[] = [...SHIFTS];
  protected readonly noticeOptions = computed<ChipOption[]>(() => [...NOTICE[this.market.code()]]);
  protected readonly salaryOptions = computed(() => [...SALARY[this.market.code()]]);
  protected readonly salaryNote = computed(() => SALARY_NOTE[this.market.code()]);
  protected readonly roleOptions = computed<ChipOption[]>(() =>
    [...new Set([...this.suggestedRoles(), ...this.model().roles])].map((r) => ({
      value: r,
      label: r,
    })),
  );
  protected readonly whereOptions = computed<ChipOption[]>(() => {
    const { near, region } = this.place();
    return [
      ...(near
        ? [
            {
              value: 'near',
              label: $localize`:@@arc.near:Near ${near}:place: · within ${RADIUS_KM}:km: km`,
            },
          ]
        : []),
      ...(region
        ? [{ value: 'region', label: $localize`:@@arc.region:Anywhere in ${region}:region:` }]
        : []),
      { value: 'relocate', label: $localize`:@@arc.relocate:Open to relocating` },
      { value: 'remote', label: $localize`:@@arc.remote:Remote` },
    ];
  });

  protected readonly errors = computed(() => {
    const e: Record<string, string> = {};
    if (!this.attempted()) return e;
    const m = this.model();
    if (!m.lookingFor.length) e['looking'] = $localize`:@@arc.lookingReq:Pick at least one`;
    if (!m.roles.length) e['roles'] = $localize`:@@arc.rolesReq:Pick or add at least one role`;
    if (!m.where.length) e['where'] = $localize`:@@arc.whereReq:Pick where you can work`;
    if (!m.notice) e['notice'] = $localize`:@@arc.noticeReq:Employers filter by this, pick one`;
    return e;
  });
  protected readonly roleProblem = computed(() =>
    this.newRole().length > ROLE_MAX
      ? $localize`:@@ch.roleLong:Keep it under 60 characters (${this.newRole().length}:n:/60).`
      : '',
  );

  readonly total = 4;
  readonly answered = computed(() => {
    const m = this.model();
    return [m.lookingFor.length, m.roles.length, m.where.length, m.notice].filter(Boolean).length;
  });
  readonly hint = computed(() =>
    this.answered() === 4 ? $localize`:@@arc.moreQuests:2 more quests` : '',
  );

  async ngOnInit(): Promise<void> {
    const a = this.context().answers;
    const list = (k: string) => (Array.isArray(a[k]) ? (a[k] as string[]) : []);
    this.model.set({
      lookingFor: list('lookingFor'),
      roles: list('roles'),
      where: list('where'),
      shifts: list('shifts'),
      notice: str(a['notice']),
      salary: str(a['salary']),
    });
    const [spot, lore] = await Promise.all([
      this.store.loadAnswers('hit-me-up').catch(() => ({})),
      this.store.loadAnswers('work-lore').catch(() => ({})),
    ]);
    const s = spot as Record<string, unknown>;
    const near = [str(s['area']), str(s['city'])].filter(Boolean).join(', ');
    this.place.set({ near, region: str(s['region']) });
    // Roles: Work Lore chapters first (often from the CV), then popular ones.
    const chapters = Array.isArray((lore as Record<string, unknown>)['chapters'])
      ? ((lore as Record<string, unknown>)['chapters'] as Chapter[])
      : [];
    const fromLore = chapters.map((c) => c.role).filter(Boolean);
    this.cvRoles.set(chapters.some((c) => c.fromCv));
    this.suggestedRoles.set([...new Set([...fromLore, ...POPULAR_ROLES])].slice(0, 6));
    // First visit: pre-pick the closest place and the latest role, so most learners just confirm.
    if (!a['where'] && near) this.patch({ where: ['near'] });
    if (!a['roles'] && fromLore[0]) this.patch({ roles: [fromLore[0]] });
  }

  protected setList(
    key: 'lookingFor' | 'roles' | 'where' | 'shifts',
    value: string | string[] | null,
  ): void {
    this.patch({ [key]: Array.isArray(value) ? value : [] });
  }

  protected setOne(key: 'notice' | 'salary', value: string | string[] | null): void {
    this.patch({ [key]: typeof value === 'string' ? value : '' });
  }

  protected startRole(): void {
    this.addingRole.set(true);
    setTimeout(() => this.host.querySelector<HTMLInputElement>('.add-role input')?.focus());
  }

  protected addRole(): void {
    const role = this.newRole().trim();
    if (!role || this.roleProblem()) return;
    if (this.model().roles.length >= ROLES_MAX) return;
    this.suggestedRoles.update((r) => (r.includes(role) ? r : [...r, role]));
    this.patch({ roles: [...new Set([...this.model().roles, role])] });
    this.newRole.set('');
    this.addingRole.set(false);
  }

  validate(): boolean {
    this.attempted.set(true);
    const first = Object.keys(this.errors())[0];
    if (first)
      setTimeout(() =>
        this.host
          .querySelector<HTMLElement>(`[data-q="${first}"] input, [data-q="${first}"] button`)
          ?.focus(),
      );
    return !first;
  }

  value() {
    return this.model();
  }

  private patch(change: Partial<ReturnType<typeof this.model>>): void {
    this.model.update((m) => ({ ...m, ...change }));
  }
}
