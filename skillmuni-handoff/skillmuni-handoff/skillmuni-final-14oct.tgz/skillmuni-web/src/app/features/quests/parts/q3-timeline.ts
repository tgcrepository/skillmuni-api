import {
  Component,
  ElementRef,
  OnInit,
  computed,
  forwardRef,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { Market } from '../../../core/market/market';
import { QuestStore } from '../../../core/quests/quest-store';
import { Button } from '../../../shared/ui/button/button';
import { Field } from '../../../shared/ui/field/field';
import { Icon } from '../../../shared/ui/icon/icon';
import { IconButton } from '../../../shared/ui/icon-button/icon-button';
import { Input } from '../../../shared/ui/input/input';
import { Select, SelectOption } from '../../../shared/ui/select/select';
import { Tag } from '../../../shared/ui/tag/tag';
import { ToastService } from '../../../shared/ui/toast/toast.service';
import {
  BOARDS,
  COURSE,
  DEGREES,
  EDUCATION,
  BRANCHES,
  LEVELS,
  MAX_TIMELINE,
  STREAMS,
  TimelineEntry,
  timelineLevels,
  yearsBack,
} from '../data/education';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { str } from './part-utils';

const SLUG = 'big-brain-stuff';
const PART = 3;
/** Figma §7: Undo toast stays 6 s. */
const UNDO_MS = 6000;

const opts = (list: readonly string[]): SelectOption[] => list.map((v) => ({ value: v, label: v }));

type Draft = Omit<TimelineEntry, 'id'>;

const EMPTY: Draft = {
  level: '',
  board: '',
  stream: '',
  name: '',
  institute: '',
  year: '',
  score: '',
  qual: '',
  degree: '',
  branch: '',
};

/** Levels an "Add education" entry can be (A-244). */
const QUAL_LEVELS = new Set(['iti', 'diploma', 'tvet', 'nqf5', 'graduate', 'postgraduate', 'phd']);

/**
 * Q3 · Part 3 — Education timeline, optional (Figma 200:21058 / 200:22349 / 200:23477 · States §7).
 * The highest level (from parts 1–2) is pinned and edit-only. Lower school levels can be added once,
 * courses can repeat, max 6 entries. Add / edit open an inline form; delete confirms inline, then an
 * Undo toast (6 s). Each distinct extra level is +10 XP, saved straight away (not on Lock it in).
 */
@Component({
  selector: 'sm-q3-timeline',
  imports: [NgTemplateOutlet, Button, Field, Icon, IconButton, Input, Select, Tag],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q3Timeline) }],
  templateUrl: './q3-timeline.html',
  styleUrl: './q3-timeline.scss',
})
export class Q3Timeline implements QuestPart, OnInit {
  private readonly market = inject(Market);
  private readonly store = inject(QuestStore);
  private readonly toast = inject(ToastService);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  private readonly thisYear = new Date().getFullYear();

  readonly context = input.required<QuestPartContext>();
  /** Ask the quest page to open another part (1-based index → 0-based). */
  readonly goTo = output<number>();

  protected readonly entries = signal<readonly TimelineEntry[]>([]);
  /** Id being edited, 'new' while adding, or '' when no form is open. */
  protected readonly editing = signal('');
  protected readonly confirming = signal('');
  protected readonly draft = signal<Draft>(EMPTY);
  private readonly attempted = signal(false);

  protected readonly max = MAX_TIMELINE;
  protected readonly needed = $localize`:@@ui.needed:Needed`;
  protected readonly optional = $localize`:@@ui.optional:Optional`;
  protected readonly editLabel = $localize`:@@q3t.edit:Edit`;
  protected readonly deleteLabel = $localize`:@@q3t.delete:Remove`;
  protected readonly courseLabel = $localize`:@@q3t.courseName:Course name`;
  protected readonly instituteLabel = $localize`:@@q3t.institute:Institute`;
  protected readonly schoolLabel = $localize`:@@q3t.school:School`;

  private readonly answers = computed(() => this.context().answers);
  protected readonly highestLevel = computed(() => str(this.answers()['level']));
  protected readonly highest = computed(() => {
    const a = this.answers();
    const level = LEVELS[this.market.code()].find((l) => l.value === this.highestLevel());
    const title =
      [str(a['degree']), str(a['branch'])].filter(Boolean).join(' · ') ||
      [str(a['board']), level?.title].filter(Boolean).join(' · ');
    return {
      badge: level?.title ?? '',
      title,
      meta: this.meta(str(a['institute']), str(a['year']), this.highestScore()),
      studying: a['status'] === 'studying',
    };
  });

  /** Sorted by level, highest first (courses straight under the pinned highest level, Figma dev note). */
  protected readonly sorted = computed(() => {
    const rank = (level: string): number =>
      level === EDUCATION
        ? -1
        : level === COURSE
          ? 0
          : 1 + timelineLevels(this.market.code(), this.highestLevel()).indexOf(level);
    return [...this.entries()].sort((a, b) => rank(a.level) - rank(b.level));
  });
  /** First entry of each level carries the XP tag; repeats (courses) don't. */
  protected readonly rewarded = computed(() => {
    const seen = new Set<string>();
    return new Set(
      this.sorted()
        .filter((e) => !seen.has(e.level) && seen.add(e.level))
        .map((e) => e.id),
    );
  });
  protected readonly addable = computed(() => {
    const taken = new Set(this.entries().map((e) => e.level));
    return timelineLevels(this.market.code(), this.highestLevel())
      .filter((level) => level === COURSE || level === EDUCATION || !taken.has(level))
      .map((level) => ({ level, label: this.addLabel(level), xp: !taken.has(level) }));
  });
  /** The pinned highest level counts towards the 6. */
  protected readonly full = computed(() => this.entries().length + 1 >= MAX_TIMELINE);

  protected readonly boardOptions = computed(() => opts(BOARDS[this.market.code()]));
  protected readonly streamOptions = opts(STREAMS);
  protected readonly yearOptions = computed(() => opts(yearsBack(this.thisYear, 50)));
  protected readonly isCourse = computed(() => this.draft().level === COURSE);
  protected readonly isEducation = computed(() => this.draft().level === EDUCATION);
  protected readonly qualOptions = computed<SelectOption[]>(() =>
    LEVELS[this.market.code()]
      .filter((l) => QUAL_LEVELS.has(l.value) || l.kind === 'degree' || l.kind === 'vocational')
      .map((l) => ({ value: l.value, label: l.title })),
  );
  protected readonly degreeOptions = computed(() => opts(DEGREES[this.draft().qual ?? ''] ?? []));
  protected readonly branchOptions = opts(BRANCHES);
  protected readonly qualLabel = $localize`:@@q3t.qual:Level`;
  protected readonly degreeLabel = $localize`:@@q3t.degree:Degree or qualification`;
  protected readonly branchLabel = $localize`:@@q3t.branch:Specialisation`;
  protected readonly hasStream = computed(() => this.draft().level === '12th');
  protected readonly formTitle = computed(() =>
    this.editing() === 'new'
      ? this.addLabel(this.draft().level)
      : $localize`:@@q3t.editTitle:Edit your ${this.levelName(this.draft().level)}:level:`,
  );
  protected readonly saveLabel = computed(
    () => $localize`:@@q3t.save:Save ${this.levelName(this.draft().level)}:level:`,
  );

  protected readonly errors = computed(() => {
    const e: Record<string, string> = {};
    if (!this.attempted()) return e;
    const d = this.draft();
    const need = $localize`:@@q3.need:Needed to match you right`;
    if (this.isCourse()) {
      if (!d.name.trim()) e['name'] = need;
    } else if (this.isEducation()) {
      if (!d.qual) e['qual'] = need;
      if (!d.degree?.trim()) e['degree'] = need;
      if (!d.institute.trim()) e['institute'] = need;
    } else {
      if (!d.board) e['board'] = need;
      if (!d.institute.trim()) e['institute'] = need;
    }
    if (!d.year) e['year'] = need;
    const n = Number(d.score);
    if (d.score && !(/^\d{1,3}(\.\d{1,2})?$/.test(d.score.trim()) && n >= 0 && n <= 100))
      e['score'] = $localize`:@@q3t.pct:Percentages go up to 100.`;
    return e;
  });

  /** Nothing to count: the part is optional, so the stepper shows no "N of M" (Figma 200:21058). */
  /** Corrections #9: optional extras pay the step XP once at least one is added. */
  readonly earnsXp = computed(() => this.entries().length > 0);
  readonly xpHint = $localize`:@@q3.timelineXpHint:Add your 10th or another course to earn +20 XP`;
  readonly total = 0;
  readonly answered = signal(0).asReadonly();
  readonly hint = computed(() =>
    this.editing()
      ? $localize`:@@q3t.hintForm:Save or cancel the entry first`
      : $localize`:@@q3t.hint:Optional, add more or finish`,
  );
  /** Lock it in waits while a form is open, so a half-typed entry isn't lost silently. */
  readonly blocked = computed(() => !!this.editing());

  ngOnInit(): void {
    const saved = this.answers()['timeline'];
    this.entries.set(Array.isArray(saved) ? (saved as TimelineEntry[]) : []);
  }

  protected add(level: string): void {
    this.open('new', { ...EMPTY, level });
  }

  protected edit(entry: TimelineEntry): void {
    this.confirming.set('');
    this.open(entry.id, entry);
  }

  protected set(key: keyof Draft, value: string | string[] | null): void {
    this.draft.update((d) => ({ ...d, [key]: typeof value === 'string' ? value : '' }));
  }

  protected cancel(): void {
    const was = this.editing();
    this.editing.set('');
    this.attempted.set(false);
    this.focusLater(was === 'new' ? '.add' : `[data-entry="${was}"] .edit`);
  }

  protected save(): void {
    this.attempted.set(true);
    if (Object.keys(this.errors()).length) {
      this.focusLater('.form [aria-invalid="true"], .form .is-invalid input');
      return;
    }
    const id = this.editing() === 'new' ? `e${Date.now().toString(36)}` : this.editing();
    const entry: TimelineEntry = { ...this.draft(), id };
    const isNew = this.editing() === 'new';
    const earned = isNew && !this.entries().some((e) => e.level === entry.level);
    this.commit(
      isNew ? [...this.entries(), entry] : this.entries().map((e) => (e.id === id ? entry : e)),
    );
    this.editing.set('');
    this.attempted.set(false);
    if (earned)
      this.toast.show($localize`:@@q3t.added:${this.levelName(entry.level)}:level: added`);
    this.focusLater(`[data-entry="${id}"] .edit`);
  }

  protected askDelete(entry: TimelineEntry): void {
    this.editing.set('');
    this.confirming.set(entry.id);
    this.focusLater(`[data-entry="${entry.id}"] .confirm-keep`);
  }

  protected keep(entry: TimelineEntry): void {
    this.confirming.set('');
    this.focusLater(`[data-entry="${entry.id}"] .delete`);
  }

  protected remove(entry: TimelineEntry): void {
    const before = this.entries();
    this.confirming.set('');
    this.commit(before.filter((e) => e.id !== entry.id));
    this.toast.show($localize`:@@q3t.removed:${this.levelName(entry.level)}:level: removed`, {
      duration: UNDO_MS,
      action: { label: $localize`:@@q3t.undo:Undo`, run: () => this.commit(before) },
    });
    this.focusLater('.add, .list .edit');
  }

  protected lossNote(entry: TimelineEntry): string {
    void entry;
    return '';
  }

  protected removeQuestion(entry: TimelineEntry): string {
    return $localize`:@@q3t.removeQ:Remove your ${this.levelName(entry.level)}:level:?`;
  }

  protected entryTitle(entry: TimelineEntry): string {
    if (entry.level === EDUCATION)
      return (
        [entry.degree, entry.branch].filter(Boolean).join(' · ') || this.levelName(entry.qual ?? '')
      );
    return entry.level === COURSE
      ? entry.name
      : [entry.board, entry.stream].filter(Boolean).join(' · ') || this.levelName(entry.level);
  }

  protected entryMeta(entry: TimelineEntry): string {
    return this.meta(entry.institute, entry.year, entry.score ? `${entry.score}%` : '');
  }

  protected badge(level: string, entry?: TimelineEntry): string {
    if (level === EDUCATION)
      return this.levelName(entry?.qual ?? '') || $localize`:@@q3t.badgeEdu:Education`;
    return level === COURSE ? $localize`:@@q3t.badgeCourse:Course` : this.levelName(level);
  }

  validate(): boolean {
    return !this.editing();
  }

  value() {
    return { timeline: this.entries() };
  }

  private open(id: string, draft: Draft): void {
    this.attempted.set(false);
    this.draft.set(draft);
    this.editing.set(id);
    this.focusLater('.form input, .form button');
  }

  private commit(next: readonly TimelineEntry[]): void {
    this.entries.set(next);
    void this.store.saveBonus(SLUG, PART, { timeline: next }, 0); // A-168: no in-between XP
  }

  private highestScore(): string {
    const a = this.answers();
    const score = str(a['score']);
    if (!score) return '';
    if (a['scoreKind'] === 'cgpa') return `CGPA ${score}/10`;
    if (a['scoreKind'] === 'percentage') return `${score}%`;
    return score;
  }

  private meta(...parts: string[]): string {
    return parts.filter(Boolean).join(' · ');
  }

  private levelName(level: string): string {
    if (level === COURSE) return $localize`:@@q3t.course:course`;
    if (level === EDUCATION) return $localize`:@@q3t.education:education`;
    return LEVELS[this.market.code()].find((l) => l.value === level)?.title ?? level;
  }

  private addLabel(level: string): string {
    if (level === EDUCATION) return $localize`:@@q3t.addEducation:Add education`;
    return level === COURSE
      ? $localize`:@@q3t.addCourse:Add a diploma or certificate course`
      : $localize`:@@q3t.addLevel:Add your ${this.levelName(level)}:level:`;
  }

  /** Move focus after the view updates (form open/close, delete) so keyboard users don't get lost. */
  private focusLater(selector: string): void {
    setTimeout(() => this.host.querySelector<HTMLElement>(selector)?.focus());
  }
}
