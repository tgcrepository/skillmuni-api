import { CdkMenu, CdkMenuItem, CdkMenuTrigger } from '@angular/cdk/menu';
import {
  Component,
  ElementRef,
  OnInit,
  computed,
  forwardRef,
  inject,
  input,
  signal,
} from '@angular/core';
import { FLEX_API } from '../../../core/flex/flex.api';
import { Market } from '../../../core/market/market';
import { Button } from '../../../shared/ui/button/button';
import { Icon } from '../../../shared/ui/icon/icon';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { Tag } from '../../../shared/ui/tag/tag';
import { ToastService } from '../../../shared/ui/toast/toast.service';
import {
  ExpiryState,
  TROPHY_MAX,
  Trophy,
  expiryState,
  monthLabel,
  monthsUntil,
} from '../data/flex';
import { DECK_MAX, DeckSkill } from '../data/skills';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { TrophyDialog, TrophyDialogData, TrophyDialogResult } from './trophy-dialog';

const UNDO_MS = 6000;

/**
 * Q4 · Part 3 — Trophy shelf, optional (Figma 200:26058 · tablet 200:27806 · mobile 200:28946 · §7).
 * Certificates as trophies, 3 per row, max 20. Verified (link checked or DigiLocker), expiring ≤ 90 days
 * (amber, "Add the renewed one"), expired (red, kept). "···" → Edit / Remove (confirm, then Undo).
 */
@Component({
  selector: 'sm-q4-trophies',
  imports: [Button, CdkMenu, CdkMenuItem, CdkMenuTrigger, Icon, Tag],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q4Trophies) }],
  templateUrl: './q4-trophies.html',
  styleUrl: './q4-trophies.scss',
})
export class Q4Trophies implements QuestPart, OnInit {
  private readonly api = inject(FLEX_API);
  private readonly market = inject(Market);
  private readonly overlays = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  private readonly today = new Date();

  readonly context = input.required<QuestPartContext>();

  protected readonly trophies = signal<readonly Trophy[]>([]);
  protected readonly deck = signal<readonly DeckSkill[]>([]);
  protected readonly confirming = signal('');
  protected readonly importing = signal(false);
  protected readonly imported = signal(false);
  protected readonly max = TROPHY_MAX;
  protected readonly moreLabel = $localize`:@@q4t.more:More actions for`;

  protected readonly full = computed(() => this.trophies().length >= TROPHY_MAX);
  protected readonly expiring = computed(() =>
    this.trophies().find((t) => expiryState(t, this.today) === 'soon'),
  );

  /** Corrections #11: the trophy step pays +20 XP only when a certificate is added. */
  readonly earnsXp = computed(() => this.trophies().length > 0);
  readonly xpHint = $localize`:@@q4.trophyXpHint:Add a certificate to earn +20 XP`;
  readonly total = 0;
  readonly answered = signal(0).asReadonly();
  readonly hint = computed(() =>
    this.trophies().length
      ? $localize`:@@q4t.count:${this.trophies().length}:n: on your shelf`
      : $localize`:@@q4t.optional:Optional`,
  );

  ngOnInit(): void {
    const a = this.context().answers;
    this.trophies.set(Array.isArray(a['trophies']) ? (a['trophies'] as Trophy[]) : []);
    this.deck.set(Array.isArray(a['skills']) ? (a['skills'] as DeckSkill[]) : []);
    this.imported.set(this.trophies().some((t) => t.source === 'digilocker'));
  }

  protected state(t: Trophy): ExpiryState {
    return expiryState(t, this.today);
  }

  protected meta(t: Trophy): string {
    return [t.issuer, monthLabel(t.issuedOn, this.market.config().locale)]
      .filter(Boolean)
      .join(' · ');
  }

  protected expiresIn(t: Trophy): string {
    const n = monthsUntil(t.expiresOn, this.today);
    return n === 1
      ? $localize`:@@q4t.exp1:Expires in 1 month`
      : $localize`:@@q4t.expN:Expires in ${n}:n: months`;
  }

  protected expiredOn(t: Trophy): string {
    return $localize`:@@q4t.expired:Expired · ${monthLabel(t.expiresOn, this.market.config().locale)}:date:`;
  }

  protected renewNote(t: Trophy): string {
    return $localize`:@@q4t.renew:Your ${t.name}:name: trophy expires in ${monthLabel(t.expiresOn, this.market.config().locale)}:date:.`;
  }

  protected add(): void {
    this.open(undefined);
  }

  protected edit(t: Trophy): void {
    this.open(t);
  }

  protected askRemove(t: Trophy): void {
    this.confirming.set(t.id);
    setTimeout(() =>
      this.host.querySelector<HTMLElement>(`[data-trophy="${t.id}"] .keep`)?.focus(),
    );
  }

  protected keep(t: Trophy): void {
    this.confirming.set('');
    setTimeout(() =>
      this.host.querySelector<HTMLElement>(`[data-trophy="${t.id}"] .menu`)?.focus(),
    );
  }

  protected remove(t: Trophy): void {
    const before = this.trophies();
    this.confirming.set('');
    this.trophies.set(before.filter((x) => x.id !== t.id));
    this.toast.show($localize`:@@q4t.removed:${t.name}:name: removed`, {
      duration: UNDO_MS,
      action: { label: $localize`:@@q3t.undo:Undo`, run: () => this.trophies.set(before) },
    });
    setTimeout(() => this.host.querySelector<HTMLElement>('.slot')?.focus());
  }

  /** DigiLocker: Skill India / NPTEL certificates arrive verified (Figma 200:26058 banner). */
  protected importDigilocker(): void {
    if (this.importing()) return;
    this.importing.set(true);
    this.api.importDigilocker().subscribe({
      next: (list) => {
        const have = new Set(this.trophies().map((t) => t.name));
        const fresh: Trophy[] = list
          .filter((x) => !have.has(x.name))
          .slice(0, TROPHY_MAX - this.trophies().length)
          .map((x, i) => ({
            id: `dl${Date.now().toString(36)}${i}`,
            name: x.name,
            issuer: x.issuer,
            issuedOn: x.issuedOn,
            expiresOn: '',
            noExpiry: true,
            credentialUrl: '',
            credentialId: x.credentialId,
            fileName: '',
            verified: true,
            linkedSkills: [],
            source: 'digilocker',
          }));
        this.trophies.update((t) => [...t, ...fresh]);
        this.importing.set(false);
        this.imported.set(true);
        this.toast.show(
          fresh.length === 1
            ? $localize`:@@q4t.imported1:1 certificate imported from DigiLocker`
            : $localize`:@@q4t.importedN:${fresh.length}:n: certificates imported from DigiLocker`,
        );
      },
      error: () => {
        this.importing.set(false);
        this.toast.show(
          $localize`:@@q4t.importFail:DigiLocker didn’t answer. Try again in a bit.`,
          {
            tone: 'error',
          },
        );
      },
    });
  }

  validate(): boolean {
    return true;
  }

  value() {
    return { trophies: this.trophies(), skills: this.deck() };
  }

  private open(trophy: Trophy | undefined): void {
    const isNew = !trophy;
    const data: TrophyDialogData = {
      ...(trophy ? { trophy } : {}),
      deck: this.deck(),
      slotsLeft: DECK_MAX - this.deck().length,
    };
    const ref = this.overlays.adaptive<TrophyDialog, TrophyDialogData, TrophyDialogResult>(
      TrophyDialog,
      { data, size: 'md', autoFocus: 'input, button.trigger' },
    );
    ref.closed.subscribe((result) => {
      if (!result) return;
      const t = { ...result.trophy, id: result.trophy.id || `t${Date.now().toString(36)}` };
      this.trophies.update((list) =>
        list.some((x) => x.id === t.id) ? list.map((x) => (x.id === t.id ? t : x)) : [...list, t],
      );
      if (result.newSkills.length) this.deck.update((d) => [...d, ...result.newSkills]);
      if (isNew)
        this.toast.show(
          t.verified
            ? $localize`:@@q4t.addedVerified:${t.name}:name: is on your shelf, verified`
            : $localize`:@@q4t.added:${t.name}:name: is on your shelf`,
        );
      setTimeout(() =>
        this.host.querySelector<HTMLElement>(`[data-trophy="${t.id}"] .menu`)?.focus(),
      );
    });
  }
}
