import { InjectionToken, Signal } from '@angular/core';
import { QuestAnswers } from '../../core/quests/quest.api';

/**
 * Contract every quest part component implements (provide it with `QUEST_PART`).
 * The quest page owns the card chrome (eyebrow, stepper, footer); the part owns its questions.
 */
export interface QuestPart {
  /** Questions answered so far / total, for "N of M answered" and the counter. */
  readonly answered: Signal<number>;
  readonly total: number;
  /** Mark everything touched and say whether the part can be saved. */
  validate(): boolean;
  /** Current values to save (also used for Save & exit drafts, valid or not). */
  value(): QuestAnswers;
  /**
   * Corrections #8, #9, #11, #15: an optional part pays its step XP only when the learner adds
   * something (backup mobile, an extra education, a trophy, a proof). Omit for required parts.
   */
  readonly earnsXp?: Signal<boolean>;
  /** Footer line while `earnsXp` is false, e.g. "Add a certificate to earn +20 XP". */
  readonly xpHint?: string;
  /** Overrides the footer counter, e.g. "Verify your number first". */
  readonly hint?: Signal<string>;
  /** Primary stays disabled while true (the hint says why). */
  readonly blocked?: Signal<boolean>;
  /** Live heading override, e.g. Q5 "Chapter 1: Data Analyst Intern" or the fresher title. */
  readonly heading?: Signal<{ pre: string; em: string; post?: string } | null>;
  /** Live primary label override, e.g. "Save chapter" / "Finish quest". */
  readonly primaryLabel?: Signal<string>;
  /**
   * Back / quest map with unsaved work (Q5 chapter): ask first. `stay` cancels the navigation; `save` keeps
   * `value()` as a draft; `discard` saves `discardValue()`. Resolve null when there is nothing to ask.
   */
  confirmLeave?(): Promise<'save' | 'discard' | 'stay' | null>;
  discardValue?(): QuestAnswers;
}

export const QUEST_PART = new InjectionToken<QuestPart>('QUEST_PART');

/** Inputs every part receives from the quest page. */
export interface QuestPartContext {
  readonly answers: QuestAnswers;
  readonly firstName: string;
}
