/**
 * Every living language with an ISO 639-1 code (A-243). Names come from Intl.DisplayNames in the
 * learner's locale, so there is no copy to translate and RTL names render natively.
 */
const ISO_639_1 =
  'aa ab af ak am an ar as av ay az ba be bg bi bm bn bo br bs ca ce ch co cr cs cv cy da de dv dz ee el en eo es et eu fa ff fi fj fo fr fy ga gd gl gn gu gv ha he hi ho hr ht hu hy hz ia id ig ii ik io is it iu ja jv ka kg ki kj kk kl km kn ko kr ks ku kv kw ky la lb lg li ln lo lt lu lv mg mh mi mk ml mn mr ms mt my na nb nd ne ng nl nn no nr nv ny oc oj om or os pa pl ps pt qu rm rn ro ru rw sa sc sd se sg si sk sl sm sn so sq sr ss st su sv sw ta te tg th ti tk tl tn to tr ts tt tw ty ug uk ur uz ve vi vo wa wo xh yi yo za zh zu'.split(
    ' ',
  );

/** Widely spoken languages without a 639-1 code (ISO 639-3), common in our markets. */
const EXTRA = ['bho', 'brx', 'doi', 'kok', 'mai', 'mni', 'sat', 'raj', 'tcy', 'nso', 'hne', 'mag'];

export function worldLanguages(locale: string): readonly string[] {
  let names: Intl.DisplayNames;
  try {
    names = new Intl.DisplayNames([locale], { type: 'language' });
  } catch {
    names = new Intl.DisplayNames(['en'], { type: 'language' });
  }
  const seen = new Set<string>();
  for (const code of [...ISO_639_1, ...EXTRA]) {
    const n = names.of(code);
    if (n && n !== code) seen.add(n.charAt(0).toUpperCase() + n.slice(1));
  }
  return [...seen].sort((a, b) => a.localeCompare(b, locale));
}
