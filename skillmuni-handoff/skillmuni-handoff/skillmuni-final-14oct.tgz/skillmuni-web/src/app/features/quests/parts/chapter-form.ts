import {
  Component,
  ElementRef,
  OnInit,
  booleanAttribute,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { Market } from '../../../core/market/market';
import { QuestStore } from '../../../core/quests/quest-store';
import { Button } from '../../../shared/ui/button/button';
import { ChipGroup, ChipOption } from '../../../shared/ui/chip/chip-group';
import { Field } from '../../../shared/ui/field/field';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import { Segment, SegmentedControl } from '../../../shared/ui/segmented-control/segmented-control';
import { Select, SelectOption } from '../../../shared/ui/select/select';
import { Switch } from '../../../shared/ui/switch/switch';
import { Tag } from '../../../shared/ui/tag/tag';
import { TextLink } from '../../../shared/ui/text-link/text-link';
import { DECK_MAX, DeckSkill, SKILLS } from '../data/skills';
import {
  CHAPTER_SKILLS_MAX,
  COMPANIES,
  Chapter,
  ChapterType,
  DESCRIPTION_MAX,
  DESCRIPTION_PROMPTS,
  DESCRIPTION_WARN,
  FIRST_YEAR,
  NAME_MAX,
  ROLES,
  WorkMode,
  chapterMonths,
  durationLabel,
  monthIndex,
  thisMonth,
  typeTitle,
} from '../data/work';

type Key = 'type' | 'role' | 'company' | 'start' | 'end' | 'description';

function complete(value: string): boolean {
  return /^\d{4}-(0[1-9]|1[0-2])$/.test(value) && !value.startsWith('0000');
}

const EMPTY: Chapter = {
  id: '',
  type: '',
  role: '',
  company: '',
  start: '',
  end: '',
  current: false,
  mode: '',
  skills: [],
  description: '',
};

/**
 * One chapter of Work Lore (Figma 200:31127 role search · 200:31391 filled, current job · States §2–§4).
 * Required: type, role, company or client, start, end (or "I still work here"). Optional: work mode,
 * skills from the Quest 4 deck (≤ 5), description (≤ 300). Errors on save only, with a summary that
 * jumps to each field. `embedded` = the quest card's primary saves it (Part 2); otherwise it has its
 * own Save / Cancel (editing in the timeline).
 */
@Component({
  selector: 'sm-chapter-form',
  imports: [Button, ChipGroup, Field, SegmentedControl, Select, Switch, Tag, TextLink],
  templateUrl: './chapter-form.html',
  styleUrl: './chapter-form.scss',
})
export class ChapterForm implements OnInit {
  private readonly market = inject(Market);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;
  private readonly today = new Date();

  readonly chapter = input<Chapter | null>(null);
  /** Types offered in "What kind was it?" (Part 1 picks, plus the chapter's own). */
  readonly types = input<readonly ChapterType[]>([]);
  readonly deck = input<readonly DeckSkill[]>([]);
  readonly embedded = input(false, { transform: booleanAttribute });
  readonly saved = output<Chapter>();
  readonly cancelled = output<void>();

  protected readonly model = signal<Chapter>(EMPTY);
  protected readonly attempted = signal(false);
  protected readonly notice = signal('');
  private initial = '';

  protected readonly ids = {
    summary: uniqueId('ch-summary'),
    type: uniqueId('ch-type'),
    mode: uniqueId('ch-mode'),
    skills: uniqueId('ch-skills'),
    desc: uniqueId('ch-desc'),
    descCount: uniqueId('ch-count'),
    start: uniqueId('ch-start'),
    end: uniqueId('ch-end'),
  };
  protected readonly needed = $localize`:@@ui.needed:Needed`;
  protected readonly optional = $localize`:@@ui.optional:Optional`;
  protected readonly max = DESCRIPTION_MAX;
  protected readonly prompts = DESCRIPTION_PROMPTS;
  protected readonly presentLabel = $localize`:@@ch.present:Present`;
  protected readonly monthLabel = $localize`:@@ch.month:Month`;
  protected readonly yearLabel = $localize`:@@ch.year:Year`;
  protected readonly modes: readonly Segment[] = [
    { value: 'onsite', label: $localize`:@@ch.onsite:On-site` },
    { value: 'hybrid', label: $localize`:@@ch.hybrid:Hybrid` },
    { value: 'remote', label: $localize`:@@ch.remote:Remote` },
  ];

  protected readonly typeSegments = computed<Segment[]>(() => {
    const list = [
      ...new Set([
        ...this.types(),
        ...(this.model().type ? [this.model().type as ChapterType] : []),
      ]),
    ];
    return list.map((t) => ({ value: t, label: typeTitle(t) }));
  });
  protected readonly roleOptions: SelectOption[] = ROLES.map((r) => ({
    value: r.name,
    label: r.name,
  }));
  protected readonly companyOptions: SelectOption[] = COMPANIES.map((c) => ({
    value: c.name,
    label: c.name,
  }));
  protected readonly companyMeta = computed(
    () => COMPANIES.find((c) => c.name === this.model().company)?.meta ?? '',
  );
  private readonly monthNames = computed(() => {
    const fmt = new Intl.DateTimeFormat(this.market.config().locale, { month: 'short' });
    return Array.from({ length: 12 }, (_, i) => fmt.format(new Date(2000, i, 1)));
  });
  protected readonly yearOptions: SelectOption[] = Array.from(
    { length: this.today.getFullYear() - FIRST_YEAR + 1 },
    (_, i) => String(this.today.getFullYear() - i),
  ).map((y) => ({ value: y, label: y }));

  /** Future months are disabled (Figma §3). */
  protected monthOptions(year: string): SelectOption[] {
    const now = thisMonth(this.today);
    return this.monthNames().map((name, i) => {
      const value = String(i + 1).padStart(2, '0');
      return { value, label: name, disabled: !!year && `${year}-${value}` > now };
    });
  }

  /** Dates are "YYYY-MM"; a half-picked one keeps "0000" / "00" for the missing part. */
  protected part(value: string, which: 'y' | 'm'): string {
    const [y, m] = value.split('-');
    const v = (which === 'y' ? y : m) ?? '';
    return /^0+$/.test(v) ? '' : v;
  }

  // ── "+ Add a skill not in your deck" (Figma Q5 states §4): joins the Quest 4 deck on save ──
  private readonly store = inject(QuestStore);
  protected readonly added = signal<readonly DeckSkill[]>([]);
  protected readonly adding = signal(false);
  private readonly allSkills = computed(() => [...this.deck(), ...this.added()]);
  protected readonly slotsLeft = computed(() => Math.max(0, DECK_MAX - this.allSkills().length));
  protected readonly addOptions = computed<SelectOption[]>(() => {
    const have = new Set(this.allSkills().map((k) => k.id));
    return SKILLS.filter((k) => !have.has(k.id)).map((k) => ({ value: k.id, label: k.name }));
  });
  protected readonly addLabel = $localize`:@@ch.addSkillLabel:Add a skill`;
  protected readonly addPlaceholder = $localize`:@@ch.addSkillPh:Search skills`;

  protected startAdd(): void {
    this.adding.set(true);
    setTimeout(() => this.host.querySelector<HTMLElement>('.add-skill button')?.focus());
  }

  protected addSkill(id: string | null): void {
    const def = SKILLS.find((k) => k.id === id);
    if (def)
      this.pushSkill({
        id: def.id,
        name: def.name,
        category: def.category,
        level: 0,
        source: 'search',
      });
  }

  protected addCustom(name: string): void {
    const clean = name.trim();
    if (!clean) return;
    const id = `custom-${clean.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
    if (this.allSkills().some((k) => k.id === id)) return;
    this.pushSkill({ id, name: clean, category: 'custom', level: 0, source: 'custom' });
  }

  private pushSkill(skill: DeckSkill): void {
    if (!this.slotsLeft()) return;
    this.added.update((list) => [...list, skill]);
    if (!this.skillsFull()) this.set('skills', [...this.model().skills, skill.id]);
    this.adding.set(false);
    setTimeout(() => this.host.querySelector<HTMLElement>('.add-link')?.focus());
    this.notice.set(
      $localize`:@@ch.skillAdded:${skill.name}:name: added. It joins your deck when you save.`,
    );
  }

  protected readonly skillOptions = computed<ChipOption[]>(() => {
    const picked = new Set(this.model().skills);
    const full = picked.size >= CHAPTER_SKILLS_MAX;
    return this.allSkills().map((k) => ({
      value: k.id,
      label: k.name,
      disabled: full && !picked.has(k.id),
    }));
  });
  protected readonly skillValue = computed(() => [...this.model().skills]);
  protected readonly skillsFull = computed(() => this.model().skills.length >= CHAPTER_SKILLS_MAX);
  protected readonly descLength = computed(() => this.model().description.length);
  protected readonly duration = computed(() => {
    const m = this.model();
    if (!complete(m.start) || (!m.current && !complete(m.end))) return '';
    const months = chapterMonths(m, this.today);
    return m.current
      ? $localize`:@@ch.soFar:${durationLabel(months)}:d: so far`
      : durationLabel(months);
  });
  protected readonly oldWarning = computed(() => {
    const s = complete(this.model().start) ? monthIndex(this.model().start) : NaN;
    const years = Math.floor((monthIndex(thisMonth(this.today)) - s) / 12);
    return Number.isFinite(s) && years > 30
      ? $localize`:@@ch.old:That’s ${years}:n: years ago. Just checking, all good?`
      : '';
  });

  protected readonly errors = computed(() => {
    const e: Partial<Record<Key, string>> = {};
    if (!this.attempted()) return e;
    const m = this.model();
    const now = monthIndex(thisMonth(this.today));
    if (!m.type) e.type = $localize`:@@ch.typeReq:Pick what kind it was`;
    if (!m.role.trim()) e.role = $localize`:@@ch.roleReq:Add your role`;
    else if (m.role.length > NAME_MAX)
      e.role = $localize`:@@ch.roleLong:Keep it under 60 characters (${m.role.length}:n:/60).`;
    if (!m.company.trim()) e.company = $localize`:@@ch.companyReq:Add the company or client`;
    else if (m.company.length > NAME_MAX)
      e.company = $localize`:@@ch.companyLong:Keep it under 60 characters (${m.company.length}:n:/60).`;
    if (!complete(m.start)) e.start = $localize`:@@ch.startReq:Add the month and year you started`;
    else if (monthIndex(m.start) > now)
      e.start = $localize`:@@ch.future:That’s in the future. Add it once it starts.`;
    if (!m.current) {
      if (!complete(m.end))
        e.end = $localize`:@@ch.endReq:Add when it ended, or switch on “I still work here”`;
      else if (complete(m.start) && monthIndex(m.end) < monthIndex(m.start))
        e.end = $localize`:@@ch.endBefore:End date can’t be before your start date (${this.label(m.start)}:start:).`;
    }
    if (m.description.length > DESCRIPTION_MAX)
      e.description = $localize`:@@ch.trim:Trim ${m.description.length - DESCRIPTION_MAX}:n: characters to save this chapter.`;
    return e;
  });
  protected readonly errorList = computed(() =>
    (Object.entries(this.errors()) as [Key, string][]).map(([key, message]) => ({
      key,
      message,
      label: this.fieldLabel(key),
    })),
  );

  /** Required fields filled, for "N of 4" in the stepper. */
  readonly filled = computed(() => {
    const m = this.model();
    return [
      m.role.trim(),
      m.company.trim(),
      complete(m.start),
      m.current || complete(m.end),
    ].filter(Boolean).length;
  });
  /** Live model, for autosave. */
  readonly snapshot = computed(() => this.model());
  /** Fields with anything in them (for "You’ve filled N fields"). */
  readonly touchedFields = computed(() => {
    const m = this.model();
    return [
      m.type,
      m.role,
      m.company,
      m.start.replace(/0/g, '').replace('-', ''),
      m.end.replace(/0/g, '').replace('-', ''),
      m.description,
      m.skills.length ? 'x' : '',
    ].filter((v) => !!v).length;
  });
  readonly dirty = computed(() => JSON.stringify(this.model()) !== this.initial);
  /** Title for "Chapter N: {role}". */
  readonly role = computed(() => this.model().role.trim());

  ngOnInit(): void {
    const ch = this.chapter();
    const types = this.types();
    const start: Chapter = ch ?? {
      ...EMPTY,
      type: types.length === 1 ? (types[0] ?? '') : '',
      company: types.length === 1 && types[0] === 'freelance' ? 'Self-employed' : '',
    };
    this.model.set(start);
    this.initial = JSON.stringify(start);
  }

  protected set<K extends keyof Chapter>(key: K, value: Chapter[K]): void {
    this.model.update((m) => ({ ...m, [key]: value }));
  }

  protected setText(key: 'role' | 'company', value: string | string[] | null): void {
    this.set(key, typeof value === 'string' ? value : '');
  }

  protected setType(type: string): void {
    this.model.update((m) => ({
      ...m,
      type: type as ChapterType,
      // Freelance pre-fills "Self-employed" (Figma §2); editable.
      company: type === 'freelance' && !m.company ? 'Self-employed' : m.company,
    }));
  }

  protected setMode(mode: string): void {
    this.set('mode', (this.model().mode === mode ? '' : mode) as WorkMode | '');
  }

  protected setDate(key: 'start' | 'end', which: 'y' | 'm', value: string | string[] | null): void {
    const v = typeof value === 'string' ? value : '';
    const current = this.model()[key];
    const y = which === 'y' ? v : this.part(current, 'y');
    const m = which === 'm' ? v : this.part(current, 'm');
    this.set(key, y || m ? `${y || '0000'}-${m || '00'}` : '');
  }

  protected setCurrent(on: boolean): void {
    const had = this.model().end;
    this.model.update((m) => ({ ...m, current: on, end: on ? '' : m.end }));
    this.notice.set(
      on && had
        ? $localize`:@@ch.cleared:You said you still work here, so we cleared the end date.`
        : '',
    );
  }

  protected setSkills(value: string | string[] | null): void {
    const list = Array.isArray(value) ? value.slice(0, CHAPTER_SKILLS_MAX) : [];
    this.set('skills', list);
  }

  protected onDescription(event: Event): void {
    this.set('description', (event.target as HTMLTextAreaElement).value);
  }

  /** "Need ideas?" chips add a starter at the cursor, never overwrite (Figma §4). */
  protected addPrompt(starter: string): void {
    const area = this.host.querySelector<HTMLTextAreaElement>('textarea');
    const text = this.model().description;
    const at = area?.selectionStart ?? text.length;
    const before = text.slice(0, at);
    const glue = before && !/\s$/.test(before) ? ' ' : '';
    const next = `${before}${glue}${starter}${text.slice(at)}`;
    this.set('description', next);
    // Focus moves to the text straight away so typing continues the sentence.
    area?.focus();
    setTimeout(() => {
      if (!area) return;
      const caret = at + glue.length + starter.length;
      area.setSelectionRange(caret, caret);
    });
  }

  protected descState(): 'ok' | 'warn' | 'over' {
    const n = this.descLength();
    return n > DESCRIPTION_MAX ? 'over' : n >= DESCRIPTION_WARN ? 'warn' : 'ok';
  }

  protected jump(key: Key): void {
    const target = this.host.querySelector<HTMLElement>(
      `[data-field="${key}"] input, [data-field="${key}"] button, [data-field="${key}"] textarea`,
    );
    target?.focus();
  }

  /** Validate, and on failure move focus to the error summary (Figma §4). */
  /** Bring the error summary into focus (a parent switching to this form's tab, A-246). */
  focusSummary(): void {
    this.host.querySelector<HTMLElement>(`#${this.ids.summary}`)?.focus();
  }

  validate(): boolean {
    this.attempted.set(true);
    const ok = this.errorList().length === 0;
    if (ok) void this.joinDeck();
    if (!ok)
      setTimeout(() => this.host.querySelector<HTMLElement>(`#${this.ids.summary}`)?.focus());
    return ok;
  }

  /** New skills picked for this chapter join the Quest 4 deck (deduped, ≤ 15). */
  private async joinDeck(): Promise<void> {
    const picked = new Set(this.model().skills);
    const fresh = this.added().filter((k) => picked.has(k.id));
    if (!fresh.length) return;
    try {
      const q4 = await this.store.loadAnswers('your-flex-era');
      const deck = Array.isArray(q4['skills']) ? (q4['skills'] as DeckSkill[]) : [];
      const merged = [...deck, ...fresh.filter((k) => !deck.some((d) => d.id === k.id))].slice(
        0,
        DECK_MAX,
      );
      if (merged.length !== deck.length)
        await this.store.savePart('your-flex-era', 1, { skills: merged }, false);
    } catch {
      /* the chapter still keeps the skill ids; the deck catches up next save */
    }
  }

  value(): Chapter {
    const m = this.model();
    return {
      ...m,
      id: m.id || `ch${Date.now().toString(36)}`,
      role: m.role.trim(),
      company: m.company.trim(),
      description: m.description.trim(),
      typeUnsure: false,
    };
  }

  protected submit(): void {
    if (this.validate()) this.saved.emit(this.value());
  }

  private label(value: string): string {
    const [y, m] = value.split('-').map(Number);
    return y && m ? `${this.monthNames()[m - 1]} ${y}` : value;
  }

  private fieldLabel(key: Key): string {
    switch (key) {
      case 'type':
        return $localize`:@@ch.kind:What kind was it?`;
      case 'role':
        return $localize`:@@ch.role:Your role`;
      case 'company':
        return $localize`:@@ch.company:Company or client`;
      case 'start':
        return $localize`:@@ch.started:Started`;
      case 'end':
        return $localize`:@@ch.ended:Ended`;
      default:
        return $localize`:@@ch.desc:What did you do?`;
    }
  }
}
