import { Component, OnInit, computed, forwardRef, inject, input, signal } from '@angular/core';
import { Market } from '../../../core/market/market';
import { OptionCardItem, OptionCards } from '../../../shared/ui/option-card/option-cards';
import { Segment, SegmentedControl } from '../../../shared/ui/segmented-control/segmented-control';
import { Tag } from '../../../shared/ui/tag/tag';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import { LEVELS } from '../data/education';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { str } from './part-utils';

/** Q3 · Part 1 — Your level (Figma 200:19838 / 200:21580 / 200:22780): one option card + done / studying. */
/** A-250: every level card gets a picture in its tile (the tiles were blank). */
const LEVEL_ICON: Readonly<Record<string, string>> = {
  '10th': '📘',
  '12th': '📗',
  grade9: '📘',
  matric: '📗',
  iti: '🔧',
  tvet: '🔧',
  diploma: '🛠️',
  graduate: '🎓',
  postgraduate: '📜',
  phd: '🔬',
};

@Component({
  selector: 'sm-q3-level',
  imports: [OptionCards, SegmentedControl, Tag],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q3Level) }],
  template: `
    <section class="q">
      <h2 class="q-title" [id]="ids.level">
        <ng-container i18n="@@q3.levelQ">Highest education level</ng-container>
        <sm-tag tone="danger" i18n="@@ui.needed">Needed</sm-tag>
      </h2>
      <sm-option-cards
        [multiple]="false"
        [labelledBy]="ids.level"
        [items]="items()"
        [value]="model().level ? [model().level] : []"
        (valueChange)="setLevel($event)"
        [invalid]="!!levelError()"
      />
      @if (levelError()) {
        <p class="error" role="alert">{{ levelError() }}</p>
      }
    </section>
    @if (model().level && model().level !== 'none') {
      <section class="q">
        <h2 class="q-title" [id]="ids.status" i18n="@@q3.doneQ">Is it done?</h2>
        <sm-segmented-control
          class="status"
          [labelledBy]="ids.status"
          [segments]="statuses"
          [value]="model().status"
          (valueChange)="setStatus($event)"
        />
      </section>
    }
  `,
  styles: `
    :host {
      display: grid;
      gap: var(--sm-space-600);
    }

    .q {
      display: grid;
      gap: var(--sm-space-300);
    }

    .q-title {
      display: flex;
      align-items: center;
      gap: var(--sm-space-200);
      color: var(--sm-color-text-primary);
      font: var(--sm-font-label);
    }

    .status {
      justify-self: start;
      min-inline-size: min(100%, calc(var(--sm-layout-shell-map-width) * 1.1));
    }

    .error {
      color: var(--sm-color-feedback-error-text);
      font: var(--sm-font-caption);
    }
  `,
})
export class Q3Level implements QuestPart, OnInit {
  private readonly market = inject(Market);
  readonly context = input.required<QuestPartContext>();
  private readonly attempted = signal(false);
  protected readonly ids = { level: uniqueId('q3-level'), status: uniqueId('q3-status') };
  protected readonly statuses: readonly Segment[] = [
    { value: 'completed', label: $localize`:@@q3.completed:Completed` },
    { value: 'studying', label: $localize`:@@q3.studying:Still studying` },
  ];
  protected readonly model = signal({ level: '', status: 'completed' });
  protected readonly items = computed<readonly OptionCardItem[]>(() =>
    LEVELS[this.market.code()].map((l) => ({
      value: l.value,
      title: l.title,
      description: l.description,
      code: LEVEL_ICON[l.value] ?? '🎓',
      optOut: l.kind === 'none',
    })),
  );
  protected readonly levelError = computed(() =>
    this.attempted() && !this.model().level
      ? $localize`:@@q3.levelRequired:Pick your highest level`
      : '',
  );

  readonly total = 2;
  readonly answered = computed(() => (this.model().level ? 2 : 0));

  ngOnInit(): void {
    const a = this.context().answers;
    this.model.set({ level: str(a['level']), status: str(a['status']) || 'completed' });
  }

  protected setLevel(values: string[]): void {
    this.model.update((m) => ({ ...m, level: values[0] ?? '' }));
  }

  protected setStatus(status: string): void {
    this.model.update((m) => ({ ...m, status }));
  }

  validate(): boolean {
    this.attempted.set(true);
    return !!this.model().level;
  }

  value() {
    const m = this.model();
    return { level: m.level, status: m.level === 'none' ? '' : m.status };
  }
}
