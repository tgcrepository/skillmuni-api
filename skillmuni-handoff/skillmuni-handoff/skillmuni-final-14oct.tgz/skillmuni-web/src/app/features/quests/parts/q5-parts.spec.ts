import { Component, signal, viewChild } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import {
  Chapter,
  ChapterType,
  chapterMonths,
  durationLabel,
  findGaps,
  findOverlaps,
  lookup,
  ROLES,
  sortChapters,
  totalMonths,
} from '../data/work';
import { ChapterForm } from './chapter-form';

const today = new Date(2026, 9, 4); // Oct 2026

const ch = (id: string, start: string, end: string, current = false): Chapter => ({
  id,
  type: 'full_time',
  role: id,
  company: id,
  start,
  end,
  current,
  mode: '',
  skills: [],
  description: '',
});

describe('Q5 work maths', () => {
  it('labels durations inclusively; the same month is "Under a month"', () => {
    expect(chapterMonths(ch('a', '2024-01', '2024-06'), today)).toBe(6);
    expect(chapterMonths(ch('a', '2024-01', '2024-01'), today)).toBe(0);
    expect(durationLabel(0)).toBe('Under a month');
    expect(durationLabel(16)).toBe('1 yr 4 mos');
    expect(durationLabel(7)).toBe('7 mos');
  });

  it('counts total experience as a union (overlaps never double-count)', () => {
    const a = ch('a', '2024-01', '2024-12');
    const b = ch('b', '2024-07', '2025-03');
    expect(totalMonths([a, b], today)).toBe(15);
    expect(findOverlaps([a, b], today)[0]?.months).toBe(6);
  });

  it('sorts current first, then newest end; finds 3+ month gaps, including up to now', () => {
    const old = ch('old', '2022-03', '2023-12');
    const intern = ch('intern', '2024-01', '2024-06');
    const now = ch('now', '2026-03', '', true);
    expect(sortChapters([old, now, intern], today).map((c) => c.id)).toEqual([
      'now',
      'intern',
      'old',
    ]);
    const gaps = findGaps([old, intern, now], today);
    expect(gaps).toEqual([{ start: '2024-07', end: '2026-02', months: 20, after: 'now' }]);
    expect(findGaps([old, intern], today)[0]).toMatchObject({
      start: '2024-07',
      end: '',
      after: '',
    });
  });

  it('looks up roles from 2 letters, with synonyms', () => {
    expect(lookup(ROLES, 'd')).toEqual([]);
    expect(lookup(ROLES, 'sde')[0]?.name).toBe('Software Engineer');
    expect(lookup(ROLES, 'data an').map((r) => r.name)).toContain('Data Analyst Intern');
  });
});

@Component({
  imports: [ChapterForm],
  template: `<sm-chapter-form embedded [types]="types()" [chapter]="chapter()" />`,
})
class Host {
  readonly types = signal<ChapterType[]>(['freelance']);
  readonly chapter = signal<Chapter | null>(null);
  readonly form = viewChild.required(ChapterForm);
}

describe('ChapterForm', () => {
  it('pre-fills freelance with Self-employed and lists what to fix', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.detectChanges();
    const form = fixture.componentInstance.form();
    expect(form.value().company).toBe('Self-employed');
    expect(form.validate()).toBe(false);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('[role="alert"]')?.textContent).toContain('3 things to fix');
  });

  it('rejects an end before the start and a too-long description', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.componentInstance.chapter.set({
      ...ch('x', '2025-05', '2025-02'),
      description: 'x'.repeat(312),
    });
    fixture.detectChanges();
    const form = fixture.componentInstance.form();
    expect(form.validate()).toBe(false);
    fixture.detectChanges();
    const text = (fixture.nativeElement as HTMLElement).textContent ?? '';
    expect(text).toContain('End date can’t be before your start date');
    expect(text).toContain('Trim 12 characters');
  });

  it('a complete current chapter is valid and has no end date', () => {
    const fixture = TestBed.createComponent(Host);
    fixture.componentInstance.chapter.set(ch('ok', '2025-03', '', true));
    fixture.detectChanges();
    const form = fixture.componentInstance.form();
    expect(form.validate()).toBe(true);
    expect(form.value()).toMatchObject({ current: true, end: '' });
  });
});
