import {
  Component,
  OnInit,
  computed,
  effect,
  forwardRef,
  inject,
  input,
  signal,
  untracked,
} from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { firstValueFrom, of, switchMap } from 'rxjs';
import { CONTACT_API, PostalLookup } from '../../../core/contact/contact.api';
import { Market, isValidPostal } from '../../../core/market/market';
import { Banner } from '../../../shared/ui/banner/banner';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { Select, SelectOption } from '../../../shared/ui/select/select';
import { Tag } from '../../../shared/ui/tag/tag';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { isFilled, str } from './part-utils';

const TYPE_AREA = '__type__';

interface Lookup {
  readonly state: 'idle' | 'loading' | 'found' | 'not-found';
  readonly data?: PostalLookup;
}

/**
 * Q2 · Part 3 — Your spot. India (200:15844 PIN auto-fill + area · 200:16121 PIN not found + state search)
 * and South Africa (200:16379 postal code → province + municipality, suburb, street). The code fills
 * region / district / city and offers the areas under it; anything auto-filled stays editable.
 */
@Component({
  selector: 'sm-q2-spot',
  imports: [Field, Input, Select, Tag, Banner],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q2Spot) }],
  templateUrl: './q2-spot.html',
  styleUrl: './q2-spot.scss',
})
export class Q2Spot implements QuestPart, OnInit {
  private readonly api = inject(CONTACT_API);
  protected readonly market = inject(Market);
  readonly context = input.required<QuestPartContext>();
  protected readonly attempted = signal(false);
  protected readonly needed = $localize`:@@ui.needed:Needed`;
  protected readonly optional = $localize`:@@ui.optional:Optional`;
  protected readonly fromPostal = $localize`:@@q2.fromPostal:From postal code`;
  protected readonly autoLabel = $localize`:@@q2.autoFilled:Auto-filled`;
  protected readonly zaPostalHelp = $localize`:@@q2.zaPostalHelp:4 digits · fills province and municipality`;
  protected readonly inPostalHelp = $localize`:@@q2.inPostalHelp:6 digits · fills state and city`;
  protected readonly provinceLabel = $localize`:@@q2.province:Province`;
  protected readonly stateLabel = $localize`:@@q2.state:State / UT`;
  protected readonly suburbLabel = $localize`:@@q2.suburb:Suburb / Area`;
  protected readonly areaLabel = $localize`:@@q2.area:Area / Locality`;
  protected readonly streetLabel = $localize`:@@q2.street:Street address`;
  protected readonly flatLabel = $localize`:@@q2.flat:Flat / House no., Building`;
  protected readonly streetPh = $localize`:@@q2.streetPh:House / street number and name`;
  protected readonly flatPh = $localize`:@@q2.flatPh:e.g. Flat 402, Sai Residency`;
  protected readonly cvHelp = $localize`:@@q2.cvHelp:From your CV — pick the exact area`;
  protected readonly typeArea = TYPE_AREA;
  protected readonly typingArea = signal(false);

  protected readonly model = signal({
    postal: '',
    region: '',
    district: '',
    city: '',
    area: '',
    line1: '',
    unit: '',
    landmark: '',
  });
  protected readonly isZa = computed(() => this.market.code() === 'ZA');

  private readonly validCode = computed(() =>
    isValidPostal(this.market.config(), this.model().postal) ? this.model().postal : '',
  );
  protected readonly lookup = toSignal(
    toObservable(this.validCode).pipe(
      switchMap((code) => {
        if (!code) return of<Lookup>({ state: 'idle' });
        return new Promise<Lookup>((resolve) => {
          firstValueFrom(this.api.lookupPostal(this.market.code(), code))
            .then((data) => resolve({ state: 'found', data }))
            .catch(() => resolve({ state: 'not-found' }));
        });
      }),
    ),
    { initialValue: { state: 'idle' } as Lookup },
  );
  protected readonly regions = toSignal(
    toObservable(this.market.code).pipe(switchMap((code) => this.api.regions(code))),
    { initialValue: [] as readonly string[] },
  );
  protected readonly regionOptions = computed<readonly SelectOption[]>(() =>
    this.regions().map((r) => ({ value: r, label: r })),
  );
  protected readonly areaOptions = computed<readonly SelectOption[]>(() => [
    ...(this.lookup().data?.areas ?? []).map((a) => ({ value: a.name, label: a.name })),
    { value: TYPE_AREA, label: $localize`:@@q2.typeArea:Not listed? Type your area` },
  ]);
  protected readonly autoFilled = computed(() => this.lookup().state === 'found');
  protected readonly cvArea = computed(() => str(this.context().answers['cvArea']));

  protected readonly errors = computed(() => {
    if (!this.attempted()) return {} as Record<string, string>;
    const m = this.model();
    const need = $localize`:@@q2.needed:Needed so your certificates reach you`;
    const e: Record<string, string> = {};
    if (!isValidPostal(this.market.config(), m.postal)) {
      e['postal'] = this.isZa()
        ? $localize`:@@q2.postalZa:Postal codes are 4 digits`
        : $localize`:@@q2.pinIn:PIN codes are 6 digits`;
    }
    if (!m.region) e['region'] = need;
    if (!m.city && !this.isZa()) e['city'] = need;
    if (!m.area) e['area'] = need;
    if (!m.line1) e['line1'] = need;
    return e;
  });

  readonly total = 6;
  readonly answered = computed(() => {
    const m = this.model();
    const city = this.isZa() ? m.district : m.city;
    return [
      m.postal && !this.errors()['postal'] ? m.postal : '',
      m.region,
      city,
      m.area,
      m.line1,
      m.landmark,
    ].filter(isFilled).length;
  });

  constructor() {
    effect(() => {
      const l = this.lookup();
      if (l.state !== 'found' || !l.data) return;
      const data = l.data;
      untracked(() =>
        this.model.update((m) => ({
          ...m,
          region: data.region,
          district: data.district,
          city: data.city,
          area: data.areas.some((a) => a.name === m.area) ? m.area : '',
        })),
      );
    });
  }

  ngOnInit(): void {
    const a = this.context().answers;
    this.model.set({
      postal: str(a['postal']),
      region: str(a['region']),
      district: str(a['district']),
      city: str(a['city']),
      area: str(a['area']) || str(a['cvArea']),
      line1: str(a['line1']),
      unit: str(a['unit']),
      landmark: str(a['landmark']),
    });
  }

  protected set(key: keyof ReturnType<typeof this.model>, value: string | null): void {
    if (key === 'area' && value === TYPE_AREA) {
      this.typingArea.set(true);
      this.model.update((m) => ({ ...m, area: '' }));
      return;
    }
    this.model.update((m) => ({ ...m, [key]: value ?? '' }));
  }

  validate(): boolean {
    this.attempted.set(true);
    return Object.keys(this.errors()).length === 0;
  }

  value() {
    return this.model();
  }
}
