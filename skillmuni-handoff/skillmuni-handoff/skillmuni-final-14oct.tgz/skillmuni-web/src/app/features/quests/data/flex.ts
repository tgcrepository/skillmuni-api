/** Q4 Language passport + Trophy shelf data (Figma spec 200:23877, States §6–§7). */

export type Fluency = 'basic' | 'conversational' | 'fluent' | 'native';

export interface LanguageStamp {
  readonly name: string;
  readonly fluency: Fluency | '';
  readonly speak: boolean;
  readonly read: boolean;
  readonly write: boolean;
  readonly motherTongue: boolean;
  readonly fromCv: boolean;
}

export const FLUENCIES: readonly { value: Fluency; label: string; cefr: string }[] = [
  { value: 'basic', label: $localize`:@@lang.basic:Basic`, cefr: 'A2' },
  { value: 'conversational', label: $localize`:@@lang.conv:Conversational`, cefr: 'B1' },
  { value: 'fluent', label: $localize`:@@lang.fluent:Fluent`, cefr: 'C1' },
  { value: 'native', label: $localize`:@@lang.native:Native`, cefr: 'C2' },
];

/** Native script, shown when the font supports it (Figma §6); otherwise the English name. */
export const SCRIPTS: Readonly<Record<string, string>> = {
  Hindi: 'हिन्दी',
  Bengali: 'বাংলা',
  Marathi: 'मराठी',
  Telugu: 'తెలుగు',
  Tamil: 'தமிழ்',
  Gujarati: 'ગુજરાતી',
  Urdu: 'اردو',
  Kannada: 'ಕನ್ನಡ',
  Odia: 'ଓଡ଼ିଆ',
  Malayalam: 'മലയാളം',
  Punjabi: 'ਪੰਜਾਬੀ',
  Assamese: 'অসমীয়া',
};

export function stampProblem(stamp: LanguageStamp): '' | 'fluency' | 'ability' {
  if (!stamp.fluency) return 'fluency';
  if (!stamp.speak && !stamp.read && !stamp.write) return 'ability';
  return '';
}

export interface Trophy {
  readonly id: string;
  readonly name: string;
  readonly issuer: string;
  /** YYYY-MM */
  readonly issuedOn: string;
  /** YYYY-MM, empty when it doesn't expire. */
  readonly expiresOn: string;
  readonly noExpiry: boolean;
  readonly credentialUrl: string;
  readonly credentialId: string;
  readonly fileName: string;
  readonly verified: boolean;
  readonly linkedSkills: readonly string[];
  readonly source: 'manual' | 'digilocker';
}

export const TROPHY_MAX = 20;
export const TROPHY_FILE_MAX = 5 * 1024 * 1024;
export const TROPHY_ACCEPT = '.pdf,.jpg,.jpeg,.png';

export interface TrophySuggestion {
  readonly name: string;
  readonly issuer: string;
  /** Skill ids this certificate usually proves. */
  readonly skills: readonly string[];
}

export const TROPHY_SUGGESTIONS: readonly TrophySuggestion[] = [
  {
    name: 'Google Data Analytics Professional',
    issuer: 'Google · via Coursera',
    skills: ['data-analysis', 'sql', 'tableau', 'google-sheets'],
  },
  {
    name: 'Google Analytics Certification',
    issuer: 'Google',
    skills: ['digital-marketing', 'data-analysis'],
  },
  { name: 'AWS Cloud Practitioner', issuer: 'Amazon Web Services', skills: ['cloud-aws'] },
  {
    name: 'Microsoft Office Specialist: Excel',
    issuer: 'Microsoft',
    skills: ['excel', 'ms-office'],
  },
  {
    name: 'Python for Everybody',
    issuer: 'University of Michigan · via Coursera',
    skills: ['python'],
  },
  {
    name: 'NPTEL Programming in Java',
    issuer: 'NPTEL · IIT Kharagpur',
    skills: ['java'],
  },
  {
    name: 'Skill India: Customer Care Executive',
    issuer: 'NSDC · Skill India',
    skills: ['customer-service', 'communication'],
  },
  {
    name: 'Canva Design School: Graphic Design Basics',
    issuer: 'Canva',
    skills: ['canva', 'graphic-design'],
  },
  { name: 'HubSpot Inbound Marketing', issuer: 'HubSpot Academy', skills: ['digital-marketing'] },
  {
    name: 'Services SETA: Contact Centre Support',
    issuer: 'Services SETA',
    skills: ['customer-service', 'call-centre-systems'],
  },
];

export const ISSUERS: readonly string[] = [
  ...new Set(TROPHY_SUGGESTIONS.map((t) => t.issuer)),
  'LinkedIn Learning',
  'Udemy',
  'Skillmuni',
];

export type ExpiryState = 'ok' | 'soon' | 'expired' | 'none';

/** Expiring ≤ 90 days → amber; expired → red but kept (Figma §7). `today` is injectable for tests. */
export function expiryState(trophy: Trophy, today: Date): ExpiryState {
  if (trophy.noExpiry || !trophy.expiresOn) return 'none';
  const [y, m] = trophy.expiresOn.split('-').map(Number);
  if (!y || !m) return 'none';
  const end = new Date(y, m, 0); // last day of that month
  const days = (end.getTime() - today.getTime()) / 86_400_000;
  if (days < 0) return 'expired';
  return days <= 90 ? 'soon' : 'ok';
}

/** "Aug 2024" from "2024-08", in the user's locale. */
export function monthLabel(value: string, locale: string): string {
  const [y, m] = value.split('-').map(Number);
  if (!y || !m) return '';
  return new Intl.DateTimeFormat(locale, { month: 'short', year: 'numeric' }).format(
    new Date(y, m - 1, 1),
  );
}

/** Months between two dates, at least 1, for "Expires in N months". */
export function monthsUntil(value: string, today: Date): number {
  const [y, m] = value.split('-').map(Number);
  if (!y || !m) return 0;
  return Math.max(1, (y - today.getFullYear()) * 12 + (m - 1 - today.getMonth()));
}
