import {
  Component,
  OnInit,
  computed,
  forwardRef,
  inject,
  input,
  signal,
  viewChild,
} from '@angular/core';
import { FormField, email, form, required } from '@angular/forms/signals';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../../core/api/api-error';
import { Auth } from '../../../core/auth/auth';
import { CONTACT_API, emailSuggestion } from '../../../core/contact/contact.api';
import { Market, isValidMobile, nationalNumber } from '../../../core/market/market';
import { Button } from '../../../shared/ui/button/button';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { Switch } from '../../../shared/ui/switch/switch';
import { Tag } from '../../../shared/ui/tag/tag';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import {
  OTP_AUTOFOCUS,
  OtpDialog,
  OtpDialogData,
  OtpDialogResult,
} from '../../auth/login/otp-dialog';
import { PhoneField } from '../../auth/login/phone-field';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { isFilled, shownError, str } from './part-utils';

/**
 * Q2 · Part 1 — Your digits (Figma 200:14952 enter mobile · 200:15156 OTP · 200:15387 verified + email ·
 * mobile 200:18303 OTP sheet). The number must be verified before Next (Primary disabled, hint says why).
 * A number already verified at login comes in verified. Email typos get a one-tap fix.
 */
@Component({
  selector: 'sm-q2-digits',
  imports: [PhoneField, Field, Input, Button, Tag, Switch, FormField],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q2Digits) }],
  template: `
    <div class="row">
      <sm-phone-field
        needed
        [value]="model().phone"
        (valueChange)="setPhone($event)"
        [error]="phoneError()"
        [status]="verified() ? 'valid' : 'none'"
        [helper]="verified() ? loginHint : ''"
      >
        @if (verified()) {
          <sm-tag tone="success" class="inline-tag" i18n="@@q2.verified">Verified</sm-tag>
        } @else {
          <button
            sm-button
            variant="accent"
            type="button"
            class="get-otp"
            [loading]="sending()"
            (click)="getCode()"
            i18n="@@q2.getOtp"
          >
            Get OTP
          </button>
        }
      </sm-phone-field>

      <div class="email">
        <sm-field
          i18n-label="@@login.emailLabel"
          label="Email"
          required
          [error]="emailError()"
          [status]="suggestion() ? 'warning' : emailOk() ? 'valid' : 'none'"
        >
          <sm-tag tone="danger" i18n="@@ui.needed">Needed</sm-tag>
          <sm-input
            type="email"
            inputmode="email"
            autocomplete="email"
            placeholder="you@email.com"
            [formField]="form.email"
          />
        </sm-field>
        @if (suggestion(); as fix) {
          <p class="suggest" role="status">
            <span i18n="@@q2.didYouMean">Did you mean {{ fix }}?</span>
            <button type="button" class="fix" (click)="applyFix(fix)" i18n="@@q2.fixIt">
              Yes, fix it
            </button>
          </p>
        }
      </div>
    </div>

    <div class="whatsapp">
      <sm-switch
        [checked]="model().whatsapp"
        (checkedChange)="setWhatsapp($event)"
        [describedBy]="waHelp"
      >
        <span class="wa-title" i18n="@@q2.whatsapp"
          >Send me course updates and reminders on WhatsApp</span
        >
      </sm-switch>
      <p class="wa-help" [id]="waHelp" i18n="@@q2.whatsappHelp">Optional. Turn it off anytime.</p>
    </div>
  `,
  styles: `
    :host {
      display: grid;
      gap: var(--sm-space-600);
    }

    .row {
      display: grid;
      grid-template-columns: repeat(
        auto-fit,
        minmax(min(var(--sm-layout-shell-map-width), 100%), 1fr)
      );
      gap: var(--sm-space-600);
    }

    .email {
      display: grid;
      gap: var(--sm-space-150);
      align-content: start;
    }

    .get-otp {
      --sm-size-control-lg: var(--sm-size-control-sm);
      flex: none;
      padding-inline: var(--sm-space-400);
    }

    .inline-tag {
      flex: none;
    }

    .suggest {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: var(--sm-space-200);
      color: var(--sm-color-feedback-warning-text);
      font: var(--sm-font-caption);
    }

    .fix {
      min-block-size: var(--sm-size-touch-min);
      margin-block: calc((var(--sm-size-touch-min) - 1lh) / -2);
      border: 0;
      background: none;
      color: var(--sm-color-text-link);
      font: var(--sm-font-caption-semibold);
      text-decoration: underline;
      cursor: pointer;
    }

    .whatsapp {
      display: grid;
      gap: var(--sm-space-100);
      padding: var(--sm-space-350) var(--sm-space-400);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-subtle);
      border-radius: var(--sm-radius-lg);
      background: var(--sm-color-surface-subtle);
    }

    .wa-title {
      color: var(--sm-color-text-primary);
      font: var(--sm-font-body-sm-medium);
    }

    .wa-help {
      padding-inline-start: calc(var(--sm-size-control-md) + var(--sm-space-300));
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }
  `,
})
export class Q2Digits implements QuestPart, OnInit {
  private readonly api = inject(CONTACT_API);
  private readonly auth = inject(Auth);
  private readonly market = inject(Market);
  private readonly overlay = inject(OverlayService);
  private readonly phoneField = viewChild(PhoneField);
  readonly context = input.required<QuestPartContext>();
  private readonly attempted = signal(false);
  protected readonly sending = signal(false);
  protected readonly codeError = signal('');
  protected readonly waHelp = uniqueId('q2-wa');
  protected readonly loginHint = $localize`:@@q2.loginHint:This is also how you’ll log in.`;

  protected readonly model = signal({
    phone: '',
    phoneVerified: false,
    email: '',
    whatsapp: false,
  });
  protected readonly form = form(this.model, (p) => {
    required(p.email, { message: $localize`:@@login.emailRequired:Pop in your email` });
    email(p.email, {
      message: $localize`:@@login.emailInvalid:That email looks off — check for typos`,
    });
  });

  protected readonly verified = computed(() => this.model().phoneVerified);
  protected readonly suggestion = computed(() => emailSuggestion(this.model().email));
  protected readonly emailOk = computed(
    () => this.form.email().valid() && isFilled(this.model().email),
  );
  protected readonly emailError = computed(() => shownError(this.form.email(), this.attempted()));
  protected readonly phoneError = computed(() => {
    if (this.codeError()) return this.codeError();
    if (!this.attempted() || this.verified()) return '';
    return isValidMobile(this.market.config(), this.model().phone)
      ? $localize`:@@q2.verifyFirst:Verify your number first`
      : $localize`:@@login.phoneShort:That number looks short — ${this.market.config().mobile.digits}:digits: digits, please`;
  });

  readonly total = 2;
  readonly answered = computed(() => (this.verified() ? 1 : 0) + (this.emailOk() ? 1 : 0));
  readonly blocked = computed(() => !this.verified());
  readonly hint = computed(() =>
    !this.verified()
      ? $localize`:@@q2.verifyFirst:Verify your number first`
      : this.suggestion()
        ? $localize`:@@q2.doubleCheck:1 thing to double-check`
        : '',
  );

  ngOnInit(): void {
    const a = this.context().answers;
    const user = this.auth.user();
    const savedPhone = str(a['phone']);
    const loginPhone = user?.phone ? nationalNumber(this.market.config(), user.phone) : '';
    this.model.set({
      phone: savedPhone || loginPhone,
      phoneVerified: a['phoneVerified'] === true || (!savedPhone && !!loginPhone),
      email: str(a['email']) || user?.email || '',
      whatsapp: a['whatsapp'] === true,
    });
  }

  protected setPhone(value: string): void {
    this.codeError.set('');
    this.model.update((m) => ({ ...m, phone: value, phoneVerified: false }));
  }

  protected setWhatsapp(on: boolean): void {
    this.model.update((m) => ({ ...m, whatsapp: on }));
  }

  protected applyFix(fix: string): void {
    this.model.update((m) => ({ ...m, email: fix }));
  }

  protected async getCode(): Promise<void> {
    const market = this.market.config();
    if (!isValidMobile(market, this.model().phone)) {
      this.attempted.set(true);
      return;
    }
    const phone = `${market.dialCode}${nationalNumber(market, this.model().phone)}`;
    this.sending.set(true);
    this.codeError.set('');
    try {
      const challenge = await firstValueFrom(this.api.sendPhoneCode(phone));
      const ref = this.overlay.adaptive<OtpDialog, OtpDialogData, OtpDialogResult>(OtpDialog, {
        data: {
          phone,
          challenge,
          verify: (code) => this.api.verifyPhone(phone, code),
          resend: () => this.api.sendPhoneCode(phone),
          verifyLabel: $localize`:@@q2.verifyNumber:Verify number`,
        },
        size: 'sm',
        autoFocus: OTP_AUTOFOCUS,
      });
      ref.closed.subscribe((result) => {
        if (result === 'verified') this.model.update((m) => ({ ...m, phoneVerified: true }));
        else if (result === 'edit') this.phoneField()?.focus();
      });
    } catch (err) {
      this.codeError.set(
        err instanceof ApiError && err.kind === 'offline'
          ? $localize`:@@otp.offline:You’re offline. Reconnect and try again.`
          : $localize`:@@q2.codeFailed:Couldn’t send the code. Try again in a sec.`,
      );
    } finally {
      this.sending.set(false);
    }
  }

  validate(): boolean {
    this.attempted.set(true);
    return this.verified() && this.form().valid();
  }

  value() {
    return this.model();
  }
}
