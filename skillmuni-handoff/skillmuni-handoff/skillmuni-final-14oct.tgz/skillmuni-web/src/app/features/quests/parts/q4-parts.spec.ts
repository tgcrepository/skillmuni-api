import { Component, signal, viewChild } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { QuestStore } from '../../../core/quests/quest-store';
import { QuestAnswers } from '../../../core/quests/quest.api';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { LanguageStamp, Trophy, expiryState, monthsUntil, stampProblem } from '../data/flex';
import {
  DeckSkill,
  customSkillProblem,
  nearMatch,
  playerStats,
  searchSkills,
  suggestions,
} from '../data/skills';
import { Q4Deck } from './q4-deck';
import { Q4Passport } from './q4-passport';

const skill = (
  id: string,
  category: DeckSkill['category'],
  level: DeckSkill['level'],
): DeckSkill => ({
  id,
  name: id,
  category,
  level,
  source: 'search',
});

describe('Q4 skill helpers', () => {
  it('searches names and synonyms, best match first', () => {
    // A-285: the ESCO sheet, with everyday synonyms.
    expect(searchSkills('excel').map((k) => k.name)).toContain('Microsoft Excel');
    expect(searchSkills('aws')[0]?.name).toBe('Amazon Web Services (AWS)');
    expect(searchSkills('pyth').map((k) => k.name)).toEqual(['Python']);
    expect(searchSkills('   ')).toEqual([]);
    expect(nearMatch('javascripts')?.name).toBe('JavaScript');
  });

  it('suggests from the Quest 3 branch, then popular skills', () => {
    const picks = suggestions('Computer Science').map((k) => k.id);
    expect(picks.slice(0, 3)).toEqual(['python', 'sql', 'javascript']);
    expect(suggestions('').length).toBeGreaterThan(8);
  });

  it('rejects long or unfriendly custom skills', () => {
    expect(customSkillProblem('Rangoli')).toBe('');
    expect(customSkillProblem('x'.repeat(41))).toContain('40 characters');
  });

  it('builds the Player Card: radar, class title, All-Rounder ties, empty under 3', () => {
    expect(playerStats([skill('a', 'tech', 3), skill('b', 'tech', 3)]).ready).toBe(false);
    const tech = playerStats([
      skill('a', 'tech', 3),
      skill('b', 'tech', 3),
      skill('c', 'people', 1),
    ]);
    expect(tech.classTitle).toBe('Code Crafter');
    expect(tech.radar.find((r) => r.id === 'tech')?.value).toBeCloseTo(0.4);
    const tie = playerStats([
      skill('a', 'tech', 3),
      skill('b', 'data', 3),
      skill('c', 'people', 1),
    ]);
    expect(tie.classTitle).toBe('All-Rounder');
    const capped = playerStats(Array.from({ length: 6 }, (_, i) => skill(`t${i}`, 'trades', 3)));
    expect(capped.radar.find((r) => r.id === 'trades')?.value).toBe(1);
    expect(capped.classTitle).toBe('Master Maker');
  });
});

describe('Q4 passport and trophy helpers', () => {
  const stamp = (s: Partial<LanguageStamp>): LanguageStamp => ({
    name: 'English',
    fluency: 'fluent',
    speak: true,
    read: false,
    write: false,
    motherTongue: false,
    fromCv: false,
    ...s,
  });

  it('needs a fluency and one ability per stamp', () => {
    expect(stampProblem(stamp({}))).toBe('');
    expect(stampProblem(stamp({ fluency: '' }))).toBe('fluency');
    expect(stampProblem(stamp({ speak: false }))).toBe('ability');
  });

  it('flags trophies expiring within 90 days and expired ones', () => {
    const today = new Date(2026, 9, 4);
    const t = (expiresOn: string, noExpiry = false) => ({ expiresOn, noExpiry }) as Trophy;
    expect(expiryState(t('2026-12'), today)).toBe('soon');
    expect(expiryState(t('2027-08'), today)).toBe('ok');
    expect(expiryState(t('2025-01'), today)).toBe('expired');
    expect(expiryState(t('', true), today)).toBe('none');
    expect(monthsUntil('2026-12', today)).toBe(2);
  });
});

@Component({
  imports: [Q4Deck, Q4Passport],
  template: `
    @if (which() === 'deck') {
      <sm-q4-deck [context]="{ answers: answers(), firstName: 'Yash' }" />
    } @else {
      <sm-q4-passport [context]="{ answers: answers(), firstName: 'Yash' }" />
    }
  `,
})
class Host {
  readonly which = signal<'deck' | 'passport'>('deck');
  readonly answers = signal<QuestAnswers>({});
  readonly deck = viewChild(Q4Deck);
  readonly passport = viewChild(Q4Passport);
}

async function setup(which: 'deck' | 'passport', answers: QuestAnswers = {}) {
  const store = {
    loadAnswers: vi.fn((slug: string) =>
      Promise.resolve(
        slug === 'who-dis' ? { homeLanguage: 'Hindi' } : { branch: 'Computer Science' },
      ),
    ),
  };
  TestBed.configureTestingModule({
    providers: [
      { provide: QuestStore, useValue: store },
      {
        provide: OverlayService,
        useValue: {
          isMobile: () => false,
          sheet: () => ({ closed: of(undefined), close: () => undefined }),
        },
      },
    ],
  });
  const fixture = TestBed.createComponent(Host);
  fixture.componentInstance.which.set(which);
  fixture.componentInstance.answers.set(answers);
  fixture.detectChanges();
  await fixture.whenStable();
  fixture.detectChanges();
  return { fixture, host: fixture.componentInstance, el: fixture.nativeElement as HTMLElement };
}

describe('Q4 parts', () => {
  it('deck: needs 3 skills with levels; the first 3 are signatures', async () => {
    const { fixture, host, el } = await setup('deck');
    const deck = host.deck();
    expect(deck?.blocked()).toBe(true);
    expect(deck?.hint()).toBe('Add 3 more skills');

    const card = (name: string) =>
      [...el.querySelectorAll<HTMLButtonElement>('button[role="checkbox"]')].find((b) =>
        b.getAttribute('aria-label')?.startsWith(`${name},`),
      );
    card('Python')?.click();
    fixture.detectChanges();
    expect(deck?.hint()).toBe('Set Python’s level to continue');
    const d = deck as unknown as { setLevel(l: 1 | 2 | 3): void; setSignature(on: boolean): void };
    d.setLevel(3);
    for (const name of ['SQL', 'Java', 'JavaScript']) {
      card(name)?.click();
      fixture.detectChanges();
      d.setLevel(2);
    }
    fixture.detectChanges();
    expect(deck?.blocked()).toBe(false);
    expect(card('Python')?.getAttribute('aria-checked')).toBe('true');

    // Pin JavaScript (4th) as a signature: it becomes 3rd, Java drops to 4th.
    card('JavaScript')?.click();
    d.setSignature(true);
    const ids = (deck?.value()['skills'] as DeckSkill[]).map((k) => k.id);
    expect(ids).toEqual(['python', 'sql', 'javascript', 'java']);
    expect(deck?.validate()).toBe(true);
  });

  it('passport: mother tongue from Quest 1 is pre-stamped; new stamps need a level', async () => {
    const { host } = await setup('passport', {
      languages: [
        {
          name: 'English',
          fluency: '',
          speak: true,
          read: false,
          write: false,
          motherTongue: false,
          fromCv: true,
        },
      ],
    });
    const passport = host.passport();
    const stamps = passport?.value()['languages'] as LanguageStamp[];
    expect(stamps.map((s) => [s.name, s.motherTongue])).toEqual([
      ['Hindi', true],
      ['English', false],
    ]);
    expect(passport?.hint()).toBe('Pick a level for English');
    expect(passport?.validate()).toBe(false);
  });
});
