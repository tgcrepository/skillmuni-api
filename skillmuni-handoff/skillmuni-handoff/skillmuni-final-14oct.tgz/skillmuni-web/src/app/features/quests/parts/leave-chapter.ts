import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, inject, viewChild } from '@angular/core';
import { Button } from '../../../shared/ui/button/button';
import { SmDialog } from '../../../shared/ui/overlay/dialog';

export interface LeaveChapterData {
  readonly filled: number;
}

/** Closing (Esc, scrim, X) means stay. */
export type LeaveChapterResult = 'save' | 'discard' | undefined;

/**
 * Q5 · Leaving with an unsaved chapter (Figma States §6, 200:30567): Back or the quest map with a
 * half-filled chapter asks "Save draft" or "Ditch it". Closing the tab uses the browser prompt instead.
 */
@Component({
  selector: 'sm-leave-chapter',
  imports: [SmDialog, Button],
  template: `
    <sm-dialog centered stacked [title]="title">
      <p class="body">{{ body }}</p>
      <div smDialogActions>
        <button
          sm-button
          variant="secondary"
          type="button"
          cdkFocusInitial
          (click)="dialog().close('save')"
          i18n="@@leave.save"
        >
          Save draft
        </button>
        <button
          sm-button
          variant="secondary"
          type="button"
          class="ditch"
          (click)="dialog().close('discard')"
          i18n="@@leave.ditch"
        >
          Ditch it
        </button>
      </div>
    </sm-dialog>
  `,
  styles: `
    .body {
      color: var(--sm-color-text-body);
      font: var(--sm-font-body);
      text-align: center;
    }

    [smDialogActions] .ditch {
      --_border: var(--sm-color-feedback-error-border);
      --_fg: var(--sm-color-feedback-error-text);
    }
  `,
})
export class LeaveChapter {
  protected readonly data = inject<LeaveChapterData>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@leave.title:Leave without saving this chapter?`;
  protected readonly body =
    this.data.filled === 1
      ? $localize`:@@leave.bodyOne:You’ve filled 1 field. Save it as a draft or ditch it.`
      : $localize`:@@leave.body:You’ve filled ${this.data.filled}:n: fields. Save it as a draft or ditch it.`;
}
