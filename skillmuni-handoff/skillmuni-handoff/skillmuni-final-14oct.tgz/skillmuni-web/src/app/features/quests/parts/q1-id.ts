import {
  Component,
  OnInit,
  computed,
  effect,
  forwardRef,
  inject,
  input,
  signal,
} from '@angular/core';
import { FormField, form, required, validate } from '@angular/forms/signals';
import { IdType, Market, birthdayFromSaId, isValidId } from '../../../core/market/market';
import { Banner } from '../../../shared/ui/banner/banner';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { IconButton } from '../../../shared/ui/icon-button/icon-button';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { BirthdayPicker, BirthdayPickerData } from './birthday-picker';
import { Segment, SegmentedControl } from '../../../shared/ui/segmented-control/segmented-control';
import { Tag } from '../../../shared/ui/tag/tag';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { MAX_AGE, MIN_AGE, ageOn, formatBirthday, parseBirthday } from './birthday';
import { isFilled, shownError, str } from './part-utils';
import { Button } from '../../../shared/ui/button/button';
import { Icon } from '../../../shared/ui/icon/icon';
import { ToastService } from '../../../shared/ui/toast/toast.service';
import { DigiLockerFlow } from '../../../shared/identity/digilocker-flow';
import { DigiDoc, LinkedId } from '../../../core/identity/identity.api';

const NO_ID: IdType = { id: 'id', label: 'ID', pattern: /.+/ };

/**
 * Q1 · Part 2 — ID & bday (Figma 200:11774 / 200:12782 / 200:13290). Government ID (type per market),
 * birthday (auto-filled from an SA ID number), age worked out for you, encryption reassurance.
 */
@Component({
  selector: 'sm-q1-id',
  imports: [Field, Input, Tag, Banner, SegmentedControl, FormField, IconButton, Button, Icon],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q1Id) }],
  template: `
    @if (types().length > 1) {
      <sm-segmented-control
        i18n-ariaLabel="@@q1.idType"
        ariaLabel="Which ID do you have?"
        [segments]="types()"
        [value]="model().idType"
        (valueChange)="setType($event)"
      />
    }
    @if (digi()) {
      <!-- A-272: India — identity via DigiLocker; we keep only the last 4 characters. -->
      <section class="digi" [class.is-linked]="!!model().idMasked" aria-labelledby="digi-title">
        <div class="digi-head">
          <h3 class="digi-title" id="digi-title">
            <ng-container i18n="@@q1.digiTitle">Verify with DigiLocker</ng-container>
          </h3>
          @if (model().idMasked) {
            <sm-tag tone="success" i18n="@@q1.digiVerified">Verified</sm-tag>
          } @else {
            <sm-tag tone="danger" i18n="@@ui.needed">Needed</sm-tag>
          }
        </div>
        @if (model().idMasked) {
          <p class="digi-linked">
            <sm-icon name="shield" size="sm" />
            <span>
              <strong>{{ type().label }} {{ model().idMasked }}</strong>
              <span class="digi-sub" i18n="@@q1.digiLinkedSub">Linked from DigiLocker · only the last 4 are kept</span>
            </span>
          </p>
          <button type="button" class="digi-unlink" (click)="unlink()" i18n="@@q1.digiUnlink">
            Use a different ID
          </button>
        } @else {
          <p class="digi-body" i18n="@@q1.digiBody">
            Share your {{ type().label }} from DigiLocker, the Government of India’s document wallet.
            We never see or store the full number or a copy, only the last 4 characters.
          </p>
          <div class="digi-actions">
            <button
              sm-button
              type="button"
              trailingIcon="arrow-right"
              [loading]="linking()"
              (click)="linkDigi()"
              i18n="@@q1.digiLink"
            >
              Link with DigiLocker
            </button>
            <a class="digi-help" href="https://www.digilocker.gov.in" target="_blank" rel="noopener" i18n="@@q1.digiNew"
              >New to DigiLocker? Set it up free<span class="sm-visually-hidden"> (opens in a new tab)</span></a
            >
          </div>
          @if (err.link(); as e) {
            <p class="digi-error" role="alert">{{ e }}</p>
          }
        }
      </section>
    } @else {
      <sm-field
        [label]="idLabel()"
        required
        [error]="err.id()"
        [status]="idOk() ? 'valid' : 'none'"
        [helper]="idHelper()"
      >
        <sm-tag tone="danger" i18n="@@ui.needed">Needed</sm-tag>
        <sm-input leadingIcon="lock" autocomplete="off" [formField]="form.idNumber" />
      </sm-field>
    }

    <div class="row">
      <sm-field
        i18n-label="@@q1.birthday"
        label="Birthday"
        required
        [error]="err.birthday()"
        [status]="birthdayOk() ? 'valid' : 'none'"
        [helper]="birthdayPretty()"
      >
        @if (fromDigi()) {
          <sm-tag tone="accent" i18n="@@q1.fromDigi">From DigiLocker</sm-tag>
        } @else if (fromId()) {
          <sm-tag tone="accent" i18n="@@q1.fromId">Auto-filled from your ID</sm-tag>
        }
        <sm-input
          class="bday"
          leadingIcon="calendar"
          readonly
          i18n-placeholder="@@q1.bdayPick"
          placeholder="Tap to pick your birthday"
          [value]="model().birthday"
          (click)="openPicker()"
          (keydown.enter)="openPicker()"
          (keydown.space)="$event.preventDefault(); openPicker()"
          (touch)="form.birthday().markAsTouched()"
        >
          @if (!fromId() && !fromDigi()) {
            <button
              sm-icon-button
              type="button"
              tone="ghost"
              icon="calendar"
              [size]="36"
              [label]="pickLabel"
              (click)="$event.stopPropagation(); openPicker()"
            ></button>
          }
        </sm-input>
      </sm-field>
      <sm-field bare i18n-label="@@q1.age" label="Age">
        <sm-input readonly [value]="ageText()" />
      </sm-field>
    </div>

    @if (digi()) {
      <sm-banner tone="success" i18n="@@q1.trustDigi"
        >Aadhaar rules: we don’t keep your ID number or a copy of it. DigiLocker confirms it’s you,
        and only the last 4 characters stay with us.</sm-banner
      >
    } @else {
      <sm-banner tone="success" i18n="@@q1.trust"
        >Bank-level encryption. We only use your ID to verify it’s you, never for anything
        else.</sm-banner
      >
    }
  `,
  styles: `
    :host {
      display: grid;
      gap: var(--sm-space-600);
    }

    .bday {
      cursor: pointer;
    }

    .digi {
      display: grid;
      gap: var(--sm-space-300);
      padding: var(--sm-space-500);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-default);
      border-radius: var(--sm-radius-3xl);
      background: var(--sm-color-surface-inset);
    }

    .digi.is-linked {
      border-color: var(--sm-color-feedback-success-border);
      animation: digi-in var(--sm-motion-duration-emphasized) var(--sm-motion-easing-spring);
    }

    .digi-head {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: var(--sm-space-200);
    }

    .digi-title {
      margin: 0;
      color: var(--sm-color-text-heading);
      font: var(--sm-font-label);
    }

    .digi-body,
    .digi-error {
      margin: 0;
      color: var(--sm-color-text-body);
      font: var(--sm-font-body-sm);
    }

    .digi-error {
      color: var(--sm-color-feedback-error-text);
      font: var(--sm-font-caption-semibold);
    }

    .digi-actions {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: var(--sm-space-300) var(--sm-space-500);
    }

    .digi-help,
    .digi-unlink {
      padding: 0;
      border: 0;
      background: none;
      color: var(--sm-color-text-brand);
      font: var(--sm-font-caption-semibold);
      text-decoration: underline;
      cursor: pointer;
      justify-self: start;
    }

    .digi-help:focus-visible,
    .digi-unlink:focus-visible {
      box-shadow: var(--sm-shadow-focus-ring);
      outline: none;
    }

    .digi-linked {
      display: flex;
      align-items: flex-start;
      gap: var(--sm-space-250);
      margin: 0;
      color: var(--sm-color-text-heading);
      font: var(--sm-font-body-sm-semibold);

      sm-icon {
        flex: none;
        color: var(--sm-color-feedback-success-icon);
      }

      span {
        display: grid;
        gap: var(--sm-space-50);
      }

      strong {
        font-variant-numeric: tabular-nums;
        letter-spacing: 0.04em;
      }
    }

    .digi-sub {
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }

    @keyframes digi-in {
      from {
        transform: scale(0.97);
      }
    }

    .row {
      display: grid;
      grid-template-columns: repeat(
        auto-fit,
        minmax(min(var(--sm-layout-shell-map-width), 100%), 1fr)
      );
      gap: var(--sm-space-600);
    }
  `,
})
export class Q1Id implements QuestPart, OnInit {
  private readonly market = inject(Market);
  private readonly overlay = inject(OverlayService);
  private readonly digiFlow = inject(DigiLockerFlow);
  private readonly toast = inject(ToastService);
  protected readonly linking = signal(false);
  readonly context = input.required<QuestPartContext>();
  private readonly attempted = signal(false);
  private readonly today = new Date();

  protected readonly model = signal({
    idType: '',
    idNumber: '',
    birthday: '',
    /** A-272 (DigiLocker): masked number and last 4 only — never the full number. */
    idMasked: '',
    idLast4: '',
    idVia: '',
  });
  /** India: identity through DigiLocker instead of typing the number. */
  protected readonly digi = computed(() => this.market.config().idVerification === 'digilocker');
  protected readonly fromDigi = computed(
    () => this.digi() && !!this.model().idMasked && !!this.model().birthday,
  );
  protected readonly types = computed<readonly Segment[]>(() =>
    this.market.config().idTypes.map((t) => ({ value: t.id, label: t.label })),
  );
  protected readonly type = computed((): IdType => {
    const types = this.market.config().idTypes;
    return types.find((t) => t.id === this.model().idType) ?? types[0] ?? NO_ID;
  });
  protected readonly fromId = computed(
    () =>
      this.market.config().idHasBirthday.includes(this.type().id) &&
      !!birthdayFromSaId(this.model().idNumber),
  );

  protected readonly form = form(this.model, (p) => {
    validate(p.idNumber, ({ value }) =>
      !this.digi() && !value()
        ? { kind: 'required', message: $localize`:@@q1.idRequired:Pop in your ID number` }
        : undefined,
    );
    validate(p.idNumber, ({ value }) =>
      value() && !isValidId(this.type(), value())
        ? {
            kind: 'id',
            message: $localize`:@@q1.idInvalid:That doesn’t look like a valid ${this.type().label}:type: number`,
          }
        : undefined,
    );
    required(p.birthday, { message: $localize`:@@q1.bdayRequired:Pop in your birthday` });
    validate(p.birthday, ({ value }) => {
      if (!value()) return undefined;
      const date = parseBirthday(value());
      if (!date)
        return {
          kind: 'date',
          message: $localize`:@@q1.bdayInvalid:That date doesn’t exist — check the day and month`,
        };
      const age = ageOn(date, this.today);
      if (age < MIN_AGE)
        return {
          kind: 'young',
          message: $localize`:@@q1.tooYoung:You need to be ${MIN_AGE}:min: or older to join`,
        };
      if (age > MAX_AGE)
        return { kind: 'old', message: $localize`:@@q1.checkYear:Double-check the year` };
      return undefined;
    });
  });

  protected readonly err = {
    id: computed(() => shownError(this.form.idNumber(), this.attempted())),
    link: computed(() =>
      this.digi() && this.attempted() && !this.model().idMasked
        ? $localize`:@@q1.digiRequired:Link your ID with DigiLocker to carry on`
        : '',
    ),
    birthday: computed(() => shownError(this.form.birthday(), this.attempted())),
  };
  protected readonly idOk = computed(
    () => this.form.idNumber().valid() && isFilled(this.model().idNumber),
  );
  protected readonly birthdayOk = computed(
    () => this.form.birthday().valid() && isFilled(this.model().birthday),
  );
  protected readonly idLabel = computed(
    () => $localize`:@@q1.idLabel:Government ID number (${this.type().label}:type:)`,
  );
  protected readonly idHelper = computed(() =>
    this.fromId()
      ? $localize`:@@q1.idFromBday:Valid ID. We clocked your birthday from it, so you don’t have to.`
      : this.idOk()
        ? $localize`:@@q1.idValid:Valid ID. Locked and encrypted.`
        : '',
  );
  protected readonly ageText = computed(() => {
    const date = parseBirthday(this.model().birthday);
    return date ? $localize`:@@q1.ageText:${ageOn(date, this.today)}:age:, we did the maths` : '';
  });

  protected readonly pickLabel = $localize`:@@q1.bdayOpen:Open the birthday picker`;
  protected readonly birthdayPretty = computed(() => {
    const date = parseBirthday(this.model().birthday);
    return date
      ? new Intl.DateTimeFormat(this.market.config().locale, {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        }).format(date)
      : '';
  });

  /** A-166: birthday comes from the picker (or the SA ID), never typed. */
  protected openPicker(): void {
    if (this.fromId() || this.fromDigi()) return;
    const ref = this.overlay.adaptive<BirthdayPicker, BirthdayPickerData, Date>(BirthdayPicker, {
      data: { value: parseBirthday(this.model().birthday), today: this.today },
      size: 'sm',
    });
    ref.closed.subscribe((date) => {
      this.form.birthday().markAsTouched();
      if (date) this.model.update((m) => ({ ...m, birthday: formatBirthday(date) }));
    });
  }

  readonly total = 2;
  readonly answered = computed(
    () =>
      ((this.digi() ? !!this.model().idMasked : this.idOk()) ? 1 : 0) +
      (this.birthdayOk() ? 1 : 0),
  );

  constructor() {
    // Live: as soon as a valid SA ID is typed, its birthday fills in.
    effect(() => {
      if (this.model().idNumber) this.syncBirthdayFromId();
    });
  }

  ngOnInit(): void {
    const a = this.context().answers;
    const types = this.market.config().idTypes;
    const saved = str(a['idType']);
    this.model.set({
      idType: types.some((t) => t.id === saved) ? saved : (types[0]?.id ?? ''),
      // A-272: a number typed before DigiLocker is never carried over in India.
      idNumber: this.digi() ? '' : str(a['idNumber']),
      birthday: str(a['birthday']),
      idMasked: str(a['idMasked']),
      idLast4: str(a['idLast4']),
      idVia: str(a['idVia']),
    });
  }

  protected setType(id: string): void {
    this.model.update((m) =>
      m.idType === id ? m : { ...m, idType: id, idMasked: '', idLast4: '', idVia: '' },
    );
  }

  /** A-272: consent on DigiLocker → masked record; the birthday comes verified with it. */
  protected async linkDigi(): Promise<void> {
    if (this.linking()) return;
    this.linking.set(true);
    try {
      const linked = await this.digiFlow.link(this.type().id as DigiDoc, this.type().label);
      if (linked) this.applyLinked(linked);
    } catch {
      this.toast.show(
        $localize`:@@q1.digiFail:DigiLocker didn’t connect. Give it another go in a moment.`,
        { tone: 'error' },
      );
    } finally {
      this.linking.set(false);
    }
  }

  protected async unlink(): Promise<void> {
    await this.digiFlow.unlink().catch(() => undefined);
    this.model.update((m) => ({ ...m, idMasked: '', idLast4: '', idVia: '', birthday: '' }));
  }

  private applyLinked(l: LinkedId): void {
    const [y, mo, d] = (l.birthday ?? '').split('-').map(Number);
    const date = y && mo && d ? new Date(y, mo - 1, d) : null;
    this.model.update((m) => ({
      ...m,
      idNumber: '',
      idMasked: l.masked,
      idLast4: l.last4,
      idVia: 'digilocker',
      birthday: date ? formatBirthday(date) : m.birthday,
    }));
    this.form.birthday().markAsTouched();
  }

  validate(): boolean {
    this.attempted.set(true);
    this.syncBirthdayFromId();
    return this.form().valid() && (!this.digi() || !!this.model().idMasked);
  }

  value() {
    this.syncBirthdayFromId();
    return this.model();
  }

  /** SA ID carries the birthday: fill it in (and keep it in sync) when the number is valid. */
  syncBirthdayFromId(): void {
    if (!this.market.config().idHasBirthday.includes(this.type().id)) return;
    const date = birthdayFromSaId(this.model().idNumber, this.today);
    const formatted = date ? formatBirthday(date) : null;
    if (formatted && formatted !== this.model().birthday) {
      this.model.update((m) => ({ ...m, birthday: formatted }));
    }
  }
}
