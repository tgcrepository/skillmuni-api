import { Component, OnInit, computed, forwardRef, inject, input, signal } from '@angular/core';
import { FormField, email, form, validate } from '@angular/forms/signals';
import { Market, isValidMobile } from '../../../core/market/market';
import { Banner } from '../../../shared/ui/banner/banner';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { Select, SelectOption } from '../../../shared/ui/select/select';
import { Tag } from '../../../shared/ui/tag/tag';
import { PhoneField } from '../../auth/login/phone-field';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { isFilled, shownError, str } from './part-utils';

const OTHER = 'other';
const SELF = 'self';

/**
 * Q2 · Part 2 — Backup contact, optional (Figma 200:15595 dropdown open · mobile 200:18462 sheet).
 * Everything is optional, but what's typed must be valid. "Other (type it in)" opens a text field.
 */
@Component({
  selector: 'sm-q2-backup',
  imports: [Field, Input, Select, Tag, Banner, PhoneField, FormField],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q2Backup) }],
  template: `
    <div class="grid">
      <sm-field i18n-label="@@q2.relation" label="Who are they to you?">
        <sm-tag>{{ optional }}</sm-tag>
        <sm-select
          [options]="relations"
          i18n-placeholder="@@q2.relationPh"
          placeholder="Pick one"
          [value]="model().relation || null"
          (valueChange)="set('relation', $event ?? '')"
        />
      </sm-field>
      @if (!isSelf()) {
        <sm-field i18n-label="@@q2.theirName" label="Their name">
          <sm-tag>{{ optional }}</sm-tag>
          <sm-input
            i18n-placeholder="@@q2.theirNamePh"
            placeholder="e.g. Sunita Verma"
            [formField]="form.name"
          />
        </sm-field>
      }
      @if (model().relation === other) {
        <sm-field i18n-label="@@q2.relationOwn" label="How do you know them?">
          <sm-input [formField]="form.relationText" />
        </sm-field>
      }
      <sm-phone-field
        optional
        [label]="isSelf() ? ownPhoneLabel : theirPhoneLabel"
        [value]="model().phone"
        (valueChange)="set('phone', $event)"
        [error]="phoneError()"
      />
      <sm-field i18n-label="@@q2.altEmail" label="Another email of yours" [error]="emailError()">
        <sm-tag>{{ optional }}</sm-tag>
        <sm-input
          type="email"
          inputmode="email"
          i18n-placeholder="@@q2.altEmailPh"
          placeholder="In case you lose access to the first one"
          [formField]="form.altEmail"
        />
      </sm-field>
    </div>
    <sm-banner tone="info" i18n="@@q2.backupNote"
      >We never message your backup contact for marketing. Only if your account needs
      recovering.</sm-banner
    >
  `,
  styles: `
    :host {
      display: grid;
      gap: var(--sm-space-600);
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(
        auto-fit,
        minmax(min(var(--sm-layout-shell-map-width), 100%), 1fr)
      );
      gap: var(--sm-space-600);
    }
  `,
})
export class Q2Backup implements QuestPart, OnInit {
  private readonly market = inject(Market);
  readonly context = input.required<QuestPartContext>();
  private readonly attempted = signal(false);
  protected readonly other = OTHER;
  protected readonly optional = $localize`:@@ui.optional:Optional`;
  protected readonly theirPhoneLabel = $localize`:@@q2.theirPhone:Their mobile number`;
  protected readonly ownPhoneLabel = $localize`:@@q2.ownPhone:Your other mobile number`;
  protected readonly isSelf = computed(() => this.model().relation === SELF);

  protected readonly relations: readonly SelectOption[] = [
    { value: SELF, label: $localize`:@@q2.self:Self (another number of mine)` },
    { value: 'parent', label: $localize`:@@q2.parent:Parent` },
    { value: 'guardian', label: $localize`:@@q2.guardian:Guardian` },
    { value: 'sibling', label: $localize`:@@q2.sibling:Sibling` },
    { value: 'partner', label: $localize`:@@q2.partner:Spouse / Partner` },
    { value: 'friend', label: $localize`:@@q2.friend:Friend` },
    { value: 'relative', label: $localize`:@@q2.relative:Relative` },
  ];

  protected readonly model = signal({
    relation: '',
    relationText: '',
    name: '',
    phone: '',
    altEmail: '',
  });
  protected readonly form = form(this.model, (p) => {
    email(p.altEmail, {
      message: $localize`:@@login.emailInvalid:That email looks off — check for typos`,
    });
    validate(p.altEmail, ({ value }) =>
      value() && value().toLowerCase() === str(this.context().answers['email']).toLowerCase()
        ? {
            kind: 'same',
            message: $localize`:@@q2.sameEmail:That’s the same as your main email — try a different one`,
          }
        : undefined,
    );
  });

  protected readonly emailError = computed(() =>
    shownError(this.form.altEmail(), this.attempted()),
  );
  protected readonly phoneError = computed(() =>
    this.attempted() &&
    this.model().phone &&
    !isValidMobile(this.market.config(), this.model().phone)
      ? $localize`:@@q2.backupPhone:That number doesn’t look right`
      : '',
  );

  /**
   * Corrections #8: everything here is optional. The step's +20 XP is earned only when the backup
   * mobile number is given; without it the learner still moves on, with no XP.
   */
  readonly earnsXp = computed(
    () => !!this.model().phone && isValidMobile(this.market.config(), this.model().phone),
  );
  readonly xpHint = $localize`:@@q2.backupXpHint:Add their mobile number to earn +20 XP`;

  readonly total = 4;
  readonly answered = computed(() => {
    const m = this.model();
    return [m.relation, m.name, m.phone, m.altEmail].filter(isFilled).length;
  });

  ngOnInit(): void {
    const a = this.context().answers;
    this.model.set({
      relation: str(a['relation']),
      relationText: str(a['relationText']),
      name: str(a['backupName']),
      phone: str(a['backupPhone']),
      altEmail: str(a['altEmail']),
    });
  }

  protected set(key: 'relation' | 'phone', value: string): void {
    this.model.update((m) => ({ ...m, [key]: value }));
  }

  validate(): boolean {
    this.attempted.set(true);
    return this.form().valid() && !this.phoneError();
  }

  value() {
    const m = this.model();
    return {
      relation: m.relation,
      relationText: m.relationText,
      backupName: m.name,
      backupPhone: m.phone,
      altEmail: m.altEmail,
    };
  }
}
