import type { Meta, StoryObj } from '@storybook/angular-vite';
import { DeckSkill, playerStats } from '../data/skills';
import { PowerPicker } from '../parts/power-picker';
import { PlayerCard, PlayerCardData } from './player-card';

const k = (
  id: string,
  name: string,
  category: DeckSkill['category'],
  level: DeckSkill['level'],
): DeckSkill => ({
  id,
  name,
  category,
  level,
  source: 'search',
});

const deck = [
  k('python', 'Python', 'tech', 3),
  k('react', 'React', 'tech', 2),
  k('sql', 'SQL', 'data', 3),
  k('git', 'Git & GitHub', 'tech', 2),
  k('excel', 'MS Excel', 'data', 2),
  k('communication', 'Communication', 'people', 2),
  k('cloud', 'Cloud basics (AWS)', 'tech', 1),
  k('canva', 'Canva', 'creative', 1),
];

const card = (skills: readonly DeckSkill[]): PlayerCardData => ({
  name: 'Yash Verma',
  stats: playerStats(skills),
  signatures: skills.slice(0, 3),
  skills: skills.length,
  languages: 3,
  trophies: 2,
});

/** Figma: Q4 Player Card (rail 200:24911 · reveal 200:26727 · States §8). */
const meta: Meta<PlayerCard> = {
  title: 'Quests/Player Card',
  component: PlayerCard,
  render: (args) => ({
    props: args,
    template: `<div style="max-inline-size: var(--sm-size-loot-card)"><sm-player-card [data]="data" [live]="live" /></div>`,
  }),
  parameters: { figma: { node: '200:24911' } },
};
export default meta;
type Story = StoryObj<PlayerCard & { data: PlayerCardData; live: boolean }>;

export const CodeCrafter: Story = { args: { data: card(deck), live: true } };
export const EmptyUnderThree: Story = { args: { data: card(deck.slice(0, 2)), live: true } };
export const Revealed: Story = { args: { data: card(deck), live: false } };

export const PowerLevelPicker: StoryObj<PowerPicker> = {
  render: () => ({
    moduleMetadata: { imports: [PowerPicker] },
    template: `<sm-power-picker skill="Python" [level]="2" />`,
  }),
};
