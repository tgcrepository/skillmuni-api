import { Component, OnInit, computed, forwardRef, input, signal } from '@angular/core';
import { FormField, form, maxLength, required } from '@angular/forms/signals';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { Tag } from '../../../shared/ui/tag/tag';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { isFilled, shownError, str } from './part-utils';

/** Q1 · Part 1 — Name (Figma 200:11572 / 200:12629 / 200:13165). First name pre-filled from sign-up. */
@Component({
  selector: 'sm-q1-name',
  imports: [Field, Input, Tag, FormField],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q1Name) }],
  template: `
    <div class="grid">
      <sm-field
        i18n-label="@@su.first"
        label="First name"
        required
        [error]="err.first()"
        [status]="ok(form.firstName)"
      >
        <sm-input
          autocomplete="given-name"
          i18n-placeholder="@@su.firstPh"
          placeholder="e.g. Yash"
          [formField]="form.firstName"
        />
      </sm-field>
      <sm-field
        i18n-label="@@su.last"
        label="Last name"
        required
        [error]="err.last()"
        [status]="ok(form.lastName)"
      >
        <sm-input
          autocomplete="family-name"
          i18n-placeholder="@@q1.lastPh"
          placeholder="Your last name"
          [formField]="form.lastName"
        />
      </sm-field>
      <sm-field
        i18n-label="@@q1.nick"
        label="Nickname"
        i18n-helper="@@q1.nickHelp"
        helper="Your nickname in the app. Totally optional."
      >
        <sm-tag i18n="@@ui.optional">Optional</sm-tag>
        <sm-input
          autocomplete="nickname"
          i18n-placeholder="@@q1.nickPh"
          placeholder="What your friends call you"
          [formField]="form.nickname"
        />
      </sm-field>
    </div>
  `,
  styles: `
    .grid {
      display: grid;
      grid-template-columns: repeat(
        auto-fit,
        minmax(min(var(--sm-layout-shell-map-width), 100%), 1fr)
      );
      gap: var(--sm-space-600);
    }
  `,
})
export class Q1Name implements QuestPart, OnInit {
  readonly context = input.required<QuestPartContext>();
  private readonly attempted = signal(false);

  protected readonly model = signal({ firstName: '', lastName: '', nickname: '' });
  protected readonly form = form(this.model, (p) => {
    const cert = $localize`:@@signup.nameNeeded:Needed for your records.`;
    required(p.firstName, { message: cert });
    required(p.lastName, { message: cert });
    maxLength(p.nickname, 30, { message: $localize`:@@q1.nickLong:Keep it under 30 characters` });
  });
  protected readonly err = {
    first: computed(() => shownError(this.form.firstName(), this.attempted())),
    last: computed(() => shownError(this.form.lastName(), this.attempted())),
  };

  readonly total = 2;
  readonly answered = computed(
    () => [this.model().firstName, this.model().lastName].filter(isFilled).length,
  );

  ngOnInit(): void {
    const a = this.context().answers;
    this.model.set({
      firstName: str(a['firstName']) || this.context().firstName,
      lastName: str(a['lastName']),
      nickname: str(a['nickname']),
    });
  }

  protected ok(field: typeof this.form.firstName) {
    const s = field();
    return s.valid() && isFilled(s.value()) ? 'valid' : 'none';
  }

  validate(): boolean {
    this.attempted.set(true);
    return this.form().valid();
  }

  value() {
    return this.model();
  }
}
