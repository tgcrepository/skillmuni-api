import { DOCUMENT } from '@angular/common';
import { Component, OnInit, computed, forwardRef, inject, input, signal } from '@angular/core';
import { Market } from '../../../core/market/market';
import { ChipGroup, ChipOption } from '../../../shared/ui/chip/chip-group';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { Select, SelectOption } from '../../../shared/ui/select/select';
import { Tag } from '../../../shared/ui/tag/tag';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { worldLanguages } from '../data/languages';
import { isFilled, str } from './part-utils';

const VISIBLE_LANGUAGES = 6;
const DESCRIBE = 'self-describe';
/** Home language answers beyond the market list (A-243). */
const OTHER_LANG = 'lang-other';
const DESCRIBE_LANG = 'lang-self-describe';
const OTHER_TYPE = 'other';
const list = (v: unknown): readonly string[] =>
  Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : [];

/**
 * Q1 · Part 3 — The tea (Figma 200:11987 / 200:12947 / 200:13426). Chip answers: identity (optional,
 * "I’ll describe it myself" opens a text field), home language (needed, "+ N more"), race (optional,
 * ZA only — employment-equity stats, A-97) and disability (optional).
 */
@Component({
  selector: 'sm-q1-tea',
  imports: [ChipGroup, Field, Input, Select, Tag],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q1Tea) }],
  template: `
    <section class="q">
      <h2 class="q-title" [id]="ids.gender">
        <ng-container i18n="@@q1.gender">How do you identify?</ng-container>
        <sm-tag i18n="@@ui.optional">Optional</sm-tag>
      </h2>
      <sm-chip-group
        [labelledBy]="ids.gender"
        [options]="genders"
        [value]="model().gender"
        (valueChange)="set('gender', $event)"
      />
      @if (model().gender === describe) {
        <sm-field i18n-label="@@q1.genderOwn" label="In your own words">
          <sm-input [value]="model().genderText" (valueChange)="set('genderText', $event)" />
        </sm-field>
      }
    </section>

    <section class="q">
      <h2 class="q-title" [id]="ids.language">
        <ng-container i18n="@@q1.language">What’s your home language?</ng-container>
        <sm-tag tone="danger" i18n="@@ui.needed">Needed</sm-tag>
      </h2>
      <sm-chip-group
        [labelledBy]="ids.language"
        [describedBy]="languageError() ? ids.languageError : ''"
        [options]="languages()"
        [value]="model().homeLanguage"
        (valueChange)="set('homeLanguage', $event)"
        [invalid]="!!languageError()"
        [addMoreLabel]="moreLabel()"
        (addMore)="allLanguages.set(true)"
      />
      @if (model().homeLanguage === otherLang) {
        <sm-field
          i18n-label="@@q1.langOther"
          label="Pick your language"
          required
          [error]="languageDetailError()"
          i18n-helper="@@q1.langOtherHelper"
          helper="Every language, in your own language’s name. Start typing to search."
        >
          <sm-select
            [options]="worldOptions()"
            [value]="model().homeLanguageOther || null"
            (valueChange)="set('homeLanguageOther', $event)"
            [searchable]="true"
            i18n-placeholder="@@q1.langSearch"
            placeholder="Search languages"
          />
        </sm-field>
      } @else if (model().homeLanguage === describeLang) {
        <sm-field
          i18n-label="@@q1.langOwn"
          label="Your home language, in your words"
          required
          [error]="languageDetailError()"
        >
          <sm-input
            autocomplete="off"
            [value]="model().homeLanguageText"
            (valueChange)="set('homeLanguageText', $event)"
          />
        </sm-field>
      }
      @if (languageError()) {
        <p class="error" [id]="ids.languageError" role="alert">{{ languageError() }}</p>
      }
    </section>

    @if (asksRace()) {
      <section class="q">
        <h2 class="q-title" [id]="ids.race">
          <ng-container i18n="@@q1.race">Race</ng-container>
          <sm-tag i18n="@@ui.optional">Optional</sm-tag>
          <span class="why" i18n="@@q1.raceWhy"
            >· Only for employment-equity stats. That’s it.</span
          >
        </h2>
        <sm-chip-group
          [labelledBy]="ids.race"
          [options]="races"
          [value]="model().race"
          (valueChange)="set('race', $event)"
        />
      </section>
    }

    <section class="q">
      <h2 class="q-title" [id]="ids.disability">
        <ng-container i18n="@@q1.disability">Do you have a disability?</ng-container>
        <sm-tag i18n="@@ui.optional">Optional</sm-tag>
        <span class="why" i18n="@@q1.disabilityWhy">· So we can set things up to work for you</span>
      </h2>
      <sm-chip-group
        [labelledBy]="ids.disability"
        [options]="disabilities"
        [value]="model().disability"
        (valueChange)="set('disability', $event)"
      />
    </section>

    @if (model().disability === 'yes') {
      <div class="details" role="group" [attr.aria-labelledby]="ids.disability">
        <section class="q">
          <h3 class="q-title" [id]="ids.dType">
            <ng-container i18n="@@q1.dType">What kind? Pick all that apply</ng-container>
            <sm-tag tone="danger" i18n="@@ui.needed">Needed</sm-tag>
          </h3>
          <sm-chip-group
            [multiple]="true"
            [labelledBy]="ids.dType"
            [describedBy]="typeError() ? ids.dTypeError : ''"
            [invalid]="!!typeError()"
            [options]="disabilityTypes"
            [value]="typesValue()"
            (valueChange)="setList('disabilityTypes', $event)"
          />
          @if (typeError()) {
            <p class="error" [id]="ids.dTypeError" role="alert">{{ typeError() }}</p>
          }
          @if (model().disabilityTypes.includes(otherType)) {
            <sm-field i18n-label="@@q1.dTypeOwn" label="Tell us in your own words">
              <sm-input
                [value]="model().disabilityOther"
                (valueChange)="set('disabilityOther', $event)"
              />
            </sm-field>
          }
        </section>

        @if (isIndia()) {
          <section class="q">
            <h3 class="q-title" [id]="ids.dPercent">
              <ng-container i18n="@@q1.dPercent">Disability % on your certificate</ng-container>
              <sm-tag i18n="@@ui.optional">Optional</sm-tag>
              <span class="why" i18n="@@q1.dPercentWhy">· 40% or more opens reserved jobs</span>
            </h3>
            <sm-chip-group
              [labelledBy]="ids.dPercent"
              [options]="percents"
              order="given"
              [value]="model().disabilityPercent"
              (valueChange)="set('disabilityPercent', $event)"
            />
          </section>
        }

        <sm-field
          [label]="certificateLabel()"
          i18n-helper="@@q1.dCertHelper"
          helper="Speeds up verification for reserved and inclusive roles."
        >
          <sm-tag i18n="@@ui.optional">Optional</sm-tag>
          <sm-input
            autocomplete="off"
            [value]="model().disabilityCertificate"
            (valueChange)="set('disabilityCertificate', $event)"
          />
        </sm-field>

        <section class="q">
          <h3 class="q-title" [id]="ids.dSupport">
            <ng-container i18n="@@q1.dSupport">Anything that helps you work or learn?</ng-container>
            <sm-tag i18n="@@ui.optional">Optional</sm-tag>
          </h3>
          <sm-chip-group
            [multiple]="true"
            [labelledBy]="ids.dSupport"
            [options]="supports"
            [value]="supportValue()"
            (valueChange)="setList('disabilitySupport', $event)"
          />
        </section>
        <p class="private" i18n="@@q1.dPrivate">
          Private by default. Employers only see this if you choose to share it.
        </p>
      </div>
    }
  `,
  styles: `
    :host {
      display: grid;
      gap: var(--sm-space-600);
    }

    .q {
      display: grid;
      gap: var(--sm-space-300);
    }

    .q-title {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: var(--sm-space-200);
      color: var(--sm-color-text-primary);
      font: var(--sm-font-label);
    }

    .why {
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-body-sm);
    }

    .error {
      color: var(--sm-color-feedback-error-text);
      font: var(--sm-font-caption);
    }

    .details {
      display: grid;
      gap: var(--sm-space-500);
      padding: var(--sm-space-500);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-subtle);
      border-radius: var(--sm-radius-2xl);
      background: var(--sm-color-surface-inset);
    }

    .private {
      margin: 0;
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }
  `,
})
export class Q1Tea implements QuestPart, OnInit {
  private readonly market = inject(Market);
  readonly context = input.required<QuestPartContext>();
  private readonly attempted = signal(false);
  protected readonly describe = DESCRIBE;
  protected readonly allLanguages = signal(false);
  protected readonly ids = {
    gender: uniqueId('q1-gender'),
    language: uniqueId('q1-language'),
    languageError: uniqueId('q1-language-error'),
    race: uniqueId('q1-race'),
    disability: uniqueId('q1-disability'),
    dType: uniqueId('q1-dtype'),
    dTypeError: uniqueId('q1-dtype-error'),
    dPercent: uniqueId('q1-dpercent'),
    dSupport: uniqueId('q1-dsupport'),
  };
  protected readonly otherType = OTHER_TYPE;
  protected readonly isIndia = computed(() => this.market.code() === 'IN');
  protected readonly certificateLabel = computed(() =>
    this.isIndia()
      ? $localize`:@@q1.dCertIn:UDID or disability certificate number`
      : $localize`:@@q1.dCertZa:Disability certificate or medical report number`,
  );
  /** Disability types (RPwD Act 2016 groups, plain words; A-164). */
  protected readonly disabilityTypes: readonly ChipOption[] = [
    { value: 'visual', label: $localize`:@@q1.dVisual:Seeing (blind or low vision)` },
    { value: 'hearing', label: $localize`:@@q1.dHearing:Hearing (deaf or hard of hearing)` },
    { value: 'locomotor', label: $localize`:@@q1.dLocomotor:Moving (physical or locomotor)` },
    { value: 'speech', label: $localize`:@@q1.dSpeech:Speech and language` },
    { value: 'learning', label: $localize`:@@q1.dLearning:Learning (e.g. dyslexia)` },
    { value: 'intellectual', label: $localize`:@@q1.dIntellectual:Intellectual` },
    { value: 'autism', label: $localize`:@@q1.dAutism:Autism spectrum` },
    { value: 'mental-health', label: $localize`:@@q1.dMental:Mental health` },
    { value: 'chronic', label: $localize`:@@q1.dChronic:Chronic condition` },
    { value: OTHER_TYPE, label: $localize`:@@q1.dOther:Something else` },
  ];
  protected readonly percents: readonly ChipOption[] = [
    { value: 'under-40', label: $localize`:@@q1.dUnder40:Below 40%` },
    { value: '40-79', label: $localize`:@@q1.d40:40–79%` },
    { value: '80-plus', label: $localize`:@@q1.d80:80% or more` },
    { value: 'not-sure', label: $localize`:@@q1.dNotSure:Not sure / no certificate` },
  ];
  protected readonly supports: readonly ChipOption[] = [
    { value: 'screen-reader', label: $localize`:@@q1.sReader:Screen reader-friendly docs` },
    { value: 'sign-language', label: $localize`:@@q1.sSign:Sign language interpreter` },
    { value: 'captions', label: $localize`:@@q1.sCaptions:Captions on videos` },
    { value: 'step-free', label: $localize`:@@q1.sAccess:Step-free access` },
    { value: 'flexible-hours', label: $localize`:@@q1.sFlex:Flexible hours` },
    { value: 'remote', label: $localize`:@@q1.sRemote:Work from home` },
    { value: 'extra-time', label: $localize`:@@q1.sTime:Extra time in tests` },
  ];
  protected readonly typesValue = computed(() => [...this.model().disabilityTypes]);
  protected readonly supportValue = computed(() => [...this.model().disabilitySupport]);
  protected readonly typeError = computed(() =>
    this.attempted() && this.model().disability === 'yes' && !this.model().disabilityTypes.length
      ? $localize`:@@q1.dTypeReq:Pick at least one, or choose “Rather not say” above`
      : '',
  );

  protected readonly model = signal({
    gender: '',
    genderText: '',
    homeLanguage: '',
    homeLanguageOther: '',
    homeLanguageText: '',
    race: '',
    disability: '',
    disabilityTypes: [] as readonly string[],
    disabilityOther: '',
    disabilityPercent: '',
    disabilityCertificate: '',
    disabilitySupport: [] as readonly string[],
  });

  protected readonly genders: readonly ChipOption[] = [
    { value: 'female', label: $localize`:@@q1.female:Female` },
    { value: 'male', label: $localize`:@@q1.male:Male` },
    { value: 'non-binary', label: $localize`:@@q1.nonBinary:Non-binary` },
    { value: DESCRIBE, label: $localize`:@@q1.describe:I’ll describe it myself` },
    { value: 'rather-not', label: $localize`:@@q1.ratherNot:Rather not say` },
  ];
  protected readonly races: readonly ChipOption[] = [
    { value: 'black-african', label: $localize`:@@q1.raceBlack:Black African` },
    { value: 'coloured', label: $localize`:@@q1.raceColoured:Coloured` },
    { value: 'indian', label: $localize`:@@q1.raceIndian:Indian` },
    { value: 'white', label: $localize`:@@q1.raceWhite:White` },
    { value: 'other', label: $localize`:@@q1.raceOther:Other` },
    { value: 'rather-not', label: $localize`:@@q1.ratherNot:Rather not say` },
  ];
  protected readonly disabilities: readonly ChipOption[] = [
    { value: 'no', label: $localize`:@@ui.no:No` },
    { value: 'yes', label: $localize`:@@ui.yes:Yes` },
    { value: 'rather-not', label: $localize`:@@q1.ratherNot:Rather not say` },
  ];

  protected readonly asksRace = computed(() => this.market.config().asksRace);
  protected readonly languages = computed<readonly ChipOption[]>(() => {
    const all = this.market.config().languages;
    const chosen = this.model().homeLanguage;
    const shown = this.allLanguages() ? all : all.slice(0, VISIBLE_LANGUAGES);
    const special = [OTHER_LANG, DESCRIBE_LANG];
    const list =
      chosen && !shown.includes(chosen) && !special.includes(chosen) ? [...shown, chosen] : shown;
    const extra: ChipOption[] = this.allLanguages()
      ? [
          { value: OTHER_LANG, label: $localize`:@@q1.langAnother:Another language` },
          { value: DESCRIBE_LANG, label: $localize`:@@q1.langDescribe:I’ll describe it myself` },
        ]
      : [];
    return [...list.map((l) => ({ value: l, label: l })), ...extra];
  });
  protected readonly otherLang = OTHER_LANG;
  protected readonly describeLang = DESCRIBE_LANG;
  private readonly locale = inject(DOCUMENT).documentElement.lang || 'en';
  protected readonly worldOptions = computed<readonly SelectOption[]>(() =>
    worldLanguages(this.locale).map((l) => ({ value: l, label: l })),
  );
  /** "Another language" needs a pick; "describe it myself" needs words. */
  private readonly languageDetailMissing = computed(() => {
    const m = this.model();
    if (m.homeLanguage === OTHER_LANG) return !m.homeLanguageOther;
    if (m.homeLanguage === DESCRIBE_LANG) return !m.homeLanguageText.trim();
    return false;
  });
  protected readonly languageDetailError = computed(() =>
    this.attempted() && this.languageDetailMissing()
      ? this.model().homeLanguage === OTHER_LANG
        ? $localize`:@@q1.langOtherRequired:Pick your language from the list`
        : $localize`:@@q1.langOwnRequired:Tell us your home language`
      : '',
  );
  protected readonly moreLabel = computed(() => {
    const hidden = this.market.config().languages.length - VISIBLE_LANGUAGES;
    // Always offer the rest: more market languages, any other language, or their own words.
    return this.allLanguages()
      ? ''
      : hidden > 0
        ? $localize`:@@q1.moreLangs:+ ${hidden}:n: more`
        : $localize`:@@q1.moreLangsOther:+ More languages`;
  });
  protected readonly languageError = computed(() =>
    this.attempted() && !this.model().homeLanguage
      ? $localize`:@@q1.langRequired:Pick your home language`
      : '',
  );

  private readonly languageDone = computed(
    () => !!this.model().homeLanguage && !this.languageDetailMissing(),
  );

  readonly total = computed(() => (this.asksRace() ? 4 : 3))();
  readonly answered = computed(() => {
    const m = this.model();
    const keys = this.asksRace()
      ? [m.gender, this.languageDone() ? 'y' : '', m.race, m.disability]
      : [m.gender, this.languageDone() ? 'y' : '', m.disability];
    return keys.filter(isFilled).length;
  });

  ngOnInit(): void {
    const a = this.context().answers;
    this.model.set({
      gender: str(a['gender']),
      genderText: str(a['genderText']),
      homeLanguage: str(a['homeLanguage']),
      homeLanguageOther: str(a['homeLanguageOther']),
      homeLanguageText: str(a['homeLanguageText']),
      race: str(a['race']),
      disability: str(a['disability']),
      disabilityTypes: list(a['disabilityTypes']),
      disabilityOther: str(a['disabilityOther']),
      disabilityPercent: str(a['disabilityPercent']),
      disabilityCertificate: str(a['disabilityCertificate']),
      disabilitySupport: list(a['disabilitySupport']),
    });
  }

  protected set(
    key: Exclude<keyof ReturnType<typeof this.model>, 'disabilityTypes' | 'disabilitySupport'>,
    value: string | string[] | null,
  ): void {
    this.model.update((m) => ({ ...m, [key]: typeof value === 'string' ? value : '' }));
  }

  protected setList(
    key: 'disabilityTypes' | 'disabilitySupport',
    value: string | string[] | null,
  ): void {
    this.model.update((m) => ({ ...m, [key]: Array.isArray(value) ? value : [] }));
  }

  validate(): boolean {
    this.attempted.set(true);
    const m = this.model();
    return this.languageDone() && (m.disability !== 'yes' || m.disabilityTypes.length > 0);
  }

  /** Details are only kept while the answer is "Yes"; language extras only for their chip. */
  value() {
    const raw = this.model();
    const m = {
      ...raw,
      homeLanguageOther: raw.homeLanguage === OTHER_LANG ? raw.homeLanguageOther : '',
      homeLanguageText: raw.homeLanguage === DESCRIBE_LANG ? raw.homeLanguageText : '',
    };
    return m.disability === 'yes'
      ? m
      : {
          ...m,
          disabilityTypes: [],
          disabilityOther: '',
          disabilityPercent: '',
          disabilityCertificate: '',
          disabilitySupport: [],
        };
  }
}
