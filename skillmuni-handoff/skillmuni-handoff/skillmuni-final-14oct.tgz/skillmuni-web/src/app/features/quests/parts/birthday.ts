/** "12041998" / "12 / 04 / 1998" → "12 / 04 / 1998" as the learner types (DD / MM / YYYY). */
export function maskBirthday(raw: string): string {
  const d = raw.replace(/\D/g, '').slice(0, 8);
  return [d.slice(0, 2), d.slice(2, 4), d.slice(4, 8)].filter(Boolean).join(' / ');
}

export function parseBirthday(masked: string): Date | null {
  const m = /^(\d{2}) \/ (\d{2}) \/ (\d{4})$/.exec(masked);
  if (!m) return null;
  const [dd, mm, yyyy] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const date = new Date(yyyy, mm - 1, dd);
  return date.getFullYear() === yyyy && date.getMonth() === mm - 1 && date.getDate() === dd
    ? date
    : null;
}

export function formatBirthday(date: Date): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${p(date.getDate())} / ${p(date.getMonth() + 1)} / ${date.getFullYear()}`;
}

export function ageOn(birthday: Date, today: Date): number {
  let age = today.getFullYear() - birthday.getFullYear();
  const m = today.getMonth() - birthday.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthday.getDate())) age--;
  return age;
}

/** Youngest and oldest ages we accept (A-98). */
export const MIN_AGE = 13;
export const MAX_AGE = 80;
