import { Component, OnInit, computed, forwardRef, inject, input, signal } from '@angular/core';
import { Market } from '../../../core/market/market';
import { Banner } from '../../../shared/ui/banner/banner';
import { ChipGroup, ChipOption } from '../../../shared/ui/chip/chip-group';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { Segment, SegmentedControl } from '../../../shared/ui/segmented-control/segmented-control';
import { Select, SelectOption } from '../../../shared/ui/select/select';
import { Tag } from '../../../shared/ui/tag/tag';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import {
  BOARDS,
  BRANCHES,
  COLLEGES,
  DEGREES,
  LEVELS,
  LevelKind,
  ScoreKind,
  yearsAhead,
  yearsBack,
} from '../data/education';
import { QUEST_PART, QuestPart, QuestPartContext } from '../quest-part';
import { isFilled, str } from './part-utils';

const opts = (list: readonly string[]): SelectOption[] => list.map((v) => ({ value: v, label: v }));

/**
 * Q3 · Part 2 — The details (Figma 200:20070 degree · 200:20331 college search + CGPA · 200:20587 still
 * studying · mobile 200:22932 / 200:23120). Fields follow the level: degree / course → degree, branch,
 * college (searchable, add your own), year, score; school → board, school, year, score; none → nothing.
 */
@Component({
  selector: 'sm-q3-details',
  imports: [Field, Input, Select, Tag, SegmentedControl, ChipGroup, Banner],
  providers: [{ provide: QUEST_PART, useExisting: forwardRef(() => Q3Details) }],
  templateUrl: './q3-details.html',
  styleUrl: './q2-spot.scss',
})
export class Q3Details implements QuestPart, OnInit {
  private readonly market = inject(Market);
  readonly context = input.required<QuestPartContext>();
  private readonly attempted = signal(false);
  private readonly thisYear = new Date().getFullYear();
  protected readonly needed = $localize`:@@ui.needed:Needed`;
  protected readonly optional = $localize`:@@ui.optional:Optional`;
  protected readonly degreeLabel = $localize`:@@q3.degree:Degree`;
  protected readonly courseLabel = $localize`:@@q3.course:Course / Trade`;
  protected readonly finishLabel = $localize`:@@q3.finish:Expected to finish`;
  protected readonly passLabel = $localize`:@@q3.pass:Year of passing`;
  protected readonly finishHelp = $localize`:@@q3.finishHelp:Only this year or later.`;
  protected readonly scoreLabel = $localize`:@@q3.scoreValue:Score`;
  protected readonly ids = { year: uniqueId('q3-year'), score: uniqueId('q3-score') };

  protected readonly model = signal({
    degree: '',
    branch: '',
    institute: '',
    board: '',
    year: '',
    studyYear: '',
    scoreKind: 'percentage' as ScoreKind,
    score: '',
  });

  protected readonly level = computed(() => str(this.context().answers['level']));
  protected readonly studying = computed(() => this.context().answers['status'] === 'studying');
  protected readonly kind = computed<LevelKind>(
    () => LEVELS[this.market.code()].find((l) => l.value === this.level())?.kind ?? 'degree',
  );
  protected readonly degreeOptions = computed(() => opts(DEGREES[this.level()] ?? []));
  protected readonly branchOptions = opts(BRANCHES);
  protected readonly boardOptions = computed(() => opts(BOARDS[this.market.code()]));
  protected readonly collegeOptions = computed(() => opts(COLLEGES[this.market.code()]));
  protected readonly yearOptions = computed(() =>
    opts(this.studying() ? yearsAhead(this.thisYear, 7) : yearsBack(this.thisYear, 50)),
  );
  protected readonly scoreKinds: readonly Segment[] = [
    { value: 'percentage', label: $localize`:@@q3.pct:Percentage` },
    { value: 'cgpa', label: $localize`:@@q3.cgpa:CGPA` },
    { value: 'grade', label: $localize`:@@q3.grade:Grade` },
  ];
  protected readonly studyYears: readonly ChipOption[] = [
    { value: '1', label: $localize`:@@q3.y1:1st year` },
    { value: '2', label: $localize`:@@q3.y2:2nd year` },
    { value: '3', label: $localize`:@@q3.y3:3rd year` },
    { value: 'final', label: $localize`:@@q3.yf:Final year` },
  ];
  protected readonly scoreSuffix = computed(() =>
    this.model().scoreKind === 'cgpa' ? '/ 10' : this.model().scoreKind === 'percentage' ? '%' : '',
  );
  protected readonly scorePlaceholder = computed(() =>
    this.model().scoreKind === 'cgpa'
      ? 'e.g. 7.8'
      : this.model().scoreKind === 'percentage'
        ? 'e.g. 78'
        : 'e.g. A',
  );

  protected readonly errors = computed(() => {
    const e: Record<string, string> = {};
    if (!this.attempted() || this.kind() === 'none') return e;
    const m = this.model();
    const need = $localize`:@@q3.need:Needed to match you right`;
    if (this.kind() === 'school') {
      if (!m.board) e['board'] = need;
      if (!m.institute) e['institute'] = need;
    } else {
      if (!m.degree) e['degree'] = need;
      if (!m.branch && !this.studying() && this.kind() === 'degree') e['branch'] = need;
      if (!m.institute) e['institute'] = need;
    }
    if (!m.year) e['year'] = need;
    if (this.studying() && !m.studyYear) e['studyYear'] = need;
    const score = this.scoreProblem();
    if (score) e['score'] = score;
    return e;
  });

  readonly total = 5;
  readonly answered = computed(() => {
    if (this.kind() === 'none') return 5;
    const m = this.model();
    const first = this.kind() === 'school' ? m.board : m.degree;
    return [
      first,
      this.kind() === 'school' ? 'x' : m.branch,
      m.institute,
      m.year,
      this.studying() ? m.studyYear : m.score,
    ].filter(isFilled).length;
  });

  ngOnInit(): void {
    const a = this.context().answers;
    this.model.set({
      degree: str(a['degree']),
      branch: str(a['branch']),
      institute: str(a['institute']),
      board: str(a['board']),
      year: str(a['year']),
      studyYear: str(a['studyYear']),
      scoreKind:
        (str(a['scoreKind']) as ScoreKind) || (this.market.code() === 'IN' ? 'cgpa' : 'percentage'),
      score: str(a['score']),
    });
  }

  protected set(key: keyof ReturnType<typeof this.model>, value: string | string[] | null): void {
    this.model.update((m) => ({ ...m, [key]: typeof value === 'string' ? value : '' }));
  }

  validate(): boolean {
    this.attempted.set(true);
    return Object.keys(this.errors()).length === 0;
  }

  value() {
    return this.model();
  }

  private scoreProblem(): string {
    const { score, scoreKind } = this.model();
    if (!score) return '';
    const n = Number(score);
    if (scoreKind === 'cgpa' && !(n >= 0 && n <= 10))
      return $localize`:@@q3.cgpaRange:CGPA is out of 10`;
    if (scoreKind === 'percentage' && !(n >= 0 && n <= 100))
      return $localize`:@@q3.pctRange:Percentages go from 0 to 100`;
    if (scoreKind === 'grade' && !/^[A-F][+-]?$/i.test(score.trim()))
      return $localize`:@@q3.gradeFmt:Use a grade like A, B+ or C`;
    return '';
  }
}
