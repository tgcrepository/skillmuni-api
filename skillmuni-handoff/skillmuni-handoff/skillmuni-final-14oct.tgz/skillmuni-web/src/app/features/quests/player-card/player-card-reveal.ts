import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, DestroyRef, computed, inject, signal, viewChild } from '@angular/core';
import { SoundFx } from '../../../core/audio/sound-fx';
import { levelFor } from '../../../core/quests/levels';
import { Button } from '../../../shared/ui/button/button';
import { Currency } from '../../../shared/ui/currency/currency';
import { LevelTrack } from '../../../shared/ui/level-track/level-track';
import { MuniAvatar } from '../../../shared/ui/muni/muni-avatar';
import { SpeechBubble } from '../../../shared/ui/muni/speech-bubble';
import { BadgeRing } from '../../../shared/ui/quest/badge-ring';
import { SmDialog } from '../../../shared/ui/overlay/dialog';
import { Confetti } from '../../../shared/ui/quest/confetti';
import { PlayerCard, PlayerCardData } from './player-card';
import { sharePlayerCard } from './share-card';

export interface PlayerCardRevealData {
  readonly eyebrow: string;
  readonly card: PlayerCardData;
  /** Corrections #12: the quest badge and XP, like every other quest-complete pop-up. */
  readonly quest: number;
  readonly badge: string;
  readonly xpEarned: number;
  readonly xpBefore: number;
  readonly levelUp?: string;
  /** "Next: Work Lore" — omitted on the last quest. */
  readonly nextLabel?: string;
}

export type PlayerCardRevealResult = 'continue' | 'edit' | 'later';

/**
 * Figma: Q4 Complete — Player Card reveal (200:26727 · tablet 200:27996 · mobile 200:29371). The card flips
 * in (500 ms) with slow rays, the radar draws its shape; reduced motion gets a fade. "Next: Work Lore" has
 * default focus; "Share my card" shares or downloads a 1080×1350 image; "Edit my deck" returns to Part 1.
 */
@Component({
  selector: 'sm-player-card-reveal',
  imports: [
    SmDialog,
    PlayerCard,
    Button,
    MuniAvatar,
    SpeechBubble,
    Confetti,
    BadgeRing,
    Currency,
    LevelTrack,
  ],
  template: `
    <sm-confetti />
    <sm-dialog [dismissible]="false" labelledBy="sm-reveal-title" class="reveal">
      <div class="layout">
        <div class="head">
          <p class="eyebrow">{{ data.eyebrow }}</p>
          <h2 class="title" id="sm-reveal-title">
            @if (data.card.stats.classTitle) {
              <span i18n="@@reveal.meet">Meet</span>&ngsp;<span class="highlight">{{
                data.card.stats.classTitle
              }}</span>
            } @else {
              <span i18n="@@reveal.cardReady">Your Player Card is</span>&ngsp;<span
                class="highlight"
                i18n="@@reveal.cardLive"
                >live</span
              >
            }
          </h2>
          <p class="lead" i18n="@@reveal.body">
            Your Player Card is ready. It shows up on your profile and when you apply for programmes.
          </p>
        </div>
        <div class="stage">
          <span class="rays" aria-hidden="true"></span>
          <sm-player-card class="card" [data]="data.card" />
        </div>
        <div class="earned">
          <div class="earned-badge">
            <sm-badge-ring [quest]="data.quest" [progress]="100" size="m" [label]="data.badge" />
            <span class="earned-text">
              <span class="earned-eyebrow" i18n="@@reveal.badgeEarned">Badge earned</span>
              <span class="earned-name">{{ data.badge }}</span>
            </span>
            <span class="xp-pill"
              ><sm-currency kind="xp" size="sm" pop /><ng-container i18n="@@complete.xpEarned"
                >+{{ data.xpEarned }} XP</ng-container
              ></span
            >
          </div>
          @if (data.levelUp) {
            <p class="level-up">{{ data.levelUp }}</p>
          }
          <sm-level-track [xp]="xp()" />
        </div>
        <div class="muni">
          <sm-muni-avatar [size]="96" />
          <sm-speech-bubble tail="left" aria-live="polite">{{ bubble() }}</sm-speech-bubble>
        </div>
      </div>
      <div smDialogActions class="actions">
        <button
          sm-button
          variant="secondary"
          type="button"
          [loading]="sharing()"
          [loadingLabel]="preparing"
          (click)="share()"
          i18n="@@reveal.share"
        >
          Share my card
        </button>
        <button
          sm-button
          variant="secondary"
          type="button"
          (click)="dialog().close('edit')"
          i18n="@@reveal.edit"
        >
          Edit my deck
        </button>
        <button
          sm-button
          trailingIcon="arrow-right"
          type="button"
          cdkFocusInitial
          (click)="dialog().close(data.nextLabel ? 'continue' : 'later')"
        >
          {{ data.nextLabel ?? doneLabel }}
        </button>
      </div>
    </sm-dialog>
  `,
  styleUrl: './player-card-reveal.scss',
})
export class PlayerCardReveal {
  protected readonly data = inject<PlayerCardRevealData>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly sharing = signal(false);
  protected readonly preparing = $localize`:@@reveal.preparing:Preparing…`;
  protected readonly doneLabel = $localize`:@@reveal.done:Back to my quests`;
  protected readonly bubble = signal(
    this.data.card.stats.classTitle
      ? $localize`:@@reveal.bubble:${this.data.card.stats.classTitle}:class:?! Okay, that’s a whole vibe. Screenshot it, flex it.`
      : $localize`:@@reveal.bubbleEmpty:Add a few skills to your deck and your class shows up here. Recruiters love that.`,
  );

  /** XP counts up from before to after, like the quest-complete pop-up. */
  protected readonly xp = signal(this.data.xpBefore);
  protected readonly lvl = computed(() => levelFor(this.xp()));

  constructor() {
    const before = levelFor(this.data.xpBefore).level;
    const end = this.data.xpBefore + this.data.xpEarned;
    inject(SoundFx).play(levelFor(end).level > before ? 'level' : 'badge');
    const reduce = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reduce || typeof requestAnimationFrame !== 'function') {
      this.xp.set(end);
      return;
    }
    const start = performance.now();
    let frame = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / 900);
      this.xp.set(Math.round(this.data.xpBefore + this.data.xpEarned * (1 - Math.pow(1 - t, 3))));
      if (t < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    inject(DestroyRef).onDestroy(() => cancelAnimationFrame(frame));
  }

  protected async share(): Promise<void> {
    this.sharing.set(true);
    const result = await sharePlayerCard(this.data.card);
    this.sharing.set(false);
    if (result === 'downloaded')
      this.bubble.set($localize`:@@reveal.saved:Saved as an image. Post it wherever you flex.`);
    else if (result === 'failed')
      this.bubble.set($localize`:@@reveal.failed:Couldn’t make the image this time. Try again?`);
  }
}
