import type { Meta, StoryObj } from '@storybook/angular-vite';
import { applicationConfig } from '@storybook/angular-vite';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { AUTH_API, AuthApi } from '../../core/auth/auth.api';
import { ForgotPasswordPage } from './forgot-password/forgot-password-page';
import { LoginPage } from './login/login-page';
import { SignupPage } from './signup/signup-page';
import { QuestBoard } from '../onboarding/quest-overview/quest-board';

const api: AuthApi = {
  sendOtp: () => of({ sentTo: '+91 98765 43210', resendIn: 30, triesLeft: 5 }),
  verifyOtp: () => of({ id: 'u', firstName: 'Yash' }),
  sendEmailLoginCode: () => of({ sentTo: 'ya•••@gmail.com', resendIn: 30, triesLeft: 5 }),
  verifyEmailLogin: () => of({ id: 'u', firstName: 'Yash' }),
  loginWithPassword: () => of({ id: 'u', firstName: 'Yash' }),
  requestPasswordReset: () => of({ resendIn: 45, validFor: 30 }),
  logout: () => of(undefined),
  me: () => of({ id: 'u', firstName: 'Yash' }),
  register: (d) => of({ email: d.email, resendIn: 42, validFor: 10, triesLeft: 5 }),
  verifyEmail: () => of({ id: 'u', firstName: 'Yash' }),
  resendEmailCode: (email) => of({ email, resendIn: 42, validFor: 10, triesLeft: 5 }),
  googleSignIn: () => of({ user: { id: 'u', firstName: 'Yash' }, isNew: false }),
};

const meta: Meta = {
  title: 'Screens/6a Auth',
  decorators: [
    applicationConfig({
      providers: [provideRouter([]), provideHttpClient(), { provide: AUTH_API, useValue: api }],
    }),
  ],
  parameters: {
    layout: 'fullscreen',
    figma: {
      node: 'E0 200:8009 · E0b 201:8488 · L1 201:9060 · FP1 201:8594 · FP2 201:8678 · R1 200:43972',
    },
  },
};
export default meta;

export const Login: StoryObj = {
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [LoginPage] } })],
  render: () => ({ template: `<sm-login-page />` }),
};

export const Signup: StoryObj = {
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [SignupPage] } })],
  render: () => ({ template: `<sm-signup-page />` }),
};

export const ForgotPassword: StoryObj = {
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [ForgotPasswordPage] } })],
  render: () => ({ template: `<sm-forgot-password-page />` }),
};

export const QuestBoards: StoryObj = {
  parameters: { layout: 'padded' },
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [QuestBoard] } })],
  render: () => ({
    template: `
      <div style="display:grid;gap:var(--sm-space-800)">
        <sm-quest-board [completed]="1" layout="path" />
        <sm-quest-board [completed]="1" layout="grid" />
        <div style="max-inline-size:var(--sm-size-auth-card-width)"><sm-quest-board [completed]="1" layout="list" /></div>
      </div>`,
  }),
};
