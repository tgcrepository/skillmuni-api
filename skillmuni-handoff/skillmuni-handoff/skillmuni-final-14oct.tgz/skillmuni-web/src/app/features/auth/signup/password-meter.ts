import { Component, computed, input } from '@angular/core';
import { StatusIcon } from '../../../shared/ui/status-icon/status-icon';
import { passwordChecks, passwordStrength, strengthLabel } from './password-rules';

/**
 * Figma SU "Strength meter" + "Password rules" (200:9992 / 200:9999). Four bars and a label, then the
 * three rules: grey dot (not checked yet) · green check (met) · red alert (missed, after submit).
 * The label is announced politely; rules are a list so screen readers hear what's left.
 */
@Component({
  selector: 'sm-password-meter',
  imports: [StatusIcon],
  template: `
    @if (level() > 0) {
      <div class="meter">
        <span class="bars" aria-hidden="true">
          @for (i of bars; track i) {
            <span class="bar" [class.is-on]="i <= level()"></span>
          }
        </span>
        <span class="label" aria-live="polite">{{ label() }}</span>
      </div>
    }
    <ul class="rules" i18n-aria-label="@@pw.rules" aria-label="Password needs">
      @for (rule of checks(); track rule.id) {
        <li class="rule" [class.is-met]="rule.met" [class.is-missed]="showErrors() && !rule.met">
          @if (rule.met) {
            <sm-status-icon tone="success" />
          } @else if (showErrors()) {
            <sm-status-icon tone="error" />
          } @else {
            <span class="dot" aria-hidden="true"></span>
          }
          <span>{{ rule.label }}</span>
          <span class="sm-visually-hidden">
            @if (rule.met) {
              <ng-container i18n="@@pw.done">done</ng-container>
            } @else {
              <ng-container i18n="@@pw.todo">not yet</ng-container>
            }
          </span>
        </li>
      }
    </ul>
  `,
  styleUrl: './password-meter.scss',
  host: { '[class]': '"sm-password-meter level-" + level()' },
})
export class PasswordMeter {
  readonly value = input.required<string>();
  /** After a failed submit, unmet rules turn red. */
  readonly showErrors = input(false);

  protected readonly bars = [1, 2, 3, 4] as const;
  protected readonly checks = computed(() => passwordChecks(this.value()));
  protected readonly level = computed(() => passwordStrength(this.value()));
  protected readonly label = computed(() => strengthLabel(this.level()));
}
