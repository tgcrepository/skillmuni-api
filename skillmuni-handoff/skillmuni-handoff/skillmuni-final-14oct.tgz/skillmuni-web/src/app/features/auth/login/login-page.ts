import { Component, computed, inject, input, signal, viewChild } from '@angular/core';
import {
  FormField,
  disabled,
  email,
  form,
  required,
  submit,
  validate,
} from '@angular/forms/signals';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../../core/api/api-error';
import { AUTH_API, SignupPrefill } from '../../../core/auth/auth.api';
import { Auth } from '../../../core/auth/auth';
import { Market, isValidMobile, nationalNumber } from '../../../core/market/market';
import { Banner } from '../../../shared/ui/banner/banner';
import { Button } from '../../../shared/ui/button/button';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { Segment, SegmentedControl } from '../../../shared/ui/segmented-control/segmented-control';
import { TextLink } from '../../../shared/ui/text-link/text-link';
import { AuthLayout } from '../layout/auth-layout';
import { OTP_AUTOFOCUS, OtpDialog, OtpDialogData, OtpDialogResult } from './otp-dialog';
import { PhoneField } from './phone-field';
import { GoogleSignInFlow } from '../google/google-sign-in';

type Method = 'otp' | 'email';
type Blocker = 'locked' | 'offline' | 'server' | 'wrong-credentials' | null;

/**
 * E0 Login · Mobile OTP (200:8009 / 200:9623 / 200:9662), E0b Email & password (201:8488 …),
 * L1 code entry (modal / sheet). Each method keeps its own typed value (A-17).
 * Loading = button spinner + inputs locked (A-14); locked account = error banner + support link (A-16).
 */
@Component({
  selector: 'sm-login-page',
  imports: [
    AuthLayout,
    SegmentedControl,
    PhoneField,
    Field,
    Input,
    Button,
    Banner,
    TextLink,
    RouterLink,
    FormField,
  ],
  templateUrl: './login-page.html',
  styleUrl: './login-page.scss',
})
export class LoginPage {
  private readonly api = inject(AUTH_API);
  private readonly auth = inject(Auth);
  private readonly market = inject(Market);
  private readonly overlay = inject(OverlayService);
  private readonly router = inject(Router);
  private readonly phoneField = viewChild(PhoneField);

  /** `?returnUrl=` from SE1 or a guard. */
  readonly returnUrl = input<string | undefined>(undefined);

  protected readonly busy = signal(false);
  protected readonly methods: readonly Segment[] = [
    { value: 'otp', label: $localize`:@@login.otp:Mobile` },
    { value: 'email', label: $localize`:@@login.emailCode:Email` },
  ];
  protected readonly method = signal<Method>('otp');
  protected readonly blocker = signal<Blocker>(null);

  protected readonly otpModel = signal({ phone: '' });
  protected readonly otpForm = form(this.otpModel, (p) => {
    disabled(p.phone, () => this.busy());
    required(p.phone, { message: $localize`:@@login.phoneRequired:Pop in your mobile number` });
    validate(p.phone, ({ value }) => {
      const v = value();
      if (!v) return undefined;
      const market = this.market.config();
      return isValidMobile(market, v)
        ? undefined
        : {
            kind: 'phone',
            message:
              nationalNumber(market, v).length < market.mobile.digits
                ? $localize`:@@login.phoneShort:That number looks short — ${market.mobile.digits}:digits: digits, please`
                : $localize`:@@login.phoneInvalid:That doesn’t look like a ${market.name}:country: mobile number`,
          };
    });
  });

  protected readonly emailModel = signal({ email: '' });
  protected readonly emailForm = form(this.emailModel, (p) => {
    disabled(p, () => this.busy());
    required(p.email, { message: $localize`:@@login.emailRequired:Pop in your email` });
    email(p.email, {
      message: $localize`:@@login.emailInvalid:That email looks off — check for typos`,
    });
  });

  protected readonly phoneError = computed(() => fieldError(this.otpForm.phone()));
  protected readonly emailError = computed(() => fieldError(this.emailForm.email()));

  protected setMethod(value: string): void {
    this.method.set(value === 'email' ? 'email' : 'otp');
    this.blocker.set(null);
  }

  protected async sendCode(event: Event): Promise<void> {
    event.preventDefault();
    if (this.busy()) return;
    await submit(this.otpForm, async () => {
      this.busy.set(true);
      this.blocker.set(null);
      const phone = `${this.market.config().dialCode}${nationalNumber(this.market.config(), this.otpModel().phone)}`;
      try {
        const challenge = await firstValueFrom(this.api.sendOtp(phone));
        this.openCode({ phone, challenge });
      } catch (err) {
        if (notRegistered(err)) await this.toSignup({ from: 'login', phone: this.prettyPhone() });
        else this.fail(err);
      } finally {
        this.busy.set(false);
      }
      return undefined;
    });
  }

  /** Email login (A-159): code to the inbox, verified in the same code dialog as mobile. */
  protected async sendEmailCode(event: Event): Promise<void> {
    event.preventDefault();
    if (this.busy()) return;
    await submit(this.emailForm, async () => {
      this.busy.set(true);
      this.blocker.set(null);
      const address = this.emailModel().email.trim();
      try {
        const challenge = await firstValueFrom(this.api.sendEmailLoginCode(address));
        this.openCode({
          phone: address,
          challenge,
          verify: (code) => this.auth.verifyEmailLogin(address, code),
          resend: () => this.api.sendEmailLoginCode(address),
          editWhat: $localize`:@@otp.editEmail:email`,
        });
      } catch (err) {
        if (notRegistered(err)) await this.toSignup({ from: 'login', email: address });
        else this.fail(err);
      } finally {
        this.busy.set(false);
      }
      return undefined;
    });
  }

  /** A-308: no account for that mobile / email → sign-up, carrying what was typed. */
  private async toSignup(state: SignupPrefill): Promise<void> {
    await this.router.navigateByUrl('/signup', { state: { ...state } });
  }

  private prettyPhone(): string {
    const m = this.market.config();
    const d = nationalNumber(m, this.otpModel().phone);
    const cut = Math.ceil(d.length / 2);
    return `${m.dialCode} ${d.slice(0, cut)} ${d.slice(cut)}`;
  }

  /** A-253: new Google account → quests; existing learner → the Lobby (or the return URL). */
  protected readonly googleBusy = signal(false);
  private readonly googleFlow = inject(GoogleSignInFlow);
  protected async google(): Promise<void> {
    if (this.googleBusy()) return;
    this.googleBusy.set(true);
    try {
      await this.googleFlow.start(this.returnUrl());
    } finally {
      this.googleBusy.set(false);
    }
  }

  private openCode(data: OtpDialogData): void {
    const ref = this.overlay.adaptive<OtpDialog, OtpDialogData, OtpDialogResult>(OtpDialog, {
      data,
      size: 'sm',
      autoFocus: OTP_AUTOFOCUS,
    });
    ref.closed.subscribe((result) => {
      if (result === 'edit') {
        if (this.method() === 'otp') this.phoneField()?.focus();
        else document.querySelector<HTMLInputElement>('input[type="email"]')?.focus();
      } else if (result) void this.done();
    });
  }

  private async done(): Promise<void> {
    await this.router.navigateByUrl(this.auth.nextUrl(this.returnUrl()));
  }

  private fail(err: unknown): void {
    const code = err instanceof ApiError ? err.fieldErrors['code']?.[0] : undefined;
    if (code === 'account-locked') this.blocker.set('locked');
    else if (code === 'wrong-credentials') this.blocker.set('wrong-credentials');
    else if (err instanceof ApiError && err.kind === 'offline') this.blocker.set('offline');
    else this.blocker.set('server');
  }
}

function notRegistered(err: unknown): boolean {
  return err instanceof ApiError && err.fieldErrors['code']?.[0] === 'account-not-found';
}

function fieldError(state: {
  touched(): boolean;
  errors(): readonly { message?: string }[];
}): string {
  return state.touched() ? (state.errors()[0]?.message ?? '') : '';
}
