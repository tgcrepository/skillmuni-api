import { GoogleSignInFlow } from '../google/google-sign-in';
import { Component, DestroyRef, ElementRef, computed, inject, signal, viewChild } from '@angular/core';
import {
  FormField,
  disabled,
  email,
  form,
  required,
  submit,
  validate,
} from '@angular/forms/signals';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../../core/api/api-error';
import { AUTH_API, AuthUser, EmailChallenge, SignupPrefill } from '../../../core/auth/auth.api';
import { Auth } from '../../../core/auth/auth';
import { Market } from '../../../core/market/market';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { Banner } from '../../../shared/ui/banner/banner';
import { Button } from '../../../shared/ui/button/button';
import { Checkbox } from '../../../shared/ui/checkbox/checkbox';
import { Field } from '../../../shared/ui/field/field';
import { FieldStatus } from '../../../shared/ui/field/field-context';
import { Icon } from '../../../shared/ui/icon/icon';
import { IconButton } from '../../../shared/ui/icon-button/icon-button';
import { Input } from '../../../shared/ui/input/input';
import { Otp } from '../../../shared/ui/otp/otp';
import { Pill } from '../../../shared/ui/pill/pill';
import { StatusIcon } from '../../../shared/ui/status-icon/status-icon';
import { TextLink } from '../../../shared/ui/text-link/text-link';
import { AuthLayout } from '../layout/auth-layout';
import { PasswordMeter } from './password-meter';
import { passwordChecks } from './password-rules';

type Step = 'form' | 'verify' | 'done';
type VerifyError = 'invalid' | 'expired' | 'locked' | 'offline' | 'server' | null;

/** Where a brand-new learner goes after VE4: E1 Intro — Meet Muni. */
export const ONBOARDING_START = '/start';
const SECOND = 1000;

/**
 * SU1–SU4 Sign up (200:9714 · 200:10198 · 200:10698 …) → VE1–VE3 Verify email → VE4 Verified.
 * One route; "Edit it" returns to the form with everything kept. Muni's pill reacts to the state.
 */
@Component({
  selector: 'sm-signup-page',
  imports: [
    AuthLayout,
    Field,
    Input,
    IconButton,
    Checkbox,
    Button,
    Banner,
    TextLink,
    RouterLink,
    FormField,
    PasswordMeter,
    Otp,
    Pill,
    StatusIcon,
    Icon,
  ],
  templateUrl: './signup-page.html',
  styleUrls: ['../login/login-page.scss', './signup-page.scss'],
})
export class SignupPage {
  /** A-253: new Google account → quests; an existing learner is simply signed in → the Lobby. */
  protected readonly googleBusy = signal(false);
  private readonly googleFlow = inject(GoogleSignInFlow);
  protected async google(): Promise<void> {
    if (this.googleBusy()) return;
    this.googleBusy.set(true);
    try {
      await this.googleFlow.start();
    } finally {
      this.googleBusy.set(false);
    }
  }

  private readonly api = inject(AUTH_API);
  private readonly auth = inject(Auth);
  private readonly router = inject(Router);
  protected readonly market = inject(Market);
  private readonly overlay = inject(OverlayService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly otp = viewChild(Otp);
  private readonly goBtn = viewChild('go', { read: ElementRef<HTMLElement> });

  /** A-308: sent here from login because that mobile / email has no account yet. */
  protected readonly prefill = readPrefill(this.router);

  protected readonly step = signal<Step>('form');
  protected readonly busy = signal(false);
  protected readonly attempted = signal(false);
  protected readonly emailTaken = signal(false);
  protected readonly failed = signal<'offline' | 'server' | null>(null);
  protected readonly showPassword = signal(false);
  protected readonly showLabel = $localize`:@@login.showPassword:Show password`;
  protected readonly hideLabel = $localize`:@@login.hidePassword:Hide password`;

  protected readonly model = signal({
    firstName: '',
    lastName: '',
    email: this.prefill?.email ?? '',
    password: '',
    consent: false,
  });
  protected readonly form = form(this.model, (p) => {
    disabled(p, () => this.busy());
    const cert = $localize`:@@signup.nameNeeded:Needed for your records.`;
    required(p.firstName, { message: cert });
    required(p.lastName, { message: cert });
    required(p.email, { message: $localize`:@@login.emailRequired:Pop in your email` });
    email(p.email, {
      message: $localize`:@@login.emailInvalid:That email looks off — check for typos`,
    });
    validate(p.email, () =>
      this.emailTaken()
        ? { kind: 'taken', message: $localize`:@@signup.taken:Already in the squad.` }
        : undefined,
    );
    required(p.password, { message: $localize`:@@signup.passwordRequired:Create a password` });
    validate(p.password, ({ value }) =>
      value() && passwordChecks(value()).some((c) => !c.met)
        ? {
            kind: 'weak',
            message: $localize`:@@signup.weak:Make it a bit stronger — see what’s missing below.`,
          }
        : undefined,
    );
    validate(p.consent, ({ value }) =>
      value()
        ? undefined
        : { kind: 'consent', message: $localize`:@@signup.consent:Tick this to continue.` },
    );
  });

  protected readonly errors = {
    firstName: computed(() => this.err(this.form.firstName())),
    lastName: computed(() => this.err(this.form.lastName())),
    email: computed(() => this.err(this.form.email())),
    password: computed(() => this.err(this.form.password())),
    consent: computed(() => this.err(this.form.consent())),
  };
  protected readonly statuses = {
    firstName: computed(() => this.ok(this.form.firstName())),
    lastName: computed(() => this.ok(this.form.lastName())),
    email: computed(() => this.ok(this.form.email())),
  };

  // ---- verify ----
  protected readonly challenge = signal<EmailChallenge | null>(null);
  protected readonly code = signal('');
  protected readonly verifyError = signal<VerifyError>(null);
  protected readonly triesLeft = signal(5);
  protected readonly secondsLeft = signal(0);
  protected readonly user = signal<AuthUser | null>(null);
  protected readonly countdown = computed(() => {
    const s = this.secondsLeft();
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  });
  protected readonly canVerify = computed(() => this.code().length === 6 && !this.busy());

  protected readonly hello = computed(() => {
    switch (this.step()) {
      case 'done':
        return $localize`:@@ve.helloDone:Yesss! You’re officially in!`;
      case 'verify':
        return this.verifyError() === 'invalid'
          ? $localize`:@@ve.helloWrong:Hmm, that’s not it. Try again?`
          : this.verifyError() === 'expired'
            ? $localize`:@@ve.helloExpired:That code took a nap. Grab a new one!`
            : $localize`:@@ve.hello:Check your inbox, bestie!`;
      default:
        if (this.emailTaken()) return $localize`:@@su.helloTaken:Wait... I think I know you!`;
        if (this.attempted() && this.form().invalid())
          return $localize`:@@su.helloFix:Almost there, just a few fixes.`;
        if (this.form().valid()) return $localize`:@@su.helloGood:Ooh, looking good already!`;
        if (this.prefill) return $localize`:@@su.helloFromLogin:New face! Let’s get you set up.`;
        return $localize`:@@su.hello:New here? I’ll be your guide!`;
    }
  });

  constructor() {
    const id = setInterval(() => this.secondsLeft.update((s) => Math.max(0, s - 1)), SECOND);
    this.destroyRef.onDestroy(() => clearInterval(id));
  }

  /** The consent box is bound by hand so it only turns red after a submit, not on load. */
  /** Opens the policy over the form (A-289); modified clicks still open /legal/privacy in a new tab. */
  protected async openPolicy(event: MouseEvent): Promise<void> {
    event.stopPropagation();
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.button !== 0) return;
    event.preventDefault();
    const { LegalDrawer } = await import('../../legal/legal-drawer');
    this.overlay.fullscreen(LegalDrawer, {
      data: 'privacy',
      ariaLabel: $localize`:@@legal.title:Privacy Policy & Terms`,
    });
  }

  protected setConsent(checked: boolean): void {
    this.model.update((m) => ({ ...m, consent: checked }));
    this.form.consent().markAsTouched();
  }

  protected onEmailInput(): void {
    if (this.emailTaken()) this.emailTaken.set(false);
  }

  protected async create(event: Event): Promise<void> {
    event.preventDefault();
    if (this.busy()) return;
    this.attempted.set(true);
    await submit(this.form, async () => {
      this.busy.set(true);
      this.failed.set(null);
      try {
        const challenge = await firstValueFrom(this.api.register(this.model()));
        this.startVerify(challenge);
      } catch (err) {
        if (err instanceof ApiError && err.fieldErrors['code']?.[0] === 'email-taken') {
          this.emailTaken.set(true);
          this.form.email().markAsTouched();
        } else {
          this.failed.set(err instanceof ApiError && err.kind === 'offline' ? 'offline' : 'server');
        }
      } finally {
        this.busy.set(false);
      }
      return undefined;
    });
  }

  protected onCode(value: string): void {
    this.code.set(value);
    if (value && this.verifyError() !== 'expired' && this.verifyError() !== 'locked')
      this.verifyError.set(null);
  }

  protected async verify(): Promise<void> {
    const c = this.challenge();
    if (!c || !this.canVerify()) return;
    this.busy.set(true);
    try {
      this.user.set(await firstValueFrom(this.auth.verifyEmail(c.email, this.code())));
      this.step.set('done');
      // Corrections #4: no auto-advance; the learner moves on with “Let’s gooo”.
      setTimeout(() => this.goBtn()?.nativeElement.focus());
    } catch (err) {
      const code = err instanceof ApiError ? err.fieldErrors['code']?.[0] : undefined;
      if (code === 'code-expired') this.verifyError.set('expired');
      else if (code === 'too-many-tries') this.verifyError.set('locked');
      else if (code === 'invalid-code') {
        const left = Number(err instanceof ApiError ? err.fieldErrors['triesLeft']?.[0] : NaN);
        if (Number.isFinite(left)) this.triesLeft.set(left);
        this.verifyError.set('invalid');
      } else
        this.verifyError.set(
          err instanceof ApiError && err.kind === 'offline' ? 'offline' : 'server',
        );
    } finally {
      this.busy.set(false);
    }
    // Wrong code: boxes clear (still red) and focus returns so the learner can just retype.
    if (this.verifyError() === 'invalid') {
      this.code.set('');
      setTimeout(() => this.otp()?.focus());
    }
  }

  protected async resend(): Promise<void> {
    const c = this.challenge();
    if (!c) return;
    this.busy.set(true);
    try {
      this.startVerify(await firstValueFrom(this.api.resendEmailCode(c.email)));
    } catch (err) {
      this.verifyError.set(
        err instanceof ApiError && err.kind === 'offline' ? 'offline' : 'server',
      );
    } finally {
      this.busy.set(false);
    }
  }

  protected edit(): void {
    this.step.set('form');
    this.challenge.set(null);
  }

  protected continue(): void {
    if (this.step() === 'done') void this.router.navigateByUrl(ONBOARDING_START);
  }

  private startVerify(challenge: EmailChallenge): void {
    this.challenge.set(challenge);
    this.triesLeft.set(challenge.triesLeft);
    this.secondsLeft.set(challenge.resendIn);
    this.code.set('');
    this.verifyError.set(null);
    this.step.set('verify');
    setTimeout(() => this.otp()?.focus());
  }

  private err(state: { touched(): boolean; errors(): readonly { message?: string }[] }): string {
    return state.touched() || this.attempted() ? (state.errors()[0]?.message ?? '') : '';
  }

  private ok(state: { touched(): boolean; valid(): boolean; value(): unknown }): FieldStatus {
    return state.touched() && state.valid() && !!state.value() ? 'valid' : 'none';
  }
}

function readPrefill(router: Router): SignupPrefill | null {
  const state = (router.currentNavigation()?.extras.state ?? history.state) as
    | Partial<SignupPrefill>
    | null;
  if (state?.from !== 'login' || (!state.email && !state.phone)) return null;
  return { from: 'login', email: state.email, phone: state.phone };
}
