import { Routes } from '@angular/router';
import { requireGuest, requireSession } from '../../core/auth/auth.guard';

export const authRoutes: Routes = [
  {
    path: 'login',
    canActivate: [requireGuest],
    title: $localize`:@@route.login:Log in · Skillmuni`,
    loadComponent: () => import('./login/login-page').then((m) => m.LoginPage),
  },
  {
    path: 'login/forgot',
    canActivate: [requireGuest],
    title: $localize`:@@route.forgot:Reset your password · Skillmuni`,
    loadComponent: () =>
      import('./forgot-password/forgot-password-page').then((m) => m.ForgotPasswordPage),
  },
  {
    path: 'signup',
    canActivate: [requireGuest],
    title: $localize`:@@route.signup:Join the squad · Skillmuni`,
    loadComponent: () => import('./signup/signup-page').then((m) => m.SignupPage),
  },
  {
    path: 'welcome-back',
    title: $localize`:@@route.welcome:Welcome back · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./welcome-back/welcome-back-page').then((m) => m.WelcomeBackPage),
  },
];
