import { NgOptimizedImage } from '@angular/common';
import { Component, booleanAttribute, input, signal } from '@angular/core';
import { ASSETS } from '../../../shared/assets';
import { BrandLogo } from '../../../shared/shell/brand-logo';
import { PageBackground } from '../../../shared/shell/page-background';
import { MuniAvatar } from '../../../shared/ui/muni/muni-avatar';

/**
 * Frame for the logged-out screens. Figma: E0 desktop (200:8009) · tablet (200:9623) · mobile (200:9662).
 * Desktop: full-bleed illustration, glass card on the right holding logo, Muni hello, form, "Powered by".
 * Tablet / mobile: glows background; logo + Muni hello above a centred card; tagline + "Powered by" below.
 */
@Component({
  selector: 'sm-auth-layout',
  imports: [NgOptimizedImage, BrandLogo, PageBackground, MuniAvatar],
  templateUrl: './auth-layout.html',
  styleUrl: './auth-layout.scss',
  host: { class: 'sm-auth-layout', '[class.is-contained]': 'contained()' },
})
export class AuthLayout {
  /** Muni's hello pill, e.g. "Yooo, you’re back! I missed you". Empty hides it. */
  readonly hello = input('');
  /** Sign-up / verify (SU*, VE*): the glass card holds the logo at every size, over the photo. */
  readonly contained = input(false, { transform: booleanAttribute });
  protected readonly background = ASSETS.loginBackground;
  protected readonly bgMissing = signal(false);
}
