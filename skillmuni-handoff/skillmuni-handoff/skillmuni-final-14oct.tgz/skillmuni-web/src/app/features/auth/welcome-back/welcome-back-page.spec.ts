import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import { LearnerProgress, PROGRESS_API } from '../../../core/progress/progress.api';
import { WelcomeBackPage } from './welcome-back-page';

const base: LearnerProgress = {
  completed: 1,
  partsDone: 0,
  xp: 230,
  badges: 1,
  level: 1,
  rank: 'Rookie',
  target: 400,
};

async function setup(get: () => Observable<LearnerProgress>) {
  TestBed.configureTestingModule({
    providers: [provideRouter([]), { provide: PROGRESS_API, useValue: { get } }],
  });
  const fixture = TestBed.createComponent(WelcomeBackPage);
  fixture.detectChanges();
  await fixture.whenStable();
  fixture.detectChanges();
  return fixture.nativeElement as HTMLElement;
}

describe('WelcomeBackPage (R1)', () => {
  it('resumes the next quest and lists all 8 with status', async () => {
    const el = await setup(() => of(base));
    expect(el.querySelector('h1')?.textContent).toContain('Pick up where you left off');
    expect(el.querySelector('.cta button')?.textContent).toContain('Resume Hit Me Up');
    expect(el.querySelectorAll('sm-quest-board li')).toHaveLength(8);
    expect(el.querySelector('li[aria-current="step"]')?.textContent).toContain('Hit Me Up');
  });

  it('first run and all-done copy', async () => {
    let el = await setup(() => of({ ...base, completed: 0 }));
    expect(el.querySelector('.cta button')?.textContent).toContain('Start Who Dis?');
    TestBed.resetTestingModule();
    el = await setup(() => of({ ...base, completed: 8 }));
    expect(el.querySelector('h1')?.textContent).toContain('You’re all set');
  });

  it('error state offers a retry', async () => {
    const el = await setup(() => throwError(() => new Error('down')));
    expect(el.querySelector('sm-state-block')?.textContent).toContain('Couldn’t load your quests');
  });
});
