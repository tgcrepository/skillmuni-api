import { Component, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { LearnerProgress, PROGRESS_API } from '../../../core/progress/progress.api';
import { QUESTS, questById } from '../../../core/quests/quest-catalog';
import { delayed } from '../../../shared/util/delayed';
import { Button } from '../../../shared/ui/button/button';
import { Pill } from '../../../shared/ui/pill/pill';
import { Skeleton } from '../../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../../shared/ui/state-block/state-block';
import { ToastService } from '../../../shared/ui/toast/toast.service';
import {
  OVERVIEW_CONTENT_STYLES,
  QuestOverview,
} from '../../onboarding/quest-overview/quest-overview';

/** Router state flag set by Save & exit (Figma 200:44079) so R1 confirms the save. */
export interface WelcomeBackState {
  readonly saved?: boolean;
}

/**
 * R1 Welcome back — resume quests. Desktop 200:43972 · tablet 200:43874 · mobile 200:43556.
 * States: loading (skeleton after 400 ms), error (retry), first run (nothing done yet), all done.
 */
@Component({
  selector: 'sm-welcome-back-page',
  imports: [QuestOverview, Button, Pill, Skeleton, StateBlock],
  templateUrl: './welcome-back-page.html',
  styles: [
    OVERVIEW_CONTENT_STYLES,
    `
      .skeleton {
        display: grid;
        gap: var(--sm-space-400);
      }
    `,
  ],
})
export class WelcomeBackPage {
  private readonly api = inject(PROGRESS_API);
  private readonly router = inject(Router);

  protected readonly progress = signal<LearnerProgress | null>(null);
  protected readonly loading = signal(true);
  protected readonly failed = signal(false);
  protected readonly showSkeleton = delayed(this.loading);
  protected readonly total = QUESTS.length;

  protected readonly next = computed(() => {
    const p = this.progress();
    return p && p.completed < this.total ? (questById(p.completed + 1) ?? null) : null;
  });
  protected readonly allDone = computed(() => (this.progress()?.completed ?? 0) >= this.total);
  protected readonly firstRun = computed(
    () => this.progress()?.completed === 0 && !this.progress()?.partsDone,
  );
  protected readonly exclaim = computed(() =>
    this.allDone()
      ? $localize`:@@welcome.exclaimDone:Slay!`
      : this.firstRun()
        ? $localize`:@@welcome.exclaimFirst:Hey, welcome!`
        : $localize`:@@welcome.exclaim:Welcome back!`,
  );

  constructor() {
    const state = this.router.currentNavigation()?.extras.state as WelcomeBackState | undefined;
    if (state?.saved) {
      inject(ToastService).show($localize`:@@shell.saved:Progress saved. Pick up anytime.`);
    }
    void this.load();
  }

  protected async load(): Promise<void> {
    this.loading.set(true);
    this.failed.set(false);
    try {
      this.progress.set(await firstValueFrom(this.api.get()));
    } catch {
      this.failed.set(true);
    } finally {
      this.loading.set(false);
    }
  }

  protected resume(): void {
    const next = this.next();
    void this.router.navigateByUrl(next ? `/quests/${next.slug}` : '/matches');
  }
}
