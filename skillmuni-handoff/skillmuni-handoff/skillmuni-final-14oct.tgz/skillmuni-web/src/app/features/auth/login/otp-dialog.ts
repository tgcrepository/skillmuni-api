import { DIALOG_DATA } from '@angular/cdk/dialog';
import {
  Component,
  DestroyRef,
  ElementRef,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { Observable, firstValueFrom } from 'rxjs';
import { ApiError } from '../../../core/api/api-error';
import { AUTH_API, AuthUser, OtpChallenge } from '../../../core/auth/auth.api';
import { Auth } from '../../../core/auth/auth';
import { Button } from '../../../shared/ui/button/button';
import { Otp, OtpStatus } from '../../../shared/ui/otp/otp';
import { SmDialog } from '../../../shared/ui/overlay/dialog';

export interface OtpDialogData {
  readonly phone: string;
  readonly challenge: OtpChallenge;
  /** Override for non-login checks (e.g. verifying a contact number in Q2). Defaults to log-in. */
  readonly verify?: (code: string) => Observable<unknown>;
  readonly resend?: () => Observable<OtpChallenge>;
  /** Primary button label; defaults to "Verify & log in". */
  readonly verifyLabel?: string;
  /** What "Edit" changes, for screen readers ("number" by default, "email" for email login). */
  readonly editWhat?: string;
}

/** `edit` = learner wants to change the number; otherwise the signed-in user. */
export type OtpDialogResult = AuthUser | 'verified' | 'edit' | undefined;

const SECOND = 1000;

/** Open with this so focus lands on the code boxes, not the "Edit" link. */
export const OTP_AUTOFOCUS = 'sm-otp input';

/**
 * L1 "Enter the 6-digit code" — modal on tablet/desktop (201:9132), bottom sheet on mobile (201:8461).
 * Verify unlocks at 6 digits (and fires automatically when a full code is pasted / autofilled).
 * States: wrong code (unlimited tries, never counted on screen — corrections #7), expired,
 * a silent server-side abuse limit, offline. Resend unlocks after the countdown.
 */
@Component({
  selector: 'sm-otp-dialog',
  imports: [SmDialog, Otp, Button],
  templateUrl: './otp-dialog.html',
  styleUrl: './otp-dialog.scss',
})
export class OtpDialog {
  private readonly data = inject<OtpDialogData>(DIALOG_DATA);
  private readonly api = inject(AUTH_API);
  private readonly auth = inject(Auth);
  private readonly dialog = viewChild.required(SmDialog);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;

  protected readonly verifyLabel =
    this.data.verifyLabel ?? $localize`:@@otp.verify:Verify & log in`;
  protected readonly editWhat = this.data.editWhat ?? $localize`:@@otp.editNumber:number`;
  protected readonly sentTo = signal(this.data.challenge.sentTo);
  protected readonly code = signal('');
  protected readonly busy = signal(false);
  protected readonly resending = signal(false);
  protected readonly triesLeft = signal(this.data.challenge.triesLeft);
  protected readonly secondsLeft = signal(this.data.challenge.resendIn);
  protected readonly error = signal<'invalid' | 'expired' | 'locked' | 'offline' | 'server' | null>(
    null,
  );

  protected readonly status = computed<OtpStatus>(() => (this.error() ? 'error' : 'none'));
  protected readonly canVerify = computed(
    () => this.code().length === 6 && this.error() !== 'expired' && this.error() !== 'locked',
  );
  protected readonly countdown = computed(() => {
    const s = this.secondsLeft();
    return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  });

  constructor() {
    const id = setInterval(() => this.secondsLeft.update((s) => Math.max(0, s - 1)), SECOND);
    inject(DestroyRef).onDestroy(() => clearInterval(id));
  }

  protected onInput(value: string): void {
    this.code.set(value);
    if (
      (this.error() === 'invalid' && value) ||
      this.error() === 'offline' ||
      this.error() === 'server'
    ) {
      this.error.set(null);
    }
  }

  protected async verify(): Promise<void> {
    if (!this.canVerify() || this.busy()) return;
    this.busy.set(true);
    try {
      if (this.data.verify) {
        await firstValueFrom(this.data.verify(this.code()));
        this.dialog().close('verified');
      } else {
        const user = await firstValueFrom(this.auth.verifyOtp(this.data.phone, this.code()));
        this.dialog().close(user);
      }
    } catch (err) {
      this.handle(err);
    } finally {
      this.busy.set(false);
    }
    // Wrong code: boxes clear (still red) and focus returns so the learner can just retype.
    if (this.error() === 'invalid') {
      this.code.set('');
      setTimeout(() => this.host.querySelector<HTMLInputElement>('sm-otp input')?.focus());
    }
  }

  protected async resend(): Promise<void> {
    this.resending.set(true);
    try {
      const challenge = await firstValueFrom(
        this.data.resend?.() ?? this.api.sendOtp(this.data.phone),
      );
      this.sentTo.set(challenge.sentTo);
      this.triesLeft.set(challenge.triesLeft);
      this.secondsLeft.set(challenge.resendIn);
      this.code.set('');
      this.error.set(null);
    } catch (err) {
      this.handle(err);
    } finally {
      this.resending.set(false);
    }
  }

  protected edit(): void {
    this.dialog().close('edit');
  }

  private handle(err: unknown): void {
    if (!(err instanceof ApiError)) {
      this.error.set('server');
      return;
    }
    const code = err.fieldErrors['code']?.[0];
    if (err.kind === 'offline') this.error.set('offline');
    else if (code === 'code-expired') this.error.set('expired');
    else if (code === 'too-many-tries' || code === 'account-locked') this.error.set('locked');
    else if (code === 'invalid-code') {
      const left = Number(err.fieldErrors['triesLeft']?.[0]);
      if (Number.isFinite(left)) this.triesLeft.set(left);
      this.error.set('invalid');
    } else this.error.set('server');
  }
}
