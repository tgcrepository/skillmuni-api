import {
  Component,
  ElementRef,
  booleanAttribute,
  computed,
  inject,
  input,
  model,
  output,
} from '@angular/core';
import type { FormValueControl } from '@angular/forms/signals';
import { Market, MarketCode } from '../../../core/market/market';
import { Field } from '../../../shared/ui/field/field';
import { FieldStatus } from '../../../shared/ui/field/field-context';
import { Tag } from '../../../shared/ui/tag/tag';
import { Input } from '../../../shared/ui/input/input';

/**
 * Figma: "Phone field row" (201:8565) — country code select + number, one "Mobile number" label.
 * The code follows the learner's market (A-12) and is fixed — no picker (A-231).
 */
@Component({
  selector: 'sm-phone-field',
  imports: [Field, Input, Tag],
  template: `
    <sm-field
      [label]="label()"
      [helper]="helper()"
      [error]="error()"
      [status]="status()"
      [required]="!optional()"
    >
      @if (needed()) {
        <sm-tag tone="danger" i18n="@@ui.needed">Needed</sm-tag>
      }
      <div class="row">
        <span class="code" [class.code--off]="disabled()">
          <span aria-hidden="true">{{ flagOf(market.code()) }}</span>
          <span class="sm-visually-hidden" i18n="@@phone.codeSr">Country code</span>
          {{ market.config().dialCode }}
        </span>
        <sm-input
          type="tel"
          inputmode="tel"
          autocomplete="tel-national"
          [placeholder]="market.config().mobile.example"
          [(value)]="value"
          [invalid]="!!error()"
          [disabled]="disabled()"
          (touch)="touch.emit()"
        >
          <ng-content />
        </sm-input>
      </div>
    </sm-field>
  `,
  styles: `
    .row {
      display: grid;
      grid-template-columns: auto minmax(0, 1fr);
      gap: var(--sm-space-200);
    }

    /* Fixed country code (A-231): the market comes from config, not a picker. */
    .code {
      display: inline-flex;
      align-items: center;
      gap: var(--sm-space-150);
      min-block-size: var(--sm-layout-control-height);
      padding-inline: var(--sm-space-400);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-default);
      border-radius: var(--sm-radius-xl);
      background: var(--sm-color-surface-inset);
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-input);
      white-space: nowrap;
      user-select: none;
    }

    .code--off {
      opacity: var(--sm-opacity-disabled);
    }
  `,
})
export class PhoneField implements FormValueControl<string> {
  protected readonly market = inject(Market);
  readonly value = model('');
  readonly label = input($localize`:@@phone.label:Mobile number`);
  readonly helper = input('');
  readonly error = input('');
  readonly status = input<FieldStatus>('none');
  /** Show the red "Needed" tag (quest forms). */
  readonly needed = input(false, { transform: booleanAttribute });
  /** Not required (Q2 backup contact, corrections #8): shows the "Optional" tag inside quests. */
  readonly optional = input(false, { transform: booleanAttribute });
  readonly disabled = input(false);
  /** Bound by [formField]; the visible error state follows `error` (touched) instead. */
  readonly invalid = input(false);
  readonly touch = output<void>();

  protected readonly flagOf = (c: MarketCode) => flag(c);

  /** Full international number for the API. */
  readonly e164 = computed(
    () => `${this.market.config().dialCode}${this.value().replace(/\D/g, '')}`,
  );

  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;

  /** Focus the number input (used by "Edit" in the code dialog). */
  focus(): void {
    this.host.querySelector<HTMLInputElement>('input[type="tel"]')?.focus();
  }
}

/** Regional-indicator flag emoji from an ISO country code. */
function flag(code: string): string {
  return String.fromCodePoint(...[...code].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65));
}
