export interface PasswordCheck {
  readonly id: 'length' | 'number' | 'letter';
  readonly label: string;
  readonly met: boolean;
}

export type StrengthLevel = 0 | 1 | 2 | 3 | 4;

/** The three rules Figma lists under the password (SU1–SU4). */
export function passwordChecks(value: string): readonly PasswordCheck[] {
  return [
    { id: 'length', label: $localize`:@@pw.length:8+ characters`, met: value.length >= 8 },
    { id: 'number', label: $localize`:@@pw.number:1 number`, met: /\d/.test(value) },
    { id: 'letter', label: $localize`:@@pw.letter:1 letter`, met: /\p{L}/u.test(value) },
  ];
}

/**
 * 0 empty · 1 too weak (any rule missing) · 2 okay (rules met) · 3 good (12+ chars or a symbol) ·
 * 4 strong (12+ chars and a symbol, or 16+). Bars fill 1–4 (A-84).
 */
export function passwordStrength(value: string): StrengthLevel {
  if (!value) return 0;
  if (passwordChecks(value).some((c) => !c.met)) return 1;
  const long = value.length >= 12;
  const symbol = /[^\p{L}\d]/u.test(value);
  if ((long && symbol) || value.length >= 16) return 4;
  if (long || symbol) return 3;
  return 2;
}

export function strengthLabel(level: StrengthLevel): string {
  switch (level) {
    case 1:
      return $localize`:@@pw.weak:Too weak`;
    case 2:
      return $localize`:@@pw.okay:Okay`;
    case 3:
      return $localize`:@@pw.good:Good`;
    case 4:
      return $localize`:@@pw.strong:Strong`;
    default:
      return '';
  }
}
