import { Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { FormField, email, form, required, submit } from '@angular/forms/signals';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../../core/api/api-error';
import { AUTH_API } from '../../../core/auth/auth.api';
import { Banner } from '../../../shared/ui/banner/banner';
import { Button } from '../../../shared/ui/button/button';
import { Field } from '../../../shared/ui/field/field';
import { Input } from '../../../shared/ui/input/input';
import { TextLink } from '../../../shared/ui/text-link/text-link';
import { AuthLayout } from '../layout/auth-layout';

const SECOND = 1000;

/**
 * FP1 Forgot password — enter email (201:8594 / 201:8970 / 201:8821) →
 * FP2 Check your inbox (201:8678 / 201:9020 / 201:8871), with a resend countdown.
 * The response never reveals whether the email has an account.
 */
@Component({
  selector: 'sm-forgot-password-page',
  imports: [AuthLayout, Field, Input, Button, Banner, TextLink, RouterLink, FormField],
  templateUrl: './forgot-password-page.html',
  styleUrl: '../login/login-page.scss',
})
export class ForgotPasswordPage {
  private readonly api = inject(AUTH_API);

  protected readonly model = signal({ email: '' });
  protected readonly form = form(this.model, (p) => {
    required(p.email, { message: $localize`:@@login.emailRequired:Pop in your email` });
    email(p.email, {
      message: $localize`:@@login.emailInvalid:That email looks off — check for typos`,
    });
  });
  protected readonly sent = signal(false);
  protected readonly busy = signal(false);
  protected readonly failed = signal<'offline' | 'server' | null>(null);
  protected readonly validFor = signal(30);
  protected readonly secondsLeft = signal(0);
  protected readonly emailError = computed(() => {
    const f = this.form.email();
    return f.touched() ? (f.errors()[0]?.message ?? '') : '';
  });
  protected readonly countdown = computed(() => {
    const s = this.secondsLeft();
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  });

  constructor() {
    const id = setInterval(() => this.secondsLeft.update((s) => Math.max(0, s - 1)), SECOND);
    inject(DestroyRef).onDestroy(() => clearInterval(id));
  }

  protected async send(event?: Event): Promise<void> {
    event?.preventDefault();
    if (this.busy()) return;
    await submit(this.form, async () => {
      this.busy.set(true);
      this.failed.set(null);
      try {
        const res = await firstValueFrom(this.api.requestPasswordReset(this.model().email));
        this.validFor.set(res.validFor);
        this.secondsLeft.set(res.resendIn);
        this.sent.set(true);
      } catch (err) {
        this.failed.set(err instanceof ApiError && err.kind === 'offline' ? 'offline' : 'server');
      } finally {
        this.busy.set(false);
      }
      return undefined;
    });
  }
}
