import { DOCUMENT } from '@angular/common';
import { Service, inject } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Auth } from '../../../core/auth/auth';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { ToastService } from '../../../shared/ui/toast/toast.service';
import { TestAccountPicker } from './test-account-picker';

/** Where a new Google learner starts: the quests intro (same as "Join the squad"). */
const NEW_LEARNER_START = '/start';

interface GoogleId {
  accounts: {
    id: {
      initialize(cfg: { client_id: string; callback: (r: { credential: string }) => void }): void;
      prompt(): void;
    };
  };
}

/**
 * "Continue with Google" on login and sign-up (A-253). Gets a Google ID token, swaps it for a
 * session, then routes: a brand-new account → the quests; an existing learner → the Lobby.
 * With a tenant client id it uses Google Identity Services; without one (dev, demos) a test-account
 * picker stands in so both paths can be tried.
 */
@Service()
export class GoogleSignInFlow {
  private readonly auth = inject(Auth);
  private readonly router = inject(Router);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly doc = inject(DOCUMENT);

  /** Resolves false when the learner closed the picker or it failed (the page stays as it is). */
  async start(returnUrl?: string): Promise<boolean> {
    const credential = await this.credential();
    if (!credential) return false;
    try {
      const { isNew } = await firstValueFrom(this.auth.googleSignIn(credential));
      await this.router.navigateByUrl(isNew ? NEW_LEARNER_START : this.auth.nextUrl(returnUrl));
      return true;
    } catch {
      this.toast.show(
        $localize`:@@google.failed:Google sign-in didn’t go through. Try again, or use your number or email.`,
        { tone: 'error' },
      );
      return false;
    }
  }

  private async credential(): Promise<string | null> {
    if (!environment.googleClientId) {
      const ref = this.overlay.adaptive<TestAccountPicker, void, string>(TestAccountPicker, {
        size: 'sm',
      });
      return (await firstValueFrom(ref.closed)) ?? null;
    }
    const google = await this.loadGis();
    if (!google) return null;
    return new Promise((resolve) => {
      google.accounts.id.initialize({
        client_id: environment.googleClientId,
        callback: (r) => resolve(r.credential ?? null),
      });
      google.accounts.id.prompt();
    });
  }

  private loadGis(): Promise<GoogleId | null> {
    const win = this.doc.defaultView as (Window & { google?: GoogleId }) | null;
    if (win?.google) return Promise.resolve(win.google);
    return new Promise((resolve) => {
      const s = this.doc.createElement('script');
      s.src = 'https://accounts.google.com/gsi/client';
      s.async = true;
      s.onload = () => resolve(win?.google ?? null);
      s.onerror = () => resolve(null);
      this.doc.head.appendChild(s);
    });
  }
}
