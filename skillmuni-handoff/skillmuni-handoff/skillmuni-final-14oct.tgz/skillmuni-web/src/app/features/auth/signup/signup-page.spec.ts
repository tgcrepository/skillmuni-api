import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { of, throwError } from 'rxjs';
import { ApiError } from '../../../core/api/api-error';
import { AUTH_API, AuthApi } from '../../../core/auth/auth.api';
import { passwordStrength } from './password-rules';
import { SignupPage } from './signup-page';

const challenge = { email: 'new@example.com', resendIn: 42, validFor: 10, triesLeft: 5 };

function setup(api: Partial<AuthApi>) {
  TestBed.configureTestingModule({
    providers: [provideRouter([]), { provide: AUTH_API, useValue: api }],
  });
  const fixture = TestBed.createComponent(SignupPage);
  fixture.detectChanges();
  const el = fixture.nativeElement as HTMLElement;
  const type = (sel: string, value: string) => {
    const input = el.querySelector<HTMLInputElement>(sel)!;
    input.value = value;
    input.dispatchEvent(new Event('input'));
  };
  const submitForm = async () => {
    el.querySelector('form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();
    fixture.detectChanges();
  };
  const fillValid = (email = 'new@example.com') => {
    type('input[autocomplete="given-name"]', 'Yash');
    type('input[autocomplete="family-name"]', 'Verma');
    type('input[type="email"]', email);
    type('input[autocomplete="new-password"]', 'abc12345!');
    el.querySelector<HTMLInputElement>('sm-checkbox input')!.click();
    fixture.detectChanges();
  };
  return { fixture, el, type, submitForm, fillValid };
}

describe('Password rules', () => {
  it('scores strength', () => {
    expect(passwordStrength('')).toBe(0);
    expect(passwordStrength('abcdefgh')).toBe(1);
    expect(passwordStrength('abcdefg1')).toBe(2);
    expect(passwordStrength('abcdefg1!')).toBe(3);
    expect(passwordStrength('abcdefghij1!')).toBe(4);
  });
});

describe('SignupPage (SU1–SU4, VE1–VE4)', () => {
  it('SU4: submitting empty shows every fix, including consent', async () => {
    const register = vi.fn();
    const { el, submitForm } = setup({ register });
    await submitForm();
    expect(el.textContent).toContain('Needed for your records.');
    expect(el.textContent).toContain('Tick this to continue.');
    expect(el.textContent).toContain('Almost there, just a few fixes.');
    expect(register).not.toHaveBeenCalled();
  });

  it('SU3: a taken email offers "Log in instead"', async () => {
    const taken = new ApiError('conflict', 409, 'Taken', { code: ['email-taken'] });
    const { el, fillValid, submitForm } = setup({ register: () => throwError(() => taken) });
    fillValid('yash.verma@gmail.com');
    await submitForm();
    expect(el.textContent).toContain('Already in the squad.');
    expect(el.querySelector('a[href="/login"].inline-link')).toBeTruthy();
    expect(el.textContent).toContain('Wait... I think I know you!');
  });

  it('VE1 → VE2 → VE4: wrong code, right code, then on to the quests', async () => {
    const verifyEmail = vi
      .fn()
      .mockReturnValueOnce(
        throwError(
          () => new ApiError('validation', 422, 'x', { code: ['invalid-code'], triesLeft: ['4'] }),
        ),
      )
      .mockReturnValueOnce(of({ id: 'u', firstName: 'Yash' }));
    const { fixture, el, fillValid, submitForm } = setup({
      register: () => of(challenge),
      verifyEmail,
    });
    fillValid();
    await submitForm();
    expect(el.querySelector('h1')?.textContent).toContain('Verify your email');
    expect(el.textContent).toContain('new@example.com');

    const otp = () => el.querySelector<HTMLInputElement>('sm-otp input')!;
    otp().value = '111111';
    otp().dispatchEvent(new Event('input'));
    await fixture.whenStable();
    fixture.detectChanges();
    expect(el.textContent).toContain('That code doesn’t match. Check it and try again.');

    const nav = vi.spyOn(TestBed.inject(Router), 'navigateByUrl').mockResolvedValue(true);
    otp().value = '123456';
    otp().dispatchEvent(new Event('input'));
    await fixture.whenStable();
    fixture.detectChanges();
    expect(el.querySelector('h1')?.textContent).toContain('You’re in, Yash!');
    (el.querySelector('button[sm-button]') as HTMLButtonElement).click();
    expect(nav).toHaveBeenCalledWith('/start');
  });

  it('VE3: an expired code swaps the primary to "Send a new code"', async () => {
    const expired = new ApiError('unknown', 410, 'x', { code: ['code-expired'] });
    const resendEmailCode = vi.fn(() => of(challenge));
    const { fixture, el, fillValid, submitForm } = setup({
      register: () => of(challenge),
      verifyEmail: () => throwError(() => expired),
      resendEmailCode,
    });
    fillValid();
    await submitForm();
    const otp = el.querySelector<HTMLInputElement>('sm-otp input')!;
    otp.value = '000000';
    otp.dispatchEvent(new Event('input'));
    await fixture.whenStable();
    fixture.detectChanges();
    expect(el.textContent).toContain('This code expired after 10 minutes.');
    const btn = [...el.querySelectorAll<HTMLButtonElement>('button[sm-button]')].find((b) =>
      b.textContent?.includes('Send a new code'),
    )!;
    btn.click();
    await fixture.whenStable();
    expect(resendEmailCode).toHaveBeenCalledWith('new@example.com');
  });
});

describe('SignupPage from login (A-308)', () => {
  afterEach(() => history.replaceState(null, ''));

  it('prefills the email and explains why the learner is here', () => {
    history.replaceState({ from: 'login', email: 'new.face@example.com' }, '');
    const { el } = setup({});
    expect(el.querySelector<HTMLInputElement>('input[type="email"]')!.value).toBe(
      'new.face@example.com',
    );
    expect(el.querySelector('sm-banner')?.textContent).toContain(
      'No account for new.face@example.com yet',
    );
  });

  it('a mobile number gets the "sign up with your email" note', () => {
    history.replaceState({ from: 'login', phone: '+91 91234 56789' }, '');
    const { el } = setup({});
    expect(el.querySelector('sm-banner')?.textContent).toContain('+91 91234 56789');
    expect(el.querySelector<HTMLInputElement>('input[type="email"]')!.value).toBe('');
  });

  it('a plain visit shows no banner', () => {
    const { el } = setup({});
    expect(el.querySelector('sm-banner')).toBeNull();
  });
});
