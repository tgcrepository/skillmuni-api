import { Component, viewChild } from '@angular/core';
import { SmDialog } from '../../../shared/ui/overlay/dialog';

/**
 * Stand-in for Google's own account chooser while no Google client id is configured (A-253):
 * lets testers try both outcomes. Never shown in a tenant build with Google set up.
 */
@Component({
  selector: 'sm-test-account-picker',
  imports: [SmDialog],
  template: `
    <sm-dialog [title]="title" [subtitle]="subtitle">
      <ul class="list">
        <li>
          <button type="button" class="acct" (click)="dialog().close('mock:existing')">
            <span class="avatar" aria-hidden="true">{{ 'Y' }}</span>
            <span class="text">
              <span class="name">{{ 'Yash Pohare' }}</span>
              <span class="meta" i18n="@@google.existing"
                >yash.p&#64;gmail.com · already a learner</span
              >
            </span>
          </button>
        </li>
        <li>
          <button type="button" class="acct" (click)="dialog().close('mock:new:Ananya:Rao')">
            <span class="avatar avatar--new" aria-hidden="true">{{ 'A' }}</span>
            <span class="text">
              <span class="name">{{ 'Ananya Rao' }}</span>
              <span class="meta" i18n="@@google.new"
                >ananya.rao&#64;gmail.com · new to Skillmuni</span
              >
            </span>
          </button>
        </li>
      </ul>
    </sm-dialog>
  `,
  styles: `
    .list {
      display: grid;
      gap: var(--sm-space-200);
      margin: 0;
      padding: 0;
      list-style: none;
    }

    .acct {
      display: flex;
      align-items: center;
      gap: var(--sm-space-300);
      inline-size: 100%;
      min-block-size: var(--sm-size-touch-min);
      padding: var(--sm-space-300) var(--sm-space-400);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-default);
      border-radius: var(--sm-radius-xl);
      background: var(--sm-color-surface-raised);
      color: inherit;
      text-align: start;
      cursor: pointer;
    }

    .acct:hover {
      border-color: var(--sm-color-border-brand);
      background: var(--sm-color-surface-hover);
    }

    .acct:focus-visible {
      box-shadow: var(--sm-shadow-focus-ring);
      outline: none;
    }

    .avatar {
      display: grid;
      flex: none;
      place-items: center;
      inline-size: var(--sm-size-control-sm);
      block-size: var(--sm-size-control-sm);
      border-radius: var(--sm-radius-full);
      background: var(--sm-gradient-button-accent);
      color: var(--sm-color-text-on-accent);
      font: var(--sm-font-label);
    }

    .avatar--new {
      background: var(--sm-gradient-button-primary);
    }

    .text {
      display: grid;
      gap: var(--sm-space-100);
    }

    .name {
      color: var(--sm-color-text-heading);
      font: var(--sm-font-label);
    }

    .meta {
      color: var(--sm-color-text-secondary);
      font: var(--sm-font-caption);
    }
  `,
})
export class TestAccountPicker {
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@google.pickTitle:Pick a test Google account`;
  protected readonly subtitle = $localize`:@@google.pickSub:Test mode: Google isn’t connected for this workspace yet.`;
}
