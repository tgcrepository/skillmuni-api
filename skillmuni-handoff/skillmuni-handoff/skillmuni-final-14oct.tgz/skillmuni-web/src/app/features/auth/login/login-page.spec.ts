import { provideHttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { of, throwError } from 'rxjs';
import { ApiError } from '../../../core/api/api-error';
import { AUTH_API, AuthApi } from '../../../core/auth/auth.api';
import { Session } from '../../../core/session/session';
import { LoginPage } from './login-page';

function setup(api: Partial<AuthApi>) {
  TestBed.configureTestingModule({
    providers: [provideRouter([]), provideHttpClient(), { provide: AUTH_API, useValue: api }],
  });
  const fixture = TestBed.createComponent(LoginPage);
  fixture.detectChanges();
  return { fixture, el: fixture.nativeElement as HTMLElement };
}

const challenge = { sentTo: '+91 98765 43210', resendIn: 30, triesLeft: 5 };
const user = { id: 'u', firstName: 'Yash' };

describe('LoginPage (E0 / E0b / L1)', () => {
  afterEach(() => document.querySelector('.cdk-overlay-container')?.replaceChildren());

  it('validates the mobile number before sending a code', async () => {
    const sendOtp = vi.fn(() => of(challenge));
    const { fixture, el } = setup({ sendOtp });
    const input = el.querySelector<HTMLInputElement>('input[type="tel"]')!;
    input.value = '98765';
    input.dispatchEvent(new Event('input'));
    el.querySelector('form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();
    fixture.detectChanges();
    expect(el.textContent).toContain('That number looks short — 10 digits, please');
    expect(sendOtp).not.toHaveBeenCalled();
  });

  it('sends the code with the dial code and opens the code dialog; a right code signs in', async () => {
    const sendOtp = vi.fn(() => of(challenge));
    const verifyOtp = vi.fn(() => of(user));
    const { fixture, el } = setup({ sendOtp, verifyOtp });
    const nav = vi.spyOn(TestBed.inject(Router), 'navigateByUrl').mockResolvedValue(true);
    const input = el.querySelector<HTMLInputElement>('input[type="tel"]')!;
    input.value = '98765 43210';
    input.dispatchEvent(new Event('input'));
    el.querySelector('form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();
    expect(sendOtp).toHaveBeenCalledWith('+919876543210');

    await vi.waitFor(() => expect(document.querySelector('.sm-pane sm-otp')).toBeTruthy());
    const otp = document.querySelector<HTMLInputElement>('.sm-pane sm-otp input')!;
    otp.value = '123456';
    otp.dispatchEvent(new Event('input'));
    await vi.waitFor(() => expect(verifyOtp).toHaveBeenCalledWith('+919876543210', '123456'));
    await vi.waitFor(() => expect(nav).toHaveBeenCalledWith('/home'));
    expect(TestBed.inject(Session).status()).toBe('active');
  });

  it('a locked account shows the support banner', async () => {
    const locked = new ApiError('unknown', 423, 'Locked', { code: ['account-locked'] });
    const { fixture, el } = setup({ sendOtp: () => throwError(() => locked) });
    const input = el.querySelector<HTMLInputElement>('input[type="tel"]')!;
    input.value = '98765 40000';
    input.dispatchEvent(new Event('input'));
    el.querySelector('form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();
    fixture.detectChanges();
    expect(el.querySelector('sm-banner')?.textContent).toContain('on pause');
    expect(el.querySelector('sm-banner a')?.getAttribute('href')).toContain('mailto:');
  });

  it('email login sends a code to the inbox (no password field)', async () => {
    const sendEmailLoginCode = vi.fn(() => of({ ...challenge, sentTo: 'ya•••@example.com' }));
    const { fixture, el } = setup({ sendEmailLoginCode });
    el.querySelectorAll<HTMLInputElement>('sm-segmented-control input[type="radio"]')[1]!.click();
    fixture.detectChanges();
    expect(el.querySelector('input[type="password"]')).toBeNull();
    const mail = el.querySelector<HTMLInputElement>('form sm-input input')!;
    mail.value = 'yash@example.com';
    mail.dispatchEvent(new Event('input'));
    el.querySelector('form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();
    expect(sendEmailLoginCode).toHaveBeenCalledWith('yash@example.com');
    await vi.waitFor(() =>
      expect(document.querySelector('.cdk-overlay-container')?.textContent).toContain(
        'Sent to ya•••@example.com',
      ),
    );
  });

  it('A-308: an unregistered mobile goes to sign-up instead of sending a code', async () => {
    const missing = new ApiError('unknown', 404, 'No account', { code: ['account-not-found'] });
    const { fixture, el } = setup({ sendOtp: () => throwError(() => missing) });
    const nav = vi.spyOn(TestBed.inject(Router), 'navigateByUrl').mockResolvedValue(true);
    const input = el.querySelector<HTMLInputElement>('input[type="tel"]')!;
    input.value = '91234 56789';
    input.dispatchEvent(new Event('input'));
    el.querySelector('form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();
    expect(nav).toHaveBeenCalledWith('/signup', {
      state: { from: 'login', phone: '+91 91234 56789' },
    });
    expect(document.querySelector('.sm-pane sm-otp')).toBeNull();
  });

  it('A-308: an unregistered email goes to sign-up with the email', async () => {
    const missing = new ApiError('unknown', 404, 'No account', { code: ['account-not-found'] });
    const { fixture, el } = setup({ sendEmailLoginCode: () => throwError(() => missing) });
    const nav = vi.spyOn(TestBed.inject(Router), 'navigateByUrl').mockResolvedValue(true);
    el.querySelectorAll<HTMLInputElement>('sm-segmented-control input[type="radio"]')[1]!.click();
    fixture.detectChanges();
    const mail = el.querySelector<HTMLInputElement>('form sm-input input')!;
    mail.value = 'new.face@example.com';
    mail.dispatchEvent(new Event('input'));
    el.querySelector('form')!.dispatchEvent(new Event('submit'));
    await fixture.whenStable();
    expect(nav).toHaveBeenCalledWith('/signup', {
      state: { from: 'login', email: 'new.face@example.com' },
    });
  });
});
