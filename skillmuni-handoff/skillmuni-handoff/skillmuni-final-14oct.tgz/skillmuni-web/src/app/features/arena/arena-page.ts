import { Viewport } from '../../core/layout/viewport';
import { A11yModule } from '@angular/cdk/a11y';
import { CdkConnectedOverlay, ConnectedPosition } from '@angular/cdk/overlay';
import { NgTemplateOutlet } from '@angular/common';
import {
  Component,
  DestroyRef,
  ElementRef,
  OnInit,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import {
  ARENA_API,
  ArenaBoard,
  ArenaPeriod,
  ArenaPlayer,
  ArenaScope,
} from '../../core/arena/arena.api';
import { Auth } from '../../core/auth/auth';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { CountUp } from '../../shared/ui/count-up/count-up';
import { Icon } from '../../shared/ui/icon/icon';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { MuniTalk } from '../../shared/ui/muni/muni-talk';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { DAY_LETTERS, streakDayLabel } from '../../shared/util/streak-day';
import { AvatarRing, PlayerAvatar } from './player-avatar';
import { Currency } from '../../shared/ui/currency/currency';
import { SoundFx } from '../../core/audio/sound-fx';

type LoadState = 'loading' | 'ready' | 'error' | 'offline';

interface FilterOption<T> {
  readonly value: T;
  readonly label: string;
}

/** Rows shown under the podium before "You" is pinned to the bottom (handoff 58:1530). */
const VISIBLE_ROWS = 7;
const RANK_UP_MS = 5000;
const MEDALS: readonly AvatarRing[] = ['gold', 'silver', 'bronze'];

/**
 * The Arena — weekly leaderboard (Figma Leaderboard v2: 52:172 desktop · 62:2309 tablet · 62:2640 mobile;
 * states 58:445). Podium (2 · 1 · 3), ranked rows with movement, Player Peek with Cheer / Challenge,
 * Your spot (gap to the next rank), streak week and the Rewards store card.
 */
@Component({
  selector: 'sm-arena-page',
  imports: [Currency, 
    A11yModule,
    Button,
    CdkConnectedOverlay,
    CountUp,
    Icon,
    LearnerShell,
    NgTemplateOutlet,
    PlayerAvatar,
    RouterLink,
    Skeleton,
    StateBlock,
    MuniTalk,
  ],
  templateUrl: './arena-page.html',
  styleUrl: './arena-page.scss',
})
export class ArenaPage implements OnInit {
  protected readonly viewport = inject(Viewport);
  private readonly api = inject(ARENA_API);
  private readonly auth = inject(Auth);
  private readonly toast = inject(ToastService);

  protected readonly scopes: readonly FilterOption<ArenaScope>[] = [
    { value: 'everyone', label: $localize`:@@arena.everyone:Everyone` },
    { value: 'batch', label: $localize`:@@arena.batch:My batch` },
    { value: 'friends', label: $localize`:@@arena.friends:Friends` },
  ];
  protected readonly periods: readonly FilterOption<ArenaPeriod>[] = [
    { value: 'week', label: $localize`:@@arena.week:This week` },
    { value: 'month', label: $localize`:@@arena.month:This month` },
    { value: 'all', label: $localize`:@@arena.all:All time` },
  ];

  protected readonly scope = signal<ArenaScope>('everyone');
  protected readonly period = signal<ArenaPeriod>('week');
  protected readonly state = signal<LoadState>('loading');
  protected readonly refreshing = signal(false);
  protected readonly board = signal<ArenaBoard | null>(null);
  protected readonly rankUp = signal<{ to: number; passed: string } | null>(null);

  protected readonly firstName = computed(() => this.auth.user()?.firstName ?? '');
  protected readonly players = computed(() => this.board()?.players ?? []);
  protected readonly empty = computed(() => this.state() === 'ready' && !this.players().length);

  /** A-271: first-time Arena — podium seats in screen order, and a crown to try on. */
  protected readonly seats = [2, 1, 3] as const;
  protected readonly tryOn = signal(false);
  protected readonly initials = computed(() => {
    return (this.auth.user()?.firstName?.[0] ?? '★').toUpperCase();
  });
  protected readonly arenaSay = computed(() =>
    this.tryOn()
      ? $localize`:@@arena.muniTryOn:Told you it fits, ${this.firstName()}:name:. Finish one module this week and it’s yours for real.`
      : $localize`:@@arena.muniEmpty:Nobody’s scored this week, ${this.firstName()}:name:. First XP in takes the crown. No pressure. (Some pressure.)`,
  );
  protected readonly arenaLines = [
    $localize`:@@arena.muni1:I polished the #1 spot. Twice. It’s waiting for you.`,
    $localize`:@@arena.muni2:One 2-minute brief and a quiz puts you on this podium.`,
    $localize`:@@arena.muni3:Leaderboards reset every week, so legends are made every Monday.`,
  ];

  private readonly sfx = inject(SoundFx);

  protected toggleTryOn(): void {
    this.tryOn.update((v) => !v);
    if (this.tryOn()) this.sfx.play('badge');
  }

  /** Screen order 2 · 1 · 3. */
  protected readonly podium = computed(() => {
    const [a, b, c] = this.players();
    return [b, a, c].filter((p): p is ArenaPlayer => !!p);
  });
  /** A-301: the standings strip reads in rank order, 1 · 2 · 3, plus you when you're further down. */
  protected readonly top3 = computed(() => this.players().slice(0, 3));
  protected readonly meBelow = computed(() => this.players().find((p) => p.you && p.rank > 3) ?? null);
  protected readonly rows = computed(() => this.players().slice(3, 3 + VISIBLE_ROWS));
  /** "You" when you're below the visible rows: pinned to the bottom of the list. */
  protected readonly pinned = computed(() => {
    const me = this.players().find((p) => p.you);
    return me && me.rank > 3 + VISIBLE_ROWS ? me : null;
  });

  protected readonly periodLabel = computed(
    () =>
      ({
        week: $localize`:@@arena.top3Week:Top 3 this week`,
        month: $localize`:@@arena.top3Month:Top 3 this month`,
        all: $localize`:@@arena.top3All:Top 3 of all time`,
      })[this.period()],
  );

  /** "Promotion zone ends here · 27 XP to get in" — XP the learner needs to reach the last promoted spot. */
  protected readonly zoneGap = computed(() => {
    const b = this.board();
    if (!b) return null;
    const cutoff = b.players[b.promotionRank - 1];
    if (!cutoff || b.me.rank <= b.promotionRank || !b.me.rank) return null;
    return cutoff.xp - b.me.xp;
  });

  protected readonly spot = computed(() => {
    const b = this.board();
    if (!b || !b.me.rank) return null;
    const { rank, xp, nextXp, nextName, topXp } = b.me;
    const name = this.firstName();
    const title =
      rank === 1
        ? $localize`:@@arena.spotGold:Gold spot, ${name}:name:!`
        : rank === 2
          ? $localize`:@@arena.spotSilver:Silver spot, ${name}:name:!`
          : rank === 3
            ? $localize`:@@arena.spotBronze:Bronze spot, ${name}:name:!`
            : $localize`:@@arena.spotN:Keep climbing, ${name}:name:!`;
    const gap = nextXp !== null ? nextXp - xp : 0;
    const chase =
      rank === 1
        ? $localize`:@@arena.holdCrown:You hold the crown. Keep it!`
        : rank === 2
          ? $localize`:@@arena.stealCrown:${gap}:gap: XP to steal the crown`
          : $localize`:@@arena.toPass:${gap}:gap: XP to pass ${nextName}:name:`;
    const medal: AvatarRing = rank <= 3 ? (MEDALS[rank - 1] ?? 'none') : 'none';
    return { rank, xp, topXp, title, chase, medal, percent: topXp ? (xp / topXp) * 100 : 0 };
  });

  protected readonly week = computed(() =>
    (this.board()?.week ?? []).map((state, i) => ({
      state,
      letter: DAY_LETTERS[i] ?? '',
      label: streakDayLabel(i, state),
    })),
  );

  /* ---------- Player Peek ---------- */
  protected readonly peek = signal<ArenaPlayer | null>(null);
  protected readonly peekOrigin = signal<HTMLElement | null>(null);
  protected readonly peekPositions: ConnectedPosition[] = [
    { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 8 },
    { originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom', offsetY: -8 },
    { originX: 'center', originY: 'bottom', overlayX: 'center', overlayY: 'top', offsetY: 8 },
  ];
  protected readonly cheerBusy = signal(false);

  private rankUpTimer: ReturnType<typeof setTimeout> | undefined;

  /**
   * A-301: once the podium has scrolled under the header, a compact standings strip slides down
   * (and back up when the podium returns). It overlays the list, so nothing reflows and the page
   * never jumps.
   */
  protected readonly stripShown = signal(false);
  private readonly podiumPanel = viewChild<ElementRef<HTMLElement>>('podiumPanel');
  private readonly stripDock = viewChild<ElementRef<HTMLElement>>('stripDock');

  private watchScroll(): () => void {
    let frame = 0;
    const check = () => {
      const panel = this.podiumPanel()?.nativeElement;
      const dock = this.stripDock()?.nativeElement;
      if (!panel || !dock) return;
      const line = dock.getBoundingClientRect().top;
      // Shown once the podium's players are half under the header; hidden as they come back.
      const stage = panel.querySelector('.stage')?.getBoundingClientRect();
      if (stage) this.stripShown.set(stage.top + stage.height / 2 < line);
    };
    const onScroll = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(check);
    };
    addEventListener('scroll', onScroll, { passive: true });
    addEventListener('resize', onScroll, { passive: true });
    return () => {
      removeEventListener('scroll', onScroll);
      removeEventListener('resize', onScroll);
      cancelAnimationFrame(frame);
    };
  }

  constructor() {
    const stop = this.watchScroll();
    inject(DestroyRef).onDestroy(() => {
      clearTimeout(this.rankUpTimer);
      stop();
    });
  }

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    if (this.board()) this.refreshing.set(true);
    else this.state.set('loading');
    this.closePeek();
    try {
      const b = await firstValueFrom(this.api.board(this.scope(), this.period()));
      this.board.set(b);
      this.state.set('ready');
      if (b.rankUp && !this.rankUp()) this.showRankUp(b.rankUp);
    } catch (e) {
      this.board.set(null);
      this.state.set(e instanceof ApiError && e.kind === 'offline' ? 'offline' : 'error');
    } finally {
      this.refreshing.set(false);
    }
  }

  protected setScope(v: ArenaScope): void {
    if (v === this.scope()) return;
    this.scope.set(v);
    void this.load();
  }

  protected setPeriod(v: ArenaPeriod): void {
    if (v === this.period()) return;
    this.period.set(v);
    void this.load();
  }

  protected medal(p: ArenaPlayer): AvatarRing {
    return MEDALS[p.rank - 1] ?? 'none';
  }

  protected movementLabel(p: ArenaPlayer): string {
    const n = Math.abs(p.movement);
    return p.movement > 0
      ? $localize`:@@arena.up:up ${n}:n: since yesterday`
      : p.movement < 0
        ? $localize`:@@arena.down:down ${n}:n: since yesterday`
        : $localize`:@@arena.same:no change since yesterday`;
  }

  protected modulesLabel(n: number): string {
    return n === 1
      ? $localize`:@@arena.module1:1 module done`
      : $localize`:@@arena.modules:${n}:n: modules done`;
  }

  protected rowLabel(p: ArenaPlayer): string {
    const you = p.you ? $localize`:@@arena.youSuffix: (you)` : '';
    return $localize`:@@arena.rowLabel:Rank ${p.rank}:rank:, ${p.name}:name:${you}:you:, ${p.xp}:xp: XP, ${this.movementLabel(p)}:move:`;
  }

  protected openPeek(p: ArenaPlayer, event: Event): void {
    const el = event.currentTarget as HTMLElement;
    if (this.peek()?.id === p.id) {
      this.closePeek();
      return;
    }
    this.peekOrigin.set(el);
    this.peek.set(p);
  }

  protected closePeek(returnFocus = false): void {
    const origin = this.peekOrigin();
    this.peek.set(null);
    if (returnFocus) origin?.focus();
  }

  protected onPeekKey(e: KeyboardEvent): void {
    if (e.key === 'Escape') {
      e.preventDefault();
      this.closePeek(true);
    }
  }

  /** Optimistic cheer; tapping again undoes it (58:445 "Cheer · done"). */
  protected async cheer(p: ArenaPlayer): Promise<void> {
    if (this.cheerBusy()) return;
    const on = !p.cheered;
    const optimistic = { ...p, cheered: on, cheers: p.cheers + (on ? 1 : -1) };
    this.replace(optimistic);
    this.cheerBusy.set(true);
    try {
      const res = await firstValueFrom(this.api.cheer(p.id, on));
      this.replace({ ...optimistic, cheers: res.cheers });
    } catch {
      this.replace(p);
      this.toast.show($localize`:@@arena.cheerFail:Couldn’t send that cheer. Try again.`, {
        tone: 'error',
      });
    } finally {
      this.cheerBusy.set(false);
    }
  }

  protected async challenge(p: ArenaPlayer): Promise<void> {
    try {
      await firstValueFrom(this.api.challenge(p.id));
      this.toast.show(
        $localize`:@@arena.challengeSent:Challenge sent to ${p.name}:name:. The 1-week XP race starts when they accept.`,
      );
      this.closePeek(true);
    } catch {
      this.toast.show($localize`:@@arena.challengeFail:Couldn’t send the challenge. Try again.`, {
        tone: 'error',
      });
    }
  }

  protected dismissRankUp(): void {
    clearTimeout(this.rankUpTimer);
    this.rankUp.set(null);
  }

  private showRankUp(r: { to: number; passed: string }): void {
    this.rankUp.set(r);
    clearTimeout(this.rankUpTimer);
    this.rankUpTimer = setTimeout(() => this.rankUp.set(null), RANK_UP_MS);
  }

  private replace(p: ArenaPlayer): void {
    this.board.update((b) =>
      b ? { ...b, players: b.players.map((x) => (x.id === p.id ? p : x)) } : b,
    );
    if (this.peek()?.id === p.id) this.peek.set(p);
  }
}
