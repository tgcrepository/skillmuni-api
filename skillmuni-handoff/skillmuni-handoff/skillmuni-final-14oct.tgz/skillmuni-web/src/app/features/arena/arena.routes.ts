import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

export const arenaRoutes: Routes = [
  {
    path: 'arena',
    title: $localize`:@@route.arena:Arena · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./arena-page').then((m) => m.ArenaPage),
  },
];
