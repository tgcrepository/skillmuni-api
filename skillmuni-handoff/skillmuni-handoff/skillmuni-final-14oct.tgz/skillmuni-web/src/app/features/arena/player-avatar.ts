import { Component, input } from '@angular/core';

export type AvatarRing = 'none' | 'gold' | 'silver' | 'bronze' | 'you';

/**
 * Figma: Player Avatar (53:213). Photo if uploaded, else initials on the Arcane gradient.
 * Ring = medal colour, or Ember for "You". Decorative: the name is always written next to it.
 */
@Component({
  selector: 'sm-player-avatar',
  template: `
    @if (photo()) {
      <img [src]="photo()" alt="" />
    } @else {
      <span class="initials">{{ initials() }}</span>
    }
  `,
  styleUrl: './player-avatar.scss',
  host: {
    'aria-hidden': 'true',
    '[class]': '"sm-player-avatar sm-player-avatar--" + size() + " ring--" + ring()',
    '[class.is-you]': 'you()',
  },
})
export class PlayerAvatar {
  readonly initials = input('');
  readonly photo = input<string | undefined>(undefined);
  readonly size = input<'sm' | 'md' | 'lg'>('sm');
  readonly ring = input<AvatarRing>('none');
  /** Ember border on the avatar itself (podium "You"). */
  readonly you = input(false);
}
