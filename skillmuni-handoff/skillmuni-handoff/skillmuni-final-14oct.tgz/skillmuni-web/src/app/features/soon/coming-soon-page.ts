import { Component, computed, inject, input } from '@angular/core';
import { BackNav } from '../../core/layout/back-nav';
import { Icon } from '../../shared/ui/icon/icon';
import { RouterLink } from '@angular/router';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { StateBlock } from '../../shared/ui/state-block/state-block';

/**
 * Placeholder for learner destinations whose Figma screens aren't built yet (A-172). Keeps the nav
 * working end to end. `area` comes from route data.
 */
@Component({
  selector: 'sm-coming-soon-page',
  imports: [Button, Icon, LearnerShell, RouterLink, StateBlock],
  template: `
    <sm-learner-shell>
      <!-- Corrections #31: every empty screen leads back to wherever the learner came from. -->
      <div class="head">
        <button
          type="button"
          class="round sm-back"
          i18n-aria-label="@@ui.back"
          aria-label="Back"
          (click)="nav.back('/home')"
        >
          <sm-icon name="chevron-left" size="md" />
        </button>
        <h1 class="head-title">{{ area() || fallbackArea }}</h1>
      </div>
      <sm-state-block kind="empty" fill [title]="title()" [body]="body">
        @if (cameFromElsewhere) {
          <button
            sm-button
            smStateAction
            variant="secondary"
            type="button"
            (click)="nav.back('/home')"
            i18n="@@soon.goBack"
          >
            Go back
          </button>
        }
        <a sm-button smStateAction routerLink="/home" i18n="@@soon.back">Back to the Lobby</a>
      </sm-state-block>
    </sm-learner-shell>
  `,
  styles: `
    .head {
      display: flex;
      align-items: center;
      gap: var(--sm-space-300);
      margin-block-start: var(--sm-space-400);
    }

    .round {
      display: grid;
      flex: none;
      place-items: center;
      inline-size: var(--sm-size-touch-min);
      block-size: var(--sm-size-touch-min);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-subtle);
      border-radius: var(--sm-radius-full);
      background: var(--sm-color-surface-raised);
      color: var(--sm-color-text-primary);
      cursor: pointer;
    }

    .round:focus-visible {
      box-shadow: var(--sm-shadow-focus-ring);
      outline: none;
    }

    .head-title {
      margin: 0;
      color: var(--sm-color-text-heading);
      font: var(--sm-font-heading);
    }

    sm-state-block {
      margin-block-start: var(--sm-space-400);
    }
  `,
})
export class ComingSoonPage {
  /** Route data: what is coming, e.g. "My Stats". */
  readonly area = input('');
  protected readonly nav = inject(BackNav);
  /** A previous screen in this tab that isn't the Lobby (e.g. My Stats → My goals). */
  protected readonly cameFromElsewhere = !!this.nav.previousPath() && this.nav.previousPath() !== '/home';
  protected readonly fallbackArea = $localize`:@@soon.fallbackArea:Coming soon`;

  protected readonly title = computed(() =>
    this.area()
      ? $localize`:@@soon.titleArea:${this.area()}:area: is on its way`
      : $localize`:@@soon.title:This corner is on its way`,
  );
  protected readonly body = $localize`:@@soon.body:We’re still building it. Your XP and progress are safe in the meantime.`;
}
