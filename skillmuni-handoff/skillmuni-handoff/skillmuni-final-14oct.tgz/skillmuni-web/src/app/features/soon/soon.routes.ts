import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

const soon = () => import('./coming-soon-page').then((m) => m.ComingSoonPage);

/** Learner destinations not built yet (A-172). Each is replaced by its real route as the screen lands. */
export const soonRoutes: Routes = [
  {
    path: 'rewards',
    title: $localize`:@@route.rewards:Rewards · Skillmuni`,
    canActivate: [requireSession],
    data: { area: $localize`:@@nav.rewards:Rewards` },
    loadComponent: soon,
  },
  // Linked from My Stats → Rewards quick links (A-238): intentional "on its way", never "Not found".
  {
    path: 'goals',
    title: $localize`:@@route.goals:My goals · Skillmuni`,
    canActivate: [requireSession],
    data: { area: $localize`:@@nav.goals:My goals` },
    loadComponent: soon,
  },
  {
    path: 'certificates',
    title: $localize`:@@route.certificates:Certificates · Skillmuni`,
    canActivate: [requireSession],
    data: { area: $localize`:@@nav.certificates:Certificates` },
    loadComponent: soon,
  },
  {
    path: 'wallet',
    title: $localize`:@@route.wallet:Wallet · Skillmuni`,
    canActivate: [requireSession],
    data: { area: $localize`:@@nav.wallet:Wallet` },
    loadComponent: soon,
  },
  {
    path: '**',
    title: $localize`:@@route.notFound:Not found · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: soon,
  },
];
