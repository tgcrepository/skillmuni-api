import { Component, computed, inject, input, output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Market } from '../../core/market/market';
import { Badge, BadgeCategory } from '../../core/stats/stats.api';
import { BadgeMedal } from '../../shared/ui/badge-medal/badge-medal';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';

export function categoryLabel(c: BadgeCategory | 'all'): string {
  return {
    all: $localize`:@@badges.all:All badges`,
    quests: $localize`:@@badges.quests:Profile quests`,
    streaks: $localize`:@@badges.streaks:Streaks`,
    learning: $localize`:@@badges.learning:Learning`,
    quizzes: $localize`:@@badges.quizzes:Quizzes`,
    assessments: $localize`:@@badges.assessments:Assessments`,
    social: $localize`:@@badges.social:Social`,
    special: $localize`:@@badges.special:Special & seasonal`,
  }[c];
}

export function rarityLabel(r: Badge['rarity']): string {
  return {
    common: $localize`:@@badges.common:Common`,
    rare: $localize`:@@badges.rare:Rare`,
    epic: $localize`:@@badges.epic:Epic`,
    legendary: $localize`:@@badges.legendary:Legendary`,
  }[r];
}

/**
 * Badge detail (Figma 170:4660 right panel · 175:5480 bottom sheet): how to earn it, progress,
 * % of the batch who own it, a CTA and Pin to showcase. Used inline on desktop and inside a sheet
 * or modal below it.
 */
@Component({
  selector: 'sm-badge-detail',
  imports: [BadgeMedal, Button, Icon, RouterLink],
  templateUrl: './badge-detail.html',
  styleUrl: './badge-detail.scss',
  host: { class: 'sm-badge-detail' },
})
export class BadgeDetail {
  private readonly market = inject(Market);

  readonly badge = input.required<Badge>();
  /** Pinned badges in the showcase right now. */
  readonly pinnedCount = input(0);
  readonly busy = input(false);
  /** Title element id (the sheet labels itself with it). */
  readonly titleId = input('badge-detail-title');
  readonly togglePin = output<Badge>();
  readonly navigate = output<void>();

  protected readonly secret = computed(() => this.badge().state === 'secret');
  protected readonly earned = computed(() => this.badge().state === 'earned');
  protected readonly category = computed(() => categoryLabel(this.badge().category));
  protected readonly rarity = computed(() => rarityLabel(this.badge().rarity));
  protected readonly full = computed(() => !this.badge().pinned && this.pinnedCount() >= 3);
  protected readonly earnedOn = computed(() => {
    const d = this.badge().earnedOn;
    return d
      ? new Intl.DateTimeFormat(this.market.config().locale, {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        }).format(new Date(`${d}T00:00:00`))
      : '';
  });
}
