import { MuniTalk } from '../../shared/ui/muni/muni-talk';
import { Component, OnInit, computed, inject, linkedSignal, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Market } from '../../core/market/market';
import {
  CourseStatus,
  LearningCourse,
  LearningDashboard,
  STATS_API,
} from '../../core/stats/stats.api';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';

const CHESTS = [25, 50, 75, 100];
const LOG_PREVIEW = 6;

/**
 * 2 · Learning — Quest Log (Figma 161:4359 · tablet 176:5902 · mobile 171:5316; note 166:4695).
 * The current quest with a progress ring, checkpoint chests at 25 / 50 / 75 / 100%, deadline (red when
 * due), time and CPD tiles, and the quest log sorted by closest to done with status tabs.
 * Picking a quest in the log shows it as the current quest.
 */
@Component({
  selector: 'sm-learning-view',
  imports: [MuniTalk, Button, Icon, RouterLink, Skeleton, StateBlock],
  templateUrl: './learning-view.html',
  styleUrl: './learning-view.scss',
})
export class LearningView implements OnInit {
  private readonly api = inject(STATS_API);
  private readonly market = inject(Market);

  protected readonly state = signal<'loading' | 'ready' | 'error' | 'offline'>('loading');
  protected readonly data = signal<LearningDashboard | null>(null);
  protected readonly tab = signal<CourseStatus>('in-progress');
  protected readonly showAll = signal(false);
  protected readonly selectedId = linkedSignal(
    () => this.data()?.currentId ?? this.data()?.courses[0]?.id ?? null,
  );

  protected readonly courses = computed(() => this.data()?.courses ?? []);
  protected readonly current = computed(
    () => this.courses().find((c) => c.id === this.selectedId()) ?? null,
  );
  protected readonly position = computed(
    () => this.courses().findIndex((c) => c.id === this.selectedId()) + 1,
  );

  protected readonly tabs = computed(() =>
    (
      [
        ['in-progress', $localize`:@@stats.inProgress:In progress`],
        ['not-started', $localize`:@@stats.notStarted:Not started`],
        ['done', $localize`:@@stats.done:Done`],
      ] as const
    ).map(([id, label]) => ({
      id,
      label,
      count: this.courses().filter((c) => c.status === id).length,
    })),
  );
  protected readonly inTab = computed(() => this.courses().filter((c) => c.status === this.tab()));
  protected readonly visible = computed(() =>
    this.showAll() ? this.inTab() : this.inTab().slice(0, LOG_PREVIEW),
  );

  protected readonly chests = computed(() => {
    const p = this.current()?.percent ?? 0;
    return CHESTS.map((at, i) => ({ at, reached: p >= at, last: i === CHESTS.length - 1 }));
  });
  protected readonly nextChest = computed(() => this.chests().find((c) => !c.reached)?.at ?? null);

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      this.data.set(await firstValueFrom(this.api.learning()));
      this.state.set('ready');
    } catch (e) {
      this.state.set(e instanceof ApiError && e.kind === 'offline' ? 'offline' : 'error');
    }
  }

  protected setTab(id: CourseStatus): void {
    this.tab.set(id);
    this.showAll.set(false);
  }

  protected pct(n: number): string {
    return `${new Intl.NumberFormat(this.market.config().locale, { maximumFractionDigits: 2 }).format(n)}%`;
  }

  protected status(c: LearningCourse): string {
    return {
      'in-progress': $localize`:@@stats.inProgress:In progress`,
      'not-started': $localize`:@@stats.notStarted:Not started`,
      done: $localize`:@@stats.done:Done`,
    }[c.status];
  }

  protected deadline(c: LearningCourse): { value: string; sub: string; due: boolean } {
    if (c.deadlineDays === null)
      return {
        value: $localize`:@@stats.noDeadline:No deadline`,
        sub: $localize`:@@stats.ownPace:Learn at your own pace`,
        due: false,
      };
    const due = c.deadlineDays <= 1 && c.status !== 'done';
    return {
      value:
        c.deadlineDays === 1
          ? $localize`:@@stats.dayLeft:1 day left`
          : $localize`:@@stats.daysLeft:${c.deadlineDays}:n: days left`,
      sub: due
        ? $localize`:@@stats.finishToday:Finish today to keep XP`
        : $localize`:@@stats.beforeDeadline:Finish before the deadline to keep XP`,
      due,
    };
  }

  protected cta(c: LearningCourse): string {
    return c.status === 'done'
      ? $localize`:@@stats.reviewQuest:Review quest`
      : c.status === 'not-started'
        ? $localize`:@@stats.startQuest:Start quest`
        : $localize`:@@stats.continueQuest:Continue quest`;
  }

  protected rowLabel(c: LearningCourse): string {
    return `${c.title}, ${this.pct(c.percent)}`;
  }
}
