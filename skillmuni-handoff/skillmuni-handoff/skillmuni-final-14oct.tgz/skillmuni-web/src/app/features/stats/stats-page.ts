import { Component, computed, input, linkedSignal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Icon } from '../../shared/ui/icon/icon';
import { IconName } from '../../shared/ui/icon/icons';
import { AssessmentsView } from './assessments-view';
import { LearningView } from './learning-view';
import { RewardsView } from './rewards-view';

export type StatsView = 'rewards' | 'learning' | 'assessments';

interface Slide {
  readonly id: StatsView;
  readonly label: string;
  readonly title: string;
  readonly icon: IconName;
  readonly link: string;
}

/**
 * My Stats (Figma Dashboard v2 · 161:4277). Desktop: one panel per slide with ‹ › arrows and dots
 * (161:4281 · 161:4359 · 161:4439). Tablet and mobile: "My Stats" title + Rewards / Learning /
 * Assessments tabs (176:5396 · 171:4820). Each slide has its own URL so it can be linked and shared.
 */
@Component({
  selector: 'sm-stats-page',
  imports: [AssessmentsView, Icon, LearnerShell, LearningView, RewardsView, RouterLink],
  templateUrl: './stats-page.html',
  styleUrl: './stats-page.scss',
})
export class StatsPage {
  /** From route data. */
  readonly view = input<StatsView>('rewards');

  protected readonly slides: readonly Slide[] = [
    {
      id: 'rewards',
      label: $localize`:@@stats.rewards:Rewards`,
      title: $localize`:@@stats.rewardsTitle:Rewards Dashboard`,
      icon: 'gift',
      link: '/stats',
    },
    {
      id: 'learning',
      label: $localize`:@@stats.learning:Learning`,
      title: $localize`:@@stats.learningTitle:Learning Dashboard`,
      icon: 'play',
      link: '/stats/learning',
    },
    {
      id: 'assessments',
      label: $localize`:@@stats.assessments:Assessments`,
      title: $localize`:@@stats.assessmentsTitle:Assessment Dashboard`,
      icon: 'bar-chart-filled',
      link: '/stats/assessments',
    },
  ];

  protected readonly index = computed(() =>
    Math.max(
      0,
      this.slides.findIndex((s) => s.id === this.view()),
    ),
  );
  /** Which way the last move went, so the new dashboard slides in from that side (A-267). */
  protected readonly dir = linkedSignal<number, 'next' | 'prev'>({
    source: this.index,
    computation: (i, prev) => (prev && i < prev.source ? 'prev' : 'next'),
  });
  protected readonly current = computed(() => this.slides[this.index()] ?? this.slides[0]);
  protected readonly prev = computed(() => this.slides[this.index() - 1] ?? null);
  protected readonly next = computed(() => this.slides[this.index() + 1] ?? null);

  protected prevLabel(label: string): string {
    return $localize`:@@stats.prev:Previous: ${label}:label:`;
  }

  protected nextLabel(label: string): string {
    return $localize`:@@stats.next:Next: ${label}:label:`;
  }
}
