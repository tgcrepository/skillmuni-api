import { BackNav } from '../../core/layout/back-nav';
import { Component, OnInit, computed, inject, input, linkedSignal, signal } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Viewport } from '../../core/layout/viewport';
import { Market } from '../../core/market/market';
import { Badge, BadgeCatalogue, BadgeCategory, STATS_API } from '../../core/stats/stats.api';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { BadgeMedal } from '../../shared/ui/badge-medal/badge-medal';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { IconName } from '../../shared/ui/icon/icons';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { BadgeDetail, categoryLabel } from './badge-detail';
import { BadgeSheet, BadgeSheetData } from './badge-sheet';

type Filter = 'all' | 'earned' | 'progress' | 'locked';
type Sort = 'closest' | 'az';

const CATEGORIES: readonly { id: BadgeCategory; icon: IconName }[] = [
  { id: 'quests', icon: 'compass' },
  { id: 'streaks', icon: 'flame' },
  { id: 'learning', icon: 'play' },
  { id: 'quizzes', icon: 'lightbulb' },
  { id: 'assessments', icon: 'bar-chart-filled' },
  { id: 'social', icon: 'users' },
  { id: 'special', icon: 'crown' },
];

/** Tiles shown per category before "Show N more" on phones (note 177:7597: lazy per category). */
const MOBILE_PREVIEW = 6;

/**
 * My Badges — full collection (Figma 170:4660 · mobile 175:5159 · sheet 175:5480; note 177:7597).
 * Categories with earned / total, filters All · Earned · In progress · Locked, sort Closest to unlock,
 * 6 per row (3 on phones). Detail: right panel on desktop, modal on tablet, bottom sheet on mobile.
 */
@Component({
  selector: 'sm-badges-page',
  imports: [BadgeDetail, BadgeMedal, Button, Icon, LearnerShell, Skeleton, StateBlock],
  templateUrl: './badges-page.html',
  styleUrl: './badges-page.scss',
})
export class BadgesPage implements OnInit {
  protected readonly nav = inject(BackNav);
  /** Came here from Profile → “See all” (A-234): the back pill says so. */
  protected readonly fromProfile = this.nav.previousPath() === '/profile';
  private readonly api = inject(STATS_API);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly market = inject(Market);
  protected readonly viewport = inject(Viewport);

  /** Query params: ?badge=<id> selects one, ?filter=earned pre-filters (Pin a badge). */
  readonly badge = input<string | undefined>();
  readonly filter = input<string | undefined>();

  protected readonly state = signal<'loading' | 'ready' | 'error' | 'offline'>('loading');
  protected readonly data = signal<BadgeCatalogue | null>(null);
  protected readonly category = signal<BadgeCategory | 'all'>('all');
  protected readonly noneLines = [
    $localize`:@@badges.none1:Every badge you see started as a locked one. Just saying.`,
    $localize`:@@badges.none2:Earn one this week and this shelf gets its first trophy.`,
    $localize`:@@badges.none3:Psst, “In progress” is where the action is.`,
  ];

  protected showAll(): void {
    this.category.set('all');
    this.activeFilter.set('all');
  }
  protected readonly activeFilter = linkedSignal<Filter>(
    () => (['earned', 'progress', 'locked'] as const).find((f) => f === this.filter()) ?? 'all',
  );
  protected readonly sort = signal<Sort>('closest');
  protected readonly expanded = signal<ReadonlySet<BadgeCategory>>(new Set());
  protected readonly pinBusy = signal(false);

  protected readonly badges = computed(() => this.data()?.badges ?? []);
  /** Follows ?badge=; survives catalogue reloads (pinning) so the panel doesn't jump. */
  protected readonly selectedId = linkedSignal<string | null, string | null>({
    source: () => this.badge() ?? null,
    computation: (id, prev) => id ?? prev?.value ?? null,
  });
  protected readonly selected = computed(
    () =>
      this.badges().find((b) => b.id === this.selectedId()) ??
      (this.selectedId() ? null : this.closest()),
  );
  protected readonly closest = computed(() =>
    this.badges()
      .filter((b) => b.state === 'progress')
      .reduce<Badge | null>((best, b) => (!best || b.percent > best.percent ? b : best), null),
  );
  protected readonly pinnedCount = computed(() => this.badges().filter((b) => b.pinned).length);

  protected readonly categories = computed(() => [
    {
      id: 'all' as const,
      icon: 'sparkle' as IconName,
      label: categoryLabel('all'),
      earned: this.data()?.earned ?? 0,
      total: this.data()?.total ?? 0,
    },
    ...CATEGORIES.map((c) => {
      const inCat = this.badges().filter((b) => b.category === c.id);
      return {
        id: c.id,
        icon: c.icon,
        label: categoryLabel(c.id),
        earned: inCat.filter((b) => b.state === 'earned').length,
        total: inCat.length,
      };
    }),
  ]);

  private readonly inCategory = computed(() =>
    this.badges().filter((b) => this.category() === 'all' || b.category === this.category()),
  );

  protected readonly filters = computed(() => {
    const list = this.inCategory();
    const n = (s: Badge['state'][]) => list.filter((b) => s.includes(b.state)).length;
    return [
      { id: 'all' as const, label: $localize`:@@badges.filterAll:All`, count: null },
      { id: 'earned' as const, label: $localize`:@@badges.earned:Earned`, count: n(['earned']) },
      {
        id: 'progress' as const,
        label: $localize`:@@badges.inProgress:In progress`,
        count: n(['progress']),
      },
      {
        id: 'locked' as const,
        label: $localize`:@@badges.locked:Locked`,
        count: n(['locked', 'secret']),
      },
    ];
  });

  protected readonly sections = computed(() => {
    const f = this.activeFilter();
    const keep = (b: Badge) =>
      f === 'all' ||
      (f === 'earned' && b.state === 'earned') ||
      (f === 'progress' && b.state === 'progress') ||
      (f === 'locked' && (b.state === 'locked' || b.state === 'secret'));
    const order = (a: Badge, b: Badge) =>
      this.sort() === 'az'
        ? a.name.localeCompare(b.name, this.market.config().locale)
        : rank(b) - rank(a);
    return (
      CATEGORIES.filter((c) => this.category() === 'all' || c.id === this.category())
        .map((c) => {
          const all = this.badges().filter((b) => b.category === c.id);
          const items = all.filter(keep).sort(order);
          const open = this.expanded().has(c.id) || !this.viewport.isMobile();
          return {
            id: c.id,
            label: categoryLabel(c.id),
            earned: all.filter((b) => b.state === 'earned').length,
            total: all.length,
            items: open ? items : items.slice(0, MOBILE_PREVIEW),
            hidden: open ? 0 : Math.max(0, items.length - MOBILE_PREVIEW),
          };
        })
        .filter((s) => s.items.length)
        // Categories with something earned come first (Figma leads with Learning & quizzes).
        .sort((a, b) => Number(b.earned > 0) - Number(a.earned > 0))
    );
  });

  protected readonly sortLabel = computed(() =>
    this.sort() === 'closest'
      ? $localize`:@@badges.sortClosest:Sort: Closest to unlock`
      : $localize`:@@badges.sortAz:Sort: A–Z`,
  );

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      this.data.set(await firstValueFrom(this.api.badges()));
      this.state.set('ready');
      if (this.badge() && !this.viewport.isDesktop()) {
        const b = this.selected();
        if (b) this.openSheet(b);
      }
    } catch (e) {
      this.state.set(e instanceof ApiError && e.kind === 'offline' ? 'offline' : 'error');
    }
  }

  protected pick(b: Badge): void {
    this.selectedId.set(b.id);
    if (!this.viewport.isDesktop()) this.openSheet(b);
  }

  protected toggleSort(): void {
    this.sort.update((s) => (s === 'closest' ? 'az' : 'closest'));
  }

  protected expand(id: BadgeCategory): void {
    this.expanded.update((s) => new Set([...s, id]));
  }

  protected tileSub(b: Badge): string {
    if (b.state === 'secret') return $localize`:@@badges.keepLearning:Keep learning`;
    if (b.state === 'earned' && b.earnedOn)
      return $localize`:@@badges.earnedShort:Earned ${new Intl.DateTimeFormat(
        this.market.config().locale,
        {
          day: 'numeric',
          month: 'short',
        },
      ).format(new Date(`${b.earnedOn}T00:00:00`))}:date:`;
    if (b.state === 'progress' && b.percent >= 90) return `${Math.floor(b.percent)}%`;
    return b.progressLabel ?? '';
  }

  protected tileLabel(b: Badge): string {
    const name = b.state === 'secret' ? $localize`:@@badges.secretName:Secret badge` : b.name;
    const state = {
      earned: $localize`:@@badges.stEarned:earned`,
      progress: $localize`:@@badges.stProgress:in progress`,
      locked: $localize`:@@badges.stLocked:locked`,
      secret: $localize`:@@badges.stSecret:secret`,
    }[b.state];
    const sub = this.tileSub(b);
    return [name, state, b.state === 'secret' ? '' : sub].filter(Boolean).join(', ');
  }

  protected async togglePin(b: Badge): Promise<Badge | null> {
    const ids = this.badges()
      .filter((x) => x.pinned && x.id !== b.id)
      .map((x) => x.id);
    if (!b.pinned) ids.push(b.id);
    this.pinBusy.set(true);
    try {
      const next = await firstValueFrom(this.api.setShowcase(ids));
      this.data.set(next);
      const updated = next.badges.find((x) => x.id === b.id) ?? null;
      this.toast.show(
        updated?.pinned
          ? $localize`:@@badges.pinned:${b.name}:name: is in your showcase`
          : $localize`:@@badges.unpinned:${b.name}:name: left your showcase`,
        { tone: 'success' },
      );
      return updated;
    } catch {
      this.toast.show($localize`:@@badges.pinFailed:Couldn’t update your showcase. Try again.`, {
        tone: 'error',
      });
      return null;
    } finally {
      this.pinBusy.set(false);
    }
  }

  private openSheet(b: Badge): void {
    this.overlay.adaptive<BadgeSheet, BadgeSheetData>(BadgeSheet, {
      data: { badge: b, pinnedCount: this.pinnedCount(), togglePin: (x) => this.togglePin(x) },
      size: 'sm',
    });
  }
}

/** Closest to unlock first: earned at the top, then by progress, secrets last. */
function rank(b: Badge): number {
  return b.state === 'earned' ? 1000 : b.state === 'secret' ? -1 : b.percent;
}
