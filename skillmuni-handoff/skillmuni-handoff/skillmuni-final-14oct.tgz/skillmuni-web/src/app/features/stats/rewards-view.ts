import { LevelTrack } from '../../shared/ui/level-track/level-track';
import { levelFor } from '../../core/quests/levels';
import { Component, DestroyRef, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Auth } from '../../core/auth/auth';
import { Market } from '../../core/market/market';
import { RewardsDashboard, STATS_API } from '../../core/stats/stats.api';
import { BadgeMedal } from '../../shared/ui/badge-medal/badge-medal';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { IconName } from '../../shared/ui/icon/icons';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { DAY_LETTERS, streakDayLabel } from '../../shared/util/streak-day';
import { Currency } from '../../shared/ui/currency/currency';

const MINUTE = 60_000;

interface QuickLink {
  readonly id: string;
  readonly icon: IconName;
  readonly label: string;
  readonly link: string;
}

/**
 * 1 · Rewards — Player HQ (Figma 161:4281 · tablet 176:5396 · mobile 171:4820; note 166:4687).
 * Player card with level ring and streak week, XP / Credits wallet (no coins for now), three daily quests with a
 * reset timer, a fixed six-slot badge preview (3 pinned + 3 closest to unlock), rank nudge and links.
 */
@Component({
  selector: 'sm-rewards-view',
  imports: [
    LevelTrack,
    Currency,
    BadgeMedal,
    Button,
    Icon,
    RouterLink,
    Skeleton,
    StateBlock,
  ],
  templateUrl: './rewards-view.html',
  styleUrl: './rewards-view.scss',
})
export class RewardsView implements OnInit {
  /** Rank and level always come from the XP total (one ladder, A-249). */
  protected lvlOf(xp: number) {
    return levelFor(xp);
  }

  private readonly api = inject(STATS_API);
  private readonly auth = inject(Auth);
  private readonly market = inject(Market);

  protected readonly state = signal<'loading' | 'ready' | 'error' | 'offline'>('loading');
  protected readonly data = signal<RewardsDashboard | null>(null);
  private readonly now = signal(Date.now());

  protected readonly firstName = computed(() => this.auth.user()?.firstName ?? '');

  /** Progress within the current level (A-249). */
  protected readonly levelPercent = computed(() => {
    const p = this.data()?.player;
    if (!p || !p.nextLevelXp) return 0;
    const start = levelFor(p.xp).start;
    return Math.min(100, ((p.xp - start) / Math.max(1, p.nextLevelXp - start)) * 100);
  });

  protected readonly week = computed(() =>
    (this.data()?.streak.week ?? []).map((state, i) => ({
      state,
      letter: DAY_LETTERS[i] ?? '',
      label: streakDayLabel(i, state),
    })),
  );

  protected readonly resetsIn = computed(() => {
    const at = this.data()?.quests.resetsAt;
    if (!at) return '';
    const mins = Math.max(0, Math.round((Date.parse(at) - this.now()) / MINUTE));
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return $localize`:@@stats.resetsIn:Resets in ${h}:h:h ${m}:m:m`;
  });

  protected readonly hours = computed(() =>
    new Intl.NumberFormat(this.market.config().locale, { maximumFractionDigits: 1 }).format(
      this.data()?.learningHours ?? 0,
    ),
  );
  protected readonly days = computed(() => Math.round((this.data()?.learningHours ?? 0) / 24));

  protected readonly quickLinks: readonly QuickLink[] = [
    {
      id: 'badges',
      icon: 'shield',
      label: $localize`:@@stats.myBadges:My badges`,
      link: '/stats/badges',
    },
    { id: 'goals', icon: 'target', label: $localize`:@@stats.myGoals:My goals`, link: '/goals' },
    { id: 'store', icon: 'gift', label: $localize`:@@stats.store:Rewards store`, link: '/rewards' },
    {
      id: 'certificates',
      icon: 'check-circle',
      label: $localize`:@@stats.certificates:Certificates`,
      link: '/certificates',
    },
  ];

  constructor() {
    const id = setInterval(() => this.now.set(Date.now()), MINUTE);
    inject(DestroyRef).onDestroy(() => clearInterval(id));
  }

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      this.data.set(await firstValueFrom(this.api.rewards()));
      this.state.set('ready');
    } catch (e) {
      this.state.set(e instanceof ApiError && e.kind === 'offline' ? 'offline' : 'error');
    }
  }

  protected streakNudge(days: number): string {
    return $localize`:@@stats.streakNudge:Finish a brief’s quiz today to make it ${days + 1}:n: 🔥`;
  }
}
