import { ResolveFn, Routes, UrlMatcher, UrlSegment } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

const VIEWS = ['learning', 'assessments'];

/**
 * `/stats`, `/stats/learning` and `/stats/assessments` share one route (A-267), so the page stays
 * mounted between dashboards and can swipe from one to the next instead of rebuilding.
 */
const statsMatcher: UrlMatcher = (segments) => {
  if (segments[0]?.path !== 'stats') return null;
  if (segments.length === 1)
    return { consumed: segments, posParams: { view: new UrlSegment('rewards', {}) } };
  const second = segments[1];
  if (segments.length === 2 && second && VIEWS.includes(second.path))
    return { consumed: segments, posParams: { view: second } };
  return null;
};

const TITLES: Record<string, string> = {
  rewards: $localize`:@@route.stats:My Stats · Skillmuni`,
  learning: $localize`:@@route.statsLearning:Learning · My Stats · Skillmuni`,
  assessments: $localize`:@@route.statsAssessments:Assessments · My Stats · Skillmuni`,
};
const statsTitle: ResolveFn<string> = (route) =>
  TITLES[route.paramMap.get('view') ?? 'rewards'] ?? $localize`:@@route.stats:My Stats · Skillmuni`;

/** My Stats (Figma Dashboard v2 161:4277): three slides plus the full badge collection. */
export const statsRoutes: Routes = [
  {
    path: 'stats/badges',
    title: $localize`:@@route.badges:My badges · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./badges-page').then((m) => m.BadgesPage),
  },
  {
    matcher: statsMatcher,
    title: statsTitle,
    canActivate: [requireSession],
    loadComponent: () => import('./stats-page').then((m) => m.StatsPage),
  },
];
