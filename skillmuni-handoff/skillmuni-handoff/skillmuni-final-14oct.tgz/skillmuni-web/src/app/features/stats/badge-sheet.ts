import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, inject, signal, viewChild } from '@angular/core';
import { Badge } from '../../core/stats/stats.api';
import { SmDialog } from '../../shared/ui/overlay/dialog';
import { BadgeDetail } from './badge-detail';

export interface BadgeSheetData {
  readonly badge: Badge;
  readonly pinnedCount: number;
  /** Pins or unpins; resolves with the updated badge. */
  readonly togglePin: (b: Badge) => Promise<Badge | null>;
}

/** Badge detail as a bottom sheet on mobile (Figma 175:5480) and a modal on tablet. */
@Component({
  selector: 'sm-badge-sheet',
  imports: [SmDialog, BadgeDetail],
  template: `
    <sm-dialog labelledBy="badge-sheet-title">
      <sm-badge-detail
        titleId="badge-sheet-title"
        [badge]="badge()"
        [pinnedCount]="pinnedCount()"
        [busy]="busy()"
        (togglePin)="toggle($event)"
        (navigate)="dialog().close()"
      />
    </sm-dialog>
  `,
})
export class BadgeSheet {
  private readonly data = inject<BadgeSheetData>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly badge = signal(this.data.badge);
  protected readonly pinnedCount = signal(this.data.pinnedCount);
  protected readonly busy = signal(false);

  protected async toggle(b: Badge): Promise<void> {
    this.busy.set(true);
    try {
      const next = await this.data.togglePin(b);
      if (next) {
        this.pinnedCount.update((n) => n + (next.pinned ? 1 : -1));
        this.badge.set(next);
      }
    } finally {
      this.busy.set(false);
    }
  }
}
