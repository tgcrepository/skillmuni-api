import { Component, OnInit, computed, inject, linkedSignal, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Market } from '../../core/market/market';
import {
  AssessmentResult,
  AssessmentsDashboard,
  STATS_API,
  SkillTier,
  TIER_FLOORS,
  TIER_ORDER,
} from '../../core/stats/stats.api';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { MuniAvatar } from '../../shared/ui/muni/muni-avatar';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { Currency } from '../../shared/ui/currency/currency';
import { Typewriter } from '../../shared/ui/muni/typewriter';

/**
 * 3 · Assessments — Skill Stats (Figma 161:4439 · mobile 174:5037 · empty 161:4514; notes 166:4703,
 * 166:4711). The best skill card is featured (pick any row to feature it instead), with cards
 * unlocked, tier spread, the skill closest to a tier-up and every result with tier pips.
 */
@Component({
  selector: 'sm-assessments-view',
  imports: [Typewriter, Currency, Button, Icon, MuniAvatar, RouterLink, Skeleton, StateBlock],
  templateUrl: './assessments-view.html',
  styleUrl: './assessments-view.scss',
})
export class AssessmentsView implements OnInit {
  private readonly api = inject(STATS_API);
  private readonly market = inject(Market);

  protected readonly state = signal<'loading' | 'ready' | 'error' | 'offline'>('loading');
  protected readonly data = signal<AssessmentsDashboard | null>(null);

  protected readonly results = computed(() =>
    [...(this.data()?.results ?? [])].sort((a, b) => b.score - a.score),
  );
  protected readonly bestId = computed(() => this.results()[0]?.id ?? null);
  protected readonly selectedId = linkedSignal(() => this.bestId());
  protected readonly featured = computed(
    () => this.results().find((r) => r.id === this.selectedId()) ?? null,
  );

  protected readonly average = computed(() => {
    const r = this.results();
    return r.length ? Math.round(r.reduce((s, x) => s + x.score, 0) / r.length) : 0;
  });

  protected readonly tiers = computed(() => {
    const r = this.results();
    return [...TIER_ORDER].reverse().map((t) => ({
      tier: t,
      label: this.tierLabel(t),
      count: r.filter((x) => x.tier === t).length,
    }));
  });

  /** The result needing the fewest points to reach the next tier (placeholder floors). */
  protected readonly tierUp = computed(() => {
    let best: { r: AssessmentResult; next: SkillTier; gap: number } | null = null;
    for (const r of this.results()) {
      const next = TIER_ORDER[TIER_ORDER.indexOf(r.tier) + 1];
      if (!next) continue;
      const gap = TIER_FLOORS[next] - r.score;
      if (gap > 0 && (!best || gap < best.gap)) best = { r, next, gap };
    }
    return best;
  });

  protected readonly tierUpHint = computed(() => {
    const t = this.tierUp();
    return t
      ? $localize`:@@stats.tierUpHint:Retake it to jump from ${this.tierLabel(t.r.tier)}:from: to ${this.tierLabel(t.next)}:to:.`
      : '';
  });

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      this.data.set(await firstValueFrom(this.api.assessments()));
      this.state.set('ready');
    } catch (e) {
      this.state.set(e instanceof ApiError && e.kind === 'offline' ? 'offline' : 'error');
    }
  }

  protected tierLabel(t: SkillTier): string {
    return {
      beginner: $localize`:@@tier.beginner:Beginner`,
      intermediate: $localize`:@@tier.intermediate:Intermediate`,
      advanced: $localize`:@@tier.advanced:Advanced`,
      expert: $localize`:@@tier.expert:Expert`,
    }[t];
  }

  /** 1–4 filled pips. */
  protected pips(t: SkillTier): number {
    return TIER_ORDER.indexOf(t) + 1;
  }

  protected date(iso: string): string {
    return new Intl.DateTimeFormat(this.market.config().locale, {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
    }).format(new Date(`${iso}T00:00:00`));
  }

  protected unlockLabel(available: number): string {
    return $localize`:@@stats.unlockLabel:${this.results().length}:n: of ${available}:total: skill cards unlocked`;
  }

  protected rowLabel(r: AssessmentResult): string {
    return `${r.title}, ${this.tierLabel(r.tier)}, ${r.score}%`;
  }
}
