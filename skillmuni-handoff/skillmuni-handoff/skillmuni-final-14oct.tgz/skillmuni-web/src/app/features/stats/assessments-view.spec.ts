import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { AssessmentResult, STATS_API, SkillTier } from '../../core/stats/stats.api';
import { AssessmentsView } from './assessments-view';

const r = (id: string, tier: SkillTier, score: number): AssessmentResult => ({
  id,
  title: id,
  subtitle: id,
  tier,
  score,
  correct: 0,
  total: 20,
  completed: '2026-06-07',
  retakeUrl: `/assessments/${id}`,
});

interface ViewApi {
  load(): Promise<void>;
  bestId(): string | null;
  average(): number;
  tierUp(): { r: AssessmentResult; next: SkillTier; gap: number } | null;
  tiers(): { tier: SkillTier; count: number }[];
  pips(t: SkillTier): number;
}

function setup(results: AssessmentResult[]) {
  TestBed.configureTestingModule({
    providers: [
      provideRouter([]),
      {
        provide: STATS_API,
        useValue: {
          assessments: () =>
            of({
              results,
              available: 20,
              firstCardXp: 20,
              recommended: { title: 'x', url: '/x', why: 'x' },
            }),
        },
      },
    ],
  });
  return TestBed.createComponent(AssessmentsView).componentInstance as unknown as ViewApi;
}

describe('AssessmentsView', () => {
  it('features the best card and finds the skill closest to a tier-up', async () => {
    const view = setup([
      r('a', 'advanced', 86),
      r('b', 'expert', 95),
      r('c', 'beginner', 59),
      r('d', 'intermediate', 75),
    ]);
    await view.load();
    expect(view.bestId()).toBe('b');
    expect(view.average()).toBe(79);
    expect(view.tierUp()?.r.id).toBe('c');
    expect(view.tierUp()?.next).toBe('intermediate');
    expect(view.tiers().map((t) => t.count)).toEqual([1, 1, 1, 1]);
    expect(view.pips('expert')).toBe(4);
    expect(view.pips('beginner')).toBe(1);
  });

  it('has no tier-up when every card is Expert', async () => {
    const view = setup([r('a', 'expert', 99)]);
    await view.load();
    expect(view.tierUp()).toBeNull();
  });
});
