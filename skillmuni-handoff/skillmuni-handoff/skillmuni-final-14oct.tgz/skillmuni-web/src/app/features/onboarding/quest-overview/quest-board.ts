import { Component, computed, input } from '@angular/core';
import { QUESTS, questXp } from '../../../core/quests/quest-catalog';
import { uniqueId } from '../../../shared/ui/internal/unique-id';
import { QuestIllustration } from '../../../shared/ui/quest/quest-illustration';

export type QuestBoardLayout = 'path' | 'grid' | 'list';
export type QuestBoardMode = 'intro' | 'progress';

/**
 * All 8 quests with where the learner stands. Figma R1: desktop path with dashed connectors (200:43972),
 * tablet 4 × 2 tiles (200:43874), mobile list with status (200:43556). Read-only; the page CTA resumes.
 */
@Component({
  selector: 'sm-quest-board',
  imports: [QuestIllustration],
  template: `
    <h2 class="heading" [id]="headingId" [class.sm-visually-hidden]="layout() === 'path'">
      @if (mode() === 'intro') {
        <ng-container i18n="@@board.headingIntro">Your 8 quests</ng-container>
      } @else {
        <ng-container i18n="@@board.heading">Your quests</ng-container>
      }
    </h2>
    @if (layout() === 'grid') {
      <p class="count">
        @if (summary()) {
          {{ summary() }}
        } @else {
          <ng-container i18n="@@board.count"
            >{{ completed() }} of {{ items().length }} done</ng-container
          >
        }
      </p>
    }
    <ol class="list" [attr.aria-labelledby]="headingId">
      @for (q of items(); track q.id) {
        <li
          class="quest"
          [class]="'quest is-' + q.state"
          [attr.aria-current]="q.state === 'next' ? 'step' : null"
        >
          <sm-quest-illustration [quest]="q.id" />
          <span class="text">
            <span class="name">{{ q.name }}</span>
            <span class="tagline">{{ q.tagline }}</span>
          </span>
          <span class="status" [class.sm-visually-hidden]="layout() !== 'list'">
            @switch (q.state) {
              @case ('done') {
                <ng-container i18n="@@board.done">Done ✓</ng-container>
              }
              @case ('next') {
                <ng-container i18n="@@board.next">Up next</ng-container>
              }
              @case ('open') {
                <ng-container i18n="@@board.xp">+{{ totalOf(q) }} XP</ng-container>
              }
              @default {
                <span class="sm-visually-hidden" i18n="@@board.locked">Locked,</span>
                <ng-container i18n="@@board.xp">+{{ totalOf(q) }} XP</ng-container>
              }
            }
          </span>
        </li>
      }
    </ol>
    @if (layout() === 'path') {
      <svg class="turn" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        <path
          d="M 96 18 C 104 30 104 46 92 50 L 8 50 C -4 54 -4 70 4 82"
          vector-effect="non-scaling-stroke"
        />
      </svg>
    }
  `,
  styleUrl: './quest-board.scss',
  host: { '[class]': '"sm-quest-board is-" + layout()' },
})
export class QuestBoard {
  protected readonly totalOf = questXp;
  readonly completed = input(0);
  readonly layout = input<QuestBoardLayout>('list');
  /** E1 intro: every quest looks available and shows its XP; R1 progress: done / up next / locked. */
  readonly mode = input<QuestBoardMode>('progress');
  /** Right-hand summary, e.g. "~10 mins · 400 XP · 8 badges" (E1) — defaults to "N of 8 done". */
  readonly summary = input('');
  protected readonly headingId = uniqueId('quest-board');

  protected readonly items = computed(() =>
    QUESTS.map((q) => ({
      ...q,
      state:
        this.mode() === 'intro'
          ? 'open'
          : q.id <= this.completed()
            ? 'done'
            : q.id === this.completed() + 1
              ? 'next'
              : 'locked',
    })),
  );
}
