import { Component, inject, input, output } from '@angular/core';
import { Viewport } from '../../../core/layout/viewport';
import { AppHeader } from '../../../shared/shell/app-header';
import { BrandTagline } from '../../../shared/shell/brand-tagline';
import { PageBackground } from '../../../shared/shell/page-background';
import { Button } from '../../../shared/ui/button/button';
import { MuniAvatar } from '../../../shared/ui/muni/muni-avatar';
import { MuniCharacter } from '../../../shared/ui/muni/muni-character';
import { SpeechBubble } from '../../../shared/ui/muni/speech-bubble';
import { QuestBoard, QuestBoardMode } from './quest-board';

/** Styles for content projected into the overview (owned by the page component). */
export const OVERVIEW_CONTENT_STYLES = `
  em {
    color: var(--sm-color-text-highlight);
    font-style: normal;
  }

  strong {
    display: block;
    font-weight: var(--sm-ref-font-weight-bold);
  }
`;

/**
 * The "8 quests" page frame shared by E1 Intro (200:8079 / 200:8609 / 200:8803) and R1 Welcome back
 * (200:43972 / 200:43874 / 200:43556): header, Muni + bubble, heading, quest board, one CTA.
 * Desktop: Muni left, content right · tablet: board on top, Muni beside the copy · mobile: list + pinned CTA.
 * Project `[smOverviewBubble]`, `[smOverviewTitle]`, `[smOverviewSub]`, `[smOverviewPills]` (mobile),
 * `[smOverviewCta]` (button label) and default content for loading / error states.
 */
@Component({
  selector: 'sm-quest-overview',
  imports: [
    AppHeader,
    PageBackground,
    BrandTagline,
    QuestBoard,
    Button,
    MuniAvatar,
    MuniCharacter,
    SpeechBubble,
  ],
  templateUrl: './quest-overview.html',
  styleUrl: './quest-overview.scss',
  host: { '[attr.data-size]': 'viewport.size()' },
})
export class QuestOverview {
  protected readonly viewport = inject(Viewport);

  /** Show the page body (false while loading / failed — default content is shown instead). */
  readonly ready = input(true);
  readonly busy = input(false);
  readonly exclaim = input('');
  readonly mode = input<QuestBoardMode>('progress');
  readonly completed = input(0);
  readonly summary = input('');
  readonly cta = output<void>();

  protected boardLayout() {
    const size = this.viewport.size();
    return size === 'desktop' ? 'path' : size === 'tablet' ? 'grid' : 'list';
  }
}
