import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, inject, viewChild } from '@angular/core';
import { Button } from '../../../shared/ui/button/button';
import { SmDialog } from '../../../shared/ui/overlay/dialog';
import { Tag, TagTone } from '../../../shared/ui/tag/tag';

export interface OutcomeSheetData {
  readonly tone: 'error' | 'warning' | 'info' | 'success' | 'blocked';
  readonly tag: string;
  readonly title: string;
  readonly body: string;
  readonly primary: string;
  readonly secondary?: string;
}

const TONES: Record<OutcomeSheetData['tone'], TagTone> = {
  error: 'danger',
  warning: 'warning',
  info: 'info',
  success: 'success',
  blocked: 'neutral',
};

export type OutcomeSheetResult = 'primary' | 'secondary' | undefined;

/**
 * Figma S1–S12 CV outcome sheets (200:36503 … · tablet 204:15033 …): tag, title, one line, primary
 * action and an optional quiet text action. Bottom sheet on mobile, modal elsewhere (adaptive).
 */
@Component({
  selector: 'sm-outcome-sheet',
  imports: [SmDialog, Button, Tag],
  template: `
    <sm-dialog stacked [title]="data.title" [subtitle]="data.body">
      <sm-tag smDialogLead [tone]="tagTone">{{ data.tag }}</sm-tag>
      <div smDialogActions>
        <button sm-button type="button" (click)="choose('primary')">{{ data.primary }}</button>
        @if (data.secondary) {
          <button type="button" class="quiet" (click)="choose('secondary')">
            {{ data.secondary }}
          </button>
        }
      </div>
    </sm-dialog>
  `,
  styles: `
    sm-dialog ::ng-deep .head {
      justify-items: start;
      text-align: start;
    }

    sm-dialog ::ng-deep .subtitle {
      color: var(--sm-color-text-body);
      font: var(--sm-font-body);
    }

    .quiet {
      min-block-size: var(--sm-size-touch-min);
      border: 0;
      border-radius: var(--sm-radius-full);
      background: none;
      color: var(--sm-color-text-accent);
      font: var(--sm-font-body-medium);
      cursor: pointer;
    }

    .quiet:focus-visible {
      outline: none;
      box-shadow: var(--sm-shadow-focus-ring);
    }
  `,
})
export class OutcomeSheet {
  protected readonly data = inject<OutcomeSheetData>(DIALOG_DATA);
  private readonly dialog = viewChild.required(SmDialog);
  protected readonly tagTone: TagTone = TONES[this.data.tone];

  protected choose(result: 'primary' | 'secondary'): void {
    this.dialog().close(result);
  }
}
