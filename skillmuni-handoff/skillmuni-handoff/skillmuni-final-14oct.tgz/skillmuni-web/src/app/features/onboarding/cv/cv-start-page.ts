import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, computed, inject, signal, viewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ApiError } from '../../../core/api/api-error';
import { CV_ACCEPT, CV_API, CvOutcome, checkCvFile } from '../../../core/cv/cv.api';
import { Viewport } from '../../../core/layout/viewport';
import { MARKETS, Market } from '../../../core/market/market';
import { PermissionPrimer } from '../../../core/permissions/permission-primer';
import { QUESTS } from '../../../core/quests/quest-catalog';
import { Button } from '../../../shared/ui/button/button';
import { Checkbox } from '../../../shared/ui/checkbox/checkbox';
import { Icon } from '../../../shared/ui/icon/icon';
import { IconButton } from '../../../shared/ui/icon-button/icon-button';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { ProgressBar } from '../../../shared/ui/progress-bar/progress-bar';
import { OnboardingFrame } from '../frame/onboarding-frame';
import { autoCountry } from './countries';
import { CountryField } from './country-field';
import { CvFlow, FIRST_QUEST, sizeLabel } from './cv-flow';
import { OutcomeCopy, outcomeCopy } from './cv-outcomes';
import { OutcomeSheet, OutcomeSheetData, OutcomeSheetResult } from './outcome-sheet';

/**
 * E2 · CV or manual — consent + upload (desktop 200:8210 · tablet 200:9011 · mobile 200:9317) and
 * E2b.1–6 country field states. Left: drop a CV (consent required, S12). Right: type it yourself.
 * Upload progress sits in the picked-file row with cancel (A-19). File problems open S1/S2 sheets.
 */
@Component({
  selector: 'sm-cv-start-page',
  imports: [OnboardingFrame, Checkbox, Button, Icon, IconButton, ProgressBar, CountryField],
  templateUrl: './cv-start-page.html',
  styleUrl: './cv-start-page.scss',
})
export class CvStartPage {
  private readonly api = inject(CV_API);
  private readonly router = inject(Router);
  private readonly overlay = inject(OverlayService);
  private readonly primer = inject(PermissionPrimer);
  protected readonly flow = inject(CvFlow);
  protected readonly market = inject(Market);
  protected readonly viewport = inject(Viewport);
  private readonly fileInput = viewChild.required<ElementRef<HTMLInputElement>>('fileInput');
  private upload: Subscription | null = null;

  protected readonly accept = CV_ACCEPT;
  protected readonly cancelLabel = $localize`:@@cv.cancelUpload:Cancel upload`;
  protected readonly removeLabel = $localize`:@@cv.removeFile:Remove file`;
  protected readonly consent = signal(false);
  protected readonly dragging = signal(false);
  protected readonly uploading = signal(false);
  protected readonly percent = signal(0);
  protected readonly uploadError = signal('');

  protected readonly detected =
    autoCountry(
      this.market.code(),
      Intl.DateTimeFormat().resolvedOptions().timeZone,
      inject(DOCUMENT).defaultView?.navigator.languages ?? [],
    );
  /** Corrections #5: launching in one market, so the country is the market's and is not editable. */
  protected readonly country = signal<string | null>(this.market.code());
  protected readonly countryError = signal('');

  protected readonly manualQuests = QUESTS.slice(0, 5).map((q, i) => ({
    name: q.name,
    what: MANUAL_HINTS[i],
  }));
  protected readonly canUpload = computed(
    () => !!this.flow.picked() && this.consent() && !this.uploading(),
  );

  protected browse(): void {
    setTimeout(() => this.fileInput().nativeElement.click());
  }

  protected async snap(): Promise<void> {
    const result = await this.primer.ask('camera');
    // F1: page-by-page capture with a blur check; "fallback" means the learner chose a file instead.
    if (result === 'granted' || result === 'unsupported')
      void this.router.navigateByUrl('/onboarding/cv/snap');
    else this.browse();
  }

  protected onPicked(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (file) this.pick(file);
  }

  protected onDrop(event: DragEvent): void {
    event.preventDefault();
    this.dragging.set(false);
    const file = event.dataTransfer?.files?.[0];
    if (file) this.pick(file);
  }

  protected onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.dragging.set(true);
  }

  protected removeFile(): void {
    this.cancelUpload();
    this.flow.reset();
  }

  protected start(): void {
    const picked = this.flow.picked();
    if (!picked || !this.consent() || this.uploading()) return;
    this.uploading.set(true);
    this.flow.country.set(this.country()); // A-242: detected, never asked
    this.uploadError.set('');
    this.percent.set(0);
    this.upload = this.api.upload(picked.file).subscribe({
      next: (e) => {
        if (e.kind === 'progress') this.percent.set(e.percent);
        else {
          this.flow.cvId.set(e.cvId);
          void this.router.navigateByUrl('/onboarding/cv/reading');
        }
      },
      error: (err: unknown) => {
        this.uploading.set(false);
        this.uploadError.set(
          err instanceof ApiError && err.kind === 'offline'
            ? $localize`:@@cv.uploadOffline:You’re offline. Reconnect and hit upload again.`
            : $localize`:@@cv.uploadFailed:Upload didn’t go through. Give it another go.`,
        );
      },
    });
  }

  protected cancelUpload(): void {
    this.upload?.unsubscribe();
    this.upload = null;
    this.uploading.set(false);
    this.percent.set(0);
  }

  protected typeIt(): void {
    const code = this.country();
    if (!code) {
      this.countryError.set($localize`:@@country.required:Pick your country to keep going`);
      return;
    }
    this.flow.country.set(code);
    if (code in MARKETS) this.market.set(code as keyof typeof MARKETS);
    void this.router.navigateByUrl(FIRST_QUEST);
  }

  protected onCountry(code: string | null): void {
    this.country.set(code);
    if (code) this.countryError.set('');
  }

  protected back(): void {
    void this.router.navigateByUrl('/start');
  }

  private pick(file: File): void {
    const problem = checkCvFile(file);
    if (problem) {
      const detail =
        problem === 'too-large'
          ? (file.size / (1024 * 1024)).toFixed(1)
          : (file.name.split('.').pop() ?? '');
      this.showOutcome(problem, detail);
      return;
    }
    this.cancelUpload();
    this.flow.reset();
    this.flow.picked.set({ file, name: file.name, sizeLabel: sizeLabel(file.size) });
  }

  private showOutcome(outcome: CvOutcome, detail: string): void {
    const copy: OutcomeCopy = outcomeCopy(outcome, detail);
    const ref = this.overlay.adaptive<OutcomeSheet, OutcomeSheetData, OutcomeSheetResult>(
      OutcomeSheet,
      {
        data: copy,
        size: 'sm',
      },
    );
    ref.closed.subscribe((choice) => {
      const action =
        choice === 'primary'
          ? copy.primaryAction
          : choice === 'secondary'
            ? copy.secondaryAction
            : null;
      if (action === 'choose-file') this.browse();
      if (action === 'type-it') this.typeIt();
    });
  }
}

const MANUAL_HINTS = [
  $localize`:@@cv.manual.1:Your name & birthday`,
  $localize`:@@cv.manual.2:Phone, email, address`,
  $localize`:@@cv.manual.3:School & qualifications`,
  $localize`:@@cv.manual.4:Skills & languages`,
  $localize`:@@cv.manual.5:Jobs, gigs, internships`,
];
