import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

export const onboardingRoutes: Routes = [
  {
    path: 'start',
    title: $localize`:@@route.intro:Meet Muni · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./intro/intro-page').then((m) => m.IntroPage),
  },
  {
    path: 'onboarding/cv',
    canActivate: [requireSession],
    children: [
      {
        path: '',
        title: $localize`:@@route.cv:Your CV · Skillmuni`,
        loadComponent: () => import('./cv/cv-start-page').then((m) => m.CvStartPage),
      },
      {
        path: 'snap',
        title: $localize`:@@route.cvSnap:Snap your CV · Skillmuni`,
        loadComponent: () => import('./cv/cv-snap-page').then((m) => m.CvSnapPage),
      },
      {
        path: 'reading',
        title: $localize`:@@route.cvReading:Reading your CV · Skillmuni`,
        loadComponent: () => import('./cv/cv-reading-page').then((m) => m.CvReadingPage),
      },
      {
        path: 'summary',
        title: $localize`:@@route.cvSummary:What we found · Skillmuni`,
        loadComponent: () => import('./cv/cv-summary-page').then((m) => m.CvSummaryPage),
      },
    ],
  },
];
