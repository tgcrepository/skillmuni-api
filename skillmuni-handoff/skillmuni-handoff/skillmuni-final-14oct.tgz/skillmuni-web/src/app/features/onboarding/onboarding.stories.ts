import type { Meta, StoryObj } from '@storybook/angular-vite';
import { applicationConfig } from '@storybook/angular-vite';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { inject, provideEnvironmentInitializer } from '@angular/core';
import { of } from 'rxjs';
import { CV_API } from '../../core/cv/cv.api';
import { CvFlow } from './cv/cv-flow';
import { CvStartPage } from './cv/cv-start-page';
import { CvSummaryPage } from './cv/cv-summary-page';
import { IntroPage } from './intro/intro-page';

const meta: Meta = {
  title: 'Screens/6c Entry',
  decorators: [
    applicationConfig({
      providers: [
        provideRouter([]),
        provideHttpClient(),
        {
          provide: CV_API,
          useValue: {
            upload: () => of(),
            status: () => of(),
            summary: () => of(),
            remove: () => of(),
          },
        },
      ],
    }),
  ],
  parameters: { layout: 'fullscreen', figma: { node: 'E1 200:8079 · E2 200:8210 · E4 200:8400' } },
};
export default meta;

export const Intro: StoryObj = {
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [IntroPage] } })],
  render: () => ({ template: `<sm-intro-page />` }),
};

export const CvOrManual: StoryObj = {
  decorators: [(story) => ({ ...story(), moduleMetadata: { imports: [CvStartPage] } })],
  render: () => ({ template: `<sm-cv-start-page />` }),
};

export const Summary: StoryObj = {
  decorators: [
    applicationConfig({
      providers: [
        provideEnvironmentInitializer(() => {
          inject(CvFlow).summary.set({
            questsPrefilled: 5,
            detailsFound: 31,
            toCheck: 1,
            skillsMatched: 9,
            skipped: ['photo', 'ID number', 'marital status'],
            sections: [
              {
                quest: 1,
                title: 'Your name',
                badge: '2 found',
                fields: [
                  { key: 'f', label: 'First name', value: 'Nkosazana' },
                  { key: 'l', label: 'Last name', value: 'Dlamini' },
                ],
              },
              {
                quest: 4,
                title: 'Skills & languages',
                badge: '9 skills · 3 languages',
                chips: [
                  'Customer service',
                  'Active listening',
                  'MS Excel',
                  'Typing',
                  'Teamwork',
                  'Scheduling',
                  'Sales',
                ],
                fields: [
                  {
                    key: 'lang',
                    label: 'Languages',
                    value: 'isiZulu · English · Sesotho',
                    check: 'How well do you speak Sesotho?',
                  },
                ],
              },
            ],
          });
        }),
      ],
    }),
    (story) => ({ ...story(), moduleMetadata: { imports: [CvSummaryPage] } }),
  ],
  render: () => ({ template: `<sm-cv-summary-page />` }),
};
