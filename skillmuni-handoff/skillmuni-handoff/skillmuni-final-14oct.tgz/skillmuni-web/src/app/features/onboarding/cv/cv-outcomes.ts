import { CvOutcome } from '../../../core/cv/cv.api';
import { OutcomeSheetData } from './outcome-sheet';

/** What the primary / secondary buttons of an outcome sheet do. */
export type OutcomeAction = 'choose-file' | 'retry' | 'type-it' | 'continue' | 'retake' | 'login';

export interface OutcomeCopy extends OutcomeSheetData {
  readonly primaryAction: OutcomeAction;
  readonly secondaryAction?: OutcomeAction;
}

const TYPE_IT = $localize`:@@cvo.typeIt:Type it myself`;
const CHOOSE = $localize`:@@cvo.choose:Choose another file`;
const KEEP = $localize`:@@cvo.keepGoing:Keep going`;

/** Figma S1–S9 copy. `detail` fills the file type, size, language, count or support reference. */
export function outcomeCopy(outcome: CvOutcome, detail = ''): OutcomeCopy {
  const error = $localize`:@@cvo.tagError:Error`;
  const warning = $localize`:@@cvo.tagWarning:Warning`;
  switch (outcome) {
    case 'unsupported-type':
      return {
        tone: 'error',
        tag: error,
        title: $localize`:@@cvo.s1.title:Can't read this type`,
        body: $localize`:@@cvo.s1.body:Muni can't read .${detail}:ext: files. Use PDF, Word or a photo of your CV.`,
        primary: CHOOSE,
        primaryAction: 'choose-file',
        secondary: TYPE_IT,
        secondaryAction: 'type-it',
      };
    case 'too-large':
      return {
        tone: 'error',
        tag: error,
        title: $localize`:@@cvo.s2.title:That file's a bit chunky`,
        body: $localize`:@@cvo.s2.body:It's ${detail}:size: MB. Keep it under 10 MB — export a PDF or snap a photo instead.`,
        primary: CHOOSE,
        primaryAction: 'choose-file',
        secondary: TYPE_IT,
        secondaryAction: 'type-it',
      };
    case 'locked-pdf':
      return {
        tone: 'error',
        tag: error,
        title: $localize`:@@cvo.s3.title:This PDF is locked`,
        body: $localize`:@@cvo.s3.body:It's password-protected. Save an unlocked copy and drop it again.`,
        primary: CHOOSE,
        primaryAction: 'choose-file',
        secondary: TYPE_IT,
        secondaryAction: 'type-it',
      };
    case 'blurry-photo':
      return {
        tone: 'warning',
        tag: warning,
        title: $localize`:@@cvo.s4.title:Your photo's a little blurry`,
        body: $localize`:@@cvo.s4.body:Muni couldn't read some bits. Lay it flat in good light and try again.`,
        primary: $localize`:@@cvo.retake:Retake photo`,
        primaryAction: 'choose-file',
        secondary: TYPE_IT,
        secondaryAction: 'type-it',
      };
    case 'other-language':
      return {
        tone: 'info',
        tag: $localize`:@@cvo.tagInfo:Heads up`,
        title: $localize`:@@cvo.s5.title:Your CV is in ${detail}:language: — sharp!`,
        body: $localize`:@@cvo.s5.body:Muni read it fine. Your profile will show in English.`,
        primary: KEEP,
        primaryAction: 'continue',
      };
    case 'parse-failed':
      return {
        tone: 'error',
        tag: error,
        title: $localize`:@@cvo.s6.title:Muni got stuck reading that`,
        body: $localize`:@@cvo.s6.body:Your file is saved (ref ${detail}:ref:). Try again or type it in.`,
        primary: $localize`:@@ui.tryAgain:Try again`,
        primaryAction: 'retry',
        secondary: TYPE_IT,
        secondaryAction: 'type-it',
      };
    case 'no-work-history':
      return {
        tone: 'warning',
        tag: warning,
        title: $localize`:@@cvo.s7.title:Found your school and skills`,
        body: $localize`:@@cvo.s7.body:No work history on this CV — you'll add it in Work Lore.`,
        primary: KEEP,
        primaryAction: 'continue',
      };
    case 'little-found':
      return {
        tone: 'warning',
        tag: warning,
        title: $localize`:@@cvo.s8.title:Couldn't pull much from this one`,
        body: $localize`:@@cvo.s8.body:Muni found ${detail}:count: details. You'll fill in the rest as you go.`,
        primary: KEEP,
        primaryAction: 'continue',
        secondary: CHOOSE,
        secondaryAction: 'choose-file',
      };
    case 'email-taken':
      return {
        tone: 'warning',
        tag: warning,
        title: $localize`:@@cvo.s9.title:That email already has an account`,
        body: $localize`:@@cvo.s9.body:The email on your CV belongs to another account. We'll keep the one you signed up with.`,
        primary: KEEP,
        primaryAction: 'continue',
      };
  }
}
