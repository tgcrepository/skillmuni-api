import { BLUR_THRESHOLD, laplacianVariance } from './sharpness';

describe('laplacianVariance', () => {
  const image = (w: number, h: number, f: (x: number, y: number) => number) =>
    Array.from({ length: w * h }, (_, i) => f(i % w, Math.floor(i / w)));

  it('scores sharp text-like edges above the threshold and a flat page below it', () => {
    const sharp = image(40, 40, (x, y) => (((x >> 1) + (y >> 1)) % 2 ? 240 : 20));
    const flat = image(40, 40, () => 128);
    const soft = image(40, 40, (x) => 100 + x); // gentle gradient, no edges
    expect(laplacianVariance(sharp, 40, 40)).toBeGreaterThan(BLUR_THRESHOLD);
    expect(laplacianVariance(flat, 40, 40)).toBe(0);
    expect(laplacianVariance(soft, 40, 40)).toBeLessThan(BLUR_THRESHOLD);
  });
});
