import {
  Component,
  ElementRef,
  OnDestroy,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ApiError } from '../../../core/api/api-error';
import { CV_API } from '../../../core/cv/cv.api';
import { Market } from '../../../core/market/market';
import { Banner } from '../../../shared/ui/banner/banner';
import { Button } from '../../../shared/ui/button/button';
import { Checkbox } from '../../../shared/ui/checkbox/checkbox';
import { Icon } from '../../../shared/ui/icon/icon';
import { ProgressBar } from '../../../shared/ui/progress-bar/progress-bar';
import { ToastService } from '../../../shared/ui/toast/toast.service';
import { OnboardingFrame } from '../frame/onboarding-frame';
import { CvFlow } from './cv-flow';
import { BLUR_THRESHOLD, sharpness } from './sharpness';

interface Page {
  readonly id: number;
  readonly file: File;
  readonly url: string;
  readonly state: 'checking' | 'ok' | 'blurry';
}

const MAX_PAGES = 10;

/**
 * F1 · Snap each page of your CV (Figma mobile extras 200:36331). Each page opens the phone camera
 * (native capture), gets a blur check, and can be retaken or removed. "Done — read my CV" uploads all
 * pages together and goes to E3 parsing. Reached from E2 "Snap a photo instead" (tablet / mobile).
 */
@Component({
  selector: 'sm-cv-snap-page',
  imports: [OnboardingFrame, Banner, Button, Checkbox, Icon, ProgressBar],
  templateUrl: './cv-snap-page.html',
  styleUrl: './cv-snap-page.scss',
})
export class CvSnapPage implements OnDestroy {
  private readonly router = inject(Router);
  private readonly api = inject(CV_API);
  private readonly flow = inject(CvFlow);
  private readonly toast = inject(ToastService);
  protected readonly market = inject(Market);
  private readonly camera = viewChild.required<ElementRef<HTMLInputElement>>('camera');

  protected readonly pages = signal<readonly Page[]>([]);
  protected readonly selected = signal<number | null>(null);
  protected readonly consent = signal(false);
  protected readonly attempted = signal(false);
  protected readonly uploading = signal(false);
  protected readonly percent = signal(0);
  protected readonly uploadError = signal('');
  private upload: Subscription | null = null;
  private replacing: number | null = null;
  private nextId = 1;

  protected readonly current = computed(() => {
    const list = this.pages();
    return list.find((p) => p.id === this.selected()) ?? list.at(-1) ?? null;
  });
  protected readonly currentIndex = computed(() => {
    const c = this.current();
    return c ? this.pages().indexOf(c) + 1 : this.pages().length + 1;
  });
  protected readonly checking = computed(() => this.pages().some((p) => p.state === 'checking'));
  protected readonly blurry = computed(() => this.pages().filter((p) => p.state === 'blurry'));
  protected readonly full = computed(() => this.pages().length >= MAX_PAGES);
  protected readonly why = computed(() => {
    if (!this.pages().length) return $localize`:@@snap.whyNone:Snap at least one page`;
    if (this.attempted() && !this.consent())
      return $localize`:@@snap.whyConsent:Tick the box so Muni can read your CV`;
    return '';
  });

  protected readonly pageLabel = (i: number) => $localize`:@@snap.page:Page ${i}:n:`;
  protected readonly chipLabel = (i: number, state: Page['state']) =>
    state === 'ok'
      ? $localize`:@@snap.chipOk:Page ${i}:n:, sharp`
      : state === 'blurry'
        ? $localize`:@@snap.chipBlurry:Page ${i}:n:, blurry`
        : $localize`:@@snap.chipChecking:Page ${i}:n:, checking`;

  ngOnDestroy(): void {
    this.upload?.unsubscribe();
    // Pages handed to the upload keep their File; only the preview URLs go.
    for (const p of this.pages()) URL.revokeObjectURL(p.url);
  }

  protected snap(replace: number | null = null): void {
    if (replace === null && this.full()) return;
    this.replacing = replace;
    this.camera().nativeElement.click();
  }

  protected async onPhoto(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      this.toast.show(
        $localize`:@@snap.notPhoto:That isn’t a photo. Snap the page with your camera.`,
        {
          tone: 'error',
        },
      );
      return;
    }
    const id = this.replacing ?? this.nextId++;
    const page: Page = { id, file, url: URL.createObjectURL(file), state: 'checking' };
    this.pages.update((list) => {
      const old = list.find((p) => p.id === id);
      if (old) URL.revokeObjectURL(old.url);
      return old ? list.map((p) => (p.id === id ? page : p)) : [...list, page];
    });
    this.selected.set(id);
    this.replacing = null;
    const score = await sharpness(file);
    const state = score !== null && score < BLUR_THRESHOLD ? 'blurry' : 'ok';
    this.pages.update((list) =>
      list.map((p) => (p.id === id && p.file === file ? { ...p, state } : p)),
    );
  }

  protected select(id: number): void {
    this.selected.set(id);
  }

  protected keep(id: number): void {
    this.pages.update((list) => list.map((p) => (p.id === id ? { ...p, state: 'ok' } : p)));
  }

  protected remove(id: number): void {
    this.pages.update((list) => {
      const old = list.find((p) => p.id === id);
      if (old) URL.revokeObjectURL(old.url);
      return list.filter((p) => p.id !== id);
    });
    this.selected.set(null);
  }

  protected done(): void {
    this.attempted.set(true);
    const pages = this.pages();
    if (!pages.length || !this.consent() || this.checking() || this.uploading()) return;
    const files = pages.map((p, i) => renamed(p.file, i + 1));
    this.flow.reset();
    this.flow.pages.set(files);
    this.uploading.set(true);
    this.uploadError.set('');
    this.percent.set(0);
    this.upload = this.api.upload(files).subscribe({
      next: (e) => {
        if (e.kind === 'progress') this.percent.set(e.percent);
        else {
          this.flow.cvId.set(e.cvId);
          void this.router.navigateByUrl('/onboarding/cv/reading');
        }
      },
      error: (err: unknown) => {
        this.uploading.set(false);
        this.uploadError.set(
          err instanceof ApiError && err.kind === 'offline'
            ? $localize`:@@cv.uploadOffline:You’re offline. Reconnect and hit upload again.`
            : $localize`:@@cv.uploadFailed:Upload didn’t go through. Give it another go.`,
        );
      },
    });
  }

  protected cancelUpload(): void {
    this.upload?.unsubscribe();
    this.upload = null;
    this.uploading.set(false);
  }

  protected uploadInstead(): void {
    void this.router.navigateByUrl('/onboarding/cv');
  }
}

/** Keeps the original name (it carries mock outcome hints) but orders pages for the parser. */
function renamed(file: File, n: number): File {
  return new File([file], `page-${String(n).padStart(2, '0')}-${file.name}`, { type: file.type });
}
