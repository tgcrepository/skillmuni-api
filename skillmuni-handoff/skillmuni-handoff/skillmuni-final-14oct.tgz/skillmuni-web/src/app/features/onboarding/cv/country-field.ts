import { DOCUMENT } from '@angular/common';
import {
  booleanAttribute,
  Component,
  ElementRef,
  computed,
  inject,
  input,
  model,
  signal,
  viewChild,
} from '@angular/core';
import { Field } from '../../../shared/ui/field/field';
import { Icon } from '../../../shared/ui/icon/icon';
import { Select, SelectOption } from '../../../shared/ui/select/select';
import { Tag } from '../../../shared/ui/tag/tag';
import { countries, flagOf } from './countries';

/**
 * Figma: Country Field (233:20869) — E2 "I’ll type it myself" and E2b.1–6.
 * A-242: the country is auto-detected, so nobody is asked to pick it. It shows as a read-out
 * ("🇮🇳 India · Auto-detected") with a quiet "Change" for the rare wrong guess, which opens the
 * searchable picker. Only when nothing could be detected does the picker show (and can error).
 * Sets address, school and phone formats.
 */
@Component({
  selector: 'sm-country-field',
  imports: [Field, Icon, Select, Tag],
  template: `
    @if (value() && !editing()) {
      <div class="detected" role="group" [attr.aria-label]="groupLabel">
        <sm-icon name="map-pin" size="sm" />
        <span class="detected-name">
          <span aria-hidden="true">{{ flag() }}</span> {{ name() }}
        </span>
        @if (value() === detected() || locked()) {
          <sm-tag tone="success" i18n="@@country.auto">Auto-detected</sm-tag>
        }
        @if (!locked()) {
          <button type="button" class="change" (click)="edit()">
            <ng-container i18n="@@country.change">Change</ng-container>
            <span class="sm-visually-hidden" i18n="@@country.changeSr">country</span>
          </button>
        }
      </div>
    } @else {
      <div #picker>
        <sm-field
          i18n-label="@@country.label"
          label="Country"
          required
          [error]="error()"
          i18n-helper="@@country.helper"
          helper="Sets your address, school and phone formats"
        >
          <sm-select
            [options]="options()"
            [value]="value()"
            (valueChange)="pick($event)"
            [searchable]="true"
            i18n-placeholder="@@country.placeholder"
            placeholder="Pick your country"
          />
        </sm-field>
      </div>
    }
  `,
  styles: `
    .detected {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: var(--sm-space-200) var(--sm-space-250);
      padding: var(--sm-space-300) var(--sm-space-400);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-subtle);
      border-radius: var(--sm-radius-xl);
      background: var(--sm-color-surface-inset);
      color: var(--sm-color-icon-muted);
    }

    .detected-name {
      color: var(--sm-color-text-heading);
      font: var(--sm-font-body-sm-semibold);
    }

    .change {
      margin-inline-start: auto;
      padding: var(--sm-space-100) var(--sm-space-200);
      border: 0;
      border-radius: var(--sm-radius-md);
      background: none;
      color: var(--sm-color-text-link);
      font: var(--sm-font-caption-semibold);
      text-decoration: underline;
      cursor: pointer;
    }

    .change:focus-visible {
      box-shadow: var(--sm-shadow-focus-ring);
      outline: none;
    }
  `,
})
export class CountryField {
  private readonly locale = inject(DOCUMENT).documentElement.lang || 'en';
  readonly value = model<string | null>(null);
  /** The code we detected (market → time zone → locale), for the "Auto-detected" tag. */
  readonly detected = input<string | null>(null);
  readonly error = input('');
  /** Corrections #5: one launch market (India), so the country is shown but can't be changed. */
  readonly locked = input(false, { transform: booleanAttribute });

  protected readonly editing = signal(false);
  private readonly picker = viewChild<ElementRef<HTMLElement>>('picker');
  protected readonly groupLabel = $localize`:@@country.label:Country`;

  private readonly all = computed(() => countries(this.locale));
  protected readonly options = computed<readonly SelectOption[]>(() =>
    this.all().map((c) => ({ value: c.code, label: `${c.flag}  ${c.name}` })),
  );
  protected readonly name = computed(
    () => this.all().find((c) => c.code === this.value())?.name ?? this.value() ?? '',
  );
  protected readonly flag = computed(() => (this.value() ? flagOf(this.value() ?? '') : ''));

  protected edit(): void {
    this.editing.set(true);
    setTimeout(() =>
      this.picker()?.nativeElement.querySelector<HTMLElement>('input, button')?.focus(),
    );
  }

  protected pick(code: string | null): void {
    this.value.set(code);
    if (code) this.editing.set(false);
  }
}
