import { Component, booleanAttribute, input, output } from '@angular/core';
import { AppHeader } from '../../../shared/shell/app-header';
import { BrandTagline } from '../../../shared/shell/brand-tagline';
import { PageBackground } from '../../../shared/shell/page-background';

/**
 * Page frame for single-column onboarding screens (E2, E3, E4): header "Let’s Gooo" (back chevron on
 * mobile), glows, centred content up to the card width, tagline + "Powered by" footer on tablet/desktop.
 */
@Component({
  selector: 'sm-onboarding-frame',
  imports: [AppHeader, PageBackground, BrandTagline],
  template: `
    <sm-page-background />
    <sm-app-header
      i18n-title="@@welcome.header"
      title="Let’s Gooo"
      [showBack]="showBack()"
      [showExit]="false"
      (back)="back.emit()"
    />
    <main class="page" id="sm-main" [class.is-wide]="wide()">
      <ng-content />
    </main>
    <footer class="foot">
      <sm-brand-tagline />
      <p class="powered" i18n="@@shell.powered">© Powered by The Gamification Company</p>
    </footer>
  `,
  styles: `
    @use 'mq';

    :host {
      display: flex;
      flex-direction: column;
      gap: var(--sm-layout-page-column-gap);
      min-block-size: 100dvh;
      padding: var(--sm-layout-shell-header-inset-mobile);
    }

    sm-app-header {
      position: sticky;
      inset-block-start: var(--sm-layout-shell-header-inset-mobile);
      z-index: var(--sm-z-header);
    }

    .page {
      display: grid;
      flex: 1 0 auto;
      align-content: start;
      gap: var(--sm-space-600);
      inline-size: 100%;
      max-inline-size: var(--sm-layout-shell-card-max-width);
      margin-inline: auto;
      padding-block: var(--sm-space-600);
    }

    .page.is-wide {
      max-inline-size: var(--sm-layout-content-max-width);
    }

    .page:focus {
      outline: none;
    }

    .foot {
      display: none;
    }

    @include mq.tablet-up {
      :host {
        padding: var(--sm-layout-shell-header-inset);
      }

      sm-app-header {
        inset-block-start: var(--sm-layout-shell-header-inset);
      }

      .foot {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        gap: var(--sm-space-600);
      }

      .powered {
        color: var(--sm-color-text-tertiary);
        font: var(--sm-font-caption-semibold);
      }
    }
  `,
})
export class OnboardingFrame {
  readonly showBack = input(true, { transform: booleanAttribute });
  /** Two-column screens (E2, E4) use the wider content width. */
  readonly wide = input(false, { transform: booleanAttribute });
  readonly back = output<void>();
}
