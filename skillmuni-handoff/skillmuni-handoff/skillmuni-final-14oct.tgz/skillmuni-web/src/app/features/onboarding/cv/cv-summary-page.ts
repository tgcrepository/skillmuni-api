import { Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CvSection } from '../../../core/cv/cv.api';
import { QUESTS, questById } from '../../../core/quests/quest-catalog';
import { Button } from '../../../shared/ui/button/button';
import { Icon } from '../../../shared/ui/icon/icon';
import { Tag } from '../../../shared/ui/tag/tag';
import { TextLink } from '../../../shared/ui/text-link/text-link';
import { OnboardingFrame } from '../frame/onboarding-frame';
import { CvFlow, FIRST_QUEST } from './cv-flow';

const VISIBLE_CHIPS = 6;

/**
 * E4 · CV summary — everything we found (desktop 200:8400 · tablet 200:9421 · mobile 200:9114).
 * Stats, one card per pre-filled quest (amber "Check" rows need a look).
 * Every row links into its quest; "Looks right, let's go" opens Quest 1 pre-filled.
 */
@Component({
  selector: 'sm-cv-summary-page',
  imports: [OnboardingFrame, Button, Icon, Tag, TextLink, RouterLink],
  templateUrl: './cv-summary-page.html',
  styleUrl: './cv-summary-page.scss',
})
export class CvSummaryPage {
  private readonly router = inject(Router);
  protected readonly flow = inject(CvFlow);
  protected readonly summary = this.flow.summary;
  protected readonly showAllChips = signal(false);
  protected readonly visibleChips = VISIBLE_CHIPS;
  protected readonly editLabel = $localize`:@@e4.editField:Edit`;

  constructor() {
    if (!this.summary()) void this.router.navigateByUrl('/onboarding/cv');
  }

  protected left(sections: readonly CvSection[]): readonly CvSection[] {
    return sections.filter((s) => s.quest <= 3);
  }

  protected right(sections: readonly CvSection[]): readonly CvSection[] {
    return sections.filter((s) => s.quest > 3);
  }

  protected questLink(quest: number): string {
    return `/quests/${questById(quest)?.slug ?? QUESTS[0]?.slug}`;
  }

  protected eyebrow(quest: number): string {
    return $localize`:@@e4.eyebrow:Quest ${quest}:n: · ${questById(quest)?.name ?? ''}:name:`;
  }

  protected hasCheck(section: CvSection): boolean {
    return section.fields.some((f) => !!f.check);
  }

  protected differentCv(): void {
    this.flow.reset();
    void this.router.navigateByUrl('/onboarding/cv');
  }

  protected go(): void {
    void this.router.navigateByUrl(FIRST_QUEST);
  }

  protected back(): void {
    void this.router.navigateByUrl('/onboarding/cv');
  }
}
