/**
 * Blur check for photographed CV pages (F1): variance of the Laplacian on a small grayscale copy.
 * Sharp text has strong edges (high variance); a shaky or out-of-focus photo is smooth (low variance).
 */
export const BLUR_THRESHOLD = 40;
const SAMPLE_WIDTH = 320;

/** Variance of the 4-neighbour Laplacian over a grayscale image (0–255 per pixel). */
export function laplacianVariance(gray: ArrayLike<number>, width: number, height: number): number {
  let sum = 0;
  let sumSq = 0;
  let n = 0;
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const i = y * width + x;
      const v =
        (gray[i - width] ?? 0) +
        (gray[i + width] ?? 0) +
        (gray[i - 1] ?? 0) +
        (gray[i + 1] ?? 0) -
        4 * (gray[i] ?? 0);
      sum += v;
      sumSq += v * v;
      n++;
    }
  }
  if (!n) return 0;
  const mean = sum / n;
  return sumSq / n - mean * mean;
}

/** Sharpness score for an image file, or null when the browser can't decode it (then we skip the check). */
export async function sharpness(file: File): Promise<number | null> {
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, SAMPLE_WIDTH / bitmap.width);
    const width = Math.max(3, Math.round(bitmap.width * scale));
    const height = Math.max(3, Math.round(bitmap.height * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return null;
    ctx.drawImage(bitmap, 0, 0, width, height);
    bitmap.close();
    const { data } = ctx.getImageData(0, 0, width, height);
    const gray = new Float32Array(width * height);
    for (let i = 0; i < gray.length; i++) {
      gray[i] =
        0.299 * (data[i * 4] ?? 0) +
        0.587 * (data[i * 4 + 1] ?? 0) +
        0.114 * (data[i * 4 + 2] ?? 0);
    }
    return laplacianVariance(gray, width, height);
  } catch {
    return null;
  }
}
