import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { QUESTS, TOTAL_XP } from '../../../core/quests/quest-catalog';
import { Pill } from '../../../shared/ui/pill/pill';
import { OVERVIEW_CONTENT_STYLES, QuestOverview } from '../quest-overview/quest-overview';

/** Next step after E1: consent + CV upload or manual (E2). */
export const CV_STEP = '/onboarding/cv';

/**
 * E1 Onboarding · Intro — Meet Muni. Desktop 200:8079 · tablet 200:8609 · mobile 200:8803.
 * First screen after verifying: what the 8 quests are, roughly how long, what you earn.
 */
@Component({
  selector: 'sm-intro-page',
  imports: [QuestOverview, Pill],
  template: `
    <sm-quest-overview mode="intro" [exclaim]="exclaim" [summary]="summary" (cta)="start()">
      <ng-container smOverviewBubble>
        <strong i18n="@@intro.bubbleTitle">Welcome to Skillmuni, bestie</strong>
        <span i18n="@@intro.bubble">
          {{ count }} quick quests, a bunch of XP and some badges. Lowkey the most fun sign-up
          you’ll ever do.</span
        >
      </ng-container>
      <ng-container smOverviewTitle i18n="@@intro.title"
        >A few quick quests, then it’s your <em>glow-up era</em></ng-container
      >
      <ng-container smOverviewSub i18n="@@intro.sub"
        >Sign up once and we’ll match you with courses and opportunities that actually fit your
        vibe. Your progress saves as you go, no cap.</ng-container
      >
      <ng-container smOverviewPills>
        <sm-pill tone="brand" i18n="@@intro.pillTime">10 mins</sm-pill>
        <sm-pill tone="brand" i18n="@@intro.pillXp">{{ xp }} XP</sm-pill>
        <sm-pill tone="brand" i18n="@@intro.pillBadges">{{ count }} badges</sm-pill>
      </ng-container>
      <ng-container smOverviewCta i18n="@@intro.cta">Let’s gooo</ng-container>
    </sm-quest-overview>
  `,
  styles: OVERVIEW_CONTENT_STYLES,
})
export class IntroPage {
  private readonly router = inject(Router);
  protected readonly count = QUESTS.length;
  protected readonly xp = TOTAL_XP;
  protected readonly exclaim = $localize`:@@intro.exclaim:Heyyy, I’m Muni!`;
  protected readonly summary = $localize`:@@intro.summary:10 mins · ${TOTAL_XP}:xp: XP · ${QUESTS.length}:count: badges`;

  protected start(): void {
    void this.router.navigateByUrl(CV_STEP);
  }
}
