import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { CV_API, CvApi, CvSummary, checkCvFile } from '../../../core/cv/cv.api';
import { countries, detectCountry } from './countries';
import { CvFlow } from './cv-flow';
import { CvStartPage } from './cv-start-page';
import { CvSummaryPage } from './cv-summary-page';
import { outcomeCopy } from './cv-outcomes';

const file = (name: string, size = 1000) => new File([new Uint8Array(size)], name);

describe('CV helpers', () => {
  it('rejects unsupported types (S1) and big files (S2)', () => {
    expect(checkCvFile(file('cv.pages'))).toBe('unsupported-type');
    expect(checkCvFile(file('cv.pdf', 11 * 1024 * 1024))).toBe('too-large');
    expect(checkCvFile(file('cv.docx'))).toBeNull();
    expect(checkCvFile(file('photo.HEIC'))).toBeNull();
  });

  it('outcome copy fills details', () => {
    expect(outcomeCopy('unsupported-type', 'pages').body).toContain('.pages');
    expect(outcomeCopy('parse-failed', 'CV-2291').body).toContain('CV-2291');
    expect(outcomeCopy('other-language', 'Afrikaans').title).toContain('Afrikaans');
  });

  it('country names come from Intl and the browser region is detected', () => {
    const list = countries('en');
    expect(list.find((c) => c.code === 'ZA')?.name).toBe('South Africa');
    expect(list.filter((c) => c.name.toLowerCase().includes('so')).length).toBeGreaterThan(1);
    expect(detectCountry(['en-IN', 'en'])).toBe('IN');
    expect(detectCountry(['en'])).toBeNull();
  });
});

describe('CvStartPage (E2)', () => {
  function setup(api: Partial<CvApi> = {}) {
    TestBed.configureTestingModule({
      providers: [provideRouter([]), { provide: CV_API, useValue: api }],
    });
    const fixture = TestBed.createComponent(CvStartPage);
    fixture.detectChanges();
    return { fixture, el: fixture.nativeElement as HTMLElement };
  }

  afterEach(() => document.querySelector('.cdk-overlay-container')?.replaceChildren());

  it('upload needs a file and consent (S12), then uploads and moves to E3', async () => {
    const upload = vi.fn(() => of({ kind: 'done' as const, cvId: 'cv-1' }));
    const { fixture, el } = setup({ upload });
    const nav = vi.spyOn(TestBed.inject(Router), 'navigateByUrl').mockResolvedValue(true);
    const input = el.querySelector<HTMLInputElement>('input[type="file"]')!;
    Object.defineProperty(input, 'files', { value: [file('Nkosazana_CV.pdf')] });
    input.dispatchEvent(new Event('change'));
    fixture.detectChanges();
    expect(el.textContent).toContain('Nkosazana_CV.pdf');
    expect(el.textContent).toContain('Tick the box so Muni can read your CV');
    const uploadBtn = [...el.querySelectorAll<HTMLButtonElement>('button[sm-button]')].find((b) =>
      b.textContent?.includes('Upload'),
    )!;
    expect(uploadBtn.getAttribute('aria-disabled')).toBe('true');

    el.querySelector<HTMLInputElement>('sm-checkbox input')!.click();
    fixture.detectChanges();
    uploadBtn.click();
    expect(upload).toHaveBeenCalled();
    expect(TestBed.inject(CvFlow).cvId()).toBe('cv-1');
    expect(nav).toHaveBeenCalledWith('/onboarding/cv/reading');
  });

  it('a .pages file opens the S1 sheet', async () => {
    const { fixture, el } = setup();
    const input = el.querySelector<HTMLInputElement>('input[type="file"]')!;
    Object.defineProperty(input, 'files', { value: [file('cv.pages')] });
    input.dispatchEvent(new Event('change'));
    fixture.detectChanges();
    await vi.waitFor(() =>
      expect(document.querySelector('.sm-pane')?.textContent).toContain("Can't read this type"),
    );
  });
});

describe('CvSummaryPage (E4)', () => {
  it('renders stats and check rows, with no privacy note', () => {
    TestBed.configureTestingModule({ providers: [provideRouter([])] });
    const summary: CvSummary = {
      questsPrefilled: 5,
      detailsFound: 31,
      toCheck: 1,
      skillsMatched: 9,
      skipped: ['photo', 'ID number'],
      sections: [
        {
          quest: 2,
          title: 'Contact & address',
          badge: '1 found · 1 to check',
          fields: [
            { key: 'area', label: 'Area', value: 'Randburg', check: 'Add your postal code' },
          ],
        },
      ],
    };
    TestBed.inject(CvFlow).summary.set(summary);
    const fixture = TestBed.createComponent(CvSummaryPage);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('h1')?.textContent).toContain('hired vibes');
    expect(el.querySelector('.row.is-check')?.textContent).toContain('Add your postal code');
    expect(el.querySelector('.row.is-check a')?.getAttribute('href')).toBe('/quests/hit-me-up');
    expect(el.querySelector('.privacy')).toBeNull();
  });
});
