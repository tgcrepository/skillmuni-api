/** ISO 3166-1 alpha-2 codes. Names come from Intl.DisplayNames in the learner's locale (no copy to translate). */
const CODES =
  'AF AL DZ AD AO AG AR AM AU AT AZ BS BH BD BB BY BE BZ BJ BT BO BA BW BR BN BG BF BI CV KH CM CA CF TD CL CN CO KM CG CD CR CI HR CU CY CZ DK DJ DM DO EC EG SV GQ ER EE SZ ET FJ FI FR GA GM GE DE GH GR GD GT GN GW GY HT HN HU IS IN ID IR IQ IE IL IT JM JP JO KZ KE KI KW KG LA LV LB LS LR LY LI LT LU MG MW MY MV ML MT MH MR MU MX FM MD MC MN ME MA MZ MM NA NR NP NL NZ NI NE NG KP MK NO OM PK PW PA PG PY PE PH PL PT QA RO RU RW KN LC VC WS SM ST SA SN RS SC SL SG SK SI SB SO ZA KR SS ES LK SD SR SE CH SY TW TJ TZ TH TL TG TO TT TN TR TM TV UG UA AE GB US UY UZ VU VE VN YE ZM ZW'.split(
    ' ',
  );

export interface Country {
  readonly code: string;
  readonly name: string;
  readonly flag: string;
}

export function flagOf(code: string): string {
  return String.fromCodePoint(
    ...[...code.toUpperCase()].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65),
  );
}

export function countries(locale: string): readonly Country[] {
  const names = new Intl.DisplayNames([locale], { type: 'region' });
  return CODES.map((code) => ({ code, name: names.of(code) ?? code, flag: flagOf(code) })).sort(
    (a, b) => a.name.localeCompare(b.name, locale),
  );
}

/** Region from the browser locale ("en-IN" → "IN"), if it is a known country. */
export function detectCountry(languages: readonly string[]): string | null {
  for (const tag of languages) {
    const region = tag.split('-')[1]?.toUpperCase();
    if (region && CODES.includes(region)) return region;
  }
  return null;
}

/** Time zones that pin a country on their own (A-242). Extend as markets launch. */
const ZONES: Readonly<Record<string, string>> = {
  'Asia/Kolkata': 'IN',
  'Asia/Calcutta': 'IN',
  'Africa/Johannesburg': 'ZA',
  'Asia/Dubai': 'AE',
  'Europe/London': 'GB',
  'Asia/Singapore': 'SG',
  'Africa/Nairobi': 'KE',
  'Africa/Lagos': 'NG',
};

/**
 * Best guess with no question asked (A-242): the tenant's market (the country the learner signed
 * up in, which also set their phone code) → the device time zone → the browser locale.
 */
export function autoCountry(
  market: string | null,
  timeZone: string | undefined,
  languages: readonly string[],
): string | null {
  if (market && CODES.includes(market)) return market;
  const tz = timeZone ? ZONES[timeZone] : undefined;
  if (tz) return tz;
  return detectCountry(languages);
}
