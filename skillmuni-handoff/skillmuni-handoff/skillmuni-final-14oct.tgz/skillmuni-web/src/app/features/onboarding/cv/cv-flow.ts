import { Service, signal } from '@angular/core';
import { CvSummary } from '../../../core/cv/cv.api';

/** Where both paths land: Quest 1 (slice 6d). */
export const FIRST_QUEST = '/quests/who-dis';

export interface PickedFile {
  readonly file: File;
  readonly name: string;
  readonly sizeLabel: string;
}

/** Shared state across E2 → E3 → E4 (the file, its id and the parsed summary) for this session. */
@Service()
export class CvFlow {
  readonly picked = signal<PickedFile | null>(null);
  /** F1 · photographed pages (phone camera), uploaded together. */
  readonly pages = signal<readonly File[]>([]);
  readonly cvId = signal<string | null>(null);
  readonly summary = signal<CvSummary | null>(null);
  /** Country chosen on the manual path (or confirmed when prefilled). */
  readonly country = signal<string | null>(null);

  reset(): void {
    this.picked.set(null);
    this.pages.set([]);
    this.cvId.set(null);
    this.summary.set(null);
  }
}

export function sizeLabel(bytes: number): string {
  return bytes >= 1024 * 1024
    ? `${(bytes / (1024 * 1024)).toFixed(1)} MB`
    : `${Math.max(1, Math.round(bytes / 1024))} KB`;
}
