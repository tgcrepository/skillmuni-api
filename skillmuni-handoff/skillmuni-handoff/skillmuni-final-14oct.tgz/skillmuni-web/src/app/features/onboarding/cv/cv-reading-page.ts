import { Component, DestroyRef, computed, effect, inject, signal, untracked } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription, firstValueFrom, switchMap, timer } from 'rxjs';
import { CV_API, ParseStatus } from '../../../core/cv/cv.api';
import { Connectivity } from '../../../core/network/connectivity';
import { Banner } from '../../../shared/ui/banner/banner';
import { Icon } from '../../../shared/ui/icon/icon';
import { SpeechBubble } from '../../../shared/ui/muni/speech-bubble';
import { OverlayService } from '../../../shared/ui/overlay/overlay.service';
import { ProgressBar } from '../../../shared/ui/progress-bar/progress-bar';
import { OnboardingFrame } from '../frame/onboarding-frame';
import { CvFlow, FIRST_QUEST, PickedFile } from './cv-flow';
import { outcomeCopy } from './cv-outcomes';
import { OutcomeSheet, OutcomeSheetData, OutcomeSheetResult } from './outcome-sheet';

const POLL_MS = 800;
/** A-20: after this long, offer "Keep waiting" / "Type it myself". */
const SLOW_MS = 20_000;

/**
 * E3 · Parsing — Muni's reading your CV (desktop 200:8319 · tablet 200:8721 · mobile 200:8929).
 * Advances on the API, not a timer (A-20). Polling pauses while offline and resumes on reconnect (A-22).
 * Outcomes S3–S9 open the outcome sheet; clean results go straight to E4.
 */
@Component({
  selector: 'sm-cv-reading-page',
  imports: [OnboardingFrame, ProgressBar, Icon, SpeechBubble, Banner],
  templateUrl: './cv-reading-page.html',
  styleUrl: './cv-reading-page.scss',
})
export class CvReadingPage {
  private readonly api = inject(CV_API);
  private readonly router = inject(Router);
  private readonly overlay = inject(OverlayService);
  private readonly connectivity = inject(Connectivity);
  protected readonly flow = inject(CvFlow);
  private poll: Subscription | null = null;
  private readonly started = Date.now();

  protected readonly status = signal<ParseStatus>({ state: 'parsing', percent: 0, step: 0 });
  protected readonly slow = signal(false);
  protected readonly quip = signal('');

  protected readonly steps = [
    $localize`:@@e3.step1:Reading your file`,
    $localize`:@@e3.step2:Finding your contact details`,
    $localize`:@@e3.step3:Spotting school & qualifications`,
    $localize`:@@e3.step4:Matching skills to our skill list`,
    $localize`:@@e3.step5:Building your work timeline`,
    $localize`:@@e3.step6:Skipping private details (photo, ID, religion…)`,
  ];
  protected readonly current = computed(() => {
    const i = Math.min(this.status().step, this.steps.length - 1);
    return `${this.steps[i]}…`;
  });

  constructor() {
    if (!this.flow.cvId()) {
      void this.router.navigateByUrl('/onboarding/cv');
      return;
    }
    effect(() => {
      // Pause while offline; resume when back (A-22).
      if (this.connectivity.online()) untracked(() => this.startPolling());
      else untracked(() => this.stopPolling());
    });
    const slowTimer = setTimeout(() => this.slow.set(this.status().state === 'parsing'), SLOW_MS);
    inject(DestroyRef).onDestroy(() => {
      clearTimeout(slowTimer);
      this.stopPolling();
    });
  }

  protected keepWaiting(): void {
    this.slow.set(false);
  }

  protected async cancel(): Promise<void> {
    this.stopPolling();
    const id = this.flow.cvId();
    if (id) void firstValueFrom(this.api.remove(id)).catch(() => undefined);
    this.flow.cvId.set(null);
    await this.router.navigateByUrl('/onboarding/cv');
  }

  protected typeIt(): void {
    this.stopPolling();
    void this.router.navigateByUrl(FIRST_QUEST);
  }

  private startPolling(): void {
    const id = this.flow.cvId();
    if (!id || this.poll) return;
    this.poll = timer(0, POLL_MS)
      .pipe(switchMap(() => this.api.status(id)))
      .subscribe({
        next: (s) => this.onStatus(s),
        error: () => {
          this.poll = null;
          this.onStatus({
            state: 'failed',
            percent: 0,
            step: 0,
            outcome: 'parse-failed',
            detail: id.toUpperCase(),
          });
        },
      });
  }

  private stopPolling(): void {
    this.poll?.unsubscribe();
    this.poll = null;
  }

  private onStatus(s: ParseStatus): void {
    this.status.set(s);
    if (s.quip) this.quip.set(s.quip);
    if (s.state === 'parsing') return;
    this.stopPolling();
    this.slow.set(false);
    if (s.state === 'failed') {
      this.showOutcome(s, true);
    } else if (s.outcome) {
      this.showOutcome(s, false);
    } else {
      void this.toSummary();
    }
  }

  private showOutcome(s: ParseStatus, failed: boolean): void {
    const copy = outcomeCopy(s.outcome ?? 'parse-failed', s.detail ?? '');
    const ref = this.overlay.adaptive<OutcomeSheet, OutcomeSheetData, OutcomeSheetResult>(
      OutcomeSheet,
      {
        data: copy,
        size: 'sm',
        critical: failed,
      },
    );
    ref.closed.subscribe((choice) => {
      const action = choice === 'secondary' ? copy.secondaryAction : copy.primaryAction;
      if (action === 'continue') void this.toSummary();
      else if (action === 'type-it') this.typeIt();
      else if (action === 'retry') void this.retry();
      else void this.router.navigateByUrl('/onboarding/cv');
    });
  }

  private async retry(): Promise<void> {
    const picked = this.flow.picked();
    const pages = this.flow.pages();
    if (!picked && !pages.length) {
      await this.router.navigateByUrl('/onboarding/cv');
      return;
    }
    this.status.set({ state: 'parsing', percent: 0, step: 0 });
    this.api.upload(pages.length ? pages : (picked as PickedFile).file).subscribe({
      next: (e) => {
        if (e.kind === 'done') {
          this.flow.cvId.set(e.cvId);
          this.startPolling();
        }
      },
      error: () => void this.router.navigateByUrl('/onboarding/cv'),
    });
  }

  private async toSummary(): Promise<void> {
    const id = this.flow.cvId();
    if (!id) return;
    this.flow.summary.set(await firstValueFrom(this.api.summary(id)));
    await this.router.navigateByUrl('/onboarding/cv/summary');
  }
}

export const SLOW_PARSE_MS = SLOW_MS;
