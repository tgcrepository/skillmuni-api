import {
  Component,
  DestroyRef,
  ElementRef,
  OnInit,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Auth } from '../../core/auth/auth';
import {
  CLAIM_API,
  ClaimConsent,
  ClaimInvite,
  ClaimResult,
  ClaimSection,
  DeclineReason,
} from '../../core/claim/claim.api';
import { Market } from '../../core/market/market';
import { Banner } from '../../shared/ui/banner/banner';
import { Button } from '../../shared/ui/button/button';
import { Checkbox } from '../../shared/ui/checkbox/checkbox';
import { uniqueId } from '../../shared/ui/internal/unique-id';
import { Otp, OtpStatus } from '../../shared/ui/otp/otp';
import { Pill } from '../../shared/ui/pill/pill';
import { Radio } from '../../shared/ui/radio/radio';
import { RadioGroup } from '../../shared/ui/radio/radio-group';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { Switch } from '../../shared/ui/switch/switch';
import { Tag } from '../../shared/ui/tag/tag';
import { TextLink } from '../../shared/ui/text-link/text-link';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { delayed } from '../../shared/util/delayed';
import { OnboardingFrame } from '../onboarding/frame/onboarding-frame';

type Stage =
  | 'loading'
  | 'invalid'
  | 'claimed'
  | 'expired'
  | 'error'
  | 'offline'
  | 'verify'
  | 'consent'
  | 'validate'
  | 'confirmed'
  | 'decline'
  | 'not-me'
  | 'deleted';
type CodeError = 'invalid' | 'expired' | 'locked' | 'offline' | 'server' | null;

const SECOND = 1000;

/**
 * Institute claim (Figma section 11): V1 "Verify it's you" 200:36751 → V2 "Your data, your call"
 * 200:36844 → E4 CV summary. Public route; the code goes to the number the institute gave us.
 * States: loading, link not found / already claimed / expired, error, offline, wrong code, expired code,
 * too many tries, "This isn't me", "Delete my data", consent required.
 */
@Component({
  selector: 'sm-claim-page',
  imports: [
    Banner,
    Button,
    Checkbox,
    OnboardingFrame,
    Otp,
    Pill,
    Radio,
    RadioGroup,
    RouterLink,
    Skeleton,
    StateBlock,
    Switch,
    Tag,
    TextLink,
  ],
  templateUrl: './claim-page.html',
  styleUrl: './claim-page.scss',
})
export class ClaimPage implements OnInit {
  /** Route param. */
  readonly token = input.required<string>();

  private readonly api = inject(CLAIM_API);
  private readonly auth = inject(Auth);
  private readonly market = inject(Market);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef).nativeElement;

  protected readonly stage = signal<Stage>('loading');
  protected readonly loading = computed(() => this.stage() === 'loading');
  protected readonly showSkeleton = delayed(this.loading);
  protected readonly invite = signal<ClaimInvite | null>(null);

  // ── V1 verify ──
  protected readonly code = signal('');
  protected readonly codeError = signal<CodeError>(null);
  protected readonly triesLeft = signal(5);
  protected readonly secondsLeft = signal(0);
  protected readonly sentTo = signal('');
  protected readonly verifying = signal(false);
  protected readonly resending = signal(false);
  protected readonly wrongNumber = signal(false);
  protected readonly rejecting = signal(false);

  // ── V2 consent ──
  protected readonly agree = signal(false);
  protected readonly choices = signal<ClaimConsent>({
    shareProgress: true,
    verifyCertificate: true,
    applyForMe: false,
  });
  protected readonly attempted = signal(false);
  protected readonly saving = signal(false);

  // ── V3 validate ──
  protected readonly sections = signal<readonly ClaimSection[]>([]);
  protected readonly open = signal('');
  protected readonly confirming = signal('');
  protected readonly finishing = signal(false);
  protected readonly doneCount = computed(
    () => this.sections().filter((s) => s.status === 'confirmed').length,
  );

  // ── V4 confirmed ──
  protected readonly result = signal<ClaimResult | null>(null);

  // ── V5 decline ──
  protected readonly reason = signal<DeclineReason | null>(null);
  private readonly declineFrom = signal<Stage>('verify');
  protected readonly reasons: readonly { value: DeclineReason; label: string }[] = [
    { value: 'not-me', label: $localize`:@@claim.rNotMe:This isn’t me` },
    { value: 'not-now', label: $localize`:@@claim.rNotNow:I don’t want job matching right now` },
    {
      value: 'has-account',
      label: $localize`:@@claim.rAccount:I already have a Skillmuni account`,
    },
    { value: 'other', label: $localize`:@@claim.rOther:Something else` },
  ];

  protected readonly ids = {
    why: uniqueId('cl-why'),
    verify: uniqueId('cl-verify'),
    added: uniqueId('cl-added'),
    message: uniqueId('cl-msg'),
    agreeErr: uniqueId('cl-agree'),
    share: uniqueId('cl-share'),
    cert: uniqueId('cl-cert'),
    apply: uniqueId('cl-apply'),
  };

  protected readonly otpStatus = computed<OtpStatus>(() => (this.codeError() ? 'error' : 'none'));
  protected readonly canVerify = computed(
    () =>
      this.code().length === 6 &&
      this.codeError() !== 'expired' &&
      this.codeError() !== 'locked' &&
      !this.verifying(),
  );
  protected readonly countdown = computed(() => {
    const s = this.secondsLeft();
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  });
  protected readonly deleteBy = computed(() => {
    const iso = this.invite()?.deleteBy;
    return iso
      ? new Intl.DateTimeFormat(this.market.config().locale, {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        }).format(new Date(iso))
      : '';
  });
  protected readonly agreeError = computed(() =>
    this.attempted() && !this.agree()
      ? $localize`:@@claim.agreeReq:Tick this to build your profile, or delete your data instead.`
      : '',
  );
  protected readonly statusLabel = {
    confirmed: $localize`:@@claim.sConfirmed:Confirmed ✓`,
    review: $localize`:@@claim.sReview:Needs your OK`,
    fix: $localize`:@@claim.sFix:Fix this`,
  };
  protected readonly sourceLabel = {
    institute: $localize`:@@claim.srcInstitute:Added by institute`,
    verified: $localize`:@@claim.srcVerified:Verified by institute ✓`,
    you: $localize`:@@claim.srcYou:Added by you`,
  };

  protected readonly privacyNotice = computed(() =>
    this.market.code() === 'ZA'
      ? $localize`:@@claim.popia:POPIA privacy notice`
      : $localize`:@@claim.dpdp:DPDP Act 2023 privacy notice`,
  );

  constructor() {
    const id = setInterval(() => this.secondsLeft.update((s) => Math.max(0, s - 1)), SECOND);
    inject(DestroyRef).onDestroy(() => clearInterval(id));
  }

  async ngOnInit(): Promise<void> {
    await this.load();
  }

  protected async load(): Promise<void> {
    this.stage.set('loading');
    try {
      const invite = await firstValueFrom(this.api.invite(this.token()));
      this.invite.set(invite);
      this.sentTo.set(invite.sentTo);
      this.triesLeft.set(invite.triesLeft);
      this.secondsLeft.set(invite.resendIn);
      const resume = invite.resume;
      if (resume) {
        this.sections.set(resume.sections);
        this.open.set(resume.sections.find((x) => x.status !== 'confirmed')?.slug ?? '');
        this.result.set(resume.result);
        this.agree.set(resume.stage !== 'consent');
      }
      this.stage.set(resume?.stage ?? 'verify');
    } catch (err) {
      const e = err instanceof ApiError ? err : null;
      const reason = e?.fieldErrors['code']?.[0];
      if (e?.kind === 'offline') this.stage.set('offline');
      else if (e?.kind === 'not-found') this.stage.set('invalid');
      else if (e?.status === 410)
        this.stage.set(
          reason === 'claimed' ? 'claimed' : reason === 'deleted' ? 'deleted' : 'expired',
        );
      else this.stage.set('error');
    }
  }

  // ── V1 ──

  protected onCode(value: string): void {
    this.code.set(value);
    const e = this.codeError();
    if ((e === 'invalid' && value) || e === 'offline' || e === 'server') this.codeError.set(null);
  }

  protected async verify(): Promise<void> {
    if (!this.canVerify()) return;
    this.verifying.set(true);
    try {
      const user = await firstValueFrom(this.api.verify(this.token(), this.code()));
      this.auth.adopt(user);
      this.stage.set('consent');
      this.focusHeading();
    } catch (err) {
      this.handleCode(err);
    } finally {
      this.verifying.set(false);
    }
    if (this.codeError() === 'invalid') {
      this.code.set('');
      setTimeout(() => this.host.querySelector<HTMLInputElement>('sm-otp input')?.focus());
    }
  }

  protected async resend(): Promise<void> {
    this.resending.set(true);
    try {
      const c = await firstValueFrom(this.api.resend(this.token()));
      this.sentTo.set(c.sentTo);
      this.triesLeft.set(c.triesLeft);
      this.secondsLeft.set(c.resendIn);
      this.code.set('');
      this.codeError.set(null);
      this.toast.show($localize`:@@claim.resent:New code sent.`);
    } catch (err) {
      this.handleCode(err);
    } finally {
      this.resending.set(false);
    }
  }

  /** V5 — from V1's "This isn't me" (pre-picks the reason) or "Delete my data". */
  protected toDecline(reason: DeclineReason | null): void {
    this.declineFrom.set(this.stage());
    this.reason.set(reason);
    this.stage.set('decline');
    this.focusHeading();
  }

  protected keep(): void {
    this.stage.set(this.declineFrom());
    this.focusHeading();
  }

  protected setReason(value: string | null): void {
    this.reason.set(this.reasons.find((r) => r.value === value)?.value ?? null);
  }

  protected async decline(): Promise<void> {
    if (this.rejecting()) return;
    this.rejecting.set(true);
    try {
      await firstValueFrom(this.api.decline(this.token(), this.reason()));
      this.stage.set(this.reason() === 'not-me' ? 'not-me' : 'deleted');
      this.focusHeading();
    } catch {
      this.toast.show($localize`:@@claim.rejectFail:That didn’t go through. Try again?`, {
        tone: 'error',
      });
    } finally {
      this.rejecting.set(false);
    }
  }

  // ── V2 ──

  protected setChoice(key: keyof ClaimConsent, value: boolean): void {
    this.choices.update((c) => ({ ...c, [key]: value }));
  }

  protected async submit(): Promise<void> {
    if (this.saving()) return;
    this.attempted.set(true);
    if (!this.agree()) {
      setTimeout(() => this.host.querySelector<HTMLInputElement>('.agree input')?.focus());
      return;
    }
    this.saving.set(true);
    try {
      const sections = await firstValueFrom(this.api.consent(this.token(), this.choices()));
      this.sections.set(sections);
      this.open.set(sections.find((x) => x.status !== 'confirmed')?.slug ?? '');
      this.stage.set('validate');
      this.focusHeading();
    } catch {
      this.toast.show(
        $localize`:@@claim.consentFail:Couldn’t save that just now. Your choices are kept, try again.`,
        { tone: 'error' },
      );
    } finally {
      this.saving.set(false);
    }
  }

  // ── V3 ──

  protected toggle(slug: string): void {
    this.open.update((o) => (o === slug ? '' : slug));
  }

  /** Opens the pre-filled quest; it brings the learner back here when they finish or leave (A-148). */
  protected edit(section: ClaimSection): void {
    void this.router.navigate(['/quests', section.slug], {
      queryParams: { returnTo: `/claim/${this.token()}` },
    });
  }

  protected async looksRight(section: ClaimSection): Promise<void> {
    if (this.confirming()) return;
    this.confirming.set(section.slug);
    try {
      await firstValueFrom(this.api.confirmSection(this.token(), section.slug));
      this.sections.update((list) =>
        list.map((x) => (x.slug === section.slug ? { ...x, status: 'confirmed' as const } : x)),
      );
      const next = this.sections().find((x) => x.status !== 'confirmed');
      if (next) {
        this.open.set(next.slug);
        setTimeout(() =>
          this.host
            .querySelector<HTMLElement>(`[data-section="${next.slug}"] .section-head`)
            ?.focus(),
        );
      } else await this.finish();
    } catch {
      this.toast.show($localize`:@@claim.confirmFail:Couldn’t save that. Try again?`, {
        tone: 'error',
      });
    } finally {
      this.confirming.set('');
    }
  }

  protected async finish(): Promise<void> {
    this.finishing.set(true);
    try {
      this.result.set(await firstValueFrom(this.api.finish(this.token())));
      this.stage.set('confirmed');
      this.focusHeading();
    } finally {
      this.finishing.set(false);
    }
  }

  // ── V4 ──

  protected go(url: string): void {
    void this.router.navigateByUrl(url);
  }

  private handleCode(err: unknown): void {
    if (!(err instanceof ApiError)) {
      this.codeError.set('server');
      return;
    }
    const code = err.fieldErrors['code']?.[0];
    if (err.kind === 'offline') this.codeError.set('offline');
    else if (code === 'code-expired') this.codeError.set('expired');
    else if (code === 'too-many-tries') this.codeError.set('locked');
    else if (code === 'invalid-code') {
      const left = Number(err.fieldErrors['triesLeft']?.[0]);
      if (Number.isFinite(left)) this.triesLeft.set(left);
      this.codeError.set('invalid');
    } else this.codeError.set('server');
  }

  private focusHeading(): void {
    setTimeout(() => this.host.querySelector<HTMLElement>('h1, h2')?.focus());
  }
}
