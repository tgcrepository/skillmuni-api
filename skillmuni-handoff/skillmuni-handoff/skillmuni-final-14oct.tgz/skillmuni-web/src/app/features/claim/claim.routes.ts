import { Routes } from '@angular/router';

/** Public: the link an institute sends works before the learner has an account (A-148). */
export const claimRoutes: Routes = [
  {
    path: 'claim/:token',
    title: $localize`:@@route.claim:Claim your profile · Skillmuni`,
    loadComponent: () => import('./claim-page').then((m) => m.ClaimPage),
  },
];
