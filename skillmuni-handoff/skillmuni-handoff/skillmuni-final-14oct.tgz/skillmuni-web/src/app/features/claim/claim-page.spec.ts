import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of, throwError } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { CLAIM_API, ClaimInvite } from '../../core/claim/claim.api';
import { ClaimPage } from './claim-page';

const invite: ClaimInvite = {
  institute: 'Pune Skills Academy',
  name: 'Aarav Mehta',
  programme: 'Customer Care Executive',
  batch: 'Pune batch 15',
  fromCv: '8 skills',
  sentTo: '+91 98•••• 4521',
  resendIn: 24,
  triesLeft: 5,
  deleteBy: '2026-10-30',
  certificate: 'NSQF L4 certificate',
};

interface PageApi {
  load(): Promise<void>;
  stage(): string;
  onCode(v: string): void;
  verify(): Promise<void>;
  codeError(): string | null;
  triesLeft(): number;
  submit(): Promise<void>;
  agreeError(): string;
}

function setup(api: Record<string, unknown>) {
  TestBed.configureTestingModule({
    providers: [provideRouter([]), { provide: CLAIM_API, useValue: api }],
  });
  const fixture = TestBed.createComponent(ClaimPage);
  fixture.componentRef.setInput('token', 't');
  return fixture.componentInstance as unknown as PageApi;
}

describe('ClaimPage', () => {
  it('maps link errors to states', async () => {
    let err = new ApiError('not-found', 404, 'x');
    const page = setup({ invite: () => throwError(() => err) });
    await page.load();
    expect(page.stage()).toBe('invalid');
    err = new ApiError('unknown', 410, 'x', { code: ['claimed'] });
    await page.load();
    expect(page.stage()).toBe('claimed');
    err = new ApiError('unknown', 410, 'x', { code: ['expired'] });
    await page.load();
    expect(page.stage()).toBe('expired');
    err = new ApiError('offline', 0, 'x');
    await page.load();
    expect(page.stage()).toBe('offline');
  });

  it('counts down tries on a wrong code, then moves to consent which needs the agreement', async () => {
    let ok = false;
    const page = setup({
      invite: () => of(invite),
      verify: () =>
        ok
          ? of({ id: 'u', firstName: 'Aarav' })
          : throwError(
              () =>
                new ApiError('validation', 422, 'x', {
                  code: ['invalid-code'],
                  triesLeft: ['4'],
                }),
            ),
    });
    await page.load();
    expect(page.stage()).toBe('verify');
    page.onCode('111111');
    await page.verify();
    expect(page.codeError()).toBe('invalid');
    expect(page.triesLeft()).toBe(4);
    ok = true;
    page.onCode('123456');
    await page.verify();
    expect(page.stage()).toBe('consent');
    await page.submit();
    expect(page.agreeError()).toContain('Tick this');
  });
});
