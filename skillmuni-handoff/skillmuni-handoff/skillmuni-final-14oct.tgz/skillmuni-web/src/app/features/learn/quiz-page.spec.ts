import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { Auth } from '../../core/auth/auth';
import { LEARN_API, Quiz, QuizResult } from '../../core/learn/learn.api';
import { QuizPage } from './quiz-page';

const quiz: Quiz = {
  id: 'q',
  title: 'Digital Workplace Essentials',
  module: { slug: 'digital-basics', title: 'Digital Basics' },
  topic: { slug: 'dwe', title: 'Digital Workplace Essentials' },
  knook: { title: 'Digital Foundations Knook' },
  quizzesDone: 4,
  quizzesTotal: 10,
  xp: 3,
  questions: [
    {
      id: 'a',
      prompt: 'A?',
      options: [
        { id: 'a0', text: 'x' },
        { id: 'a1', text: 'y' },
      ],
    },
    {
      id: 'b',
      prompt: 'B?',
      options: [
        { id: 'b0', text: 'x' },
        { id: 'b1', text: 'y' },
      ],
    },
  ],
  draft: {},
  alreadyPassed: false,
};

const result: QuizResult = {
  correct: 1,
  total: 2,
  xp: 1,
  muni: 'So close!',
  results: [
    {
      questionId: 'a',
      correctOptionId: 'a1',
      pickedOptionId: 'a0',
      correct: false,
      explanation: 'why a',
    },
    {
      questionId: 'b',
      correctOptionId: 'b0',
      pickedOptionId: 'b0',
      correct: true,
      explanation: 'why b',
    },
  ],
};

interface PageApi {
  load(): Promise<void>;
  pick(q: string, o: string): void;
  submit(): Promise<void>;
  retry(): void;
  allAnswered(): boolean;
  phase(): string;
  questions(): readonly { id: string; options: readonly { id: string }[] }[];
  headline(): { title: string; score: string; xp: string } | null;
  stats(): { value: string }[];
  optionState(q: unknown, o: unknown): string;
  missed(): number;
}

function setup() {
  const submit = vi.fn(() => of(result));
  TestBed.configureTestingModule({
    providers: [
      provideRouter([]),
      {
        provide: LEARN_API,
        useValue: { quiz: () => of(quiz), submit, saveDraft: () => of(undefined) },
      },
      { provide: Auth, useValue: { user: () => ({ id: '1', firstName: 'Yash' }) } },
    ],
  });
  const fixture = TestBed.createComponent(QuizPage);
  fixture.componentRef.setInput('module', 'digital-basics');
  fixture.componentRef.setInput('topic', 'dwe');
  return { page: fixture.componentInstance as unknown as PageApi, submit };
}

describe('QuizPage', () => {
  it('needs every answer, reveals all at once, then retries only the misses as practice', async () => {
    const { page, submit } = setup();
    await page.load();
    page.pick('a', 'a0');
    expect(page.allAnswered()).toBe(false);
    await page.submit();
    expect(submit).not.toHaveBeenCalled();

    page.pick('b', 'b0');
    await page.submit();
    expect(page.phase()).toBe('revealed');
    expect(page.headline()?.title).toBe('Nice one, Yash! 1 of 2 correct');
    expect(page.headline()?.xp).toBe('+1 XP');
    expect(page.stats()[1]?.value).toBe('4 XP');
    const [qa] = page.questions();
    expect(page.optionState(qa, qa?.options[0])).toBe('wrong-pick');
    expect(page.optionState(qa, qa?.options[1])).toBe('correct');
    expect(page.missed()).toBe(1);

    page.retry();
    expect(page.phase()).toBe('practice');
    expect(page.questions().map((q) => q.id)).toEqual(['a']);
    // Options reshuffled so the right answer moves.
    expect(page.questions()[0]?.options[0]?.id).toBe('a1');
    page.pick('a', 'a1');
    await page.submit();
    expect(page.phase()).toBe('practice-revealed');
    expect(page.headline()?.title).toBe('Nailed it this time!');
    expect(submit).toHaveBeenCalledTimes(1);
  });
});
