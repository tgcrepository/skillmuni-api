import { NgOptimizedImage } from '@angular/common';
import { Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { LEARN_API, ModuleDetail, TopicSummary, topicStatus } from '../../core/learn/learn.api';
import { Viewport } from '../../core/layout/viewport';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { MuniAvatar } from '../../shared/ui/muni/muni-avatar';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { LearnHeader, LearnStat } from './learn-header';
import { Currency } from '../../shared/ui/currency/currency';

type LoadState = 'loading' | 'ready' | 'error' | 'offline' | 'not-found';

interface NextStep {
  readonly title: string;
  readonly body: string;
  readonly cta: string;
  readonly mobileCta: string;
  readonly link: string;
}

/**
 * Module (subcategory) — e.g. Brain Vita (Figma 67:1228 desktop · 67:1502 tablet · 67:1739 mobile).
 * Header with stats, a card per topic (Mastered / N quizzes left / new) and Muni's next step.
 */
@Component({
  selector: 'sm-module-page',
  imports: [Currency, 
    Button,
    Icon,
    LearnHeader,
    LearnerShell,
    MuniAvatar,
    NgOptimizedImage,
    RouterLink,
    Skeleton,
    StateBlock,
  ],
  templateUrl: './module-page.html',
  styleUrl: './module-page.scss',
})
export class ModulePage implements OnInit {
  private readonly api = inject(LEARN_API);
  protected readonly viewport = inject(Viewport);

  /** Route param. */
  readonly module = input.required<string>();

  protected readonly lobby = $localize`:@@nav.lobby:Lobby`;
  protected readonly state = signal<LoadState>('loading');
  protected readonly detail = signal<ModuleDetail | null>(null);

  protected readonly stats = computed<LearnStat[]>(() => {
    const d = this.detail();
    return d
      ? [
          {
            icon: 'lightbulb',
            label: $localize`:@@learn.quizzesDone:Quizzes done`,
            value: `${d.quizzesDone} / ${d.quizzesTotal}`,
          },
          { icon: 'zap', label: $localize`:@@learn.xpEarned:XP earned`, value: `${d.xp} XP` },
        ]
      : [];
  });

  protected readonly next = computed<NextStep | null>(() => {
    const d = this.detail();
    if (!d) return null;
    const open = d.topics.find((t) => topicStatus(t) === 'in-progress');
    const fresh = d.topics.find((t) => topicStatus(t) === 'new');
    if (open) {
      const left = open.quizzesTotal - open.quizzesDone;
      return left === 1
        ? {
            title: $localize`:@@learn.lastQuiz:Just 1 quiz left to master ${d.title}:module:`,
            body: $localize`:@@learn.lastQuizBody:Finish ${open.title}:topic: to unlock the ${d.title}:module: badge.`,
            cta: $localize`:@@learn.takeLast:Take the last quiz`,
            mobileCta: $localize`:@@learn.takeLastMobile:Take the last quiz · 1 left`,
            link: this.topicLink(open, true),
          }
        : {
            title: $localize`:@@learn.keepGoing:${left}:n: quizzes left in ${open.title}:topic:`,
            body: $localize`:@@learn.keepGoingBody:Pick up where you stopped. Every right answer is +1 XP.`,
            cta: $localize`:@@learn.continue:Continue`,
            mobileCta: $localize`:@@learn.continueMobile:Continue · ${left}:n: left`,
            link: this.topicLink(open, false),
          };
    }
    if (fresh) {
      return {
        title: $localize`:@@learn.startWith:Start with ${fresh.title}:topic:`,
        body: $localize`:@@learn.startBody:Short briefs, then a quick quiz. +1 XP for every right answer.`,
        cta: $localize`:@@learn.start:Start`,
        mobileCta: $localize`:@@learn.startMobile:Start ${fresh.title}:topic:`,
        link: this.topicLink(fresh, false),
      };
    }
    return {
      title: $localize`:@@learn.mastered:You’ve mastered ${d.title}:module:!`,
      body: $localize`:@@learn.masteredBody:Every quiz done. Pick another module from the Lobby.`,
      cta: $localize`:@@learn.backLobby:Back to the Lobby`,
      mobileCta: $localize`:@@learn.backLobby:Back to the Lobby`,
      link: '/home',
    };
  });

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      this.detail.set(await firstValueFrom(this.api.module(this.module())));
      this.state.set('ready');
    } catch (e) {
      const kind = e instanceof ApiError ? e.kind : 'unknown';
      this.state.set(kind === 'offline' ? 'offline' : kind === 'not-found' ? 'not-found' : 'error');
    }
  }

  protected status(t: TopicSummary) {
    return topicStatus(t);
  }

  protected left(t: TopicSummary): number {
    return t.quizzesTotal - t.quizzesDone;
  }

  protected percent(t: TopicSummary): number {
    return t.quizzesTotal ? (t.quizzesDone / t.quizzesTotal) * 100 : 0;
  }

  protected topicLink(t: TopicSummary, quiz = false): string {
    return `/learn/${this.module()}/${t.slug}${quiz ? '/quiz' : ''}`;
  }

  protected cardLabel(t: TopicSummary): string {
    const s = this.status(t);
    const state =
      s === 'mastered'
        ? $localize`:@@learn.statusMastered:Mastered`
        : s === 'in-progress'
          ? $localize`:@@learn.statusLeft:${this.left(t)}:n: left`
          : $localize`:@@learn.statusNew:Not started`;
    return $localize`:@@learn.cardLabel:${t.title}:topic:. ${state}:state:. ${t.quizzesDone}:done: of ${t.quizzesTotal}:total: quizzes, ${t.xp}:xp: XP.`;
  }
}
