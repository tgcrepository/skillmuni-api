import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

const soon = () => import('../soon/coming-soon-page').then((m) => m.ComingSoonPage);

/** Lobby → module (subcategory) → topic briefs → quiz (Figma 64:1180 · 74:2417 · 132:2709). */
export const learnRoutes: Routes = [
  {
    path: 'learn',
    canActivate: [requireSession],
    children: [
      {
        path: 'bookmarks',
        title: $localize`:@@route.bookmarks:My bookmarks · Skillmuni`,
        data: { area: $localize`:@@learn.bookmarks:My bookmarks` },
        loadComponent: soon,
      },
      {
        path: ':module',
        title: $localize`:@@route.module:Module · Skillmuni`,
        loadComponent: () => import('./module-page').then((m) => m.ModulePage),
      },
      {
        path: ':module/:topic',
        title: $localize`:@@route.briefs:Briefs · Skillmuni`,
        loadComponent: () => import('./brief-page').then((m) => m.BriefPage),
      },
      {
        path: ':module/:topic/quiz',
        title: $localize`:@@route.quiz:Quiz · Skillmuni`,
        loadComponent: () => import('./quiz-page').then((m) => m.QuizPage),
      },
      {
        path: ':module/:topic/course',
        title: $localize`:@@route.course:Course · Skillmuni`,
        data: { area: $localize`:@@learn.course:The full course` },
        loadComponent: soon,
      },
    ],
  },
];
