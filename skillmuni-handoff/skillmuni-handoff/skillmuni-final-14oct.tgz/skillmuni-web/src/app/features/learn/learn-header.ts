import { BackNav } from '../../core/layout/back-nav';
import { Component, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Viewport } from '../../core/layout/viewport';
import { Icon } from '../../shared/ui/icon/icon';
import { IconName } from '../../shared/ui/icon/icons';
import { Currency } from '../../shared/ui/currency/currency';

export interface LearnStat {
  readonly icon: IconName;
  readonly label: string;
  readonly value: string;
  /** XP bursts land here (A-263). */
  readonly xpTarget?: boolean;
}

/**
 * Page header shared by the module, brief reader and quiz screens (Figma 67:1243 · 78:2535).
 * Desktop/tablet: back · breadcrumb + title (+ tagline) · stat chips · My bookmarks.
 * Mobile: compact bar (back · overline + title · bookmark) and the stats as small chips under it.
 * Project extra mobile chip-row content (e.g. "Brief 11 of 11") with `smHeaderAside`.
 */
@Component({
  selector: 'sm-learn-header',
  imports: [Currency, Icon, RouterLink],
  templateUrl: './learn-header.html',
  styleUrl: './learn-header.scss',
  host: { '[class]': '"sm-learn-header sm-learn-header--" + viewport.size()' },
})
export class LearnHeader {
  protected readonly nav = inject(BackNav);
  protected readonly viewport = inject(Viewport);

  readonly backLink = input.required<string>();
  readonly backLabel = input.required<string>();
  readonly crumbs = input.required<readonly string[]>();
  readonly title = input.required<string>();
  readonly tagline = input('');
  readonly stats = input<readonly LearnStat[]>([]);
  /** Mobile: big stat cards (module screen) or small chips (brief, quiz). */
  readonly mobileStats = input<'cards' | 'chips'>('chips');

  protected readonly bookmarksLabel = $localize`:@@learn.bookmarks:My bookmarks`;
}
