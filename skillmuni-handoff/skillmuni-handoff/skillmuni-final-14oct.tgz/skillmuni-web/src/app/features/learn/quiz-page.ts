import {
  Component,
  DestroyRef,
  ElementRef,
  OnInit,
  afterNextRender,
  computed,
  inject,
  input,
  signal,
  viewChild,
  Injector,
} from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Auth } from '../../core/auth/auth';
import {
  LEARN_API,
  Quiz,
  QuizOption,
  QuizQuestion,
  QuizResult,
  QuestionResult,
} from '../../core/learn/learn.api';
import { Viewport } from '../../core/layout/viewport';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { MuniAvatar } from '../../shared/ui/muni/muni-avatar';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { LearnHeader, LearnStat } from './learn-header';
import { XpFx } from '../../shared/ui/xp-fx/xp-fx';
import { FeedbackPrompt } from '../../core/feedback/feedback-prompt';
import { Currency } from '../../shared/ui/currency/currency';
import { Typewriter } from '../../shared/ui/muni/typewriter';

type LoadState = 'loading' | 'ready' | 'error' | 'offline' | 'not-found';
/** QZ1/QZ2 answering · QZ3/QZ4 revealed · QZ5 practice (answering, then revealed). */
type Phase = 'answering' | 'revealed' | 'practice' | 'practice-revealed';
type OptionState = 'idle' | 'picked' | 'correct' | 'right-pick' | 'wrong-pick' | 'dim';

const DRAFT_DELAY = 600;

/**
 * Quiz — all questions on one page; Submit reveals every answer at once (Figma 132:2709:
 * QZ1 answering · QZ2 ready · QZ3 revealed 2/3 · QZ4 perfect · QZ5 retry wrong ones as practice).
 * +1 XP per correct answer, no bonus. Practice earns no XP and doesn't change the saved score.
 */
@Component({
  selector: 'sm-quiz-page',
  imports: [Typewriter, Currency, Button, Icon, LearnHeader, LearnerShell, MuniAvatar, RouterLink, Skeleton, StateBlock],
  templateUrl: './quiz-page.html',
  styleUrl: './quiz-page.scss',
})
export class QuizPage implements OnInit {
  private readonly api = inject(LEARN_API);
  private readonly feedback = inject(FeedbackPrompt);
  private readonly auth = inject(Auth);
  private readonly router = inject(Router);
  private readonly toast = inject(ToastService);
  private readonly injector = inject(Injector);
  private readonly xpFx = inject(XpFx);
  protected readonly viewport = inject(Viewport);

  readonly module = input.required<string>();
  readonly topic = input.required<string>();

  protected readonly state = signal<LoadState>('loading');
  protected readonly quiz = signal<Quiz | null>(null);
  protected readonly phase = signal<Phase>('answering');
  protected readonly answers = signal<Readonly<Record<string, string>>>({});
  protected readonly practiceAnswers = signal<Readonly<Record<string, string>>>({});
  protected readonly result = signal<QuizResult | null>(null);
  protected readonly submitting = signal(false);
  private readonly summary = viewChild<ElementRef<HTMLElement>>('summary');
  private draftTimer: ReturnType<typeof setTimeout> | undefined;

  protected readonly firstName = computed(() => this.auth.user()?.firstName ?? '');
  protected readonly backLink = computed(() => `/learn/${this.module()}/${this.topic()}`);
  protected readonly quizCrumb = $localize`:@@quiz.crumb:Quiz`;

  protected readonly stats = computed<LearnStat[]>(() => {
    const q = this.quiz();
    return q
      ? [
          {
            icon: 'lightbulb',
            label: $localize`:@@learn.quizzesSolved:Quizzes solved`,
            value: `${q.quizzesDone} / ${q.quizzesTotal}`,
          },
          {
            icon: 'zap',
            label: $localize`:@@learn.xpEarned:XP earned`,
            value: `${q.xp + (this.result()?.xp ?? 0)} XP`,
            xpTarget: true,
          },
        ]
      : [];
  });

  private readonly byId = computed(
    () => new Map((this.result()?.results ?? []).map((r) => [r.questionId, r] as const)),
  );

  /** Questions on screen: all of them, or only the missed ones (reshuffled) in practice. */
  protected readonly questions = computed<readonly QuizQuestion[]>(() => {
    const q = this.quiz();
    if (!q) return [];
    if (this.phase() === 'practice' || this.phase() === 'practice-revealed') {
      return q.questions
        .filter((x) => this.byId().get(x.id)?.correct === false)
        .map((x) => ({ ...x, options: reshuffle(x.options) }));
    }
    return q.questions;
  });

  protected readonly inPractice = computed(
    () => this.phase() === 'practice' || this.phase() === 'practice-revealed',
  );
  protected readonly revealed = computed(
    () => this.phase() === 'revealed' || this.phase() === 'practice-revealed',
  );
  protected readonly picks = computed(() =>
    this.inPractice() ? this.practiceAnswers() : this.answers(),
  );
  protected readonly answeredCount = computed(
    () => this.questions().filter((q) => this.picks()[q.id]).length,
  );
  protected readonly allAnswered = computed(
    () => this.questions().length > 0 && this.answeredCount() === this.questions().length,
  );
  protected readonly missed = computed(
    () => (this.result()?.results ?? []).filter((r) => !r.correct).length,
  );
  protected readonly practiceCorrect = computed(
    () => this.questions().filter((q) => this.isCorrectPractice(q.id)).length,
  );

  protected readonly counter = computed(() => {
    const left = this.questions().length - this.answeredCount();
    return left
      ? $localize`:@@quiz.counter:${this.answeredCount()}:done: of ${this.questions().length}:total: answered · answer all to submit`
      : $localize`:@@quiz.ready:All answered · you can still change your picks`;
  });

  /** Summary card copy (QZ3 / QZ4 / QZ5). */
  protected readonly headline = computed(() => {
    const r = this.result();
    const name = this.firstName();
    if (!r) return null;
    if (this.phase() === 'practice') {
      return {
        eyebrow: $localize`:@@quiz.practiceRound:Practice round`,
        title: $localize`:@@quiz.goAgain:Have another go`,
        body: $localize`:@@quiz.goAgainBody:Only the ones you missed, with the options shuffled. Practice earns no XP.`,
        muni: $localize`:@@quiz.gotThis:You’ve got this.`,
        score: '',
        xp: '',
      };
    }
    if (this.inPractice()) {
      const all = this.practiceCorrect() === this.questions().length;
      return {
        eyebrow: $localize`:@@quiz.practiceRound:Practice round`,
        title: all
          ? $localize`:@@quiz.nailed:Nailed it this time!`
          : $localize`:@@quiz.stillTricky:Still tricky. Read the why below.`,
        body: $localize`:@@quiz.practiceBody:Practice answers don’t earn XP, but this one’s locked in now.`,
        muni: all
          ? $localize`:@@quiz.hadIt:See? You had it all along!`
          : $localize`:@@quiz.nextTime:You’ll get it next time.`,
        score: `${this.practiceCorrect()}/${this.questions().length}`,
        xp: '',
      };
    }
    const perfect = r.correct === r.total;
    const xpLine = r.xp
      ? $localize`:@@quiz.xpAdded:+${r.xp}:xp: XP added.`
      : $localize`:@@quiz.noXp:No new XP: this quiz was already counted.`;
    return {
      eyebrow: perfect
        ? $localize`:@@quiz.cleared:Quiz cleared`
        : $localize`:@@quiz.checked:Quiz checked`,
      title: perfect
        ? $localize`:@@quiz.flawless:Flawless, ${name}:name:! ${r.correct}:c: of ${r.total}:t: correct`
        : r.correct
          ? $localize`:@@quiz.niceOne:Nice one, ${name}:name:! ${r.correct}:c: of ${r.total}:t: correct`
          : $localize`:@@quiz.tough:Tough one, ${name}:name:. ${r.correct}:c: of ${r.total}:t: correct`,
      body: perfect
        ? $localize`:@@quiz.perfectBody:${xpLine}:xp: Every answer spot on, and the explanations are below if you want a recap.`
        : $localize`:@@quiz.missBody:${xpLine}:xp: Read why each answer is right, then retry the ones you missed for practice.`,
      muni: r.muni,
      score: `${r.correct}/${r.total}`,
      xp: r.xp ? `+${r.xp} XP` : '',
    };
  });

  constructor() {
    inject(DestroyRef).onDestroy(() => clearTimeout(this.draftTimer));
  }

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      const q = await firstValueFrom(this.api.quiz(this.module(), this.topic()));
      this.quiz.set(q);
      this.answers.set(q.draft);
      this.phase.set('answering');
      this.result.set(null);
      this.state.set('ready');
    } catch (e) {
      const kind = e instanceof ApiError ? e.kind : 'unknown';
      this.state.set(kind === 'offline' ? 'offline' : kind === 'not-found' ? 'not-found' : 'error');
    }
  }

  protected pick(questionId: string, optionId: string): void {
    if (this.revealed()) return;
    if (this.inPractice()) {
      this.practiceAnswers.update((a) => ({ ...a, [questionId]: optionId }));
      return;
    }
    this.answers.update((a) => ({ ...a, [questionId]: optionId }));
    this.queueDraft();
  }

  protected async submit(): Promise<void> {
    if (!this.allAnswered() || this.submitting()) return;
    if (this.inPractice()) {
      this.phase.set('practice-revealed');
      this.focusSummary();
      return;
    }
    const q = this.quiz();
    if (!q) return;
    clearTimeout(this.draftTimer);
    this.submitting.set(true);
    try {
      const result = await firstValueFrom(this.api.submit(q.id, this.answers()));
      this.result.set(result);
      this.phase.set('revealed');
      this.focusSummary();
      if (result.xp > 0) this.celebrate(result.xp);
      if (result.correct > 0) this.feedback.moment('quiz');
    } catch {
      this.toast.show(
        $localize`:@@quiz.submitFail:Couldn’t check your answers. Your picks are saved, try again.`,
        {
          tone: 'error',
        },
      );
    } finally {
      this.submitting.set(false);
    }
  }

  /**
   * A-265: the XP from right answers pops out of the score chip and flies into "XP earned" in the
   * header, after the ticks have landed on each correct card. The summary already says it in words.
   */
  private celebrate(xp: number): void {
    afterNextRender(
      () => {
        const chip = this.summary()?.nativeElement.querySelector('.xp-chip') ?? null;
        setTimeout(() => this.xpFx.burst(xp, chip, { announce: false }), 450);
      },
      { injector: this.injector },
    );
  }

  protected retry(): void {
    this.practiceAnswers.set({});
    this.phase.set('practice');
    this.focusSummary();
  }

  protected backToResults(): void {
    this.phase.set('revealed');
    this.focusSummary();
  }

  protected continue(): void {
    void this.router.navigateByUrl(this.backLink());
  }

  protected resultFor(id: string): QuestionResult | undefined {
    return this.byId().get(id);
  }

  protected isCorrectPractice(id: string): boolean {
    return this.practiceAnswers()[id] === this.byId().get(id)?.correctOptionId;
  }

  protected questionCorrect(id: string): boolean {
    return this.inPractice() ? this.isCorrectPractice(id) : !!this.resultFor(id)?.correct;
  }

  protected optionState(q: QuizQuestion, o: QuizOption): OptionState {
    const picked = this.picks()[q.id] === o.id;
    if (!this.revealed()) return picked ? 'picked' : 'idle';
    const correctId = this.resultFor(q.id)?.correctOptionId;
    if (o.id === correctId) return picked ? 'right-pick' : 'correct';
    return picked ? 'wrong-pick' : 'dim';
  }

  protected pickedText(q: QuizQuestion): string {
    return q.options.find((o) => o.id === this.picks()[q.id])?.text ?? '';
  }

  protected optionLabel(q: QuizQuestion, o: QuizOption): string {
    switch (this.optionState(q, o)) {
      case 'right-pick':
        return $localize`:@@quiz.yourCorrect:${o.text}:text: — your answer, correct`;
      case 'correct':
        return $localize`:@@quiz.correctAnswer:${o.text}:text: — correct answer`;
      case 'wrong-pick':
        return $localize`:@@quiz.yourWrong:${o.text}:text: — your answer, not correct`;
      default:
        return o.text;
    }
  }

  private queueDraft(): void {
    const q = this.quiz();
    if (!q) return;
    clearTimeout(this.draftTimer);
    this.draftTimer = setTimeout(() => {
      this.api.saveDraft(q.id, this.answers()).subscribe({ error: () => undefined });
    }, DRAFT_DELAY);
  }

  private focusSummary(): void {
    afterNextRender(
      () => {
        const el = this.summary()?.nativeElement;
        el?.focus({ preventScroll: true });
        el?.scrollIntoView({ block: 'start', behavior: 'smooth' });
        if (!el) window.scrollTo({ top: 0, behavior: 'smooth' });
      },
      { injector: this.injector },
    );
  }
}

/** Deterministic reshuffle for practice (rotate by one) so the right answer moves. */
function reshuffle(options: readonly QuizOption[]): QuizOption[] {
  return options.length > 1 ? [...options.slice(1), options[0] as QuizOption] : [...options];
}
