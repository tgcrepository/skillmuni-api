import type { Meta, StoryObj } from '@storybook/angular-vite';
import { Brief } from '../../core/learn/learn.api';
import { BriefCard } from './brief-card';

const brief: Brief = {
  id: 'b11',
  index: 11,
  title: 'Mirror and Water Images',
  status: 'current',
  body: 'A mirror image is how a figure looks when a mirror is placed beside it: left and right swap, while top and bottom stay the same.',
  example:
    'Hold the word “CAB” up to a mirror on its right and you read BAC, with every letter flipped sideways.',
  keyTerm: 'Lateral inversion',
  videoUrl: 'https://example.com',
  media: {
    kind: 'image',
    src: 'assets/learn/brief-mirror.svg',
    alt: 'A triangle and its mirror image either side of a vertical line.',
  },
  bookmarked: false,
  helpful: null,
  xp: 0,
  quiz: { id: 'q', questions: 3, result: null },
};

const meta: Meta<BriefCard> = {
  title: 'Learn/Brief card',
  component: BriefCard,
  parameters: { figma: { node: 'Brief Card 77:2714 · states 79:3005' }, layout: 'padded' },
};
export default meta;

export const Wide: StoryObj<BriefCard> = { args: { brief, total: 11 } };

export const ShortNoExample: StoryObj<BriefCard> = {
  args: {
    brief: {
      ...brief,
      index: 10,
      title: 'Embedded Figures',
      example: undefined,
      videoUrl: undefined,
    },
    total: 11,
    review: true,
  },
};
