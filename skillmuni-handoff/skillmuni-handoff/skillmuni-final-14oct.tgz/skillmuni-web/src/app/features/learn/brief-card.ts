import {
  Component,
  DestroyRef,
  PLATFORM_ID,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Brief } from '../../core/learn/learn.api';
import { Icon } from '../../shared/ui/icon/icon';

/**
 * Figma: Brief Card (77:2714). The open brief: ONE scroll (the page), no inner scroll box, no "See more".
 * Order: media → text → Example → Key term / Video reference. Wide (media left, ≤ 70ch text) on desktop,
 * stacked on tablet portrait and mobile. Read aloud reads title → text → example.
 */
@Component({
  selector: 'sm-brief-card',
  imports: [Icon],
  templateUrl: './brief-card.html',
  styleUrl: './brief-card.scss',
  host: { class: 'sm-brief-card', '[class.is-review]': 'review()' },
})
export class BriefCard {
  readonly brief = input.required<Brief>();
  readonly total = input.required<number>();
  /** A finished brief opened from its row (no orange "current" frame). */
  readonly review = input(false);
  readonly bookmark = output<void>();
  readonly helpful = output<boolean>();
  readonly expand = output<void>();

  private readonly browser = isPlatformBrowser(inject(PLATFORM_ID));
  protected readonly canSpeak =
    this.browser && typeof window !== 'undefined' && 'speechSynthesis' in window;
  protected readonly speaking = signal(false);

  protected readonly readLabel = $localize`:@@brief.readAloud:Read this brief aloud`;
  protected readonly stopLabel = $localize`:@@brief.stopReading:Stop reading aloud`;
  protected readonly exampleLabel = $localize`:@@brief.example:Example`;

  protected readonly headingId = computed(() => `brief-${this.brief().id}`);
  protected readonly overline = computed(
    () => $localize`:@@brief.overline:Brief ${this.brief().index}:n: of ${this.total()}:total:`,
  );

  constructor() {
    inject(DestroyRef).onDestroy(() => this.stop());
  }

  protected toggleSpeech(): void {
    if (!this.canSpeak) return;
    if (this.speaking()) {
      this.stop();
      return;
    }
    const b = this.brief();
    const u = new SpeechSynthesisUtterance([b.title, b.body, b.example ?? ''].join('. '));
    u.onend = () => this.speaking.set(false);
    u.onerror = () => this.speaking.set(false);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
    this.speaking.set(true);
  }

  private stop(): void {
    if (this.canSpeak) window.speechSynthesis.cancel();
    this.speaking.set(false);
  }
}
