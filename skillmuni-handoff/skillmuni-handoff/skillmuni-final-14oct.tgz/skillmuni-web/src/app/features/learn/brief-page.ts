import { NgTemplateOutlet } from '@angular/common';
import {
  Component,
  OnInit,
  TemplateRef,
  computed,
  inject,
  input,
  signal,
  viewChild,
} from '@angular/core';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Brief, LEARN_API, TopicDetail } from '../../core/learn/learn.api';
import { Viewport } from '../../core/layout/viewport';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { SmDialog } from '../../shared/ui/overlay/dialog';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { BriefCard } from './brief-card';
import { LearnHeader, LearnStat } from './learn-header';
import { Currency } from '../../shared/ui/currency/currency';

type LoadState = 'loading' | 'ready' | 'error' | 'offline' | 'not-found';

/** More than this many finished briefs collapse into one "N briefs done" row (handoff 79:3169 §3). */
const GROUP_AFTER = 2;

/**
 * Brief reader for one topic (Figma 78:2520 desktop · 78:2760 tablet · 78:2977 mobile · states 79:3005).
 * Progress segments, finished briefs as rows (tap to review), the open brief card, the Quiz Bar
 * (always available; pinned above the tabs on mobile), the next locked brief and the course card.
 */
@Component({
  selector: 'sm-brief-page',
  imports: [
    Currency,
    BriefCard,
    Button,
    Icon,
    LearnHeader,
    LearnerShell,
    NgTemplateOutlet,
    RouterLink,
    Skeleton,
    SmDialog,
    StateBlock,
  ],
  templateUrl: './brief-page.html',
  styleUrl: './brief-page.scss',
})
export class BriefPage implements OnInit {
  private readonly api = inject(LEARN_API);
  private readonly toast = inject(ToastService);
  private readonly overlay = inject(OverlayService);
  protected readonly viewport = inject(Viewport);

  readonly module = input.required<string>();
  readonly topic = input.required<string>();

  protected readonly state = signal<LoadState>('loading');
  protected readonly detail = signal<TopicDetail | null>(null);
  /** Brief ids opened for review, plus "group" for the collapsed row. */
  protected readonly expanded = signal<ReadonlySet<string>>(new Set());
  protected readonly viewer = signal<Brief | null>(null);
  private readonly viewerTpl = viewChild<TemplateRef<unknown>>('viewerTpl');

  protected readonly briefs = computed(() => this.detail()?.briefs ?? []);
  protected readonly total = computed(() => this.briefs().length);
  protected readonly done = computed(() => this.briefs().filter((b) => b.status === 'done'));
  /** The brief on screen: the current one, or the last brief once the topic is finished. */
  protected readonly open = computed(
    () => this.briefs().find((b) => b.status === 'current') ?? this.briefs().at(-1) ?? null,
  );
  protected readonly finished = computed(() => this.open()?.status === 'done');
  /** Finished briefs shown as rows above the open card. */
  protected readonly rows = computed(() => this.done().filter((b) => b.id !== this.open()?.id));
  protected readonly grouped = computed(() =>
    this.rows().length > GROUP_AFTER ? this.rows().slice(0, -1) : [],
  );
  protected readonly singles = computed(() =>
    this.rows().length > GROUP_AFTER ? this.rows().slice(-1) : this.rows(),
  );
  protected readonly nextLocked = computed(
    () => this.briefs().find((b) => b.status === 'locked') ?? null,
  );

  protected readonly lobby = $localize`:@@nav.lobby:Lobby`;

  protected readonly stats = computed<LearnStat[]>(() => {
    const d = this.detail();
    return d
      ? [
          {
            icon: 'lightbulb',
            label: $localize`:@@learn.quizzesSolved:Quizzes solved`,
            value: `${d.quizzesDone} / ${d.quizzesTotal}`,
          },
          { icon: 'zap', label: $localize`:@@learn.xpEarned:XP earned`, value: `${d.xp} XP` },
        ]
      : [];
  });

  protected readonly progressText = computed(() => {
    const done = this.done().length;
    const left = this.total() - done;
    return left
      ? $localize`:@@brief.progress:${done}:done: done · ${left}:left: to go`
      : $localize`:@@brief.progressAll:All ${done}:done: done`;
  });

  protected readonly quizLink = computed(() => `/learn/${this.module()}/${this.topic()}/quiz`);

  ngOnInit(): void {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      this.detail.set(await firstValueFrom(this.api.topic(this.module(), this.topic())));
      this.state.set('ready');
    } catch (e) {
      const kind = e instanceof ApiError ? e.kind : 'unknown';
      this.state.set(kind === 'offline' ? 'offline' : kind === 'not-found' ? 'not-found' : 'error');
    }
  }

  protected isOpen(id: string): boolean {
    return this.expanded().has(id);
  }

  protected toggle(id: string): void {
    this.expanded.update((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  protected groupXp(): number {
    return this.grouped().reduce((a, b) => a + b.xp, 0);
  }

  protected segment(b: Brief): string {
    return b.status === 'done' ? 'done' : b.id === this.open()?.id ? 'current' : 'locked';
  }

  protected questionsLabel(b: Brief): string {
    const n = b.quiz.questions;
    return n === 1
      ? $localize`:@@brief.oneQuestion:1 question · +1 XP per correct answer`
      : $localize`:@@brief.questions:${n}:n: questions · +1 XP per correct answer`;
  }

  protected async toggleBookmark(b: Brief): Promise<void> {
    const on = !b.bookmarked;
    this.patch(b.id, { bookmarked: on });
    try {
      await firstValueFrom(this.api.bookmark(b.id, on));
      this.toast.show(
        on
          ? $localize`:@@brief.saved:Saved to My bookmarks`
          : $localize`:@@brief.unsaved:Removed from My bookmarks`,
      );
    } catch {
      this.patch(b.id, { bookmarked: !on });
      this.toast.show($localize`:@@brief.bookmarkFail:Couldn’t save that. Try again.`, {
        tone: 'error',
      });
    }
  }

  protected async rate(b: Brief, helpful: boolean): Promise<void> {
    const value = b.helpful === helpful ? null : helpful;
    this.patch(b.id, { helpful: value });
    try {
      await firstValueFrom(this.api.feedback(b.id, value));
      if (value !== null)
        this.toast.show($localize`:@@brief.thanks:Thanks! That helps us improve.`);
    } catch {
      this.patch(b.id, { helpful: b.helpful });
    }
  }

  protected openViewer(b: Brief): void {
    const tpl = this.viewerTpl();
    if (!tpl || !b.media) return;
    this.viewer.set(b);
    this.overlay.modal(tpl, { ariaLabel: b.title });
  }

  private patch(id: string, change: Partial<Brief>): void {
    this.detail.update((d) =>
      d ? { ...d, briefs: d.briefs.map((b) => (b.id === id ? { ...b, ...change } : b)) } : d,
    );
  }
}
