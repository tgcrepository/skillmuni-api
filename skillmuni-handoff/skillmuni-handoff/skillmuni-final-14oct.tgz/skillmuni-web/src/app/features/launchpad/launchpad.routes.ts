import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

export const launchpadRoutes: Routes = [
  {
    path: 'launchpad',
    title: $localize`:@@route.launchpad:Career Launchpad · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./launchpad-page').then((m) => m.LaunchpadPage),
  },
];
