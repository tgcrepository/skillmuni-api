import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of, throwError } from 'rxjs';
import { LAUNCHPAD_API, LaunchpadApi, MissionId, Sector } from '../../core/launchpad/launchpad.api';
import { LaunchpadPage } from './launchpad-page';

const missions = (done: MissionId[]) =>
  (['assessment', 'profile', 'apply', 'fest'] as const).map((id) => ({
    id,
    label: id,
    xp: 100,
    done: done.includes(id),
  }));

const sector = (id: string, name: string, jobs: number, fit: number | null): Sector => ({
  id,
  name,
  emoji: '•',
  jobs,
  newJobs: 0,
  fit,
});

interface PageApi {
  current(): MissionId | null;
  primaryCard(): string | null;
  prepDone(): number;
  previewSectors(): Sector[];
  moreSectors(): number;
  bestFitId(): string | null;
  oppsPill(): { text: string } | null;
  jobsV(): unknown;
}

function setup(done: MissionId[], sectors: Sector[], jobsFail = false) {
  const api: Partial<LaunchpadApi> = {
    readiness: () => of({ level: 1, levelName: 'x', percent: 25, missions: missions(done) }),
    profile: () => of({ percent: 70, sectionsLeft: 3, sectionsTotal: 8, stepsLeft: 3, missing: [] }),
    assessment: () =>
      of({
        status: 'not-started',
        answered: 0,
        total: 36,
        minutes: 8,
        archetype: null,
        mandatoryCourses: 0,
      }),
    jobs: () =>
      jobsFail
        ? throwError(() => new Error('503'))
        : of({
            locked: false,
            unlockAt: 60,
            matched: 1,
            applied: 0,
            saved: 0,
            newMatches: 5,
            interviews: 0,
            top: null,
          }),
    fest: () => of({ fest: null, alertsOn: false }),
    sectors: () => of(sectors),
  };
  TestBed.configureTestingModule({
    providers: [provideRouter([]), { provide: LAUNCHPAD_API, useValue: api }],
  });
  const fixture = TestBed.createComponent(LaunchpadPage);
  fixture.detectChanges();
  return { fixture, page: fixture.componentInstance as unknown as PageApi };
}

describe('LaunchpadPage', () => {
  it('gives the Primary button to the card of the first unfinished mission', async () => {
    const { fixture, page } = setup(['assessment'], []);
    await fixture.whenStable();
    expect(page.current()).toBe('profile');
    expect(page.primaryCard()).toBe('profile');
    expect(page.prepDone()).toBe(1);
    expect(page.oppsPill()?.text).toBe('5 new matches');
  });

  it('has no primary once launched', async () => {
    const { fixture, page } = setup(['assessment', 'profile', 'apply', 'fest'], []);
    await fixture.whenStable();
    expect(page.current()).toBeNull();
    expect(page.primaryCard()).toBeNull();
  });

  it('sorts sectors by fit, or A–Z before the assessment, and caps the preview at 7', async () => {
    const list = Array.from({ length: 9 }, (_, i) => sector(`s${i}`, `Z${9 - i}`, i, i * 10));
    const { fixture, page } = setup([], list);
    await fixture.whenStable();
    expect(page.bestFitId()).toBe('s8');
    expect(page.previewSectors()).toHaveLength(7);
    expect(page.moreSectors()).toBe(2);

    TestBed.resetTestingModule();
    const noFit = setup([], [sector('b', 'Banking', 1, null), sector('a', 'Auto', 9, null)]);
    await noFit.fixture.whenStable();
    expect(noFit.page.previewSectors().map((s) => s.name)).toEqual(['Auto', 'Banking']);
    expect(noFit.page.bestFitId()).toBeNull();
  });

  it('keeps the page working when only My Jobs fails', async () => {
    const { fixture, page } = setup(['assessment'], [], true);
    await fixture.whenStable();
    expect(page.jobsV()).toBeUndefined();
    expect(page.current()).toBe('profile');
    expect(fixture.nativeElement.textContent).toContain('Couldn’t load your jobs');
  });
});
