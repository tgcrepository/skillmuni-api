import { BackNav } from '../../core/layout/back-nav';
import { NgTemplateOutlet } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { LAUNCHPAD_API, MissionId, Sector } from '../../core/launchpad/launchpad.api';
import { Market } from '../../core/market/market';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { SectorsDialog, SectorsDialogData } from './sectors-dialog';
import { Currency } from '../../shared/ui/currency/currency';

/** Sectors shown before the "+N View all" tile. */
const SECTOR_PREVIEW = 7;

/** Which card owns each mission's Primary button (only one per page). */
const MISSION_CARD: Record<MissionId, 'profile' | 'assessment' | 'jobs' | 'fest'> = {
  assessment: 'assessment',
  profile: 'profile',
  apply: 'jobs',
  fest: 'fest',
};

/** Not built yet: these land on the coming-soon page (A-200). */
export const LAUNCHPAD_LINKS = {
  assessment: '/assessments/career',
  assessmentReport: '/assessments/career/report',
  courses: '/stats/learning',
  fest: '/hire-fest',
  jobs: '/jobs',
  profile: '/job-profile',
} as const;

/**
 * Career Launchpad v2 (Figma 241:18014 · note 247:19784). Launch readiness (4 missions, levels 0–4)
 * → Career Prep (My Job Profile, Career Assessment) → Career Opportunities (My Jobs, Hire Fest)
 * → Placement Zone (sectors + View all). Only the card for the current mission gets the Primary
 * button. Every card loads and fails on its own (L6, L7).
 */
@Component({
  selector: 'sm-launchpad-page',
  imports: [Currency, Button, Icon, LearnerShell, NgTemplateOutlet, RouterLink, Skeleton],
  templateUrl: './launchpad-page.html',
  styleUrl: './launchpad-page.scss',
})
export class LaunchpadPage {
  private readonly api = inject(LAUNCHPAD_API);
  private readonly market = inject(Market);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);
  private readonly nav = inject(BackNav);

  protected readonly links = LAUNCHPAD_LINKS;

  protected readonly readiness = rxResource({ stream: () => this.api.readiness() });
  protected readonly profile = rxResource({ stream: () => this.api.profile() });
  protected readonly assessment = rxResource({ stream: () => this.api.assessment() });
  protected readonly jobs = rxResource({ stream: () => this.api.jobs() });
  protected readonly fest = rxResource({ stream: () => this.api.fest() });
  protected readonly sectors = rxResource({ stream: () => this.api.sectors() });
  protected readonly alertsBusy = signal(false);

  /* resource.value() throws while in error, so templates read these instead. */
  protected readonly readinessV = computed(() =>
    this.readiness.hasValue() ? this.readiness.value() : undefined,
  );
  protected readonly profileV = computed(() =>
    this.profile.hasValue() ? this.profile.value() : undefined,
  );
  protected readonly assessmentV = computed(() =>
    this.assessment.hasValue() ? this.assessment.value() : undefined,
  );
  protected readonly jobsV = computed(() => (this.jobs.hasValue() ? this.jobs.value() : undefined));
  protected readonly festV = computed(() => (this.fest.hasValue() ? this.fest.value() : undefined));
  protected readonly sectorsV = computed(() =>
    this.sectors.hasValue() ? this.sectors.value() : undefined,
  );

  /** First mission not done; null once launched. */
  protected readonly current = computed<MissionId | null>(
    () => this.readinessV()?.missions.find((m) => !m.done)?.id ?? null,
  );
  protected readonly primaryCard = computed(() => {
    const c = this.current();
    return c ? MISSION_CARD[c] : null;
  });

  protected readonly prepDone = computed(() => {
    const m = this.readinessV()?.missions ?? [];
    return m.filter((x) => (x.id === 'assessment' || x.id === 'profile') && x.done).length;
  });

  protected readonly oppsPill = computed(() => {
    const j = this.jobsV();
    if (!j) return null;
    if (j.interviews)
      return { tone: 'success', text: $localize`:@@lp.interviews:${j.interviews}:n: interviews` };
    if (j.newMatches)
      return { tone: 'brand', text: $localize`:@@lp.newMatches:${j.newMatches}:n: new matches` };
    return null;
  });

  /** Best fit first once the assessment is done; alphabetical before (L2). */
  protected readonly sortedSectors = computed(() => {
    const list = [...(this.sectorsV() ?? [])];
    const hasFit = list.some((s) => s.fit !== null);
    return hasFit
      ? list.sort((a, b) => (b.fit ?? 0) - (a.fit ?? 0))
      : list.sort((a, b) => a.name.localeCompare(b.name, this.market.config().locale));
  });
  protected readonly hasFit = computed(() => this.sortedSectors().some((s) => s.fit !== null));
  protected readonly previewSectors = computed(() => this.sortedSectors().slice(0, SECTOR_PREVIEW));
  protected readonly moreSectors = computed(() =>
    Math.max(0, this.sortedSectors().length - SECTOR_PREVIEW),
  );
  protected readonly bestFitId = computed(() =>
    this.hasFit() ? this.sortedSectors()[0]?.id : null,
  );

  protected back(): void {
    this.nav.back('/home');
  }

  protected festDate(iso: string): { day: string; month: string } {
    const d = new Date(`${iso}T00:00:00`);
    const loc = this.market.config().locale;
    return {
      day: new Intl.DateTimeFormat(loc, { day: 'numeric' }).format(d),
      month: new Intl.DateTimeFormat(loc, { month: 'short' }).format(d).toUpperCase(),
    };
  }

  protected openSectors(): void {
    this.overlay.adaptive<SectorsDialog, SectorsDialogData>(SectorsDialog, {
      data: { sectors: this.sortedSectors(), hasFit: this.hasFit() },
      autoFocus: 'input',
    });
  }

  protected sectorLabel(s: Sector): string {
    const base = $localize`:@@lp.sectorJobs:${s.name}:name:, ${s.jobs}:n: jobs`;
    return s.id === this.bestFitId() ? `${base}, ${$localize`:@@lp.bestFit:Best fit`}` : base;
  }

  protected async toggleAlerts(on: boolean): Promise<void> {
    this.alertsBusy.set(true);
    try {
      const f = await firstValueFrom(this.api.setFestAlerts(on));
      this.fest.set(f);
      this.toast.show(
        on
          ? $localize`:@@lp.alertsOn:Done! We’ll ping you when a fest drops.`
          : $localize`:@@lp.alertsOff:Fest alerts turned off.`,
        { tone: 'success' },
      );
    } catch {
      this.toast.show($localize`:@@lp.alertsFailed:Couldn’t change fest alerts. Try again.`, {
        tone: 'error',
      });
    } finally {
      this.alertsBusy.set(false);
    }
  }

  /** Add-to-calendar: a small .ics file the phone or laptop opens in its calendar. */
  protected addToCalendar(): void {
    const f = this.festV()?.fest;
    if (!f) return;
    const day = f.date.replace(/-/g, '');
    const ics = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Skillmuni//Hire Fest//EN',
      'BEGIN:VEVENT',
      `UID:${f.id}@skillmuni`,
      `DTSTART;VALUE=DATE:${day}`,
      `SUMMARY:${f.name}${f.bookedSlot ? ` · ${f.bookedSlot}` : ''}`,
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');
    const url = URL.createObjectURL(new Blob([ics], { type: 'text/calendar' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `${f.id}.ics`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
