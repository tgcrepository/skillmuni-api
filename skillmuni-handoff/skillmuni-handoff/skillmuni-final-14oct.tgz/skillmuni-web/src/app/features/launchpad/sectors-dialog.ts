import { DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, computed, inject, signal, viewChild } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Sector } from '../../core/launchpad/launchpad.api';
import { Market } from '../../core/market/market';
import { MuniChat } from '../../shared/muni-chat/muni-chat.service';
import { Button } from '../../shared/ui/button/button';
import { ChipGroup, ChipOption } from '../../shared/ui/chip/chip-group';
import { Icon } from '../../shared/ui/icon/icon';
import { SmDialog } from '../../shared/ui/overlay/dialog';
import { uniqueId } from '../../shared/ui/internal/unique-id';

export interface SectorsDialogData {
  readonly sectors: readonly Sector[];
  readonly hasFit: boolean;
}

type Sort = 'fit' | 'jobs' | 'az';

/**
 * L8 · All sectors (Figma 246:19226) and L9 · search with no results (246:20432). Modal on desktop
 * and tablet, bottom sheet on mobile. Best fit first (when the assessment is done), sort chips,
 * search; a sector opens its jobs in My Jobs. Scales to any number of sectors.
 */
@Component({
  selector: 'sm-sectors-dialog',
  imports: [Button, ChipGroup, Icon, RouterLink, SmDialog],
  templateUrl: './sectors-dialog.html',
  styleUrl: './sectors-dialog.scss',
})
export class SectorsDialog {
  private readonly data = inject<SectorsDialogData>(DIALOG_DATA);
  private readonly market = inject(Market);
  private readonly muni = inject(MuniChat);
  protected readonly dialog = viewChild.required(SmDialog);

  protected readonly ids = { search: uniqueId('sector-search'), sort: uniqueId('sector-sort') };
  protected readonly title = $localize`:@@lp.allSectors:All sectors`;
  protected readonly query = signal('');
  protected readonly sort = signal<Sort>(this.data.hasFit ? 'fit' : 'az');

  protected readonly sortOptions: readonly ChipOption[] = [
    ...(this.data.hasFit ? [{ value: 'fit', label: $localize`:@@lp.sortFit:Best fit` }] : []),
    { value: 'jobs', label: $localize`:@@lp.sortJobs:Most jobs` },
    { value: 'az', label: $localize`:@@lp.sortAz:A–Z` },
  ];

  protected readonly newThisWeek = computed(() =>
    this.data.sectors.reduce((n, s) => n + s.newJobs, 0),
  );
  protected readonly subtitle = computed(
    () =>
      $localize`:@@lp.allSectorsSub:${this.data.sectors.length}:n: hiring now · ${this.newThisWeek()}:new: new jobs this week`,
  );
  protected readonly bestId = computed(() =>
    this.data.hasFit
      ? [...this.data.sectors].sort((a, b) => (b.fit ?? 0) - (a.fit ?? 0))[0]?.id
      : null,
  );

  protected readonly results = computed(() => {
    const q = this.query().trim().toLocaleLowerCase();
    const loc = this.market.config().locale;
    const list = this.data.sectors.filter((s) => !q || s.name.toLocaleLowerCase().includes(q));
    const by: Record<Sort, (a: Sector, b: Sector) => number> = {
      fit: (a, b) => (b.fit ?? 0) - (a.fit ?? 0),
      jobs: (a, b) => b.jobs - a.jobs,
      az: (a, b) => a.name.localeCompare(b.name, loc),
    };
    return [...list].sort(by[this.sort()]);
  });

  protected readonly status = computed(() =>
    this.query().trim()
      ? $localize`:@@lp.searchCount:${this.results().length}:n: sectors found`
      : '',
  );

  protected setSort(v: string | string[] | null): void {
    if (v === 'fit' || v === 'jobs' || v === 'az') this.sort.set(v);
  }

  protected onInput(e: Event): void {
    this.query.set((e.target as HTMLInputElement).value);
  }

  protected clear(input: HTMLInputElement): void {
    this.query.set('');
    input.value = '';
    input.focus();
  }

  protected askMuni(): void {
    const q = this.query().trim();
    this.dialog().close();
    void this.muni
      .open()
      .then(() =>
        this.muni.ask(
          $localize`:@@lp.askMuni:I searched for “${q}:q:”. Which sectors fit my skills?`,
        ),
      );
  }

  protected sectorLabel(s: Sector): string {
    const parts = [s.name, $localize`:@@lp.nJobs:${s.jobs}:n: jobs`];
    if (s.newJobs) parts.push($localize`:@@lp.nNew:${s.newJobs}:n: new`);
    if (s.id === this.bestId()) parts.push($localize`:@@lp.bestFit:Best fit`);
    return parts.join(', ');
  }
}
