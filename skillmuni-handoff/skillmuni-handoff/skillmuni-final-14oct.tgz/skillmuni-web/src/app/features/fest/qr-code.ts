import { Component, computed, input } from '@angular/core';
import qrcode from 'qrcode-generator';

/**
 * Ticket QR (Figma H6). Drawn as one SVG path from the booking code so it scans at any size and
 * stays crisp in print. The code is also shown as text under it.
 */
@Component({
  selector: 'sm-qr-code',
  template: `
    <svg
      [attr.viewBox]="'0 0 ' + size() + ' ' + size()"
      role="img"
      [attr.aria-label]="label()"
      shape-rendering="crispEdges"
    >
      <rect [attr.width]="size()" [attr.height]="size()" class="bg" />
      <path [attr.d]="path()" class="fg" />
    </svg>
  `,
  styles: `
    :host {
      display: block;
    }

    svg {
      display: block;
      inline-size: 100%;
      block-size: auto;
      border-radius: var(--sm-radius-lg);
    }

    .bg {
      fill: var(--sm-color-decor-cv-paper);
    }

    .fg {
      fill: var(--sm-color-text-inverse);
    }
  `,
})
export class QrCode {
  readonly value = input.required<string>();
  readonly label = input($localize`:@@fest.qrLabel:Ticket QR code`);

  private readonly qr = computed(() => {
    const q = qrcode(0, 'M');
    q.addData(this.value());
    q.make();
    return q;
  });

  /** Module count plus a 2-module quiet zone on each side. */
  protected readonly size = computed(() => this.qr().getModuleCount() + 4);

  protected readonly path = computed(() => {
    const q = this.qr();
    const n = q.getModuleCount();
    let d = '';
    for (let r = 0; r < n; r++)
      for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += `M${c + 2} ${r + 2}h1v1h-1z`;
    return d;
  });
}
