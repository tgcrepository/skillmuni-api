import { DIALOG_DATA } from '@angular/cdk/dialog';
import { NgOptimizedImage } from '@angular/common';
import { Component, computed, inject, signal, viewChild } from '@angular/core';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import {
  Booking,
  FEST_API,
  FestAlerts,
  FestEmployer,
  FestSummary,
  WaitlistInfo,
} from '../../core/fest/fest.api';
import { ASSETS } from '../../shared/assets';
import { Button } from '../../shared/ui/button/button';
import { SmDialog } from '../../shared/ui/overlay/dialog';
import { Switch } from '../../shared/ui/switch/switch';
import { Typewriter } from '../../shared/ui/muni/typewriter';

export interface CancelData {
  readonly booking: Booking;
  /** Preselect one interview (from its own Cancel link). */
  readonly employerId: string | null;
}

export type CancelResult =
  | { readonly kind: 'cancelled'; readonly booking: Booking | null }
  | { readonly kind: 'reschedule' };

/** H8 · Cancel or reschedule (Figma 318:46748). Reschedule is offered first; the reason is optional. */
@Component({
  selector: 'sm-fest-cancel-dialog',
  imports: [Button, SmDialog],
  template: `
    <sm-dialog [title]="title">
      <div
        class="choices"
        role="radiogroup"
        i18n-aria-label="@@fest.whatCancel"
        aria-label="What to cancel"
      >
        @for (i of data.booking.interviews; track i.employerId) {
          @if (data.booking.interviews.length > 1) {
            <label class="choice" [class.is-on]="what() === i.employerId">
              <input
                type="radio"
                name="what"
                [checked]="what() === i.employerId"
                (change)="what.set(i.employerId)"
              />
              <span class="c-text">
                <strong i18n="@@fest.onlyX">Only {{ i.company }} · {{ i.time }}</strong>
                <span i18n="@@fest.keepOther">Keep your {{ other(i.employerId) }} interview</span>
              </span>
              @if (what() === i.employerId) {
                <span class="sel" aria-hidden="true" i18n="@@fest.selected">Selected</span>
              }
            </label>
          }
        }
        <label class="choice" [class.is-on]="what() === null">
          <input type="radio" name="what" [checked]="what() === null" (change)="what.set(null)" />
          <span class="c-text">
            <strong i18n="@@fest.whole">The whole booking</strong>
            @if (data.booking.interviews.length > 1) {
              <span i18n="@@fest.wholeSub">Both interviews · your ticket stops working</span>
            } @else {
              <span i18n="@@fest.wholeSub1">Your ticket stops working</span>
            }
          </span>
          @if (what() === null) {
            <span class="sel" aria-hidden="true" i18n="@@fest.selected">Selected</span>
          }
        </label>
      </div>
      <p class="over" id="fc-why" i18n="@@fest.whyOptional">Why? (optional)</p>
      <ul class="reasons" aria-labelledby="fc-why">
        @for (r of reasons; track r) {
          <li>
            <button
              type="button"
              class="reason"
              [attr.aria-pressed]="reason() === r"
              (click)="reason.set(reason() === r ? '' : r)"
            >
              {{ r }}
            </button>
          </li>
        }
      </ul>
      <p class="note" i18n="@@fest.cancelNote">
        Your slot goes to the next learner on the waitlist. Rather pick another time? Reschedule
        instead.
      </p>
      <div smDialogActions class="actions">
        <button
          sm-button
          variant="secondary"
          type="button"
          (click)="dialog().close({ kind: 'reschedule' })"
          i18n="@@fest.rescheduleInstead"
        >
          Reschedule instead
        </button>
        <button sm-button type="button" [loading]="busy()" (click)="confirm()">
          {{ confirmLabel() }}
        </button>
      </div>
    </sm-dialog>
  `,
  styleUrl: './fest-dialogs.scss',
})
export class CancelDialog {
  protected readonly data = inject<CancelData>(DIALOG_DATA);
  private readonly api = inject(FEST_API);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly what = signal<string | null>(
    this.data.employerId ??
      (this.data.booking.interviews.length > 1
        ? (this.data.booking.interviews[0]?.employerId ?? null)
        : null),
  );
  protected readonly reason = signal('');
  protected readonly busy = signal(false);
  protected readonly title =
    this.data.booking.interviews.length > 1
      ? $localize`:@@fest.cancelTitle:Cancel your interview?`
      : $localize`:@@fest.cancelTitle1:Cancel your booking?`;
  protected readonly reasons = [
    $localize`:@@fest.r1:Clash with class`,
    $localize`:@@fest.r2:Got another offer`,
    $localize`:@@fest.r3:Can’t travel`,
    $localize`:@@fest.r4:Other`,
  ];
  protected readonly confirmLabel = computed(() =>
    this.what()
      ? $localize`:@@fest.cancelInterview:Cancel interview`
      : $localize`:@@fest.cancelBooking:Cancel booking`,
  );

  protected other(id: string): string {
    return this.data.booking.interviews.find((i) => i.employerId !== id)?.company ?? '';
  }

  protected async confirm(): Promise<void> {
    this.busy.set(true);
    try {
      const b = await firstValueFrom(
        this.api.cancel(this.data.booking.id, this.what(), this.reason()),
      );
      this.dialog().close({ kind: 'cancelled', booking: b } satisfies CancelResult);
    } finally {
      this.busy.set(false);
    }
  }
}

export interface WaitlistData {
  readonly festId: string;
  readonly employer: FestEmployer;
}

/** H9 · Slot full — join the waitlist (Figma 318:47221). */
@Component({
  selector: 'sm-fest-waitlist-dialog',
  imports: [Button, NgOptimizedImage, SmDialog, Switch, Typewriter],
  template: `
    <sm-dialog [title]="title">
      <p class="muni">
        <img [ngSrc]="avatar" alt="" width="56" height="56" />
        <span class="bubble" smTypewriter i18n="@@fest.wlMuni"
          >All slots are taken right now, but people cancel. I’ll grab one for you.</span
        >
      </p>
      @if (info(); as i) {
        <div class="row">
          <span class="pos">#{{ i.position }}</span>
          <span class="r-text">
            <strong i18n="@@fest.wlPlace">Your place in line</strong>
            <span>{{ i.odds }}</span>
          </span>
        </div>
      }
      <div class="row">
        <sm-switch class="is-block" [checked]="auto()" (checkedChange)="auto.set($event)">
          <span class="r-text">
            <strong i18n="@@fest.wlAuto">Book me automatically</strong>
            <span i18n="@@fest.wlAutoSub"
              >If a slot opens we book it and tell you. Cancel free within 2 hrs.</span
            >
          </span>
        </sm-switch>
      </div>
      <div class="row">
        <sm-switch class="is-block" [checked]="whatsapp()" (checkedChange)="whatsapp.set($event)">
          <span class="r-text">
            <strong i18n="@@fest.wlWa">Tell me on WhatsApp</strong>
            <span i18n="@@fest.wlWaSub">And in the app</span>
          </span>
        </sm-switch>
      </div>
      <div smDialogActions class="actions">
        <button
          sm-button
          variant="secondary"
          type="button"
          (click)="dialog().close()"
          i18n="@@fest.notNow"
        >
          Not now
        </button>
        <button sm-button type="button" [loading]="busy()" (click)="join()" i18n="@@fest.joinWl">
          Join waitlist
        </button>
      </div>
    </sm-dialog>
  `,
  styleUrl: './fest-dialogs.scss',
})
export class WaitlistDialog {
  protected readonly data = inject<WaitlistData>(DIALOG_DATA);
  private readonly api = inject(FEST_API);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly avatar = ASSETS.muniAvatar;
  protected readonly title = $localize`:@@fest.wlTitle:Join the ${this.data.employer.company}:company: waitlist`;
  protected readonly info = signal<WaitlistInfo | null>(null);
  protected readonly auto = signal(true);
  protected readonly whatsapp = signal(true);
  protected readonly busy = signal(false);

  constructor() {
    void firstValueFrom(this.api.waitlistInfo(this.data.festId, this.data.employer.id)).then((i) =>
      this.info.set(i),
    );
  }

  protected async join(): Promise<void> {
    this.busy.set(true);
    try {
      this.dialog().close(
        await firstValueFrom(
          this.api.waitlist(this.data.festId, this.data.employer.id, this.auto(), this.whatsapp()),
        ),
      );
    } finally {
      this.busy.set(false);
    }
  }
}

/** H10 · Locked — finish your job profile first (Figma 318:47757). */
@Component({
  selector: 'sm-fest-locked-dialog',
  imports: [Button, NgOptimizedImage, RouterLink, SmDialog, Typewriter],
  template: `
    <sm-dialog [title]="title">
      <p class="muni">
        <img [ngSrc]="avatar" alt="" width="56" height="56" />
        <span class="bubble" smTypewriter i18n="@@fest.lockMuni"
          >Employers get your CV when you book, so let’s make it count.</span
        >
      </p>
      <span
        class="bar"
        role="progressbar"
        aria-valuemin="0"
        aria-valuemax="100"
        [attr.aria-valuenow]="data.profilePercent"
        i18n-aria-label="@@fest.profileDone"
        aria-label="Job profile done"
        ><span class="bar-fill" [style.--v]="data.profilePercent / 100"></span
      ></span>
      <p class="bar-row">
        <strong i18n="@@fest.pctDone">{{ data.profilePercent }}% done</strong>
        <span i18n="@@fest.pctNeeded">{{ data.unlockAt }}% needed to book</span>
      </p>
      <ul class="todo">
        @for (m of data.missing; track m.title) {
          <li>
            <a class="todo-row" [routerLink]="m.link" (click)="dialog().close()">
              <span class="r-text">
                <strong>{{ m.title }}</strong>
                <span>{{ m.detail }}</span>
              </span>
              @if (m.xp) {
                <span class="xp" i18n="@@fest.xpPlus">+{{ m.xp }} XP</span>
              }
            </a>
          </li>
        }
      </ul>
      <div smDialogActions class="actions">
        <button
          sm-button
          variant="secondary"
          type="button"
          (click)="dialog().close()"
          i18n="@@fest.later"
        >
          Later
        </button>
        <a
          sm-button
          [routerLink]="data.missing[0]?.link ?? '/job-profile'"
          (click)="dialog().close()"
          i18n="@@fest.finishProfile"
          >Finish my profile</a
        >
      </div>
    </sm-dialog>
  `,
  styleUrl: './fest-dialogs.scss',
})
export class LockedDialog {
  protected readonly data = inject<FestSummary>(DIALOG_DATA);
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly avatar = ASSETS.muniAvatar;
  protected readonly title = $localize`:@@fest.lockTitle:Almost there!`;
}

/** Fest alerts (header button; H11 uses the same toggles inline). */
@Component({
  selector: 'sm-fest-alerts-dialog',
  imports: [Button, SmDialog, Switch],
  template: `
    <sm-dialog [title]="title">
      @if (a(); as s) {
        <div class="row">
          <sm-switch
            class="is-block"
            [checked]="s.city"
            (checkedChange)="a.set({ city: $event, online: s.online })"
          >
            <span class="r-text">
              <strong i18n="@@fest.alCity">Fests in {{ city }}</strong>
              <span i18n="@@fest.alCitySub">In-person</span>
            </span>
          </sm-switch>
        </div>
        <div class="row">
          <sm-switch
            class="is-block"
            [checked]="s.online"
            (checkedChange)="a.set({ city: s.city, online: $event })"
          >
            <span class="r-text">
              <strong i18n="@@fest.alOnline">Online fests</strong>
              <span i18n="@@fest.alOnlineSub">Anywhere in India</span>
            </span>
          </sm-switch>
        </div>
      }
      <div smDialogActions class="actions">
        <button
          sm-button
          variant="secondary"
          type="button"
          (click)="dialog().close()"
          i18n="@@ui.cancel"
        >
          Cancel
        </button>
        <button
          sm-button
          type="button"
          [loading]="busy()"
          (click)="save()"
          i18n="@@fest.saveAlerts"
        >
          Save alerts
        </button>
      </div>
    </sm-dialog>
  `,
  styleUrl: './fest-dialogs.scss',
})
export class FestAlertsDialog {
  private readonly api = inject(FEST_API);
  protected readonly city = inject<{ city: string }>(DIALOG_DATA).city;
  protected readonly dialog = viewChild.required(SmDialog);
  protected readonly title = $localize`:@@fest.alTitle:Fest alerts`;
  protected readonly a = signal<FestAlerts | null>(null);
  protected readonly busy = signal(false);

  constructor() {
    void firstValueFrom(this.api.alerts()).then((a) => this.a.set(a));
  }

  protected async save(): Promise<void> {
    const a = this.a();
    if (!a) return;
    this.busy.set(true);
    try {
      this.dialog().close(await firstValueFrom(this.api.setAlerts(a)));
    } finally {
      this.busy.set(false);
    }
  }
}
