import { Component, computed, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Fest } from '../../core/fest/fest.api';

export function dateParts(iso: string): { day: string; month: string; year: string } {
  const [y = '', m = '1', d = ''] = iso.split('-');
  const month =
    ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'][
      Number(m) - 1
    ] ?? '';
  return { day: d, month, year: y };
}

/** H1 fest card (Figma 315:44816 list): date tile, place, employers, price, live seats, match. */
@Component({
  selector: 'sm-fest-card',
  imports: [RouterLink],
  template: `
    @let f = fest();
    @let d = date();
    <article class="card" [class.is-selected]="selected()" [attr.aria-labelledby]="'fc-' + f.id">
      <span class="tile" [class.is-on]="selected()" aria-hidden="true">
        <span class="mo">{{ d.month }}</span>
        <span class="dd">{{ d.day }}</span>
        <span class="yy">{{ d.year }}</span>
      </span>
      <span class="body">
        <h3 class="name" [id]="'fc-' + f.id">
          <a
            class="link"
            [routerLink]="link()"
            [queryParams]="query()"
            queryParamsHandling="merge"
            [attr.aria-current]="selected() ? 'true' : null"
            >{{ f.name }}</a
          >
        </h3>
        <span class="where">
          <span aria-hidden="true">📍</span>
          @if (f.mode === 'online') {
            <ng-container i18n="@@fest.onlineVideo">Online · Video interviews</ng-container>
          } @else {
            <ng-container i18n="@@fest.cityInPerson">{{ f.city }} · In-person</ng-container>
          }
          · {{ when() }}
        </span>
        <span class="emps">
          <span class="avatars" aria-hidden="true">
            @for (e of f.employers.slice(0, 3); track e.id) {
              <span class="av">{{ e.initials }}</span>
            }
          </span>
          <span i18n="@@fest.moreEmployers"
            >+{{ f.employerCount - 3 }} employers · {{ f.roleCount }} roles</span
          >
        </span>
        <span class="chips">
          <span class="chip">{{ f.price }}</span>
          @if (f.booked) {
            <span class="chip chip--ok" i18n="@@fest.bookedChip">Booked ✓</span>
          } @else if (f.seatsLeft === 0) {
            <span class="chip" i18n="@@fest.fullWaitlist">Full · waitlist open</span>
          } @else if (f.seatsLeft <= 20) {
            <span class="chip chip--hot" i18n="@@fest.seatsHot"
              >🔥 {{ f.seatsLeft }} seats left</span
            >
          } @else {
            <span class="chip" i18n="@@fest.seats">{{ f.seatsLeft }} seats left</span>
          }
        </span>
        <span class="match">
          <span aria-hidden="true">🎯</span>
          @if (f.matchingRoles === 1) {
            <ng-container i18n="@@fest.oneRole">1 role matches you</ng-container>
          } @else {
            <ng-container i18n="@@fest.nRoles">{{ f.matchingRoles }} roles match you</ng-container>
          }
        </span>
      </span>
    </article>
  `,
  styleUrl: './fest-card.scss',
})
export class FestCard {
  readonly fest = input.required<Fest>();
  readonly selected = input(false);
  readonly link = input.required<string | readonly string[]>();
  readonly query = input<Record<string, string> | null>(null);

  protected readonly date = computed(() => dateParts(this.fest().start));
  protected readonly when = computed(() => {
    const f = this.fest();
    const s = dateParts(f.start);
    const e = dateParts(f.end);
    const mon = (m: string) => m.charAt(0) + m.slice(1).toLowerCase();
    return f.start === f.end
      ? `${Number(s.day)} ${mon(s.month)}`
      : `${Number(s.day)} – ${Number(e.day)} ${mon(e.month)}`;
  });
}
