import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

const page = () => import('./fest-page').then((m) => m.FestPage);
const title = $localize`:@@route.fest:Hire Fest · Skillmuni`;

export const festRoutes: Routes = [
  {
    path: 'hire-fest',
    title,
    canActivate: [requireSession],
    loadComponent: page,
    data: { tab: 'upcoming' },
  },
  {
    path: 'hire-fest/bookings',
    title,
    canActivate: [requireSession],
    loadComponent: page,
    data: { tab: 'bookings' },
  },
  {
    path: 'hire-fest/past',
    title,
    canActivate: [requireSession],
    loadComponent: page,
    data: { tab: 'past' },
  },
  {
    path: 'hire-fest/fest/:id',
    title,
    canActivate: [requireSession],
    loadComponent: () => import('./fest-detail-page').then((m) => m.FestDetailPage),
  },
  { path: 'career-fest', redirectTo: 'hire-fest' },
];
