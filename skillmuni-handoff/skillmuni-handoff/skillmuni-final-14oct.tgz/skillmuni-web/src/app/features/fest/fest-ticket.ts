import { NgOptimizedImage } from '@angular/common';
import { Component, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Booking } from '../../core/fest/fest.api';
import { ASSETS } from '../../shared/assets';
import { Button } from '../../shared/ui/button/button';
import { Confetti } from '../../shared/ui/quest/confetti';
import { FEST_LINKS, FestActions } from './fest-actions';
import { QrCode } from './qr-code';

/** H6 · You're booked — the ticket (Figma 316:48085 · 316:49236). */
@Component({
  selector: 'sm-fest-ticket',
  imports: [Button, Confetti, NgOptimizedImage, QrCode, RouterLink],
  template: `
    @let b = booking();
    <section class="ticket" aria-labelledby="tk-title">
      @if (celebrate()) {
        <sm-confetti class="confetti" />
      }
      <header class="t-head">
        <h2 class="t-title" id="tk-title" tabindex="-1">
          @if (celebrate()) {
            <ng-container i18n="@@fest.booked">You’re booked! 🎉</ng-container>
          } @else {
            <ng-container i18n="@@fest.yourTicket">Your ticket</ng-container>
          }
        </h2>
        <p class="t-sub">{{ b.fest.name }} · {{ b.interviews[0]?.dayLabel }}</p>
      </header>
      <div class="t-body">
        <div class="qr-col">
          <sm-qr-code class="qr" [value]="b.code" [label]="qrLabel(b.code)" />
          <span class="code">{{ b.code }}</span>
          <span class="hint">
            @if (b.fest.mode === 'online') {
              <ng-container i18n="@@fest.qrOnline"
                >Use this code to join the video room</ng-container
              >
            } @else {
              <ng-container i18n="@@fest.qrHint">Show at the entry desk</ng-container>
            }
          </span>
        </div>
        <div class="ivs">
          @for (i of b.interviews; track i.employerId; let k = $index) {
            <div class="iv" [style.--i]="k">
              <span class="av" aria-hidden="true">{{ i.initials }}</span>
              <span class="iv-text">
                <strong>{{ i.company }} · {{ i.role }}</strong>
                <span class="when">{{ i.dayLabel }} · {{ i.range }}</span>
                <span>{{ i.desk }}</span>
              </span>
            </div>
          }
          <p class="venue">
            <span aria-hidden="true">📍</span> {{ b.fest.venue }} · {{ b.fest.venueNote }}
          </p>
        </div>
      </div>
      <div class="t-actions">
        <button
          sm-button
          variant="secondary"
          type="button"
          (click)="actions.calendar(b)"
          i18n="@@fest.addCal"
        >
          Add to calendar
        </button>
        @if (b.fest.mode === 'in-person') {
          <button
            sm-button
            variant="secondary"
            type="button"
            (click)="actions.directions(b.fest)"
            i18n="@@fest.directions"
          >
            Directions
          </button>
        }
        <button
          sm-button
          variant="secondary"
          type="button"
          (click)="actions.share(b.fest)"
          i18n="@@fest.share"
        >
          Share
        </button>
      </div>
    </section>
    @if (celebrate()) {
      <section class="practice" aria-labelledby="tk-mock">
        <img [ngSrc]="avatar" alt="" width="56" height="56" />
        <span class="p-text">
          <strong id="tk-mock" i18n="@@fest.practice">Practise with Muni before the day</strong>
          <span i18n="@@fest.practiceSub"
            >10-min mock interview for {{ b.interviews[0]?.role }} · +20 XP</span
          >
        </span>
        <a sm-button variant="accent" [routerLink]="links.mock" i18n="@@fest.start">Start</a>
      </section>
      <a
        sm-button
        variant="secondary"
        class="all"
        [routerLink]="links.bookings"
        i18n="@@fest.viewBookings"
        >View my bookings</a
      >
    }
  `,
  styleUrl: './fest-ticket.scss',
})
export class FestTicket {
  protected readonly actions = inject(FestActions);
  readonly booking = input.required<Booking>();
  /** Fresh booking: confetti, "You're booked!" and the next-step card. */
  readonly celebrate = input(false);

  protected readonly avatar = ASSETS.muniAvatar;
  protected readonly links = FEST_LINKS;

  protected qrLabel(code: string): string {
    return $localize`:@@fest.qrFor:Ticket QR code for booking ${code}:code:`;
  }
}
