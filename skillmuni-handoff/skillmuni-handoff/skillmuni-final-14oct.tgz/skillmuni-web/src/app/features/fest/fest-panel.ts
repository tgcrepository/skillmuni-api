import {
  Component,
  ElementRef,
  computed,
  effect,
  inject,
  input,
  linkedSignal,
  signal,
  untracked,
  viewChild,
} from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { Router, RouterLink } from '@angular/router';
import { of } from 'rxjs';
import { FEST_API, Fest, FestEmployer, FestSummary, Slot } from '../../core/fest/fest.api';
import { SlotPick, clashes } from '../../core/fest/slots';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { Switch } from '../../shared/ui/switch/switch';
import { dateParts } from './fest-card';
import { FEST_LINKS, FestActions, FestStep } from './fest-actions';
import { FestTicket } from './fest-ticket';

const PREVIEW = 3;

/**
 * Fest detail and booking (Figma H2 315:46011 · H3 316:45099 · H4 316:46197 · H5 316:47142 ·
 * H6 316:48085). Desktop shows it in the right panel next to the list; tablet and mobile show it
 * as a page with a sticky footer. The step lives in the URL so Back works between steps.
 */
@Component({
  selector: 'sm-fest-panel',
  imports: [Button, FestTicket, Icon, RouterLink, Skeleton, Switch],
  templateUrl: './fest-panel.html',
  styleUrl: './fest-panel.scss',
  host: { '[class]': '"sm-fest-panel sm-fest-panel--" + mode()' },
})
export class FestPanel {
  private readonly api = inject(FEST_API);
  private readonly router = inject(Router);
  protected readonly actions = inject(FestActions);

  readonly fest = input.required<Fest>();
  readonly step = input<FestStep>('detail');
  readonly summary = input<FestSummary | undefined>();
  readonly mode = input<'panel' | 'page'>('panel');

  protected readonly links = FEST_LINKS;
  private readonly heading = viewChild<ElementRef<HTMLElement>>('stepHeading');

  protected readonly f = linkedSignal(() => this.fest());
  protected readonly tile = computed(() => dateParts(this.f().start));
  protected readonly showAll = signal(false);
  protected readonly employers = computed(() =>
    [...this.f().employers].sort((a, b) => b.match - a.match),
  );
  protected readonly visibleEmployers = computed(() =>
    this.showAll() ? this.employers() : this.employers().slice(0, PREVIEW),
  );

  /* ---------- Draft ---------- */

  protected readonly draft = computed(() => {
    this.actions.lastBooking();
    return this.actions.draft(this.f().id);
  });
  protected readonly picked = computed(() => this.draft().employers);
  protected readonly max = 2;

  protected toggleEmployer(e: FestEmployer): void {
    if (e.full) {
      void this.actions.waitlist(this.f().id, e);
      return;
    }
    const cur = this.picked();
    const on = cur.includes(e.id);
    if (!on && cur.length >= this.max) return;
    const employers = on ? cur.filter((x) => x !== e.id) : [...cur, e.id];
    this.actions.setDraft(this.f().id, {
      employers,
      picks: this.draft().picks.filter((p) => employers.includes(p.employerId)),
    });
  }

  protected isPicked(id: string): boolean {
    return this.picked().includes(id);
  }

  /* ---------- Times (H4) ---------- */

  protected readonly grid = rxResource({
    params: () =>
      this.step() === 'times' || this.step() === 'confirm'
        ? { id: this.f().id, emp: this.picked() }
        : undefined,
    stream: ({ params }) =>
      params.emp.length ? this.api.slots(params.id, params.emp) : of(undefined),
  });
  protected readonly g = computed(() => (this.grid.hasValue() ? this.grid.value() : undefined));
  protected readonly day = linkedSignal(
    () => this.draft().picks[0]?.date ?? this.g()?.days[0]?.date ?? '',
  );

  protected slotsOf(empId: string): readonly Slot[] {
    return this.g()?.slots[empId]?.[this.day()] ?? [];
  }

  protected pickOf(empId: string): SlotPick | undefined {
    return this.draft().picks.find((p) => p.employerId === empId);
  }

  protected slotState(empId: string, s: Slot): 'selected' | 'full' | 'clash' | 'open' {
    const p = this.pickOf(empId);
    if (p && p.date === this.day() && p.time === s.time) return 'selected';
    if (!s.left) return 'full';
    const g = this.g();
    const cand = { employerId: empId, date: this.day(), time: s.time };
    if (g && clashes(cand, this.draft().picks, g.minutes, g.buffer)) return 'clash';
    return 'open';
  }

  protected pickSlot(empId: string, s: Slot): void {
    const st = this.slotState(empId, s);
    if (st === 'full' || st === 'clash') return;
    const others = this.draft().picks.filter((p) => p.employerId !== empId);
    const picks =
      st === 'selected'
        ? others
        : [...others, { employerId: empId, date: this.day(), time: s.time }];
    this.actions.setDraft(this.f().id, { picks });
  }

  protected readonly allTimed = computed(
    () =>
      this.picked().length > 0 &&
      this.picked().every((id) => this.draft().picks.some((p) => p.employerId === id)),
  );

  protected readonly timesSummary = computed(() => {
    const picks = [...this.draft().picks].sort((a, b) =>
      (a.date + a.time).localeCompare(b.date + b.time),
    );
    if (!picks.length) return '';
    const day = this.g()?.days.find((d) => d.date === picks[0]?.date)?.label ?? '';
    return `${day} · ${picks.map((p) => this.clock(p.time)).join(' & ')}`;
  });

  protected clock(t: string): string {
    const [h = 0, m = 0] = t.split(':').map(Number);
    return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h < 12 ? 'am' : 'pm'}`;
  }

  protected employer(id: string): FestEmployer | undefined {
    return this.f().employers.find((e) => e.id === id);
  }

  protected dayLabel(date: string): string {
    return this.g()?.days.find((d) => d.date === date)?.label ?? date;
  }

  protected range(t: string): string {
    const [h = 0, m = 0] = t.split(':').map(Number);
    const end = h * 60 + m + (this.g()?.minutes ?? 30);
    const e = `${String(Math.floor(end / 60)).padStart(2, '0')}:${String(end % 60).padStart(2, '0')}`;
    return `${this.clock(t).replace(/ (am|pm)$/, '')} – ${this.clock(e)}`;
  }

  /* ---------- Confirm (H5) ---------- */

  protected setReminder(key: 'whatsapp' | 'sms' | 'calendar', on: boolean): void {
    this.actions.setDraft(this.f().id, { reminders: { ...this.draft().reminders, [key]: on } });
  }

  protected readonly busy = signal(false);

  protected async confirm(): Promise<void> {
    if (this.busy()) return;
    this.busy.set(true);
    const b = await this.actions.book(this.f().id);
    this.busy.set(false);
    if (b) {
      this.f.set(b.fest);
      this.actions.go(b.fest.id, 'ticket');
    }
  }

  protected readonly booking = computed(() => this.actions.lastBooking()[this.f().id] ?? null);

  /* ---------- Navigation ---------- */

  protected go(step: FestStep): void {
    this.actions.go(this.f().id, step);
  }

  protected async save(): Promise<void> {
    const next = await this.actions.toggleSave(this.f());
    if (next) this.f.set(next);
  }

  protected viewTicket(): void {
    void this.router.navigateByUrl(FEST_LINKS.bookings);
  }

  /** CV file from My Job Profile (name from the profile in the real API). */
  protected readonly cvName = computed(() => `Yash_Pohare_CV.pdf · ${this.draft().template}`);

  protected readonly roleLbl = $localize`:@@fest.stRole:Role`;
  protected readonly timeLbl = $localize`:@@fest.stTime:Time`;
  protected readonly confirmLbl = $localize`:@@fest.stConfirm:Confirm`;

  protected readonly firstEmployer = computed(() => this.employers()[0] ?? null);

  protected readonly stepIndex = computed(
    () => ({ employers: 1, times: 2, confirm: 3 })[this.step() as 'employers'] ?? 0,
  );

  constructor() {
    // Each step change moves focus to its heading (screen readers hear where they are).
    effect(() => {
      this.step();
      untracked(() =>
        setTimeout(
          () => this.heading()?.nativeElement.focus({ preventScroll: this.mode() === 'panel' }),
          0,
        ),
      );
    });
    // A step that needs earlier choices falls back to the first one.
    effect(() => {
      const s = this.step();
      const d = this.draft();
      if ((s === 'times' && !d.employers.length) || (s === 'confirm' && !d.picks.length))
        untracked(() => this.go('employers'));
      if (s === 'ticket' && !this.booking()) untracked(() => this.go('detail'));
    });
  }
}
