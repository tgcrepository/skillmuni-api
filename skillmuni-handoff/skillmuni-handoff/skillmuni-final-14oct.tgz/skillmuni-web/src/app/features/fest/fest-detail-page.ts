import { BackNav } from '../../core/layout/back-nav';
import { Component, computed, inject, input } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { Router } from '@angular/router';
import { FEST_API } from '../../core/fest/fest.api';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { FEST_LINKS, FestActions, FestStep } from './fest-actions';
import { FestPanel } from './fest-panel';

/** Tablet/mobile: fest detail (H2), booking steps (H3–H5) and ticket (H6) as one page. */
@Component({
  selector: 'sm-fest-detail-page',
  imports: [Button, FestPanel, Icon, LearnerShell, Skeleton, StateBlock],
  template: `
    <sm-learner-shell pageHeaderOnMobile [hideTabsOnMobile]="step() !== 'ticket'">
      <div class="page">
        <header class="head">
          <button
            type="button"
            class="round sm-back"
            i18n-aria-label="@@ui.back"
            aria-label="Back"
            (click)="back()"
          >
            <sm-icon name="chevron-left" size="md" />
          </button>
          <h1 class="h1">{{ heading() }}</h1>
        </header>
        @if (res.isLoading() && !res.hasValue()) {
          <div class="sk" aria-busy="true">
            <span class="sm-visually-hidden" role="status" i18n="@@fest.loadingFest"
              >Loading the fest…</span
            >
            <sm-skeleton shape="block" />
          </div>
        } @else if (res.error()) {
          <sm-state-block
            kind="error"
            i18n-title="@@fest.festErr"
            title="Couldn’t load this fest"
            i18n-body="@@fest.festErrBody"
            body="Check your connection and try again."
          >
            <button sm-button smStateAction (click)="res.reload()" i18n="@@ui.tryAgain">
              Try again
            </button>
          </sm-state-block>
        } @else if (fest(); as f) {
          @for (k of [step()]; track k) {
            <sm-fest-panel mode="page" [fest]="f" [step]="step() ?? 'detail'" [summary]="sum()" />
          }
        }
      </div>
    </sm-learner-shell>
  `,
  styles: `
    .page {
      display: grid;
      grid-template-columns: minmax(0, 1fr);
      gap: var(--sm-space-400);
      inline-size: 100%;
      max-inline-size: var(--sm-layout-shell-card-max-width);
      margin-inline: auto;
    }

    .head {
      display: flex;
      align-items: center;
      gap: var(--sm-space-350);
    }

    .round {
      display: grid;
      flex: none;
      place-items: center;
      inline-size: var(--sm-size-touch-min);
      block-size: var(--sm-size-touch-min);
      border: var(--sm-stroke-sm) solid var(--sm-color-border-subtle);
      border-radius: var(--sm-radius-full);
      background: var(--sm-color-surface-raised);
      color: var(--sm-color-text-primary);
      cursor: pointer;

      &:focus-visible {
        box-shadow: var(--sm-shadow-focus-ring);
        outline: none;
      }
    }

    .h1 {
      margin: 0;
      color: var(--sm-color-text-heading);
      font: var(--sm-font-heading-lg);
    }

    .sk sm-skeleton {
      min-block-size: calc(var(--sm-size-jobs-list) * 1.4);
    }
  `,
})
export class FestDetailPage {
  private readonly api = inject(FEST_API);
  private readonly actions = inject(FestActions);
  private readonly router = inject(Router);
  private readonly nav = inject(BackNav);

  readonly id = input.required<string>();
  readonly step = input<FestStep | undefined>();

  protected readonly res = rxResource({
    params: () => ({ id: this.id(), v: this.actions.changed() }),
    stream: ({ params }) => this.api.fest(params.id),
  });
  protected readonly fest = computed(() => (this.res.hasValue() ? this.res.value() : undefined));
  protected readonly summary = rxResource({ stream: () => this.api.summary() });
  protected readonly sum = computed(() =>
    this.summary.hasValue() ? this.summary.value() : undefined,
  );

  protected readonly heading = computed(() => {
    switch (this.step()) {
      case 'employers':
      case 'times':
      case 'confirm':
        return $localize`:@@fest.bookSlot:Book your slot`;
      case 'ticket':
        return $localize`:@@fest.yourTicket:Your ticket`;
      default:
        return $localize`:@@fest.festDetails:Fest details`;
    }
  });

  protected back(): void {
    const order: (FestStep | undefined)[] = [undefined, 'employers', 'times', 'confirm'];
    const i = order.indexOf(this.step());
    if (i > 0) {
      this.actions.go(this.id(), order[i - 1] ?? 'detail');
      return;
    }
    if (this.step() === 'ticket') void this.router.navigateByUrl(FEST_LINKS.bookings);
    else this.nav.back(FEST_LINKS.upcoming);
  }
}
