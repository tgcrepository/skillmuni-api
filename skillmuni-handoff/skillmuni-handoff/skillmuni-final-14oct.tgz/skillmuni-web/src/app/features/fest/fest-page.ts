import { BackNav } from '../../core/layout/back-nav';
import { Component, computed, inject, input, signal } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { Router, RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { Viewport } from '../../core/layout/viewport';
import { Booking, FEST_API, FestAlerts, Outcome, PastFest } from '../../core/fest/fest.api';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { Switch } from '../../shared/ui/switch/switch';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { FestCard, dateParts } from './fest-card';
import { FEST_LINKS, FestActions, FestStep } from './fest-actions';
import { FestPanel } from './fest-panel';
import { FestTicket } from './fest-ticket';

type Tab = 'upcoming' | 'bookings' | 'past';
type Filter = 'all' | 'free' | 'in-person' | 'online' | 'city';

/**
 * Hire Fest v2 (Figma 315:44812, handoff 318:55923). Upcoming (H1 list + H2–H6 panel), My bookings
 * (H7 tickets with countdown, H8 cancel/reschedule, H12 fest-day live queue) and Past (H13 outcomes
 * and rating). Locked (H10) and waitlist (H9) open as dialogs; no fests (H11) offers alerts inline.
 */
@Component({
  selector: 'sm-fest-page',
  imports: [
    Button,
    FestCard,
    FestPanel,
    FestTicket,
    Icon,
    LearnerShell,
    RouterLink,
    Skeleton,
    StateBlock,
    Switch,
  ],
  templateUrl: './fest-page.html',
  styleUrl: './fest-page.scss',
})
export class FestPage {
  protected readonly festLines = [
    $localize`:@@fest.muni1:Fests are where recruiters say “you’re hired” in person. Big energy.`,
    $localize`:@@fest.muni2:Pro move: book early, slots go faster than samosas.`,
    $localize`:@@fest.muni3:Bring your best smile. I’ll bring the hype.`,
  ];

  protected readonly nav = inject(BackNav);
  private readonly api = inject(FEST_API);
  private readonly router = inject(Router);
  private readonly toast = inject(ToastService);
  protected readonly actions = inject(FestActions);
  protected readonly viewport = inject(Viewport);

  /** Route data. */
  readonly tab = input<Tab>('upcoming');
  /** Desktop panel: `?fest=` and `?step=`. */
  readonly fest = input<string | undefined>();
  readonly step = input<FestStep | undefined>();

  protected readonly links = FEST_LINKS;
  protected readonly filter = signal<Filter>('all');

  protected readonly summary = rxResource({
    params: () => ({ v: this.actions.changed() }),
    stream: () => this.api.summary(),
  });
  protected readonly sum = computed(() =>
    this.summary.hasValue() ? this.summary.value() : undefined,
  );

  protected readonly fests = rxResource({
    params: () =>
      this.tab() === 'upcoming' ? { f: this.filter(), v: this.actions.changed() } : undefined,
    stream: ({ params }) => this.api.fests(params.f),
  });
  protected readonly list = computed(() =>
    this.fests.hasValue() ? this.fests.value() : undefined,
  );
  protected readonly selected = computed(() => {
    const l = this.list() ?? [];
    return l.find((f) => f.id === this.fest()) ?? l[0] ?? null;
  });
  protected readonly panelStep = computed<FestStep>(() =>
    this.selected()?.id === this.fest() ? (this.step() ?? 'detail') : 'detail',
  );

  protected readonly bookings = rxResource({
    params: () => (this.tab() === 'bookings' ? { v: this.actions.changed() } : undefined),
    stream: () => this.api.bookings(),
  });
  protected readonly bk = computed(() =>
    this.bookings.hasValue() ? this.bookings.value() : undefined,
  );
  protected readonly live = computed(() => this.bk()?.find((b) => b.live) ?? null);
  protected readonly ticketFor = signal<string | null>(null);

  protected readonly past = rxResource({
    params: () => (this.tab() === 'past' ? { v: this.actions.changed() } : undefined),
    stream: () => this.api.past(),
  });
  protected readonly pastList = signal<readonly PastFest[] | null>(null);
  protected readonly pastV = computed(
    () => this.pastList() ?? (this.past.hasValue() ? this.past.value() : undefined),
  );

  protected readonly filters: readonly { id: Filter; label: string }[] = [
    { id: 'all', label: $localize`:@@fest.fAll:All` },
    { id: 'free', label: $localize`:@@fest.fFree:Free` },
    { id: 'in-person', label: $localize`:@@fest.fInPerson:In-person` },
    { id: 'online', label: $localize`:@@fest.fOnline:Online` },
  ];

  protected readonly state = computed(() => {
    const t = this.tab();
    const res = t === 'upcoming' ? this.fests : t === 'bookings' ? this.bookings : this.past;
    if (res.error() || this.summary.error()) return 'error';
    if (t === 'upcoming')
      return this.list() === undefined ? 'loading' : this.list()?.length ? 'ready' : 'empty';
    if (t === 'bookings')
      return this.bk() === undefined ? 'loading' : this.bk()?.length ? 'ready' : 'empty';
    return this.pastV() === undefined ? 'loading' : this.pastV()?.length ? 'ready' : 'empty';
  });

  protected cardLink(id: string): string | readonly string[] {
    return this.viewport.isDesktop() ? [] : ['/hire-fest/fest', id];
  }

  protected cardQuery(id: string): Record<string, string> | null {
    return this.viewport.isDesktop() ? { fest: id } : null;
  }

  protected setFilter(f: Filter): void {
    this.filter.set(f);
    void this.router.navigate([], {
      queryParams: { fest: null, step: null },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  /* ---------- H11 alerts inline ---------- */

  protected readonly alerts = rxResource({
    params: () => (this.state() === 'empty' && this.tab() === 'upcoming' ? {} : undefined),
    stream: () => this.api.alerts(),
  });
  protected readonly alertDraft = signal<FestAlerts | null>(null);
  protected readonly alertV = computed(
    () => this.alertDraft() ?? (this.alerts.hasValue() ? this.alerts.value() : null),
  );

  protected async saveAlerts(): Promise<void> {
    const a = this.alertV();
    if (!a) return;
    await firstValueFrom(this.api.setAlerts(a));
    this.toast.show($localize`:@@fest.alertsSaved:Fest alerts saved`, { tone: 'success' });
  }

  /* ---------- H7 bookings ---------- */

  protected tile(b: Booking) {
    return dateParts(b.interviews[0]?.date ?? b.fest.start);
  }

  protected async cancel(b: Booking, employerId: string | null = null): Promise<void> {
    await this.actions.cancel(b, employerId);
  }

  protected toggleTicket(id: string): void {
    this.ticketFor.update((t) => (t === id ? null : id));
  }

  /* ---------- H13 past ---------- */

  protected readonly outcomes: readonly { id: Exclude<Outcome, null>; label: string }[] = [
    { id: 'offer', label: $localize`:@@fest.oOffer:Offer 🎉` },
    { id: 'waiting', label: $localize`:@@fest.oWaiting:Waiting` },
    { id: 'no', label: $localize`:@@fest.oNo:No` },
  ];

  protected async setOutcome(p: PastFest, employerId: string, o: Outcome): Promise<void> {
    const next = await firstValueFrom(this.api.outcome(p.id, employerId, o));
    this.pastList.set((this.pastV() ?? []).map((x) => (x.id === next.id ? next : x)));
    if (o === 'offer')
      this.toast.show($localize`:@@fest.offerSynced:Congrats! Added to My Jobs → Applied.`, {
        tone: 'reward',
        action: {
          label: $localize`:@@fest.viewApplied:View`,
          run: () => void this.router.navigateByUrl(FEST_LINKS.applied),
        },
      });
  }

  protected async rate(p: PastFest, stars: number): Promise<void> {
    const next = await firstValueFrom(this.api.rate(p.id, stars));
    this.pastList.set((this.pastV() ?? []).map((x) => (x.id === next.id ? next : x)));
  }

  protected readonly stars = [1, 2, 3, 4, 5];

  protected starLabel(n: number): string {
    return $localize`:@@fest.nStars:${n}:n: out of 5`;
  }

  protected outcomeName(p: PastFest): string {
    return `fest-${p.id}`;
  }

  protected attended(p: PastFest): string {
    return p.interviews.length === 1
      ? $localize`:@@fest.attended1:Attended · 1 interview`
      : $localize`:@@fest.attendedN:Attended · ${p.interviews.length}:n: interviews`;
  }
}
