import { Service, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { Viewport } from '../../core/layout/viewport';
import {
  Booking,
  FEST_API,
  Fest,
  FestEmployer,
  FestSummary,
  Reminders,
  WaitlistInfo,
} from '../../core/fest/fest.api';
import { SlotPick } from '../../core/fest/slots';
import { OverlayService } from '../../shared/ui/overlay/overlay.service';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { downloadIcs } from '../../shared/util/ics';
import {
  CancelData,
  CancelDialog,
  CancelResult,
  FestAlertsDialog,
  LockedDialog,
  WaitlistData,
  WaitlistDialog,
} from './fest-dialogs';
import { FeedbackPrompt } from '../../core/feedback/feedback-prompt';

export type FestStep = 'detail' | 'employers' | 'times' | 'confirm' | 'ticket';

export const FEST_LINKS = {
  upcoming: '/hire-fest',
  bookings: '/hire-fest/bookings',
  past: '/hire-fest/past',
  applied: '/jobs/applied',
  matching: '/jobs/matching',
  mock: '/assessments/career',
} as const;

export interface Draft {
  readonly employers: readonly string[];
  readonly picks: readonly SlotPick[];
  readonly reminders: Reminders;
  readonly template: string;
  /** Set when rescheduling an existing booking. */
  readonly bookingId: string | null;
}

const EMPTY: Draft = {
  employers: [],
  picks: [],
  reminders: { whatsapp: true, sms: true, calendar: true },
  template: 'Creative',
  bookingId: null,
};

/**
 * Hire Fest actions shared by the desktop panel and the tablet/mobile pages, plus the booking
 * draft (employers → times → confirm) kept per fest so going back and forth keeps choices.
 */
@Service()
export class FestActions {
  private readonly api = inject(FEST_API);
  private readonly feedback = inject(FeedbackPrompt);
  private readonly overlay = inject(OverlayService);
  private readonly toast = inject(ToastService);
  private readonly router = inject(Router);
  private readonly viewport = inject(Viewport);

  readonly changed = signal(0);
  private readonly drafts = signal<Readonly<Record<string, Draft>>>({});
  /** Booking just confirmed per fest (H6 ticket in the panel). */
  readonly lastBooking = signal<Readonly<Record<string, Booking>>>({});

  draft(festId: string): Draft {
    return this.drafts()[festId] ?? EMPTY;
  }

  setDraft(festId: string, patch: Partial<Draft>): void {
    this.drafts.update((d) => ({ ...d, [festId]: { ...(d[festId] ?? EMPTY), ...patch } }));
  }

  clearDraft(festId: string): void {
    this.drafts.update((d) => Object.fromEntries(Object.entries(d).filter(([id]) => id !== festId)));
  }

  /** Where a fest step lives: query params on the list (desktop) or its own page. */
  go(festId: string, step: FestStep, extra: Record<string, string> = {}): void {
    if (this.viewport.isDesktop()) {
      void this.router.navigate([FEST_LINKS.upcoming], {
        queryParams: { fest: festId, step: step === 'detail' ? null : step, ...extra },
        queryParamsHandling: 'merge',
      });
    } else {
      void this.router.navigate(['/hire-fest/fest', festId], {
        queryParams: { step: step === 'detail' ? null : step, ...extra },
        queryParamsHandling: 'merge',
      });
    }
  }

  /** "Book an interview slot": the job profile must be 60%+ first (H10). */
  async startBooking(fest: Fest, summary: FestSummary | undefined): Promise<void> {
    if (summary && summary.profilePercent < summary.unlockAt) {
      this.overlay.adaptive(LockedDialog, { data: summary, size: 'sm' });
      return;
    }
    this.go(fest.id, 'employers');
  }

  async waitlist(festId: string, employer: FestEmployer): Promise<WaitlistInfo | null> {
    const ref = this.overlay.adaptive<WaitlistDialog, WaitlistData, WaitlistInfo>(WaitlistDialog, {
      data: { festId, employer },
      size: 'sm',
    });
    const info = await firstValueFrom(ref.closed);
    if (info)
      this.toast.show(
        $localize`:@@fest.wlJoined:You’re #${info.position}:n: on the ${employer.company}:company: waitlist`,
        {
          tone: 'success',
        },
      );
    return info ?? null;
  }

  async book(festId: string): Promise<Booking | null> {
    const d = this.draft(festId);
    try {
      const b = await firstValueFrom(
        this.api.book(festId, { picks: d.picks, reminders: d.reminders, cvTemplate: d.template }),
      );
      this.lastBooking.update((m) => ({ ...m, [festId]: b }));
      this.clearDraft(festId);
      this.feedback.moment('fest');
      this.changed.update((n) => n + 1);
      return b;
    } catch {
      this.toast.show(
        $localize`:@@fest.bookFailed:Couldn’t confirm your booking. Your times are kept. Try again.`,
        {
          tone: 'error',
        },
      );
      return null;
    }
  }

  /** H8. Resolves true when something changed. */
  async cancel(booking: Booking, employerId: string | null = null): Promise<boolean> {
    const ref = this.overlay.adaptive<CancelDialog, CancelData, CancelResult>(CancelDialog, {
      data: { booking, employerId },
      size: 'sm',
    });
    const r = await firstValueFrom(ref.closed);
    if (!r) return false;
    if (r.kind === 'reschedule') {
      this.reschedule(booking);
      return false;
    }
    this.toast.show(
      r.booking
        ? $localize`:@@fest.oneCancelled:Interview cancelled. Your ticket still works.`
        : $localize`:@@fest.bookingCancelled:Booking cancelled`,
      { tone: 'success' },
    );
    this.changed.update((n) => n + 1);
    return true;
  }

  /** Reschedule = the time step with the booked employers and times preselected. */
  reschedule(booking: Booking): void {
    const toIso = (t: string) => {
      const m = /(\d+):(\d+)(?:\s*(pm))?/.exec(t);
      if (!m) return t;
      let h = Number(m[1]);
      if (m[3] && h < 12) h += 12;
      return `${String(h).padStart(2, '0')}:${m[2]}`;
    };
    this.setDraft(booking.fest.id, {
      employers: booking.interviews.map((i) => i.employerId),
      picks: booking.interviews.map((i) => ({
        employerId: i.employerId,
        date: i.date,
        time: toIso(i.time),
      })),
      reminders: booking.reminders,
      bookingId: booking.id,
    });
    this.go(booking.fest.id, 'times');
  }

  alerts(city: string): void {
    const ref = this.overlay.adaptive(FestAlertsDialog, { data: { city }, size: 'sm' });
    ref.closed.subscribe((a) => {
      if (a) this.toast.show($localize`:@@fest.alertsSaved:Fest alerts saved`, { tone: 'success' });
    });
  }

  calendar(b: Booking): void {
    const first = b.interviews[0];
    downloadIcs({
      id: b.code,
      title: `${b.fest.name}${first ? ` · ${first.company} ${first.time}` : ''}`,
      start: first?.date ?? b.fest.start,
      location: b.fest.venue,
      description: b.interviews
        .map((i) => `${i.company} · ${i.dayLabel} ${i.range} · ${i.desk}`)
        .join('\n'),
    });
  }

  directions(f: Fest): void {
    window.open(
      `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(f.venue)}`,
      '_blank',
      'noopener',
    );
  }

  async share(f: Fest): Promise<void> {
    const url = `${location.origin}/hire-fest?fest=${f.id}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: f.name, url });
        return;
      }
      await navigator.clipboard.writeText(url);
      this.toast.show($localize`:@@fest.linkCopied:Link copied`, { tone: 'success' });
    } catch (e) {
      if ((e as DOMException)?.name !== 'AbortError')
        this.toast.show($localize`:@@fest.shareFailed:Couldn’t share. Try again.`, {
          tone: 'error',
        });
    }
  }

  async toggleSave(f: Fest): Promise<Fest | null> {
    try {
      const next = await firstValueFrom(this.api.save(f.id, !f.saved));
      this.toast.show(
        next.saved
          ? $localize`:@@fest.savedToast:Saved. We’ll remind you before booking closes.`
          : $localize`:@@fest.unsavedToast:Removed from saved`,
        { tone: 'success' },
      );
      return next;
    } catch {
      return null;
    }
  }
}
