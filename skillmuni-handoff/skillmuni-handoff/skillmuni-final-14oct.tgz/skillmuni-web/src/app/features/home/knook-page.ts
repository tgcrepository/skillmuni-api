import { NgOptimizedImage } from '@angular/common';
import { Component, computed, inject, input } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { HOME_API } from '../../core/home/home.api';
import { BackNav } from '../../core/layout/back-nav';
import { LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';

/**
 * A knook's own screen (A-255): every module in it, from the Lobby's "Show more". Same tiles as the
 * Lobby, laid out as a grid at every size. States: loading, error (retry), not found, empty.
 */
@Component({
  selector: 'sm-knook-page',
  imports: [Button, Icon, LearnerShell, NgOptimizedImage, RouterLink, Skeleton, StateBlock],
  template: `
    <sm-learner-shell>
      <div class="page">
        <header class="head">
          <button
            type="button"
            class="round sm-back"
            i18n-aria-label="@@ui.back"
            aria-label="Back"
            (click)="nav.back('/home')"
          >
            <sm-icon name="chevron-left" size="md" />
          </button>
          @if (knook(); as k) {
            <img class="icon" [ngSrc]="k.icon" alt="" width="40" height="40" />
            <div class="titles">
              <h1 class="h1">{{ k.title }}</h1>
              <p class="count">{{ countLabel() }}</p>
            </div>
          } @else {
            <h1 class="h1" i18n="@@knook.title">Modules</h1>
          }
        </header>

        @if (feed.isLoading()) {
          <ul class="grid" aria-busy="true">
            <span class="sm-visually-hidden" role="status" i18n="@@knook.loading"
              >Loading modules…</span
            >
            @for (i of [1, 2, 3, 4, 5, 6]; track i) {
              <li><sm-skeleton shape="block" class="sk" /></li>
            }
          </ul>
        } @else if (feed.error()) {
          <sm-state-block
            kind="error"
            i18n-title="@@knook.error"
            title="Couldn’t load these modules"
            i18n-body="@@knook.errorBody"
            body="Your progress is safe. Give it another go."
          >
            <button sm-button smStateAction (click)="feed.reload()" i18n="@@ui.tryAgain">
              Try again
            </button>
          </sm-state-block>
        } @else if (!knook()) {
          <sm-state-block
            kind="empty"
            fill
            i18n-title="@@knook.missing"
            title="This knook isn’t here any more"
            i18n-body="@@knook.missingBody"
            body="Head back to the Lobby to see what’s on."
          >
            <a sm-button smStateAction routerLink="/home" i18n="@@learn.backLobby"
              >Back to the Lobby</a
            >
          </sm-state-block>
        } @else if (!knook()?.modules?.length) {
          <sm-state-block
            kind="empty"
            fill
            i18n-title="@@knook.empty"
            title="No modules here yet"
            i18n-body="@@knook.emptyBody"
            body="New modules land often. Check back soon."
          />
        } @else {
          <ul class="grid" [attr.aria-label]="knook()?.title">
            @for (m of knook()?.modules ?? []; track m.slug; let i = $index) {
              <li [style.--i]="i">
                <a class="tile" [routerLink]="m.link">
                  <span class="media">
                    <img [ngSrc]="m.art" alt="" width="112" height="112" />
                  </span>
                  <span class="label">{{ m.title }}</span>
                </a>
              </li>
            }
          </ul>
        }
      </div>
    </sm-learner-shell>
  `,
  styleUrl: './knook-page.scss',
})
export class KnookPage {
  private readonly api = inject(HOME_API);
  protected readonly nav = inject(BackNav);

  /** Route param. */
  readonly slug = input.required<string>();

  protected readonly feed = rxResource({ stream: () => this.api.feed() });
  protected readonly knook = computed(() =>
    this.feed.hasValue()
      ? (this.feed.value().knooks.find((k) => k.slug === this.slug()) ?? null)
      : null,
  );
  protected readonly countLabel = computed(() => {
    const n = this.knook()?.modules.length ?? 0;
    return n === 1
      ? $localize`:@@home.module1:1 module`
      : $localize`:@@home.modules:${n}:count: modules`;
  });
}
