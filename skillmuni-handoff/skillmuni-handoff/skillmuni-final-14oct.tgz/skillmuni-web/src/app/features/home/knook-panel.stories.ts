import { provideRouter } from '@angular/router';
import { applicationConfig, type Meta, type StoryObj } from '@storybook/angular-vite';
import { Knook } from '../../core/home/home.api';
import { KnookPanel } from './knook-panel';

const tile = (slug: string, title: string) => ({
  slug,
  title,
  art: `assets/home/tile-${slug}.png`,
  link: `/learn/${slug}`,
});

const skill: Knook = {
  slug: 'skill',
  title: 'Skill Knook',
  icon: 'assets/home/knook-skill.png',
  expanded: true,
  modules: [
    tile('brain-vita', 'Brain Vita'),
    tile('english-vinglish', 'English Vinglish'),
    tile('its-my-style', 'It’s My Style'),
    tile('happiness-barometer', 'Happiness Barometer'),
    tile('sharp-shooter', 'Sharp Shooter'),
    tile('surgical-strike', 'Surgical Strike'),
  ],
};

const meta: Meta<KnookPanel> = {
  title: 'Home/Knook panel',
  component: KnookPanel,
  parameters: {
    figma: { node: 'Knook 50:245 · Knook Tile 48:207 · See All 48:168' },
    layout: 'padded',
  },
  decorators: [applicationConfig({ providers: [provideRouter([])] })],
};
export default meta;

export const Open: StoryObj<KnookPanel> = { args: { knook: skill } };

export const Collapsed: StoryObj<KnookPanel> = {
  args: {
    knook: {
      slug: 'course',
      title: 'Course Knook',
      icon: 'assets/home/knook-course.png',
      expanded: false,
      modules: [tile('it-gyan', 'Digital Basics')],
    },
  },
};
