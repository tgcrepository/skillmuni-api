import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of, throwError } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Auth } from '../../core/auth/auth';
import { HOME_API, HomeFeed } from '../../core/home/home.api';
import { QuestStore } from '../../core/quests/quest-store';
import { LearnerBadges } from '../../shared/shell/learner-shell';
import { HomePage } from './home-page';

const feed: HomeFeed = {
  daypart: 'evening',
  resume: {
    module: 'Brain Vita',
    topic: 'Non-Verbal Reasoning',
    brief: 11,
    briefs: 11,
    note: '1 quiz away from 100% mastery',
    percent: 99,
    xp: 1,
    art: 'assets/home/tile-brain-vita.png',
    link: '/learn/brain-vita/non-verbal-reasoning',
  },
  pathways: [
    {
      slug: 'career-launchpad',
      title: 'Career Launchpad',
      blurb: 'Match jobs',
      tone: 'arcane',
      art: 'assets/home/pathway-career.png',
      link: '/matches',
    },
    {
      slug: 'grad-gateway',
      title: 'Grad Gateway',
      blurb: 'Compare countries',
      tone: 'ember',
      art: 'assets/home/pathway-grad.png',
      link: null,
    },
  ],
  knooks: [
    {
      slug: 'skill',
      title: 'Skill Knook',
      icon: 'assets/home/knook-skill.png',
      expanded: true,
      modules: [
        { slug: 'brain-vita', title: 'Brain Vita', art: 'a.png', link: '/learn/brain-vita' },
        { slug: 'english', title: 'English Vinglish', art: 'b.png', link: '/learn/english' },
      ],
    },
    {
      slug: 'course',
      title: 'Course Knook',
      icon: 'assets/home/knook-course.png',
      expanded: false,
      modules: [{ slug: 'digital', title: 'Digital Basics', art: 'c.png', link: '/learn/digital' }],
    },
  ],
  rewardsReady: 2,
  unreadNotifications: 1,
};

function setup(feedCall: () => unknown, completed = 8) {
  TestBed.configureTestingModule({
    providers: [
      provideRouter([]),
      { provide: HOME_API, useValue: { feed: feedCall } },
      { provide: Auth, useValue: { user: () => ({ id: '1', firstName: 'Yash' }) } },
      {
        provide: QuestStore,
        useValue: { progress: () => ({ completed }), load: () => Promise.resolve() },
      },
    ],
  });
  const fixture = TestBed.createComponent(HomePage);
  return { fixture, el: fixture.nativeElement as HTMLElement };
}

async function settle(fixture: { whenStable(): Promise<unknown>; detectChanges(): void }) {
  fixture.detectChanges();
  await fixture.whenStable();
  fixture.detectChanges();
}

describe('HomePage (Lobby)', () => {
  it('greets by daypart, shows resume, pathways and knooks, and feeds the nav badges', async () => {
    const { fixture, el } = setup(() => of(feed));
    await settle(fixture);
    expect(el.querySelector('h1')?.textContent).toContain('Good evening,');
    expect(el.querySelector('h1')?.textContent).toContain('Yash!');
    expect(el.querySelector('#home-resume')?.textContent).toContain('Pick up where you left off');
    expect(el.querySelector('[role=progressbar]')?.getAttribute('aria-valuenow')).toBe('99');
    expect(el.querySelectorAll('.pathway-item').length).toBe(2);
    // A pathway without a link is not a link, and says "Soon".
    expect(el.querySelector('a.pathway')?.textContent).toContain('Career Launchpad');
    expect(el.querySelector('div.pathway')?.textContent).toContain('Soon');
    expect(TestBed.inject(LearnerBadges).rewardsReady()).toBe(2);
    expect(el.querySelector('.finish')).toBeNull();
  });

  it('shows every knook’s tiles with a Show more link to its own screen (A-255)', async () => {
    const { fixture, el } = setup(() => of(feed));
    await settle(fixture);
    const [skill, course] = Array.from(el.querySelectorAll('sm-knook-panel'));
    expect(skill?.querySelectorAll('.tile').length).toBe(2);
    expect(course?.querySelectorAll('.tile').length).toBe(1);
    const more = course?.querySelector<HTMLAnchorElement>('a.see-all');
    expect(more?.getAttribute('aria-label')).toBe('Show all modules in Course Knook');
    expect(more?.getAttribute('href')).toBe('/knooks/course');
  });

  it('new learner: no resume card, a first-step card instead; no quests banner (A-276)', async () => {
    const { fixture, el } = setup(() => of({ ...feed, resume: null }), 3);
    await settle(fixture);
    expect(el.querySelector('#home-resume')).toBeNull();
    expect(el.querySelector('#home-start')?.textContent).toContain('Your first step');
    expect(el.querySelector('.finish')).toBeNull();
  });

  it('error state offers a retry', async () => {
    const { fixture, el } = setup(() => throwError(() => new ApiError('server', 503, 'x')));
    await settle(fixture);
    expect(el.querySelector('sm-state-block')?.textContent).toContain('Couldn’t load your Lobby');
    expect(el.querySelector('sm-state-block button')?.textContent).toContain('Try again');
  });

  it('offline state says so', async () => {
    const { fixture, el } = setup(() => throwError(() => new ApiError('offline', 0, 'x')));
    await settle(fixture);
    expect(el.querySelector('sm-state-block')?.textContent).toContain('You’re offline');
  });
});
