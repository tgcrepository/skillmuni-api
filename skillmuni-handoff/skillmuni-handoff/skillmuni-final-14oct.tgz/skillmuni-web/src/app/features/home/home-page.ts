import { NgOptimizedImage } from '@angular/common';
import {
  Component,
  DestroyRef,
  ElementRef,
  OnInit,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { RouterLink } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { ApiError } from '../../core/api/api-error';
import { Auth } from '../../core/auth/auth';
import { FirstStep, HOME_API, HomeFeed, Pathway } from '../../core/home/home.api';
import { Viewport } from '../../core/layout/viewport';
import { QuestStore } from '../../core/quests/quest-store';
import { LearnerBadges, LearnerShell } from '../../shared/shell/learner-shell';
import { Button } from '../../shared/ui/button/button';
import { Icon } from '../../shared/ui/icon/icon';
import { Skeleton } from '../../shared/ui/skeleton/skeleton';
import { StateBlock } from '../../shared/ui/state-block/state-block';
import { Tag } from '../../shared/ui/tag/tag';
import { KnookPanel } from './knook-panel';
import { Confetti } from '../../shared/ui/quest/confetti';
import { ToastService } from '../../shared/ui/toast/toast.service';
import { XpFx } from '../../shared/ui/xp-fx/xp-fx';
import { ASSETS } from '../../shared/assets';
import { FeedbackPrompt } from '../../core/feedback/feedback-prompt';
import { Currency } from '../../shared/ui/currency/currency';

type LoadState = 'loading' | 'ready' | 'error' | 'offline';

/**
 * Lobby — the homescreen after login and after registration (Figma Home v2: 185:8307 desktop ·
 * 185:8317 tablet · 62:592 mobile). Greeting · Pick up where you left off · Pathways · Knooks.
 * States: loading (skeleton in the real frames), error / offline (retry), new learner (no resume card),
 * registration unfinished (banner back to the quests).
 */
@Component({
  selector: 'sm-home-page',
  imports: [Currency, 
    Button,
    Confetti,
    Icon,
    KnookPanel,
    LearnerShell,
    NgOptimizedImage,
    RouterLink,
    Skeleton,
    StateBlock,
    Tag,
  ],
  templateUrl: './home-page.html',
  styleUrl: './home-page.scss',
})
export class HomePage implements OnInit {
  private readonly api = inject(HOME_API);
  private readonly feedback = inject(FeedbackPrompt);
  private readonly auth = inject(Auth);
  private readonly badges = inject(LearnerBadges);
  private readonly quests = inject(QuestStore);
  protected readonly viewport = inject(Viewport);
  private readonly toast = inject(ToastService);
  private readonly xpFx = inject(XpFx);
  protected readonly muni = ASSETS.muniCharacter;
  protected readonly claiming = signal(false);

  /**
   * A-304: "Pick a module below" is a first-visit hint. It fades out a minute after the learner first
   * sees it (remembered on this device), and never comes back.
   */
  protected readonly startHint = signal(startHintLeft() > 0);
  private readonly hintTimer = (() => {
    const left = startHintLeft();
    if (left <= 0) return undefined;
    const id = setTimeout(() => this.startHint.set(false), left);
    inject(DestroyRef).onDestroy(() => clearTimeout(id));
    return id;
  })();

  protected readonly state = signal<LoadState>('loading');
  protected readonly feed = signal<HomeFeed | null>(null);
  protected readonly slide = signal(0);
  private readonly rail = viewChild<ElementRef<HTMLElement>>('rail');

  protected readonly firstName = computed(() => this.auth.user()?.firstName ?? '');

  protected readonly hello = computed(() => {
    switch (this.feed()?.daypart) {
      case 'afternoon':
        return $localize`:@@home.afternoon:Good afternoon,`;
      case 'evening':
        return $localize`:@@home.evening:Good evening,`;
      default:
        return $localize`:@@home.morning:Good morning,`;
    }
  });

  protected readonly knooks = computed(() => this.feed()?.knooks ?? []);

  protected doneCount(steps: readonly FirstStep[]): number {
    return steps.filter((s) => s.done).length;
  }

  /** A-266: My Jobs counts as done once the learner opens it from here. */
  protected openStep(step: FirstStep): void {
    if (step.id === 'jobs' && !step.done) this.api.completeStep('jobs').subscribe({ error: () => undefined });
  }

  /** A-266: collect the first-moves bonus: burst into the XP counter, then the Lobby moves on. */
  protected async claim(from: HTMLElement): Promise<void> {
    if (this.claiming()) return;
    this.claiming.set(true);
    try {
      const { xp } = await firstValueFrom(this.api.claimFirstMoves());
      if (xp > 0) {
        this.xpFx.burst(xp, from, { size: 'lg', announce: false });
        this.toast.reward($localize`:@@home.bonusDone:First-moves bonus collected. Flying start!`, `+${xp} XP`);
        void this.quests.load().catch(() => undefined);
        this.feedback.moment('first-moves');
      }
      setTimeout(() => void this.load(), 1400);
    } catch {
      this.toast.show($localize`:@@home.bonusFail:Couldn’t collect your bonus. Give it another tap.`, {
        tone: 'error',
      });
    } finally {
      this.claiming.set(false);
    }
  }

  protected readonly resumeLabel = $localize`:@@home.resumeProgress:Module progress`;

  ngOnInit(): void {
    void this.load();
    void this.quests.load().catch(() => undefined);
  }

  protected async load(): Promise<void> {
    this.state.set('loading');
    try {
      const feed = await firstValueFrom(this.api.feed());
      this.feed.set(feed);
      this.badges.rewardsReady.set(feed.rewardsReady);
      this.badges.unread.set(feed.unreadNotifications);
      this.state.set('ready');
    } catch (e) {
      this.state.set(e instanceof ApiError && e.kind === 'offline' ? 'offline' : 'error');
    }
  }

  protected pathwayLabel(p: Pathway): string {
    return `${p.title}. ${p.blurb}`;
  }

  protected goToSlide(i: number): void {
    const el = this.rail()?.nativeElement;
    const card = el?.children.item(i) as HTMLElement | null;
    card?.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' });
    this.slide.set(i);
  }

  protected onRailScroll(): void {
    const el = this.rail()?.nativeElement;
    const first = el?.children.item(0) as HTMLElement | null;
    if (!el || !first) return;
    const step = first.offsetWidth + parseFloat(getComputedStyle(el).columnGap || '0');
    this.slide.set(Math.round(Math.abs(el.scrollLeft) / step));
  }
}

const START_HINT_KEY = 'sm_start_hint_seen';
const START_HINT_MS = 60_000;

/** Milliseconds the first-step hint has left; starts the clock on first sight. */
function startHintLeft(): number {
  try {
    const now = Date.now();
    const seen = Number(localStorage.getItem(START_HINT_KEY) ?? 0) || now;
    if (seen === now) localStorage.setItem(START_HINT_KEY, String(now));
    return Math.max(0, START_HINT_MS - (now - seen));
  } catch {
    return START_HINT_MS;
  }
}
