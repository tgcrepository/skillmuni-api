import { Routes } from '@angular/router';
import { requireSession } from '../../core/auth/auth.guard';

export const homeRoutes: Routes = [
  {
    path: 'home',
    title: $localize`:@@route.home:Home · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./home-page').then((m) => m.HomePage),
  },
  {
    path: 'knooks/:slug',
    title: $localize`:@@route.knook:Modules · Skillmuni`,
    canActivate: [requireSession],
    loadComponent: () => import('./knook-page').then((m) => m.KnookPage),
  },
];
