import { NgOptimizedImage } from '@angular/common';
import { Component, computed, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Knook } from '../../core/home/home.api';
import { Viewport } from '../../core/layout/viewport';
import { Icon } from '../../shared/ui/icon/icon';

let nextId = 0;

/** The Lobby shows at most this many tiles per knook; "Show more" opens the full list (A-255). */
export const KNOOK_PREVIEW = 6;

/**
 * Figma: Knook panel (Home v2 50:245) + Knook Tile (48:207) + See All Button (48:168).
 * Desktop: tiles wrap 3 per row. Tablet/mobile: one swipeable row. Every knook shows up to six
 * modules; "Show more" opens the knook's own screen with all of them, however many there are
 * (A-255, replaces the in-place See all / Show less toggle of A-171). Each tile is one link.
 */
@Component({
  selector: 'sm-knook-panel',
  imports: [Icon, NgOptimizedImage, RouterLink],
  template: `
    <div class="head">
      <img class="icon" [ngSrc]="knook().icon" alt="" width="40" height="40" />
      <h2 class="title" [id]="headingId">
        {{ knook().title }}
        <span class="count">{{ countLabel() }}</span>
      </h2>
      <a class="see-all" [routerLink]="['/knooks', knook().slug]" [attr.aria-label]="moreLabel()">
        <span aria-hidden="true" i18n="@@home.showMore">Show more</span>
        <sm-icon name="chevron-right" size="sm" />
      </a>
    </div>
    <ul class="tiles" [class.is-row]="!viewport.isDesktop()" [attr.aria-labelledby]="headingId">
      @for (m of preview(); track m.slug) {
        <li>
          <a class="tile" [routerLink]="m.link">
            <span class="media">
              <img [ngSrc]="m.art" alt="" width="112" height="112" />
            </span>
            <span class="label">{{ m.title }}</span>
          </a>
        </li>
      }
    </ul>
  `,
  styleUrl: './knook-panel.scss',
  host: { class: 'sm-knook-panel is-open' },
})
export class KnookPanel {
  protected readonly viewport = inject(Viewport);

  readonly knook = input.required<Knook>();

  private readonly uid = nextId++;
  protected readonly headingId = `sm-knook-${this.uid}`;

  protected readonly preview = computed(() => this.knook().modules.slice(0, KNOOK_PREVIEW));

  protected readonly countLabel = computed(() => {
    const n = this.knook().modules.length;
    return n === 1
      ? $localize`:@@home.module1:1 module`
      : $localize`:@@home.modules:${n}:count: modules`;
  });

  protected readonly moreLabel = computed(
    () => $localize`:@@home.showMoreAria:Show all modules in ${this.knook().title}:knook:`,
  );
}
