/// <reference types="@angular/localize" />

import { bootstrapApplication } from '@angular/platform-browser';
import { createAppConfig } from './app/app.config';
import { App } from './app/app';
import { environment } from './environments/environment';

async function start(): Promise<void> {
  // Dev mock backend runs in the page (no service worker to go idle); production talks to the real API.
  if (environment.useMockApi) await dropOldMockWorker();
  const backend = environment.useMockApi
    ? [(await import('./mocks/mock-backend.interceptor')).mockBackendInterceptor]
    : [];
  await bootstrapApplication(App, createAppConfig(backend));
}

/** Earlier builds mocked through a service worker; unregister it so it can't sit in front of requests. */
async function dropOldMockWorker(): Promise<void> {
  try {
    const regs = (await navigator.serviceWorker?.getRegistrations()) ?? [];
    await Promise.all(
      regs
        .filter((r) => r.active?.scriptURL.endsWith('/mockServiceWorker.js'))
        .map((r) => r.unregister()),
    );
  } catch {
    /* no service worker support */
  }
}

start().catch((err: unknown) => console.error(err));
