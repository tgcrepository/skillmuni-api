export const environment = {
  production: false,
  useMockApi: true,
  apiBaseUrl: '/api',
  /** Default market for this deployment (A-12). */
  market: 'IN' as 'IN' | 'ZA',
  /** Idle minutes before the session ends (SE1 copy: "after 30 minutes away"). */
  sessionIdleMinutes: 30,
  /** Google OAuth web client id (per tenant). Empty = dev test-account picker (A-253). */
  googleClientId: '',
  /** DigiLocker partner client id (India). Empty = test-mode consent simulator (A-272). */
  digilockerClientId: '',
};
