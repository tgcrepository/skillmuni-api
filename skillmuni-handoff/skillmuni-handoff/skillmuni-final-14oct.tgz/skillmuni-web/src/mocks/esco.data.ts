import type { EscoCategory, EscoSkill, EscoSkillType } from '../app/core/skills/esco.api';

import { SKILLS } from '../app/features/quests/data/skills';

/**
 * Mock of the ESCO skills pillar (A-245, A-285): the curated ESCO v1.2.1 sheet — the same 956
 * skills as the deck tabs — so search and browsing agree. The live server proxies ESCO's search
 * API, which returns real concept URIs; these mock URIs say "mock".
 */
export const ESCO_SKILLS: readonly EscoSkill[] = SKILLS.map((k) => ({
  uri: `http://data.europa.eu/esco/skill/mock-${k.id}`,
  label: k.name,
  type: (k.group.startsWith('T')
    ? 'transversal'
    : k.kind === 'knowledge'
      ? 'knowledge'
      : 'skill') as EscoSkillType,
  category: k.category as EscoCategory,
  escoCategory: k.escoCategory,
  alt: k.synonyms ?? [],
}));

const norm = (t: string) =>
  t
    .toLowerCase()
    .replace(/[^a-z0-9+#]+/g, ' ')
    .trim();

/** ESCO-like ranking: preferred-label prefix, then word prefix, then alternative labels. */
export function escoSearch(text: string, limit: number): { total: number; results: EscoSkill[] } {
  const q = norm(text);
  if (!q) return { total: 0, results: [] };
  const scored = ESCO_SKILLS.map((k) => {
    const label = norm(k.label);
    const alt = (k.alt ?? []).map(norm);
    const score = label.startsWith(q)
      ? 4
      : label.split(' ').some((w) => w.startsWith(q))
        ? 3
        : alt.some((a) => a === q)
          ? 2
          : alt.some((a) => a.startsWith(q) || a.split(' ').some((w) => w.startsWith(q)))
            ? 1
            : 0;
    return { k, score };
  })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score || a.k.label.localeCompare(b.k.label));
  return { total: scored.length, results: scored.slice(0, limit).map((x) => x.k) };
}
