import { profileProgress, questsWithGaps } from './profile-progress';
import { HttpResponse, delay, http } from 'msw';
import { isNewLearner } from './persona';
import type {
  AlertSettings,
  Application,
  ApplicationStatus,
  Facet,
  FilterState,
  Invitation,
  Job,
  ListResult,
  Suggestion,
  TimelineStep,
} from '../app/core/jobs/jobs.api';
import { JOBS, SECTORS, STATES, payIndex } from './jobs.data';

/**
 * My Jobs v2 (Figma 272:22353). Faceted search over a 128-job catalogue: every option carries the
 * count it would give with the other filters applied, Role depends on Sector, City on State, and
 * zero results suggest which filter to drop (J6). Page URL scenarios (`?jobs=`): locked (J8) ·
 * empty (J16–J19) · error (J21) · slow (J20). Saves, applications and replies live in sessionStorage.
 */

const KEY = 'sm_mock_jobs';
/** Mock "today" so relative dates match the Figma frames. */
const TODAY = '2 Oct';

interface State {
  saved: string[];
  unsaved: string[];
  applied: Record<string, Application>;
  invites: Record<string, Invitation['status']>;
  withdrawn: string[];
  alerts: AlertSettings;
}

function scenario(): string {
  return typeof location === 'undefined'
    ? ''
    : (new URLSearchParams(location.search).get('jobs') ?? '');
}

function load(): State {
  const base: State = {
    saved: [],
    unsaved: [],
    applied: {},
    invites: {},
    withdrawn: [],
    alerts: { on: true, frequency: 'daily', searches: ['Customer service · Pune'] },
  };
  try {
    const raw = sessionStorage.getItem(KEY);
    return raw ? { ...base, ...(JSON.parse(raw) as Partial<State>) } : base;
  } catch {
    return base;
  }
}

/** What the launchpad needs to know about My Jobs (A-306). */
export function jobsActivity(): { applied: number; saved: number; seen: boolean } {
  const s = load();
  const all = JOBS.map((j) => withState(j, s));
  let seen = false;
  try {
    seen = sessionStorage.getItem(SEEN_KEY) === '1';
  } catch {
    /* private mode */
  }
  return {
    applied: apps(s).filter((a) => a.status !== 'withdrawn').length,
    saved: all.filter((j) => j.saved).length,
    seen,
  };
}

/** Visiting My Jobs clears the "new matches" count on the launchpad. */
export function markJobsSeen(): void {
  try {
    sessionStorage.setItem(SEEN_KEY, '1');
  } catch {
    /* private mode */
  }
}

const SEEN_KEY = 'sm_mock_jobs_seen';

function save(s: State): void {
  try {
    sessionStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* private mode */
  }
}

function withState(j: Job, s: State): Job {
  const saved = (j.saved && !isNewLearner() && !s.unsaved.includes(j.id)) || s.saved.includes(j.id);
  const app =
    Object.values(s.applied).find((a) => a.job.id === j.id) ??
    seededApps().find((a) => a.job.id === j.id);
  return {
    ...j,
    saved,
    savedDays: saved ? (j.savedDays ?? 0) : null,
    appliedOn: app && app.status !== 'withdrawn' ? app.appliedOn : null,
  };
}

const byId = (id: string) => JOBS.find((j) => j.id === id);

/* ---------- Invitations ---------- */

function seededInvites(): Invitation[] {
  if (isNewLearner()) return [];
  const j = (id: string) => byId(id) as Job;
  return [
    {
      id: 'inv-1',
      job: j('job-1'),
      recruiter: { name: 'Priya S.', initials: 'PS', title: 'Recruiter, Teleperformance' },
      type: 'apply',
      interviewAt: null,
      message:
        'Hi Yash, your profile is a great fit for our Customer Service team in Pune. We’d love you to apply before 8 Oct.',
      respondBy: '8 Oct',
      daysLeft: 6,
      status: 'new',
    },
    {
      id: 'inv-2',
      job: j('job-2'),
      recruiter: { name: 'Rahul K.', initials: 'RK', title: 'Recruiter, HDFC Life' },
      type: 'interview',
      interviewAt: '2026-10-10T11:00:00+05:30',
      message:
        'Hi Yash, thanks for your interest in sales. We’d like to meet you for a 30-minute video interview on 10 Oct at 11:00 AM. If that doesn’t work, suggest another time.',
      respondBy: '6 Oct',
      daysLeft: 4,
      status: 'new',
    },
    {
      id: 'inv-3',
      job: j('job-3'),
      recruiter: { name: 'Anita M.', initials: 'AM', title: 'Talent partner, Concentrix' },
      type: 'apply',
      interviewAt: null,
      message:
        'Hi Yash, our Technical Support learnership starts in November. You’d be a good fit.',
      respondBy: '12 Oct',
      daysLeft: 10,
      status: 'accepted',
    },
    {
      id: 'inv-4',
      job: j('job-6'),
      recruiter: { name: 'Kavya R.', initials: 'KR', title: 'HR, Taj Hotels' },
      type: 'apply',
      interviewAt: null,
      message: 'Hi Yash, we have front desk openings in Goa this season.',
      respondBy: '28 Sep',
      daysLeft: 0,
      status: 'expired',
    },
  ];
}

/* ---------- Applications ---------- */

const STEPS = ['Applied', 'Viewed by recruiter', 'Shortlisted', 'Interview', 'Offer'];

function timeline(status: ApplicationStatus, dates: string[]): TimelineStep[] {
  if (status === 'withdrawn')
    return [
      { label: 'Applied', date: dates[0] ?? null, state: 'done' },
      { label: 'Withdrawn', date: dates[1] ?? null, state: 'failed' },
    ];
  if (status === 'not-selected')
    return [
      { label: 'Applied', date: dates[0] ?? null, state: 'done' },
      { label: 'Viewed by recruiter', date: dates[1] ?? null, state: 'done' },
      { label: 'Not selected', date: dates[2] ?? null, state: 'failed' },
    ];
  const at = { applied: 0, viewed: 1, shortlisted: 2, interview: 3, offer: 4 }[status];
  return STEPS.map((label, i) => ({
    label,
    date: dates[i] ?? null,
    state: i < at ? 'done' : i === at ? (i === 3 ? 'current' : 'done') : 'todo',
  }));
}

function seededApps(): Application[] {
  if (isNewLearner()) return [];
  const j = (id: string) => byId(id) as Job;
  const base = { cv: 'Yash_Pohare_CV_2026.pdf', answers: [], similar: 6 };
  return [
    {
      ...base,
      id: 'app-1',
      job: j('job-1'),
      appliedOn: '24 Sep',
      updated: 'Updated today',
      status: 'interview',
      timeline: timeline('interview', ['24 Sep', '26 Sep', '28 Sep', '12 Oct · 11:00 AM']),
      interview: {
        at: '2026-10-12T11:00:00+05:30',
        mode: 'Video interview · 30 min',
        detail: 'Sat, 12 Oct · 11:00 AM IST · Google Meet link arrives 1 day before',
      },
      answers: [
        { q: 'Are you comfortable with rotational shifts, including nights?', a: 'Yes' },
        { q: 'When can you join?', a: 'Immediately' },
      ],
    },
    {
      ...base,
      id: 'app-2',
      job: j('job-2'),
      appliedOn: '26 Sep',
      updated: 'Updated 2 days ago',
      status: 'shortlisted',
      timeline: timeline('shortlisted', ['26 Sep', '27 Sep', '30 Sep']),
      interview: null,
    },
    {
      ...base,
      id: 'app-3',
      job: j('job-3'),
      appliedOn: '28 Sep',
      updated: 'Viewed by recruiter',
      status: 'viewed',
      timeline: timeline('viewed', ['28 Sep', '29 Sep']),
      interview: null,
    },
    {
      ...base,
      id: 'app-4',
      job: j('job-4'),
      appliedOn: '10 Sep',
      updated: 'Closed 20 Sep',
      status: 'not-selected',
      timeline: timeline('not-selected', ['10 Sep', '12 Sep', '20 Sep']),
      interview: null,
    },
    {
      ...base,
      id: 'app-5',
      job: j('job-5'),
      appliedOn: '2 Sep',
      updated: 'You withdrew on 8 Sep',
      status: 'withdrawn',
      timeline: timeline('withdrawn', ['2 Sep', '8 Sep']),
      interview: null,
    },
  ];
}

function apps(s: State): Application[] {
  const all = [...Object.values(s.applied).reverse(), ...seededApps()];
  return all.map((a) =>
    s.withdrawn.includes(a.id) && a.status !== 'withdrawn'
      ? {
          ...a,
          status: 'withdrawn' as const,
          updated: `You withdrew on ${TODAY}`,
          interview: null,
          timeline: timeline('withdrawn', [a.appliedOn, TODAY]),
        }
      : a,
  );
}

function invites(s: State): Invitation[] {
  return seededInvites().map((i) => ({ ...i, status: s.invites[i.id] ?? i.status }));
}

/* ---------- Faceted filtering ---------- */

const LABELS: Record<string, Record<string, string>> = {
  workMode: { onsite: 'On-site', hybrid: 'Hybrid', remote: 'Remote' },
  jobType: {
    'full-time': 'Full-time',
    learnership: 'Learnership / Internship',
    'part-time': 'Part-time',
    contract: 'Contract',
  },
  pay: { '1': '₹1 LPA+', '2': '₹2 LPA+', '3': '₹3 LPA+', '5': '₹5 LPA+' },
  posted: { '1': 'Past 24 hours', '7': 'Past week', '30': 'Past month' },
  match: { '90': '90%+ match', '80': '80%+ match', '70': '70%+ match', '60': '60%+ match' },
  jobStatus: { open: 'Open', closing: 'Closing soon', closed: 'Closed' },
  remote: { yes: 'Include remote' },
  status: {
    new: 'New',
    accepted: 'Accepted',
    declined: 'Declined',
    expired: 'Expired',
    applied: 'Applied',
    viewed: 'Under review',
    shortlisted: 'Shortlisted',
    interview: 'Interview',
    offer: 'Offer',
    'not-selected': 'Not selected',
    withdrawn: 'Withdrawn',
  },
  inviteType: { apply: 'Invited to apply', interview: 'Interview invite' },
  dateApplied: { '7': 'Past week', '30': 'Past month', '90': 'Past 3 months' },
};

type Getter<T> = (item: T, key: string) => readonly string[] | null;

function jobValues(j: Job, key: string): readonly string[] | null {
  switch (key) {
    case 'sector':
      return [j.sector];
    case 'role':
      return [j.role];
    case 'state':
      return j.state ? [j.state] : [];
    case 'city':
      return j.workMode === 'remote' ? [] : [j.city];
    case 'workMode':
      return [j.workMode];
    case 'jobType':
      return [j.jobType];
    case 'pay':
      return ['1', '2', '3', '5'].filter((p) => (payIndex.get(j.id) ?? 0) >= Number(p));
    case 'posted':
      return ['1', '7', '30'].filter((d) => j.postedDays <= Number(d));
    case 'match':
      return ['60', '70', '80', '90'].filter((m) => (j.match?.percent ?? 0) >= Number(m));
    case 'jobStatus':
      return [j.closed ? 'closed' : j.closingInDays !== null ? 'closing' : 'open'];
    default:
      return null;
  }
}

/** City + "include remote" act together; everything else is AND across keys, OR within one. */
function passes<T>(item: T, f: FilterState, get: Getter<T>, skip?: string): boolean {
  for (const [key, want] of Object.entries(f)) {
    if (!want.length || key === skip || key === 'remote') continue;
    const have = get(item, key);
    if (have === null) continue;
    if (key === 'city' || key === 'state') {
      const remoteOk =
        f['remote']?.includes('yes') && (get(item, 'workMode') ?? []).includes('remote');
      if (remoteOk) continue;
    }
    if (!want.some((w) => have.includes(w))) return false;
  }
  return true;
}

function facet<T>(
  items: readonly T[],
  f: FilterState,
  get: Getter<T>,
  key: string,
  ids: readonly string[],
  label: (id: string) => string = (id) => LABELS[key]?.[id] ?? id,
): Facet {
  const pool = items.filter((i) => passes(i, f, get, key));
  return {
    key,
    options: ids.map((id) => ({
      id,
      label: label(id),
      count: pool.filter((i) => (get(i, key) ?? []).includes(id)).length,
    })),
  };
}

function suggestions<T>(items: readonly T[], f: FilterState, get: Getter<T>): Suggestion[] {
  const out: Suggestion[] = [];
  for (const [key, vals] of Object.entries(f)) {
    for (const id of vals) {
      const next = { ...f, [key]: vals.filter((v) => v !== id) };
      const count = items.filter((i) => passes(i, next, get)).length;
      if (count) out.push({ key, id, label: LABELS[key]?.[id] ?? id, count });
    }
  }
  return out.sort((a, b) => a.count - b.count).slice(0, 3);
}

function text<T>(items: readonly T[], q: string, place: string, job: (t: T) => Job): T[] {
  const ql = q.trim().toLowerCase();
  const pl = place.trim().toLowerCase();
  return items.filter((t) => {
    const j = job(t);
    const hay = `${j.title} ${j.company} ${j.skills.join(' ')} ${j.role} ${j.sector}`.toLowerCase();
    const where = `${j.city} ${j.state} ${j.workMode === 'remote' ? 'remote' : ''}`.toLowerCase();
    return (
      (!ql || hay.includes(ql)) &&
      (!pl || pl.split(/\s+and\s+|,\s*/).some((p) => where.includes(p.trim())))
    );
  });
}

function parse(url: URL): {
  q: string;
  place: string;
  sort: string;
  limit: number;
  filters: FilterState;
} {
  const sp = url.searchParams;
  let filters: FilterState = {};
  try {
    filters = JSON.parse(sp.get('filters') ?? '{}') as FilterState;
  } catch {
    /* ignore */
  }
  return {
    q: sp.get('q') ?? '',
    place: sp.get('place') ?? '',
    sort: sp.get('sort') ?? '',
    limit: sp.has('limit') ? Number(sp.get('limit')) : 20,
    filters,
  };
}

function jobFacets(items: readonly Job[], f: FilterState, tab: string): Facet[] {
  const sectors = Object.keys(SECTORS);
  const chosen = f['sector'] ?? [];
  const roles = [...new Set((chosen.length ? chosen : sectors).flatMap((s) => SECTORS[s] ?? []))];
  const state = f['state']?.[0];
  const cities = state ? (STATES[state] ?? []) : Object.values(STATES).flat();
  const remotePool = items.filter(
    (j) => passes(j, f, jobValues, 'city') && j.workMode === 'remote',
  ).length;
  const all: Facet[] = [
    facet(items, f, jobValues, 'sector', sectors),
    facet(items, f, jobValues, 'role', roles),
    facet(items, f, jobValues, 'state', Object.keys(STATES)),
    facet(items, f, jobValues, 'city', cities),
    { key: 'remote', options: [{ id: 'yes', label: 'Include remote jobs', count: remotePool }] },
    facet(items, f, jobValues, 'workMode', ['onsite', 'hybrid', 'remote']),
    facet(items, f, jobValues, 'jobType', ['full-time', 'learnership', 'part-time', 'contract']),
    facet(items, f, jobValues, 'pay', ['1', '2', '3', '5']),
    facet(items, f, jobValues, 'posted', ['1', '7', '30']),
  ];
  if (tab === 'matching')
    all.unshift(facet(items, f, jobValues, 'match', ['90', '80', '70', '60']));
  if (tab === 'bookmarked')
    all.unshift(facet(items, f, jobValues, 'jobStatus', ['open', 'closing', 'closed']));
  return all;
}

function sortJobs(items: Job[], sort: string): Job[] {
  const by: Record<string, (a: Job, b: Job) => number> = {
    relevant: (a, b) =>
      (b.match?.percent ?? 0) - (a.match?.percent ?? 0) ||
      Number(b.isNew) - Number(a.isNew) ||
      a.postedDays - b.postedDays,
    newest: (a, b) => a.postedDays - b.postedDays,
    salary: (a, b) => (payIndex.get(b.id) ?? 0) - (payIndex.get(a.id) ?? 0),
    match: (a, b) => (b.match?.percent ?? 0) - (a.match?.percent ?? 0),
    saved: (a, b) => (a.savedDays ?? 0) - (b.savedDays ?? 0),
    closing: (a, b) => (a.closingInDays ?? 99) - (b.closingInDays ?? 99),
  };
  return [...items].sort(by[sort] ?? by['relevant']);
}

function list<T>(
  items: T[],
  limit: number,
  facets: Facet[],
  sugg: Suggestion[],
  note: string | null,
): ListResult<T> {
  return {
    items: items.slice(0, limit),
    total: items.length,
    facets,
    suggestions: items.length ? [] : sugg,
    note,
  };
}

const fail = () => (scenario() === 'error' ? new HttpResponse(null, { status: 503 }) : null);
const wait = () => delay(scenario() === 'slow' ? 4000 : 350);

function summary(s: State) {
  const empty = scenario() === 'empty';
  const inv = invites(s);
  const all = JOBS.map((j) => withState(j, s));
  return {
    available: JOBS.length,
    matching: empty ? 0 : all.filter((j) => (j.match?.percent ?? 0) >= 60).length,
    invitations: empty ? 0 : inv.length,
    invitationsNew: empty ? 0 : inv.filter((i) => i.status === 'new').length,
    bookmarked: empty ? 0 : all.filter((j) => j.saved).length,
    applied: empty ? 0 : apps(s).length,
    profilePercent: scenario() === 'locked' ? 45 : profileProgress().percent,
    unlockAt: 0,
    missing: questsWithGaps(),
    minutesToUnlock: 5,
    defaultPlace: 'Pune and Remote',
  };
}

export const jobsHandlers = [
  http.get('/api/jobs/summary', async () => {
    await delay(200);
    markJobsSeen();
    return fail() ?? HttpResponse.json(summary(load()));
  }),

  http.get('/api/jobs/list/:tab', async ({ params, request }) => {
    await wait();
    const err = fail();
    if (err) return err;
    const tab = String(params['tab']);
    const s = load();
    const q = parse(new URL(request.url));
    let pool = JOBS.map((j) => withState(j, s));
    if (scenario() === 'empty' && tab !== 'available') pool = [];
    if (tab === 'matching') pool = pool.filter((j) => (j.match?.percent ?? 0) >= 60);
    if (tab === 'bookmarked') pool = pool.filter((j) => j.saved);
    // The place box is a shortcut for Location: once State/City is picked, the filter wins.
    const byLocation = !!(q.filters['state']?.length || q.filters['city']?.length);
    pool = text(pool, q.q, byLocation ? '' : q.place, (j) => j);
    const hits = sortJobs(
      pool.filter((j) => passes(j, q.filters, jobValues)),
      q.sort || (tab === 'matching' ? 'match' : tab === 'bookmarked' ? 'saved' : 'relevant'),
    );
    const closing = hits.filter((j) => j.closingInDays !== null).length;
    const note =
      tab === 'bookmarked'
        ? `${hits.length} saved job${hits.length === 1 ? '' : 's'}${closing ? ` · ${closing} closing soon` : ''}`
        : null;
    return HttpResponse.json(
      list(
        hits,
        q.limit,
        jobFacets(pool, q.filters, tab),
        suggestions(pool, q.filters, jobValues),
        note,
      ),
    );
  }),

  http.get('/api/jobs/invitations', async ({ request }) => {
    await wait();
    const err = fail();
    if (err) return err;
    const s = load();
    const q = parse(new URL(request.url));
    const get: Getter<Invitation> = (i, key) =>
      key === 'status'
        ? [i.status]
        : key === 'inviteType'
          ? [i.type]
          : key === 'company'
            ? [i.job.company]
            : null;
    let pool = scenario() === 'empty' ? [] : invites(s);
    pool = text(pool, q.q, '', (i) => i.job);
    const hits = pool
      .filter((i) => passes(i, q.filters, get))
      .sort((a, b) =>
        q.sort === 'newest'
          ? b.id.localeCompare(a.id)
          : (a.status === 'new' ? 0 : 1) - (b.status === 'new' ? 0 : 1) || a.daysLeft - b.daysLeft,
      );
    const companies = [...new Set(pool.map((i) => i.job.company))];
    const facets = [
      facet(pool, q.filters, get, 'status', ['new', 'accepted', 'declined', 'expired']),
      facet(pool, q.filters, get, 'inviteType', ['apply', 'interview']),
      facet(pool, q.filters, get, 'company', companies),
    ];
    const fresh = hits.filter((i) => i.status === 'new').length;
    return HttpResponse.json(
      list(
        hits,
        q.limit,
        facets,
        suggestions(pool, q.filters, get),
        `${fresh} new · ${hits.length} total`,
      ),
    );
  }),

  http.get('/api/jobs/applications', async ({ request }) => {
    await wait();
    const err = fail();
    if (err) return err;
    const s = load();
    const q = parse(new URL(request.url));
    const age: Record<string, number> = {
      '24 Sep': 8,
      '26 Sep': 6,
      '28 Sep': 4,
      '10 Sep': 22,
      '2 Sep': 30,
    };
    const get: Getter<Application> = (a, key) =>
      key === 'status'
        ? [a.status]
        : key === 'sector'
          ? [a.job.sector]
          : key === 'company'
            ? [a.job.company]
            : key === 'dateApplied'
              ? ['7', '30', '90'].filter((d) => (age[a.appliedOn] ?? 0) <= Number(d))
              : null;
    let pool = scenario() === 'empty' ? [] : apps(s);
    pool = text(pool, q.q, '', (a) => a.job);
    const hits = pool.filter((a) => passes(a, q.filters, get));
    const facets = [
      facet(pool, q.filters, get, 'status', [
        'applied',
        'viewed',
        'shortlisted',
        'interview',
        'offer',
        'not-selected',
        'withdrawn',
      ]),
      facet(pool, q.filters, get, 'dateApplied', ['7', '30', '90']),
      facet(pool, q.filters, get, 'sector', [...new Set(pool.map((a) => a.job.sector))]),
      facet(pool, q.filters, get, 'company', [...new Set(pool.map((a) => a.job.company))]),
    ];
    const upcoming = hits.filter((a) => a.status === 'interview').length;
    const note = `${hits.length} application${hits.length === 1 ? '' : 's'}${upcoming ? ` · ${upcoming} interview coming up` : ''}`;
    return HttpResponse.json(list(hits, q.limit, facets, suggestions(pool, q.filters, get), note));
  }),

  http.get('/api/jobs/job/:id', async ({ params }) => {
    await delay(200);
    const j = byId(String(params['id']));
    return j ? HttpResponse.json(withState(j, load())) : new HttpResponse(null, { status: 404 });
  }),

  http.get('/api/jobs/invitations/:id', async ({ params }) => {
    await delay(200);
    const i = invites(load()).find((x) => x.id === params['id']);
    return i ? HttpResponse.json(i) : new HttpResponse(null, { status: 404 });
  }),

  http.get('/api/jobs/applications/:id', async ({ params }) => {
    await delay(200);
    const a = apps(load()).find((x) => x.id === params['id']);
    return a ? HttpResponse.json(a) : new HttpResponse(null, { status: 404 });
  }),

  http.put('/api/jobs/job/:id/saved', async ({ params, request }) => {
    await delay(200);
    const id = String(params['id']);
    const { saved } = (await request.json()) as { saved: boolean };
    const s = load();
    s.saved = s.saved.filter((x) => x !== id);
    s.unsaved = s.unsaved.filter((x) => x !== id);
    (saved ? s.saved : s.unsaved).push(id);
    save(s);
    const j = byId(id);
    return j ? HttpResponse.json(withState(j, s)) : new HttpResponse(null, { status: 404 });
  }),

  http.get('/api/jobs/job/:id/apply', async () => {
    await delay(250);
    return HttpResponse.json({
      name: 'Yash Pohare',
      contact: '+91 98•••• 0697 · y••••@gmail.com · Pune, Maharashtra',
      cvs: [
        { id: 'cv-1', name: 'Yash_Pohare_CV_2026.pdf', meta: 'Updated 3 Sep · 212 KB' },
        { id: 'cv-2', name: 'Yash_CV_Sales.pdf', meta: 'Updated 12 Aug · 188 KB' },
      ],
      questions: [
        {
          id: 'q1',
          text: 'Are you comfortable with rotational shifts, including nights?',
          kind: 'yes-no',
        },
        { id: 'q2', text: 'When can you join?', kind: 'text' },
      ],
    });
  }),

  http.post('/api/jobs/cv', async ({ request }) => {
    await delay(700);
    const f = (await request.formData()).get('file');
    const name = f instanceof File ? f.name : 'My_CV.pdf';
    const kb = f instanceof File ? Math.max(1, Math.round(f.size / 1024)) : 120;
    return HttpResponse.json({ id: `cv-${Date.now()}`, name, meta: `Uploaded today · ${kb} KB` });
  }),

  http.post('/api/jobs/job/:id/apply', async ({ params, request }) => {
    await delay(700);
    const id = String(params['id']);
    const j = byId(id);
    if (!j) return new HttpResponse(null, { status: 404 });
    const body = (await request.json()) as {
      cvId: string;
      answers: Record<string, string>;
      invitationId?: string;
    };
    const s = load();
    const app: Application = {
      id: `app-new-${id}`,
      job: { ...j, appliedOn: TODAY },
      appliedOn: TODAY,
      updated: 'Updated today',
      cv: body.cvId === 'cv-2' ? 'Yash_CV_Sales.pdf' : 'Yash_Pohare_CV_2026.pdf',
      status: 'applied',
      timeline: timeline('applied', [TODAY]),
      interview: null,
      answers: Object.values(body.answers).map((a, i) => ({
        q:
          i === 0
            ? 'Are you comfortable with rotational shifts, including nights?'
            : 'When can you join?',
        a,
      })),
      similar: 6,
    };
    s.applied[app.id] = app;
    if (body.invitationId) s.invites[body.invitationId] = 'accepted';
    save(s);
    return HttpResponse.json(app);
  }),

  http.post('/api/jobs/invitations/:id/:action', async ({ params }) => {
    await delay(400);
    const id = String(params['id']);
    const action = String(params['action']);
    const s = load();
    if (action === 'accept') s.invites[id] = 'accepted';
    if (action === 'decline') s.invites[id] = 'declined';
    save(s);
    const i = invites(s).find((x) => x.id === id);
    return i ? HttpResponse.json(i) : new HttpResponse(null, { status: 404 });
  }),

  http.post('/api/jobs/applications/:id/withdraw', async ({ params }) => {
    await delay(400);
    const id = String(params['id']);
    const s = load();
    if (!s.withdrawn.includes(id)) s.withdrawn.push(id);
    save(s);
    const a = apps(s).find((x) => x.id === id);
    return a ? HttpResponse.json(a) : new HttpResponse(null, { status: 404 });
  }),

  http.get('/api/jobs/alerts', async () => {
    await delay(200);
    return HttpResponse.json(load().alerts);
  }),

  http.put('/api/jobs/alerts', async ({ request }) => {
    await delay(250);
    const s = load();
    s.alerts = (await request.json()) as AlertSettings;
    save(s);
    return HttpResponse.json(s.alerts);
  }),
];

/**
 * Hire Fest H13 "Got an offer?" → My Jobs → Applied (handoff: offers sync). Adds an Offer
 * application for that employer, using a catalogue job when one matches.
 */
export function recordFestOffer(company: string, role: string): void {
  const s = load();
  const j = JOBS.find((x) => x.company === company) ?? JOBS[0];
  if (!j) return;
  const id = `app-fest-${company.toLowerCase().replace(/\W+/g, '-')}`;
  if (s.applied[id]) return;
  s.applied[id] = {
    id,
    job: { ...j, title: role, appliedOn: TODAY },
    appliedOn: '8 Nov',
    updated: 'Offer from Hire Fest',
    cv: 'Yash_Pohare_CV.pdf',
    status: 'offer',
    timeline: timeline('offer', ['8 Nov', '8 Nov', '8 Nov', '8 Nov', TODAY]),
    interview: null,
    answers: [],
    similar: 6,
  };
  save(s);
}
