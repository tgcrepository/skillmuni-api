import { HttpResponse, delay, http } from 'msw';

/** Session + draft autosave. Drafts are kept in memory for the mock session. */
const drafts = new Map<string, unknown>();

export const coreHandlers = [
  http.put('/api/drafts/:key', async ({ params, request }) => {
    await delay(200);
    drafts.set(String(params['key']), await request.json());
    return new HttpResponse(null, { status: 204 });
  }),
  http.get('/api/drafts/:key', ({ params }) => {
    const draft = drafts.get(String(params['key']));
    return draft ? HttpResponse.json(draft) : new HttpResponse(null, { status: 404 });
  }),
];
