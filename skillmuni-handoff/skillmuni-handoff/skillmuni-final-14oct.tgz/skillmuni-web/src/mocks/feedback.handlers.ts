import { HttpResponse, delay, http } from 'msw';
import { creditXp } from './xp-ledger';
import { syncLevel } from './quest.handlers';

/** A-274: +5 XP for feedback, at most once every 30 days. */
const KEY = 'sm_mock_feedback';
const XP = 5;
const MONTH = 30 * 86_400_000;

export const feedbackHandlers = [
  http.post('/api/me/feedback', async () => {
    await delay(400);
    let last = 0;
    try {
      last = Number(sessionStorage.getItem(KEY) ?? 0);
    } catch {
      /* private mode */
    }
    const now = Date.now();
    const xp = now - last >= MONTH ? XP : 0;
    if (xp) {
      creditXp(xp);
      syncLevel();
      try {
        sessionStorage.setItem(KEY, String(now));
      } catch {
        /* private mode */
      }
    }
    return HttpResponse.json({ xp });
  }),
];
