import { HttpResponse, delay, http } from 'msw';
import { learnerName, onPersona, persona } from './persona';
import { QUEST_XP, STEP_XP, levelFor } from '../app/core/quests/levels';
import { totalXp } from './xp-ledger';

/** Mock quest progress for the signed-in learner (in memory, resets on reload of the service worker). */
const SLUGS = [
  'who-dis',
  'hit-me-up',
  'big-brain-stuff',
  'your-flex-era',
  'work-lore',
  'pick-your-arc',
  'drop-the-receipts',
  'vibe-check',
];
export const mockProgress = {
  completed: 0,
  partsDone: 0,
  xp: 0,
  badges: 0,
  level: 1,
  rank: 'Rookie',
  target: 400,
};
const answers: Record<string, Record<string, unknown>> = {
  'who-dis': { firstName: 'Yash' },
};

/** Survives a page refresh in this tab, like a real backend would (A-157). */
const KEY = 'sm_mock_quests';
try {
  const saved = JSON.parse(sessionStorage.getItem(KEY) ?? 'null') as {
    progress: typeof mockProgress;
    answers: typeof answers;
  } | null;
  if (saved) {
    Object.assign(mockProgress, saved.progress);
    Object.assign(answers, saved.answers);
  }
} catch {
  /* private mode or not a browser */
}
export function persistQuests(): void {
  try {
    sessionStorage.setItem(KEY, JSON.stringify({ progress: mockProgress, answers }));
  } catch {
    /* private mode: this page only */
  }
}

/**
 * A-286: the sample returning learner's answers, matching their Job Profile, so editing a section
 * from there opens it already filled in (the real backend returns the learner's own answers).
 */
const SAMPLE_ANSWERS: Readonly<Record<string, Record<string, unknown>>> = {
  'hit-me-up': {
    phone: '9876540697',
    phoneVerified: true,
    email: 'yash.pohare@thegamification.com',
    whatsapp: true,
    backupSkipped: true,
    postal: '411038',
    region: 'Maharashtra',
    district: 'Pune',
    city: 'Pune',
    area: 'Kothrud',
    line1: 'Flat 12, Shree Apartments, Paud Road',
    unit: '',
    landmark: 'Near Vanaz metro',
  },
  'big-brain-stuff': {
    level: 'graduate',
    status: 'completed',
    degree: 'B.Com',
    branch: 'Accounting & Finance',
    institute: 'Savitribai Phule Pune University',
    board: '',
    year: '2024',
    studyYear: '',
    scoreKind: 'cgpa',
    score: '7.4',
    timelineSkipped: true,
  },
  'your-flex-era': {
    skills: [
      {
        id: 'customer-service',
        name: 'Customer service',
        category: 'people',
        level: 3,
        source: 'cv',
      },
      {
        id: 'microsoft-excel',
        name: 'Microsoft Excel',
        category: 'business',
        level: 3,
        source: 'cv',
      },
      {
        id: 'verbal-communication',
        name: 'Verbal communication',
        category: 'people',
        level: 3,
        source: 'cv',
      },
      { id: 'data-entry', name: 'Data entry', category: 'data', level: 3, source: 'cv' },
      { id: 'zoho-crm', name: 'Zoho CRM', category: 'business', level: 2, source: 'cv' },
      { id: 'cold-calling', name: 'Cold calling', category: 'business', level: 2, source: 'cv' },
    ],
    languages: [
      {
        name: 'Hindi',
        fluency: 'native',
        speak: true,
        read: true,
        write: true,
        motherTongue: true,
        fromCv: false,
      },
      {
        name: 'English',
        fluency: 'fluent',
        speak: true,
        read: true,
        write: true,
        motherTongue: false,
        fromCv: true,
      },
      {
        name: 'Marathi',
        fluency: 'native',
        speak: true,
        read: true,
        write: false,
        motherTongue: false,
        fromCv: true,
      },
    ],
    trophiesSkipped: true,
  },
  'pick-your-arc': {
    lookingFor: ['full_time', 'internship'],
    roles: ['Customer support executive', 'BPO · voice process', 'Data entry operator'],
    where: ['near', 'remote'],
    shifts: ['day', 'rotational'],
    notice: 'immediate',
    salary: '3-4.5',
  },
};

/** Read-only view of a quest's saved answers for other mocks (job profile status, A-262). */
export function questAnswers(slug: string): Readonly<Record<string, unknown>> {
  return answers[slug] ?? {};
}

/** Lets other mocks pre-fill a quest (e.g. the CV parser fills Quest 4's deck and passport). */
export function seedAnswers(slug: string, values: Record<string, unknown>): void {
  answers[slug] = { ...values, ...answers[slug] };
  persistQuests();
}

/** Rookie 0 · Pathfinder 400 · Trailblazer 800 · Legend 1200 (mock rank ladder). */
export function syncLevel(): void {
  const l = levelFor(mockProgress.xp);
  Object.assign(mockProgress, { level: l.level, rank: l.rank, target: l.target });
  persistQuests();
}

/**
 * A-232: a new account starts the 8 quests from zero with its registered name. Logging back in
 * keeps the returning learner's own quest progress (they may have saved & exited mid-way, R1);
 * only a switch away from a new account restores the sample learner.
 */
const INITIAL = {
  completed: 0,
  partsDone: 0,
  xp: 0,
  badges: 0,
  level: 1,
  rank: 'Rookie',
  target: 400,
};
let last: string = persona();
onPersona((p) => {
  if (p === 'existing' && last !== 'new') {
    last = p;
    return;
  }
  last = p;
  for (const k of Object.keys(answers)) Reflect.deleteProperty(answers, k);
  Object.assign(mockProgress, INITIAL);
  answers['who-dis'] = { firstName: p === 'new' ? learnerName().first : 'Yash' };
  persistQuests();
});

export const questHandlers = [
  http.get('/api/me/progress', async () => {
    await delay(250);
    // One XP ledger: the learner's total (quests + assessment + learning + extras), not just quest XP.
    const xp = totalXp();
    const l = levelFor(xp);
    return HttpResponse.json({ ...mockProgress, xp, level: l.level, rank: l.rank, target: l.target });
  }),

  http.get('/api/me/quests/:slug/answers', async ({ params }) => {
    await delay(200);
    const slug = String(params['slug']);
    // Only when a section is opened for editing from the platform (the quests themselves start blank).
    const editing = typeof location !== 'undefined' && /[?&]edit=1\b/.test(location.search);
    const sample = editing && persona() === 'existing' ? (SAMPLE_ANSWERS[slug] ?? {}) : {};
    return HttpResponse.json({ ...sample, ...answers[slug] });
  }),

  http.put('/api/me/quests/:slug/parts/:part', async ({ params, request }) => {
    await delay(250);
    const slug = String(params['slug']);
    const { values, done, xp, bonusXp } = (await request.json()) as {
      values: Record<string, unknown>;
      done: boolean;
      xp?: boolean;
      bonusXp?: number;
    };
    const bonusBefore = Number(answers[slug]?.['bonusXp'] ?? 0);
    answers[slug] = { ...answers[slug], ...values };
    if (bonusXp !== undefined) void bonusBefore; // A-168: extras earn no XP
    if (done) {
      const part = Number(params['part']);
      // A-249: +20 the first time a step of the quest in progress is done (skips pass xp: false).
      const current = SLUGS.indexOf(slug) + 1 === mockProgress.completed + 1;
      if (current && xp !== false && part > mockProgress.partsDone) {
        mockProgress.xp += STEP_XP;
        syncLevel();
      }
      if (current) mockProgress.partsDone = Math.max(mockProgress.partsDone, part);
    }
    persistQuests();
    return new HttpResponse(null, { status: 204 });
  }),

  http.post('/api/me/quests/:slug/complete', async ({ params }) => {
    await delay(400);
    const index = SLUGS.indexOf(String(params['slug']));
    const first = index + 1 > mockProgress.completed;
    if (first) {
      mockProgress.completed = index + 1;
      mockProgress.badges += 1;
      mockProgress.xp += QUEST_XP;
      mockProgress.partsDone = 0;
    }
    syncLevel();
    const xp = totalXp();
    const l = levelFor(xp);
    return HttpResponse.json({
      xpEarned: first ? QUEST_XP : 0,
      progress: { ...mockProgress, xp, level: l.level, rank: l.rank, target: l.target },
    });
  }),
];
