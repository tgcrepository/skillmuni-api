import { HttpResponse, delay, http } from 'msw';
import { seedAnswers } from './quest.handlers';

/**
 * Mock CV parser. Name the file to trigger an outcome:
 * "locked" → S3 · "blurry" (image) → S4 · "afrikaans" → S5 · "stuck" → S6 · "nowork" → S7 · "little" → S8 ·
 * "taken" → S9. Anything else parses cleanly in ~6 s.
 */
const jobs = new Map<string, { name: string; started: number }>();
const STEP_MS = 1000;
const QUIPS = [
  'Opening your file…',
  'Got your number. Literally.',
  'Matric (NSC)? Respect.',
  'Ooh, a call-centre internship? Love that for you.',
  'Building your timeline…',
  'Skipping the private stuff, as promised.',
];

function outcomeFor(name: string): { outcome?: string; detail?: string; failed?: boolean } {
  const n = name.toLowerCase();
  if (n.includes('locked')) return { outcome: 'locked-pdf', failed: true };
  if (n.includes('blurry')) return { outcome: 'blurry-photo', failed: true };
  if (n.includes('stuck')) return { outcome: 'parse-failed', detail: 'CV-2291', failed: true };
  if (n.includes('afrikaans')) return { outcome: 'other-language', detail: 'Afrikaans' };
  if (n.includes('nowork')) return { outcome: 'no-work-history' };
  if (n.includes('little')) return { outcome: 'little-found', detail: '4' };
  if (n.includes('taken')) return { outcome: 'email-taken' };
  return {};
}

export const cvHandlers = [
  http.post('/api/cv', async ({ request }) => {
    const form = await request.formData();
    const file = (form.get('file') ?? form.getAll('pages')[0] ?? null) as File | null;
    await delay(700);
    const cvId = `cv-${Math.random().toString(36).slice(2, 8)}`;
    jobs.set(cvId, { name: file?.name ?? 'cv.pdf', started: Date.now() });
    return HttpResponse.json({ cvId });
  }),

  http.get('/api/cv/:id/status', ({ params }) => {
    const job = jobs.get(String(params['id']));
    if (!job) return new HttpResponse(null, { status: 404 });
    const elapsed = Date.now() - job.started;
    const { outcome, detail, failed } = outcomeFor(job.name);
    if (failed && elapsed > STEP_MS * 2) {
      return HttpResponse.json({ state: 'failed', percent: 30, step: 1, outcome, detail });
    }
    const step = Math.min(5, Math.floor(elapsed / STEP_MS));
    const percent = Math.min(100, Math.round((elapsed / (STEP_MS * 6)) * 100));
    if (percent >= 100)
      return HttpResponse.json({ state: 'done', percent: 100, step: 6, outcome, detail });
    return HttpResponse.json({ state: 'parsing', percent, step, quip: QUIPS[step] });
  }),

  http.get('/api/cv/:id/summary', async () => {
    await delay(300);
    seedAnswers('your-flex-era', CV_FLEX);
    seedAnswers('work-lore', CV_LORE);
    return HttpResponse.json({
      questsPrefilled: 5,
      detailsFound: 31,
      toCheck: 3,
      skillsMatched: 9,
      skipped: ['photo', 'ID number', 'marital status'],
      sections: [
        {
          quest: 1,
          title: 'Your name',
          badge: '2 found',
          fields: [
            { key: 'firstName', label: 'First name', value: 'Nkosazana' },
            { key: 'lastName', label: 'Last name', value: 'Dlamini' },
          ],
        },
        {
          quest: 2,
          title: 'Contact & address',
          badge: '4 found · 1 to check',
          fields: [
            { key: 'email', label: 'Email', value: 'nkosazanadlamini@gmail.com' },
            { key: 'mobile', label: 'Mobile', value: '+27 71 234 5678' },
            { key: 'homeLanguage', label: 'Home language', value: 'isiZulu' },
            {
              key: 'area',
              label: 'Area',
              value: 'Randburg, Gauteng',
              check: 'Found a suburb only — add your postal code',
            },
          ],
        },
        {
          quest: 3,
          title: 'School & qualifications',
          badge: '2 found · 1 to check',
          fields: [
            {
              key: 'level',
              label: 'Highest level',
              value: 'Matric (NSC) · Randburg High School · 2021',
            },
            {
              key: 'cert',
              label: 'Certificate',
              value: 'Contact Centre Operations · NQF 4',
              check: 'Year not found — when did you finish?',
            },
          ],
        },
        {
          quest: 4,
          title: 'Skills & languages',
          badge: '9 skills · 3 languages',
          chips: [
            'Customer service',
            'Active listening',
            'MS Excel',
            'Call centre systems',
            'Data capturing',
            'Conflict resolution',
            'Typing',
            'Teamwork',
            'Scheduling',
          ],
          fields: [
            {
              key: 'skillLevels',
              label: 'Skill levels',
              value: 'Guessed from your CV — you’ll confirm each one',
            },
            {
              key: 'languages',
              label: 'Languages',
              value: 'isiZulu (Native) · English (Fluent) · Sesotho',
              check: 'How well do you speak Sesotho?',
            },
          ],
        },
        {
          quest: 5,
          title: 'Work history',
          badge: '2 chapters · 2 yrs 3 mos',
          fields: [
            {
              key: 'job1',
              label: 'Chapter 1',
              value: 'Call centre agent (internship) · Teleperformance · Jan – Jun 2024',
            },
            { key: 'job2', label: 'Chapter 2', value: 'Cashier · Shoprite · Mar 2022 – Dec 2023' },
            { key: 'gap', label: 'Gap', value: 'Jul 2024 – now · shown only to you' },
          ],
        },
      ],
    });
  }),

  http.delete('/api/cv/:id', ({ params }) => {
    jobs.delete(String(params['id']));
    return new HttpResponse(null, { status: 204 });
  }),
];

/** What the mock CV (Nkosazana Dlamini, contact centre) gives Quest 4: 9 matched skills + 1 custom, 3 languages. */
const cvSkill = (id: string, name: string, category: string, level: number) => ({
  id,
  name,
  category,
  level,
  source: 'cv',
});
const CV_FLEX = {
  skills: [
    cvSkill('customer-service', 'Customer service', 'people', 3),
    cvSkill('active-listening', 'Active listening', 'people', 2),
    cvSkill('call-centre-systems', 'Call centre systems', 'tech', 2),
    cvSkill('excel', 'MS Excel', 'data', 2),
    cvSkill('data-capturing', 'Data capturing', 'data', 2),
    cvSkill('conflict-resolution', 'Conflict resolution', 'people', 1),
    cvSkill('communication', 'Communication', 'people', 2),
    cvSkill('problem-solving', 'Problem solving', 'people', 2),
    cvSkill('ms-office', 'MS Office', 'business', 2),
    { id: 'custom-syspro', name: 'Syspro', category: 'custom', level: 0, source: 'cv' },
  ],
  languages: [
    {
      name: 'English',
      fluency: 'fluent',
      speak: true,
      read: true,
      write: true,
      motherTongue: false,
      fromCv: true,
    },
    {
      name: 'Sesotho',
      fluency: '',
      speak: true,
      read: false,
      write: false,
      motherTongue: false,
      fromCv: true,
    },
  ],
};

/** Quest 5 chapters read from the mock CV (Figma 200:31683 "Imported from CV"). */
const CV_LORE = {
  workTypes: ['internship', 'part_time'],
  chapters: [
    {
      id: 'cv1',
      type: 'internship',
      role: 'Call Centre Agent',
      company: 'Teleperformance',
      start: '2024-01',
      end: '2024-06',
      current: false,
      mode: 'onsite',
      skills: ['customer-service', 'call-centre-systems', 'active-listening'],
      description: '',
      fromCv: true,
    },
    {
      id: 'cv2',
      type: 'part_time',
      role: 'Cashier',
      company: 'Shoprite',
      start: '2022-03',
      end: '2023-12',
      current: false,
      mode: 'onsite',
      skills: ['customer-service', 'data-capturing'],
      description: '',
      fromCv: true,
      typeUnsure: true,
    },
  ],
};
