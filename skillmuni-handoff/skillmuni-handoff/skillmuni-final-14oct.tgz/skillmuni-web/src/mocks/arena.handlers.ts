import { HttpResponse, delay, http } from 'msw';
import { sceneOr } from './persona';

/**
 * The Arena (Figma Leaderboard v2 52:172). Sample data from the design (handoff 58:1530 flags streaks,
 * movement and leagues as "to confirm" in the backend). `?arena=empty` (no XP yet this week) and
 * `?arena=error` in the page URL show those states. "All time" puts you at #9 to show the pinned row.
 */
interface Seed {
  id: string;
  name: string;
  xp: number;
  streak: number;
  modules: number;
  movement: number;
  title: string;
  level: number;
  badges: number;
  skill: string;
  cheers: number;
}

const P = (
  id: string,
  name: string,
  xp: number,
  streak: number,
  modules: number,
  movement: number,
  title = 'Rookie',
  level = 1,
  badges = 2,
  skill = 'English Vinglish',
  cheers = 12,
): Seed => ({ id, name, xp, streak, modules, movement, title, level, badges, skill, cheers });

const YOU = 'me';

const BOARDS: Record<string, Seed[]> = {
  week: [
    P('ananya', 'Ananya Iyer', 183, 9, 6, 0, 'Pathfinder', 4, 7, 'Brain Vita', 31),
    P(YOU, 'Yash', 68, 5, 3, 1, 'Explorer', 2, 4, 'Brain Vita', 8),
    P('kabir', 'Kabir Nair', 41, 0, 2, -1, 'Explorer', 2, 3, 'Banking', 5),
    P('priya', 'Priya Deshmukh', 14, 2, 2, 1),
    P('vihaan', 'Vihaan Gupta', 4, 0, 1, -1, 'Rookie', 1, 1, 'IT Gyan', 2),
    P('meera', 'Meera Joshi', 2, 1, 1, 0, 'Rookie', 1, 1, 'Hospitality', 1),
  ],
  month: [
    P('ananya', 'Ananya Iyer', 612, 9, 14, 0, 'Pathfinder', 4, 7, 'Brain Vita', 31),
    P('kabir', 'Kabir Nair', 455, 0, 11, 1, 'Explorer', 2, 3, 'Banking', 5),
    P('priya', 'Priya Deshmukh', 390, 2, 9, -1),
    P('rohan', 'Rohan Mehta', 301, 4, 8, 2, 'Explorer', 3, 5, 'Sharp Shooter', 9),
    P(YOU, 'Yash', 288, 5, 7, 1, 'Explorer', 2, 4, 'Brain Vita', 8),
    P('vihaan', 'Vihaan Gupta', 120, 0, 3, -2, 'Rookie', 1, 1, 'IT Gyan', 2),
    P('meera', 'Meera Joshi', 96, 1, 2, 0, 'Rookie', 1, 1, 'Hospitality', 1),
  ],
  all: [
    P('ananya', 'Ananya Iyer', 2140, 9, 31, 0, 'Legend', 7, 15, 'Brain Vita', 31),
    P('rohan', 'Rohan Mehta', 1870, 4, 27, 0, 'Pathfinder', 6, 12, 'Sharp Shooter', 9),
    P('sara', 'Sara Khan', 1602, 3, 22, 1, 'Pathfinder', 5, 10, 'English Vinglish', 14),
    P('kabir', 'Kabir Nair', 1499, 0, 21, -1, 'Explorer', 4, 9, 'Banking', 5),
    P('priya', 'Priya Deshmukh', 1310, 2, 19, 0, 'Explorer', 4, 8),
    P('dev', 'Dev Malhotra', 1205, 6, 18, 2, 'Explorer', 4, 7, 'IT Gyan', 6),
    P('isha', 'Isha Rao', 1102, 1, 16, -1, 'Explorer', 3, 6, 'Hospitality', 4),
    P('aditya', 'Aditya Singh', 990, 0, 15, 0, 'Explorer', 3, 6, 'Insurance', 3),
    P('tanvi', 'Tanvi Shah', 874, 2, 13, 1, 'Explorer', 3, 5, 'It’s My Style', 7),
    P('vihaan', 'Vihaan Gupta', 760, 0, 11, -1, 'Rookie', 2, 3, 'IT Gyan', 2),
    P('meera', 'Meera Joshi', 702, 1, 10, 0, 'Rookie', 2, 3, 'Hospitality', 1),
    P(YOU, 'Yash', 655, 5, 9, 2, 'Explorer', 2, 4, 'Brain Vita', 8),
  ],
};

const cheered = new Set<string>();
const cheerDelta = new Map<string, number>();

function scenario(): string {
  return sceneOr('arena', 'empty');
}

const initials = (name: string) =>
  name
    .split(/\s+/)
    .map((w) => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

function filter(scope: string, seeds: Seed[]): Seed[] {
  if (scope === 'friends') return seeds.filter((s, i) => s.id === YOU || i % 2 === 0).slice(0, 5);
  if (scope === 'batch') return seeds.filter((s) => s.id !== 'ananya');
  return seeds;
}

export const arenaHandlers = [
  http.get('/api/arena', async ({ request }) => {
    await delay(450);
    const mode = scenario();
    if (mode === 'error') return new HttpResponse(null, { status: 503 });
    const url = new URL(request.url);
    const scope = url.searchParams.get('scope') ?? 'everyone';
    const period = url.searchParams.get('period') ?? 'week';
    const seeds = mode === 'empty' ? [] : filter(scope, BOARDS[period] ?? BOARDS['week'] ?? []);
    const players = seeds.map((s, i) => ({
      id: s.id,
      rank: i + 1,
      name: s.name,
      initials: initials(s.name),
      xp: s.xp,
      streak: s.streak,
      modulesDone: s.modules,
      movement: s.movement,
      you: s.id === YOU,
      title: s.title,
      level: s.level,
      badges: s.badges,
      topSkill: s.skill,
      cheers: s.cheers + (cheerDelta.get(s.id) ?? 0),
      cheered: cheered.has(s.id),
    }));
    const me = players.find((p) => p.you);
    const above = me ? players[me.rank - 2] : undefined;
    return HttpResponse.json({
      scope,
      period,
      players,
      me: {
        rank: me?.rank ?? 0,
        xp: me?.xp ?? 0,
        rankToday: me?.movement ?? 0,
        streak: 5,
        nextName: above?.name ?? null,
        nextXp: above?.xp ?? null,
        topXp: players[0]?.xp ?? 0,
      },
      week: ['done', 'done', 'done', 'done', 'done', 'today', 'upcoming'],
      promotionRank: 3,
      league: 'Gold League',
      rankUp:
        mode !== 'empty' && period === 'week' && scope === 'everyone'
          ? { to: me?.rank ?? 0, passed: 'Kabir' }
          : null,
      rewards: {
        coins: 640,
        voucher: { discount: '20% OFF', title: 'Food & café voucher', cost: 300, ready: 2 },
      },
    });
  }),
  http.post('/api/arena/players/:id/cheer', async ({ params, request }) => {
    await delay(250);
    const id = String(params['id']);
    const { on } = (await request.json()) as { on: boolean };
    if (on) cheered.add(id);
    else cheered.delete(id);
    cheerDelta.set(id, on ? 1 : 0);
    const base = Object.values(BOARDS)
      .flat()
      .find((s) => s.id === id);
    return HttpResponse.json({ cheers: (base?.cheers ?? 0) + (on ? 1 : 0) });
  }),
  http.post('/api/arena/players/:id/challenge', async () => {
    await delay(300);
    return new HttpResponse(null, { status: 204 });
  }),
];
