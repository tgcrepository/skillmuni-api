import { QUESTS } from '../app/core/quests/quest-catalog';
import { isNewLearner } from './persona';
import { mockProgress } from './quest.handlers';

/**
 * Mock badge catalogue (Figma My Badges 170:4660; note 177:7597 "to confirm": final catalogue and
 * categories). 48 badges in 6 categories; 2 earned. The showcase (up to 3 pinned) lives in
 * sessionStorage and is shared by My Stats and the Profile showcase.
 */

type Category =
  'quests' | 'streaks' | 'learning' | 'quizzes' | 'assessments' | 'social' | 'special';
type Rarity = 'common' | 'rare' | 'epic' | 'legendary';
type State = 'earned' | 'progress' | 'locked' | 'secret';

export interface MockBadge {
  id: string;
  name: string;
  icon: string;
  category: Category;
  rarity: Rarity;
  state: State;
  earnedOn: string | null;
  progressLabel: string | null;
  percent: number;
  howTo: string;
  ownedPct: number;
  cta: { label: string; url: string } | null;
  tiers: { reached: number; total: number } | null;
  /** Quest badges show the quest's 3D illustration (corrections #24). */
  image?: string | null;
}

const QUIZ = '/learn/brain-vita/non-verbal-reasoning/quiz';
const BV = '/learn/brain-vita';

function b(
  id: string,
  name: string,
  icon: string,
  category: Category,
  rarity: Rarity,
  state: State,
  howTo: string,
  ownedPct: number,
  extra: Partial<MockBadge> = {},
): MockBadge {
  return {
    id,
    name,
    icon,
    category,
    rarity,
    state,
    earnedOn: null,
    progressLabel: null,
    percent: 0,
    howTo,
    ownedPct,
    cta: null,
    tiers: null,
    ...extra,
  };
}

const secret = (id: string, category: Category) =>
  b(id, 'Secret', 'star', category, 'epic', 'secret', 'Keep learning. This one is a surprise.', 6);

export const BADGES: MockBadge[] = [
  // Learning (14)
  b(
    'first-steps',
    'First Steps',
    'star',
    'learning',
    'legendary',
    'earned',
    'Finish your first brief.',
    3,
    {
      earnedOn: '2026-09-12',
      percent: 100,
    },
  ),
  b(
    'brain-vita-boss',
    'Brain-Vita Boss',
    'trophy',
    'learning',
    'epic',
    'progress',
    'Finish every Brain-Vita module: verbal, non-verbal, arithmetic and data.',
    14,
    {
      progressLabel: '98.86%',
      percent: 98.86,
      cta: { label: 'Finish Brain-Vita', url: BV },
    },
  ),
  b(
    'knook-explorer',
    'Knook Explorer',
    'target',
    'learning',
    'rare',
    'progress',
    'Open a module in 5 different Knooks.',
    31,
    {
      progressLabel: '2 / 5 Knooks',
      percent: 40,
      cta: { label: 'Explore Knooks', url: '/home' },
    },
  ),
  b(
    'cpd-champ',
    'CPD Champ',
    'shield-check',
    'learning',
    'rare',
    'locked',
    'Earn 10 CPD hours from finished courses.',
    22,
    { progressLabel: '0 / 10 hrs' },
  ),
  b(
    'hospitality-hero',
    'Hospitality Hero',
    'briefcase',
    'learning',
    'rare',
    'locked',
    'Finish the Hospitality course.',
    26,
    {
      progressLabel: '0%',
    },
  ),
  b(
    'it-gyan-guru',
    'IT Gyan Guru',
    'lightbulb',
    'learning',
    'rare',
    'locked',
    'Finish the IT Gyan course.',
    24,
    {
      progressLabel: '0%',
    },
  ),
  b(
    'banking-pro',
    'Banking Pro',
    'coins',
    'learning',
    'epic',
    'locked',
    'Finish the Banking course.',
    12,
    {
      progressLabel: '0%',
    },
  ),
  b(
    'globe-trotter',
    'Globe Trotter',
    'compass',
    'learning',
    'epic',
    'locked',
    'Finish International Opportunities.',
    9,
    {
      progressLabel: '0%',
    },
  ),
  b('auto-ace', 'Auto Ace', 'zap', 'learning', 'epic', 'locked', 'Finish Auto Components.', 8, {
    progressLabel: '0%',
  }),
  b(
    'module-master',
    'Module Master',
    'layout-grid',
    'learning',
    'rare',
    'locked',
    'Finish 10 modules.',
    20,
    { progressLabel: '0 / 10' },
  ),
  b(
    'course-closer',
    'Course Closer',
    'check-circle',
    'learning',
    'common',
    'locked',
    'Finish your first full course.',
    54,
    { progressLabel: '0 / 1' },
  ),
  b('bookworm', 'Bookworm', 'bookmark', 'learning', 'common', 'locked', 'Bookmark 10 briefs.', 58, {
    progressLabel: '0 / 10',
  }),
  b('deep-diver', 'Deep Diver', 'play', 'learning', 'rare', 'locked', 'Read 50 briefs.', 27, {
    progressLabel: '0 / 50',
  }),
  secret('secret-learning', 'learning'),
  // Quizzes (10)
  b(
    'quiz-starter',
    'Quiz Starter',
    'check-circle',
    'quizzes',
    'epic',
    'earned',
    'Pass your first quiz.',
    18,
    {
      earnedOn: '2026-09-20',
      percent: 100,
    },
  ),
  b(
    'ten-quizzes',
    'Quiz Regular',
    'lightbulb',
    'quizzes',
    'common',
    'progress',
    'Pass 10 quizzes.',
    61,
    {
      progressLabel: '4 / 10',
      percent: 40,
      cta: { label: 'Take a quiz', url: QUIZ },
    },
  ),
  b(
    'perfect-score',
    'Perfect Score',
    'star',
    'quizzes',
    'rare',
    'locked',
    'Get every answer right on a quiz.',
    33,
    {
      progressLabel: '0 / 1',
      cta: { label: 'Take a quiz', url: QUIZ },
    },
  ),
  b(
    'sharp-shooter',
    'Sharp Shooter',
    'target',
    'quizzes',
    'rare',
    'locked',
    'Score 80%+ on 3 quizzes.',
    29,
    {
      progressLabel: '0 / 3',
    },
  ),
  b(
    'quiz-streak',
    'On a Roll',
    'flame',
    'quizzes',
    'epic',
    'locked',
    'Pass a quiz 5 days in a row.',
    11,
    {
      progressLabel: '0 / 5 days',
    },
  ),
  b(
    'quick-thinker',
    'Quick Thinker',
    'clock',
    'quizzes',
    'rare',
    'locked',
    'Finish a quiz in under a minute.',
    21,
  ),
  b(
    'retry-hero',
    'Retry Hero',
    'repeat',
    'quizzes',
    'common',
    'locked',
    'Get a missed question right in practice.',
    52,
  ),
  b(
    'fifty-quizzes',
    'Quiz Legend',
    'trophy',
    'quizzes',
    'legendary',
    'progress',
    'Pass 50 quizzes.',
    2,
    {
      progressLabel: '4 / 50',
      percent: 8,
    },
  ),
  b(
    'night-quiz',
    'Midnight Quizzer',
    'sparkle',
    'quizzes',
    'rare',
    'locked',
    'Pass a quiz after 10 pm.',
    23,
  ),
  secret('secret-quiz', 'quizzes'),
  // Streaks (6)
  b(
    'streak-starter',
    'Streak Starter',
    'flame',
    'streaks',
    'rare',
    'progress',
    'Learn 3 days in a row.',
    38,
    {
      progressLabel: '2 / 3 days',
      percent: 66.67,
      cta: { label: 'Finish a quiz today', url: QUIZ },
    },
  ),
  b(
    'streak-master',
    'Streak Master',
    'flame',
    'streaks',
    'legendary',
    'locked',
    'Keep a 3, 7 and 30-day streak to fill all three pips.',
    4,
    { progressLabel: 'Tier 0 of 3', tiers: { reached: 0, total: 3 } },
  ),
  b(
    'night-owl',
    'Night Owl',
    'flame',
    'streaks',
    'rare',
    'locked',
    'Learn after 10 pm on 5 nights.',
    24,
    {
      progressLabel: '0 / 5 nights',
    },
  ),
  b(
    'comeback-kid',
    'Comeback Kid',
    'flame',
    'streaks',
    'common',
    'locked',
    'Return after 7 days away.',
    51,
    {
      progressLabel: 'Return after 7 days',
    },
  ),
  b(
    'early-bird',
    'Early Bird',
    'clock',
    'streaks',
    'rare',
    'locked',
    'Learn before 8 am on 5 mornings.',
    19,
    {
      progressLabel: '0 / 5 mornings',
    },
  ),
  secret('secret-streak', 'streaks'),
  // Assessments (8)
  b(
    'card-collector',
    'Card Collector',
    'layout-grid',
    'assessments',
    'epic',
    'progress',
    'Unlock 25 skill cards.',
    7,
    {
      progressLabel: '11 / 25 cards',
      percent: 44,
    },
  ),
  b(
    'expert-eye',
    'Expert Eye',
    'crown',
    'assessments',
    'legendary',
    'progress',
    'Reach Expert on 5 skill cards.',
    3,
    {
      progressLabel: '2 / 5',
      percent: 40,
    },
  ),
  b(
    'tier-up',
    'Tier Up',
    'trend-up',
    'assessments',
    'rare',
    'locked',
    'Move a skill card up a tier.',
    28,
  ),
  b(
    'all-rounder',
    'All-Rounder',
    'target',
    'assessments',
    'epic',
    'locked',
    'Reach Advanced in 4 different skills.',
    9,
  ),
  b(
    'career-clarity',
    'Career Clarity',
    'compass',
    'assessments',
    'common',
    'locked',
    'Finish Career Drivers.',
    56,
  ),
  b(
    'digital-native',
    'Digital Native',
    'zap',
    'assessments',
    'rare',
    'locked',
    'Score 90%+ in Digital Skills.',
    21,
  ),
  b(
    'leader-board',
    'Born Leader',
    'users',
    'assessments',
    'rare',
    'locked',
    'Score 90%+ in Leadership.',
    22,
  ),
  secret('secret-assess', 'assessments'),
  // Social (6)
  b(
    'cheerleader',
    'Cheerleader',
    'thumbs-up',
    'social',
    'common',
    'locked',
    'Cheer 10 players in the Arena.',
    60,
    {
      progressLabel: '0 / 10',
      cta: { label: 'Open the Arena', url: '/arena' },
    },
  ),
  b(
    'challenger',
    'Challenger',
    'trophy',
    'social',
    'rare',
    'locked',
    'Win 3 Arena challenges.',
    25,
  ),
  b(
    'top-ten',
    'Top 10',
    'crown',
    'social',
    'epic',
    'locked',
    'Finish a week in your batch’s top 10.',
    15,
    {
      cta: { label: 'Open the Arena', url: '/arena' },
    },
  ),
  b('squad-up', 'Squad Up', 'users', 'social', 'common', 'locked', 'Add 3 friends.', 57),
  b(
    'helping-hand',
    'Helping Hand',
    'message-circle',
    'social',
    'rare',
    'locked',
    'Share a brief with a friend 5 times.',
    26,
  ),
  secret('secret-social', 'social'),
  // Special & seasonal (4)
  b('xp-1k', 'XP 1K Club', 'zap', 'special', 'rare', 'progress', 'Earn 1,000 XP in total.', 21, {
    progressLabel: '529 / 1,000',
    percent: 52.9,
  }),
  b(
    'founding-learner',
    'Founding Learner',
    'sparkle',
    'special',
    'legendary',
    'locked',
    'Join in Skillmuni’s first year.',
    1,
  ),
  b(
    'festive-2026',
    'Festive Feat',
    'gift',
    'special',
    'epic',
    'locked',
    'Learn on 5 days during the festive week.',
    10,
  ),
  secret('secret-special', 'special'),
];

const KEY = 'sm_mock_showcase';
const DEFAULT_SHOWCASE = ['first-steps', 'quiz-starter'];
/** A new learner's showcase starts with their latest quest badges, so earned badges show up at once. */
const defaultShowcase = () =>
  isNewLearner()
    ? questBadges()
        .filter((x) => x.state === 'earned')
        .slice(-3)
        .reverse()
        .map((x) => x.id)
    : DEFAULT_SHOWCASE;

export function showcase(): string[] {
  try {
    const raw = sessionStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as string[]) : defaultShowcase();
  } catch {
    return defaultShowcase();
  }
}

export function setShowcase(ids: string[]): void {
  try {
    sessionStorage.setItem(KEY, JSON.stringify(ids));
  } catch {
    /* private mode */
  }
}

const QUEST_ICONS = [
  'user',
  'phone',
  'lightbulb',
  'star',
  'briefcase',
  'compass',
  'paperclip',
  'shield-check',
];
const QUEST_RARITY: Rarity[] = [
  'common',
  'common',
  'common',
  'rare',
  'rare',
  'rare',
  'epic',
  'legendary',
];

/** One badge per profile quest (A-292): earned the moment the quest is done, so the library matches it. */
export function questBadges(): MockBadge[] {
  const done = mockProgress.completed;
  const today = new Date().toISOString().slice(0, 10);
  return QUESTS.map((q, i) => {
    const earned = i < done;
    const current = i === done;
    const percent = earned
      ? 100
      : current
        ? Math.round((mockProgress.partsDone / q.parts) * 100)
        : 0;
    return b(
      `quest-${q.slug}`,
      q.badge,
      QUEST_ICONS[i] ?? 'star',
      'quests',
      QUEST_RARITY[i] ?? 'common',
      earned ? 'earned' : current ? 'progress' : 'locked',
      `Finish the ${q.name} quest.`,
      Math.max(8, 72 - i * 8),
      {
        earnedOn: earned ? today : null,
        percent,
        progressLabel: current ? `${mockProgress.partsDone} / ${q.parts} parts` : null,
        image: `assets/quests/quest-${q.id}.png`,
        cta: earned
          ? null
          : { label: current ? 'Continue quest' : 'Go to quests', url: `/quests/${q.slug}` },
      },
    );
  });
}

/** The catalogue as this learner sees it: a new learner has earned nothing yet (A-232). */
export function badgeList(): MockBadge[] {
  if (!isNewLearner()) return [...questBadges(), ...BADGES];
  return [
    ...questBadges(),
    ...BADGES.map((x): MockBadge =>
      x.state === 'earned' || x.state === 'progress'
        ? {
            ...x,
            state: 'progress',
            earnedOn: null,
            percent: 0,
            progressLabel: x.progressLabel ? '0%' : null,
            tiers: x.tiers ? { ...x.tiers, reached: 0 } : null,
          }
        : x,
    ),
  ];
}

export function earnedBadges(): MockBadge[] {
  return badgeList().filter((x) => x.state === 'earned');
}

/** Closest to unlock: highest progress among badges not yet earned. */
export function upNext(n: number): MockBadge[] {
  return badgeList()
    .filter((x) => x.state === 'progress')
    .sort((a, c) => c.percent - a.percent)
    .slice(0, n);
}
