/**
 * Career Drivers Survey 2025 (client document, 2026-10-06). Content the server owns: the 36 pairs,
 * the 9 drivers (A–I) and the 6 archetypes. Text is verbatim from the survey; the short "blurb"
 * lines and emojis are UX copy written for the results screens (A-212).
 */
import type {
  Archetype,
  DriverId,
  DriverInfo,
  Island,
  Pair,
} from '../app/core/assessment/assessment.api';

const p = (n: number, a: [string, DriverId], b: [string, DriverId]): Pair => ({
  n,
  this: { text: a[0], driver: a[1] },
  that: { text: b[0], driver: b[1] },
});

export const PAIRS: readonly Pair[] = [
  p(
    1,
    [
      'I aim for a lifestyle where I can comfortably afford the experiences and things I want.',
      'A',
    ],
    ['I want to have a strong voice in decisions and influence outcomes that matter.', 'B'],
  ),
  p(
    2,
    ['I need to feel that my work contributes to something meaningful and worthwhile.', 'C'],
    ['I want to develop deep expertise in my field and be recognized for it.', 'D'],
  ),
  p(
    3,
    ['I want opportunities to innovate, design, or bring fresh ideas to life.', 'E'],
    ['It’s important for me to work in a supportive, collaborative environment.', 'F'],
  ),
  p(
    4,
    ['I value flexibility and autonomy to decide how I work and what I focus on.', 'G'],
    [
      'I want the stability and security of knowing my future is financially and professionally predictable.',
      'H',
    ],
  ),
  p(
    5,
    ['I take pride in being respected and recognized for my achievements.', 'I'],
    ['I want to enjoy the financial freedom that comes with success.', 'A'],
  ),
  p(
    6,
    ['I want to influence and guide others toward shared goals.', 'B'],
    ['I’m motivated by doing work that aligns deeply with my personal values.', 'C'],
  ),
  p(
    7,
    ['I want to master specialized skills and be seen as a go-to expert.', 'D'],
    ['I want to create original ideas or work that carries my personal signature.', 'E'],
  ),
  p(
    8,
    ['Building meaningful, friendly relationships at work is essential to me.', 'F'],
    ['I enjoy deciding how I structure my day and tasks.', 'G'],
  ),
  p(
    9,
    ['I’m motivated by being able to afford a high-quality lifestyle.', 'A'],
    ['I want to demonstrate to myself and others that I truly know my craft.', 'D'],
  ),
  p(
    10,
    ['My work should reflect my personal sense of purpose.', 'C'],
    ['I want the things I produce to clearly carry my name or identity.', 'E'],
  ),
  p(
    11,
    ['I want to afford whatever I need without financial stress.', 'A'],
    ['Having a stable, long-term career matters a lot to me.', 'H'],
  ),
  p(
    12,
    ['I enjoy leading, influencing, and mobilizing people.', 'B'],
    ['I would enjoy becoming a respected specialist in my field.', 'D'],
  ),
  p(
    13,
    ['It matters to me that my work makes a positive difference in the world.', 'C'],
    ['Having close, trusting relationships at work is very important to me.', 'F'],
  ),
  p(
    14,
    ['I want my personal creativity to shine through in what I do.', 'E'],
    ['I’d prefer to chart my own course rather than follow strict directions.', 'G'],
  ),
  p(
    15,
    ['Working closely with people I like gives me a special sense of fulfillment.', 'F'],
    ['Knowing that my future is financially and professionally secure is critical.', 'H'],
  ),
  p(
    16,
    ['I want to have enough money to live comfortably and pursue my interests.', 'A'],
    ['I want to be innovative in my work and take on new challenges.', 'E'],
  ),
  p(
    17,
    ['I feel energized when I’m guiding, directing, or leading others.', 'B'],
    ['I feel happiest when I’m surrounded by people I connect with.', 'F'],
  ),
  p(
    18,
    ['I see my career as part of something meaningful and bigger than myself.', 'C'],
    ['I like taking full responsibility for my decisions and direction.', 'G'],
  ),
  p(
    19,
    ['I’d love to be recognized as a leading expert in my domain.', 'D'],
    ['Feeling that my career path is stable and predictable makes me comfortable.', 'H'],
  ),
  p(
    20,
    ['A comfortable and financially strong lifestyle motivates me.', 'A'],
    ['Meeting and connecting with new people through work excites me.', 'F'],
  ),
  p(
    21,
    ['I enjoy being in positions where I can set direction for others.', 'B'],
    ['Choosing my own tasks and priorities is important to me.', 'G'],
  ),
  p(
    22,
    ['I’m willing to work hard if I believe the outcome truly matters.', 'C'],
    ['I’d feel reassured knowing where I stand financially in the long run.', 'H'],
  ),
  p(
    23,
    ['Strong bonds with colleagues make it difficult for me to leave a job.', 'F'],
    ['Being acknowledged as part of an influential community is important to me.', 'I'],
  ),
  p(
    24,
    ['I’d enjoy taking charge of teams, projects, or resources.', 'B'],
    ['I want to create or build something that’s entirely new.', 'E'],
  ),
  p(
    25,
    ['I prefer to do what I deeply believe is right, even if it doesn’t boost my career.', 'C'],
    ['Being publicly recognized for my contributions matters to me.', 'I'],
  ),
  p(
    26,
    ['I want to do something that sets me apart from others.', 'E'],
    ['I usually prefer the secure and stable option.', 'H'],
  ),
  p(
    27,
    ['I want others to look to me for leadership.', 'B'],
    ['Social prestige and status are strong motivators for me.', 'I'],
  ),
  p(
    28,
    ['A high standard of living motivates me.', 'A'],
    ['I want to avoid being tightly controlled by a boss or rigid system.', 'G'],
  ),
  p(
    29,
    ['I want the work I do to clearly reflect my personal identity.', 'E'],
    ['I value formal recognition and acknowledgment of my achievements.', 'I'],
  ),
  p(
    30,
    ['I prefer to be the one making decisions and taking charge.', 'B'],
    ['It worries me when my professional future feels uncertain.', 'H'],
  ),
  p(
    31,
    ['I want to be known as someone with valuable specialist knowledge.', 'D'],
    ['I would find satisfaction in working independently without constant oversight.', 'G'],
  ),
  p(
    32,
    ['I dislike feeling like just another number in a large system.', 'G'],
    ['I’d enjoy having a high-prestige position in my field.', 'I'],
  ),
  p(
    33,
    ['I’m prepared to work harder for better financial rewards.', 'A'],
    ['I see my work as a way to grow as a person.', 'C'],
  ),
  p(
    34,
    ['I’d like to hold a position that commands respect and visibility.', 'I'],
    ['I’m consistently drawn to roles with stable futures.', 'H'],
  ),
  p(
    35,
    ['When the people I work with are my friends, nothing else matters as much.', 'F'],
    ['Making expert contributions to my field gives me great satisfaction.', 'D'],
  ),
  p(
    36,
    ['I’d enjoy the recognition and respect that come with senior roles.', 'I'],
    ['I want to be highly competent in my specialization.', 'D'],
  ),
];

/** Figma B1 quest map: 4 islands of 9 pairs. */
export const ISLANDS: readonly Island[] = [
  { n: 1, name: 'Vibe Check', emoji: '🌅', from: 1, to: 9 },
  { n: 2, name: 'Main Character', emoji: '🎬', from: 10, to: 18 },
  { n: 3, name: 'Plot Twist', emoji: '🌀', from: 19, to: 27 },
  { n: 4, name: 'Final Form', emoji: '👑', from: 28, to: 36 },
];

export const DRIVERS: readonly DriverInfo[] = [
  {
    id: 'A',
    name: 'Material Rewards',
    emoji: '💰',
    focus: 'Financial growth, lifestyle, tangible benefits',
    definition:
      'Refers to the desire for financial security, wealth, and the ability to enjoy a high standard of living. People driven by material rewards make career choices that enhance their economic well-being. They seek roles with competitive compensation and are often willing to take on challenging or less fulfilling work if it provides significant financial returns.',
    blurb: 'Good pay and the lifestyle it buys keep you going.',
    strengthZones: 'Sales, high-commission roles, entrepreneurship, competitive industries',
    families: 'Sales & retail, commercial roles, high-income tracks',
  },
  {
    id: 'B',
    name: 'Power / Influence',
    emoji: '⚡',
    focus: 'Impact, decision-making, leadership',
    definition:
      'Reflects the motivation to shape decisions, direct people or resources, and play a central role in key choices. These individuals aim for positions where they can influence outcomes, set direction, and make important decisions. Confident and proactive, they thrive in leadership, strategic, or policy-making roles.',
    blurb: 'You want a say in where things go, and to lead people there.',
    strengthZones: 'Supervisory roles, team leads, managerial tracks, operations control',
    families: 'Leadership, operations, management tracks',
  },
  {
    id: 'C',
    name: 'Meaning / Purpose',
    emoji: '🌍',
    focus: 'Contribution, values, positive impact',
    definition:
      'Centers on being motivated by work that aligns with personal beliefs, values, or a sense of higher purpose. These individuals want to make a meaningful contribution through social impact, education, sustainability, or ethical work. Personal fulfillment matters more than short-term rewards.',
    blurb: 'Work has to matter. You want to make a real difference.',
    strengthZones: 'CSR, NGOs, climate action, education, public sector, mission-driven roles',
    families: 'Education, social impact, public sector',
  },
  {
    id: 'D',
    name: 'Expertise',
    emoji: '🎯',
    focus: 'Mastery, specialization, professional excellence',
    definition:
      'Reflects the desire to build deep knowledge and skills in a specific field. People with this driver focus on developing and maintaining specialist capabilities, preferring to work within their areas of strength. Their greatest satisfaction comes from being recognized as credible experts and staying current through continuous learning.',
    blurb: 'You want to master your craft and be the go-to person for it.',
    strengthZones: 'Technical specialists, analysts, engineers, finance experts, niche consulting',
    families: 'Specialist tracks, technical roles, finance, engineering',
  },
  {
    id: 'E',
    name: 'Creativity',
    emoji: '🎨',
    focus: 'Innovation, originality, self-expression',
    definition:
      'Represents the motivation to generate new ideas, solutions, or original work. Creative individuals thrive on solving problems in new ways, pushing boundaries, and bringing unique ideas to life, whether through product design, entrepreneurship, research, or artistic pursuits.',
    blurb: 'You bring fresh ideas to life and leave your signature on the work.',
    strengthZones: 'Product design, marketing, entrepreneurship, R&D',
    families: 'Innovation, design, marketing, entrepreneurship',
  },
  {
    id: 'F',
    name: 'Affiliation',
    emoji: '🤝',
    focus: 'Connection, belonging, meaningful relationships',
    definition:
      'Highlights the value placed on close, supportive relationships at work. People with this driver prioritize trust, collaboration, and human connection. They often choose to stay in roles because of the people they work with and derive a sense of purpose through relationships rather than hierarchy.',
    blurb: 'The people you work with make or break a job for you.',
    strengthZones: 'Customer service, teaching, people management, HR, hospitality',
    families: 'People-facing roles, HR, education, service',
  },
  {
    id: 'G',
    name: 'Autonomy',
    emoji: '🧭',
    focus: 'Freedom, flexibility, independence',
    definition:
      'Reflects the desire to control one’s time, decisions, and work methods. People with this driver thrive in environments that allow them to make their own choices, often avoiding rigid hierarchies and bureaucracy. They excel in roles like freelancing, consulting, or entrepreneurship where independence is valued.',
    blurb: 'You want control over your time, decisions and how you work.',
    strengthZones: 'Freelancing, entrepreneurship, field work, consulting',
    families: 'Freelancing, consulting, entrepreneurship',
  },
  {
    id: 'H',
    name: 'Security',
    emoji: '🛡️',
    focus: 'Stability, predictability, reduced risk',
    definition:
      'Focuses on valuing stability and a clear sense of the future. These individuals prioritize avoiding unnecessary risks and ensuring long-term reliability. They often seek employers known for stability and prefer well-defined career paths that offer predictability and peace of mind.',
    blurb: 'You like stability, clear paths and knowing where you stand.',
    strengthZones: 'Government jobs, large corporates, banking, administrative operations',
    families: 'Administrative, government, stable large organisations',
  },
  {
    id: 'I',
    name: 'Status',
    emoji: '🏆',
    focus: 'Recognition, prestige, social esteem',
    definition:
      'Reflects the desire to be acknowledged, respected, and admired by others. People with this driver are motivated by visible recognition: titles, awards, networks, or association with prestigious institutions. They actively build their reputation and seek opportunities that elevate their professional profile.',
    blurb: 'Recognition, respect and visible achievement.',
    strengthZones: 'Client-facing roles, leadership, public representation, luxury sectors',
    families: 'Client relations, leadership, public-facing roles',
  },
];

export const ARCHETYPES: readonly Archetype[] = [
  {
    id: 'people-first',
    name: 'The People-First Service Builder',
    emoji: '🤝',
    dominant: ['F', 'H'],
    secondary: ['C', 'B'],
    roles:
      'Customer service, client success, HR service, training, hospitality, community operations',
    redFlags: 'Solitary specialist roles with little people contact; high-risk startups',
    summary:
      'You do your best work with people you trust, somewhere steady. Best-fit roles: customer service, client success, HR service, training, hospitality and community operations.',
  },
  {
    id: 'rainmaker',
    name: 'The Commercial Rainmaker',
    emoji: '💼',
    dominant: ['A', 'I'],
    secondary: ['B', 'G'],
    roles: 'Retail & B2C/B2B sales, business development, key accounts, luxury, revenue leadership',
    redFlags: 'Low-upside admin roles; back-office analyst work with no customer exposure',
    summary:
      'You chase big wins and like being seen for them. Best-fit roles: retail and B2B sales, business development, key accounts, luxury and revenue leadership.',
  },
  {
    id: 'specialist',
    name: 'The Specialist Operator',
    emoji: '🔧',
    dominant: ['D', 'H'],
    secondary: ['G'],
    roles: 'Technical specialist, finance/ops analyst, engineering, compliance, process excellence',
    redFlags: 'Highly ambiguous “build-as-you-go” creative roles; pure sales',
    summary:
      'You go deep, get it right and like a clear path. Best-fit roles: technical specialist, finance or ops analyst, engineering, compliance and process excellence.',
  },
  {
    id: 'pathfinder',
    name: 'The Creative Pathfinder',
    emoji: '🌈',
    dominant: ['E', 'G'],
    secondary: ['I', 'A'],
    roles: 'Product/design, marketing/content, R&D/innovation, creative consultancy, founder',
    redFlags: 'Rigid bureaucracy; narrow repetitive tasks with no room for ideas',
    summary:
      'You light up when you can create, try new things and own how you work. Best-fit roles: product and design, marketing and content, R&D, creative consultancy, founding something.',
  },
  {
    id: 'purpose',
    name: 'The Purpose-Driven Community Leader',
    emoji: '🌱',
    dominant: ['C', 'F'],
    secondary: ['D', 'B'],
    roles: 'Education/edtech, NGOs, climate/sustainability, public service, L&D, social programs',
    redFlags: 'Purely money/status-driven cultures; hard-sell commercial roles',
    summary:
      'You want your work to matter and to bring people with you. Best-fit roles: education and edtech, NGOs, climate and sustainability, public service, L&D and social programmes.',
  },
  {
    id: 'strategist',
    name: 'The Strategic Leader',
    emoji: '👑',
    dominant: ['B', 'I'],
    secondary: ['A'],
    eitherOf: ['D', 'G'],
    roles:
      'Senior leadership, strategy, policy, business unit heads, organizational shapers, entrepreneurial ventures',
    redFlags:
      'Roles with low autonomy, low visibility, or purely operational with no decision-making scope',
    summary:
      'You want to set direction and be the one people look to. Best-fit roles: senior leadership, strategy, policy, business unit heads and entrepreneurial ventures.',
  },
];
