import { profileProgress } from './profile-progress';
import { HttpResponse, delay, http } from 'msw';
import { isNewLearner } from './persona';
import type {
  BookRequest,
  BookedInterview,
  Booking,
  Fest,
  FestAlerts,
  FestEmployer,
  Outcome,
  PastFest,
  Reminders,
  Slot,
  SlotGrid,
} from '../app/core/fest/fest.api';
import { recordFestOffer } from './jobs.handlers';

/**
 * Hire Fest v2 (Figma 315:44812, handoff 318:55923). Four upcoming fests, per-employer 30-min slot
 * grid, one ticket per fest, waitlist, day-of live queue and past outcomes. Mock "today" is
 * 28 Nov 2026 so the countdowns match the frames. Page URL scenarios (`?hf=`): locked (H10) ·
 * none (H11) · live (H12) · error.
 */

const KEY = 'sm_mock_fest';
const TODAY = Date.UTC(2026, 10, 28);
const MINUTES = 30;
const BUFFER = 30;
const MAX_EMPLOYERS = 2;

function scenario(): string {
  return typeof location === 'undefined'
    ? ''
    : (new URLSearchParams(location.search).get('hf') ?? '');
}

const E = (
  id: string,
  company: string,
  initials: string,
  role: string,
  openings: number,
  slotsLeft: number,
  days: string,
  match: number,
): FestEmployer => ({
  id,
  company,
  initials,
  role,
  openings,
  slotsLeft,
  days,
  match,
  full: slotsLeft === 0,
});

const BASE: Omit<Fest, 'booked' | 'saved'>[] = [
  {
    id: 'tech-bpo-pune',
    name: 'Tech & BPO Hire Fest',
    mode: 'in-person',
    city: 'Pune',
    start: '2026-12-01',
    end: '2026-12-03',
    dateLabel: '1 – 3 Dec 2026',
    hours: '10:00 am – 6:00 pm · 30-min interviews',
    venue: 'Pune IT Park, Hall B, Hinjewadi',
    venueNote: 'Entry from Gate 2',
    distance: '12 km from you',
    organiser: 'SkillMuni Careers',
    employers: [
      E('cg', 'Cognizant', 'CG', 'Customer Support', 12, 6, 'Day 1–3', 94),
      E('tp', 'Teleperformance', 'TP', 'Voice Process Exec', 10, 11, 'Day 1–2', 90),
      E('hl', 'HDFC Life', 'HL', 'Inbound Sales Exec', 6, 14, 'Day 2–3', 82),
      E('cx', 'Concentrix', 'CX', 'Tech Support Trainee', 8, 0, 'Day 1–3', 76),
      E('il', 'ICICI Lombard', 'IL', 'Claims Support', 4, 9, 'Day 1', 71),
      E('ta', 'Tata AIG', 'TA', 'Customer Care Exec', 5, 7, 'Day 2', 68),
      E('ax', 'Axis Bank', 'AX', 'Relationship Officer', 6, 12, 'Day 3', 63),
      E('wi', 'Wipro', 'WI', 'Service Desk Analyst', 7, 8, 'Day 1–2', 58),
    ],
    employerCount: 8,
    roleCount: 46,
    price: 'Free',
    free: true,
    seatsLeft: 10,
    matchingRoles: 5,
    bookingCloses: '30 Nov, 6 pm',
    cancelPolicy: 'Cancel anytime up to 24 hrs before',
    beforeYouGo: [
      'Your CV is attached automatically from My Job Profile',
      'Photo ID + this ticket (QR) at the entry desk',
      'Dress: smart casual · arrive 15 min early',
    ],
    waitlistOpen: false,
  },
  {
    id: 'online-cs',
    name: 'Online Hire Fest: Customer Support',
    mode: 'online',
    city: 'Online',
    start: '2027-01-14',
    end: '2027-01-14',
    dateLabel: 'Wed, 14 Jan 2027',
    hours: '10:00 am – 6:00 pm IST · 30-min video interviews',
    venue: 'Online on SkillMuni Meet',
    venueNote: 'Join link + test call unlock after you book',
    distance: null,
    organiser: 'SkillMuni Careers',
    employers: [
      E('hl', 'HDFC Life', 'HL', 'Inbound Sales Exec', 6, 14, 'Day 1', 92),
      E('il', 'ICICI Lombard', 'IL', 'Claims Support', 4, 9, 'Day 1', 88),
      E('ta', 'Tata AIG', 'TA', 'Customer Care Exec', 5, 20, 'Day 1', 81),
      E('tp', 'Teleperformance', 'TP', 'Chat Support Exec', 15, 18, 'Day 1', 79),
      E('zo', 'Zomato', 'ZO', 'Customer Delight', 10, 16, 'Day 1', 74),
      E('az', 'Amazon', 'AZ', 'Virtual Customer Service', 20, 25, 'Day 1', 72),
      E('at', 'Airtel', 'AT', 'Customer Service', 8, 10, 'Day 1', 70),
      E('ib', 'Infosys BPM', 'IB', 'Process Executive', 12, 14, 'Day 1', 66),
      E('qc', 'Quess Corp', 'QC', 'Back Office', 6, 9, 'Day 1', 61),
      E('ug', 'upGrad', 'UG', 'Learner Support', 4, 6, 'Day 1', 58),
    ],
    employerCount: 10,
    roleCount: 32,
    price: 'Free',
    free: true,
    seatsLeft: 120,
    matchingRoles: 8,
    bookingCloses: '13 Jan, 6 pm',
    cancelPolicy: 'Cancel anytime up to 24 hrs before',
    beforeYouGo: [
      'Your CV is attached automatically from My Job Profile',
      'Quiet spot, earphones, 1 Mbps+ internet',
      'Do the 1-min test call the day before',
    ],
    waitlistOpen: false,
  },
  {
    id: 'retail-mumbai',
    name: 'Retail & Hospitality Hire Fest',
    mode: 'in-person',
    city: 'Mumbai',
    start: '2026-12-20',
    end: '2026-12-20',
    dateLabel: 'Sun, 20 Dec 2026',
    hours: '10:00 am – 5:00 pm · 30-min interviews',
    venue: 'NESCO Centre, Goregaon',
    venueNote: 'Hall 3, ground floor',
    distance: '148 km from you',
    organiser: 'SkillMuni Careers',
    employers: [
      E('rt', 'Reliance Trends', 'RT', 'Store Associate', 14, 8, 'Day 1', 81),
      E('tj', 'Taj Hotels', 'TJ', 'Front Desk Associate', 6, 5, 'Day 1', 77),
      E('dm', 'DMart', 'DM', 'Customer Associate', 20, 12, 'Day 1', 72),
      E('lf', 'Lifestyle', 'LF', 'Retail Associate', 10, 9, 'Day 1', 64),
    ],
    employerCount: 6,
    roleCount: 28,
    price: 'Free',
    free: true,
    seatsLeft: 34,
    matchingRoles: 3,
    bookingCloses: '18 Dec, 6 pm',
    cancelPolicy: 'Cancel anytime up to 24 hrs before',
    beforeYouGo: [
      'Your CV is attached automatically from My Job Profile',
      'Photo ID + this ticket (QR) at the entry desk',
      'Dress: smart casual · arrive 15 min early',
    ],
    waitlistOpen: false,
  },
  {
    id: 'fintech-blr',
    name: 'Fintech Careers Day',
    mode: 'in-person',
    city: 'Bengaluru',
    start: '2027-01-28',
    end: '2027-01-28',
    dateLabel: 'Thu, 28 Jan 2027',
    hours: '10:00 am – 5:00 pm · 30-min interviews',
    venue: 'KTPO Convention Centre, Whitefield',
    venueNote: 'Hall A',
    distance: '840 km from you',
    organiser: 'FinSkills Foundation',
    employers: [
      E('pz', 'PhonePe', 'PZ', 'Merchant Support', 6, 0, 'Day 1', 66),
      E('rz', 'Razorpay', 'RZ', 'Customer Success Associate', 4, 0, 'Day 1', 62),
      E('cr', 'CRED', 'CR', 'Member Support', 3, 0, 'Day 1', 55),
    ],
    employerCount: 5,
    roleCount: 18,
    price: '₹199',
    free: false,
    seatsLeft: 0,
    matchingRoles: 1,
    bookingCloses: '26 Jan, 6 pm',
    cancelPolicy: 'Full refund up to 24 hrs before',
    beforeYouGo: [
      'Your CV is attached automatically from My Job Profile',
      'Photo ID + this ticket (QR) at the entry desk',
      'Dress: business casual',
    ],
    waitlistOpen: true,
  },
];

/* ---------- State ---------- */

interface Pick {
  employerId: string;
  date: string;
  time: string;
}

interface StoredBooking {
  id: string;
  code: string;
  festId: string;
  picks: Pick[];
  reminders: Reminders;
  cv: string;
}

interface State {
  bookings: StoredBooking[];
  saved: string[];
  waitlist: Record<string, number>;
  outcomes: Record<string, Outcome>;
  ratings: Record<string, number>;
  alerts: FestAlerts;
}

const SEED_BOOKING: StoredBooking = {
  id: 'bk-retail',
  code: 'HF-3MRB-0420',
  festId: 'retail-mumbai',
  picks: [{ employerId: 'rt', date: '2026-12-20', time: '11:00' }],
  reminders: { whatsapp: true, sms: true, calendar: true },
  cv: 'Yash_Pohare_CV.pdf · Creative',
};

function load(): State {
  const base: State = {
    bookings: isNewLearner() ? [] : [SEED_BOOKING],
    saved: [],
    waitlist: {},
    outcomes: isNewLearner() ? {} : { 'pune-fresher:hl': 'offer' },
    ratings: isNewLearner() ? {} : { 'pune-fresher': 4 },
    alerts: { city: true, online: true },
  };
  if (scenario() === 'live')
    base.bookings = [
      {
        id: 'bk-live',
        code: 'HF-7Q4X-1201',
        festId: 'tech-bpo-pune',
        picks: [
          { employerId: 'cg', date: '2026-12-01', time: '10:30' },
          { employerId: 'tp', date: '2026-12-01', time: '12:00' },
        ],
        reminders: { whatsapp: true, sms: true, calendar: true },
        cv: 'Yash_Pohare_CV.pdf · Creative',
      },
      SEED_BOOKING,
    ];
  try {
    const raw = sessionStorage.getItem(KEY + scenario());
    return raw ? { ...base, ...(JSON.parse(raw) as Partial<State>) } : base;
  } catch {
    return base;
  }
}

/** Whether the learner holds a booking (A-306 / A-321: the "Book a Hire Fest slot" mission). */
export function festActivity(): { booked: boolean } {
  return { booked: load().bookings.length > 0 };
}

function save(s: State): void {
  try {
    sessionStorage.setItem(KEY + scenario(), JSON.stringify(s));
  } catch {
    /* private mode */
  }
}

/* ---------- Helpers ---------- */

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const WEEK = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function day(iso: string): Date {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(Date.UTC(y ?? 2026, (m ?? 1) - 1, d ?? 1));
}

const dayLabel = (iso: string) => {
  const d = day(iso);
  return `${WEEK[d.getUTCDay()]} ${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]}`;
};

function dates(f: { start: string; end: string }): string[] {
  const out: string[] = [];
  for (let t = day(f.start).getTime(); t <= day(f.end).getTime(); t += 86_400_000)
    out.push(new Date(t).toISOString().slice(0, 10));
  return out;
}

const clock = (t: string) => {
  const [h = 0, m = 0] = t.split(':').map(Number);
  const pm = h >= 12;
  const hh = h % 12 || 12;
  return `${hh}:${String(m).padStart(2, '0')} ${pm ? 'pm' : 'am'}`;
};

const plus = (t: string, min: number) => {
  const [h = 0, m = 0] = t.split(':').map(Number);
  const total = h * 60 + m + min;
  return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
};

const range = (t: string) => {
  const end = plus(t, MINUTES);
  const ap = (x: string) => (Number(x.split(':')[0]) >= 12 ? 'pm' : 'am');
  return `${clock(t).replace(/ (am|pm)$/, '')} – ${clock(end).replace(/ (am|pm)$/, '')} ${ap(end)}`;
};

/** Deterministic seats per slot so the grid is the same on every load. */
function seats(festId: string, emp: string, date: string, time: string): number {
  let h = 0;
  for (const c of `${festId}${emp}${date}${time}`) h = (h * 31 + c.charCodeAt(0)) % 9973;
  return h % 7 === 0 ? 0 : (h % 6) + 1;
}

const TIMES: Record<string, string[]> = {
  cg: ['10:00', '10:30', '11:00', '11:30', '14:00', '14:30'],
  tp: ['10:30', '11:00', '12:00', '12:30', '15:00', '15:30'],
};
const DEFAULT_TIMES = ['10:00', '11:00', '11:30', '12:30', '14:30', '16:00'];

function slotsFor(festId: string, empId: string, date: string): Slot[] {
  const fixed: Record<string, Record<string, number>> = {
    cg: { '10:00': 2, '10:30': 3, '11:00': 0, '11:30': 4, '14:00': 3, '14:30': 6 },
    tp: { '10:30': 2, '11:00': 5, '12:00': 3, '12:30': 2, '15:00': 0, '15:30': 4 },
  };
  return (TIMES[empId] ?? DEFAULT_TIMES).map((time) => {
    const left =
      festId === 'tech-bpo-pune' && date === '2026-12-01' && fixed[empId]
        ? (fixed[empId]?.[time] ?? 1)
        : seats(festId, empId, date, time);
    return { time, label: clock(time), left };
  });
}

function fest(f: (typeof BASE)[number], s: State): Fest {
  return { ...f, booked: s.bookings.some((b) => b.festId === f.id), saved: s.saved.includes(f.id) };
}

let deskSeed = 3;
function booking(b: StoredBooking, s: State): Booking {
  const f = BASE.find((x) => x.id === b.festId) ?? BASE[0];
  const desks: Record<string, string> = { cg: 'Desk 4', tp: 'Desk 9', rt: 'Desk 2' };
  const hall =
    f?.mode === 'online' ? 'Online room' : f?.venue.includes('Hall B') ? 'Hall B' : 'Hall 3';
  const interviews: BookedInterview[] = b.picks.map((p) => {
    const e = f?.employers.find((x) => x.id === p.employerId);
    return {
      employerId: p.employerId,
      company: e?.company ?? p.employerId,
      initials: e?.initials ?? '··',
      role: e?.role ?? '',
      date: p.date,
      dayLabel: dayLabel(p.date),
      time: clock(p.time),
      range: range(p.time),
      desk:
        f?.mode === 'online'
          ? 'Video call'
          : `${hall}, ${desks[p.employerId] ?? `Desk ${(deskSeed++ % 12) + 1}`}`,
    };
  });
  const first = b.picks.map((p) => p.date).sort()[0] ?? f?.start ?? '2026-12-01';
  const live =
    scenario() === 'live' && b.festId === 'tech-bpo-pune'
      ? {
          checkedInAt: '10:12',
          current: { employerId: 'cg', position: 3, waitMinutes: 15, lateBy: 10, progress: 0.6 },
        }
      : null;
  return {
    id: b.id,
    code: b.code,
    fest: fest(f as (typeof BASE)[number], s),
    interviews,
    daysToGo: live ? 0 : Math.max(0, Math.round((day(first).getTime() - TODAY) / 86_400_000)),
    reminders: b.reminders,
    cv: b.cv,
    live,
  };
}

function past(s: State): PastFest[] {
  if (isNewLearner()) return [];
  const rows = [
    {
      id: 'pune-fresher',
      name: 'Pune Fresher Hire Fest',
      date: '2026-11-08',
      interviews: [
        { employerId: 'hl', company: 'HDFC Life', initials: 'HL', role: 'Inbound Sales Exec' },
        { employerId: 'il', company: 'ICICI Lombard', initials: 'IL', role: 'Claims Support' },
      ],
    },
    {
      id: 'online-sept',
      name: 'Online Career Day: Freshers',
      date: '2026-09-19',
      interviews: [
        { employerId: 'ib', company: 'Infosys BPM', initials: 'IB', role: 'Process Executive' },
      ],
    },
  ];
  return rows.map((r) => {
    const d = day(r.date);
    return {
      id: r.id,
      name: r.name,
      date: r.date,
      day: String(d.getUTCDate()).padStart(2, '0'),
      month: (MONTHS[d.getUTCMonth()] ?? '').toUpperCase(),
      year: String(d.getUTCFullYear()),
      rating: s.ratings[r.id] ?? null,
      interviews: r.interviews.map((i) => ({
        ...i,
        outcome: s.outcomes[`${r.id}:${i.employerId}`] ?? null,
      })),
    };
  });
}

const fail = () => (scenario() === 'error' ? new HttpResponse(null, { status: 503 }) : null);
const code = () =>
  `HF-${Math.random().toString(36).slice(2, 6).toUpperCase()}-${String(Math.floor(1000 + Math.random() * 9000))}`;

/** A-262: booking needs a 60% job profile; what's left comes from the quests' skipped steps. */
function festGate() {
  if (scenario() === 'locked')
    return {
      profilePercent: 45,
      unlockAt: 60,
      missing: [
        { title: 'Your Flex Era · skills', detail: '3 min', xp: 0, link: '/quests/your-flex-era' },
        { title: 'Work Lore', detail: '2 min · or say you’re a fresher', xp: 0, link: '/quests/work-lore' },
      ],
    };
  const p = profileProgress();
  return {
    profilePercent: p.percent,
    unlockAt: 60,
    missing: p.quests
      .filter((q) => q.left.length)
      .map((q) => ({
        title: `${q.name} · ${q.left.map((l) => l.label).join(', ')}`,
        detail: q.left.length === 1 ? '1 step left' : `${q.left.length} steps left`,
        xp: 0,
        link: `/quests/${q.slug}`,
      })),
  };
}

export const festHandlers = [
  http.get('/api/fests/summary', async () => {
    await delay(200);
    const err = fail();
    if (err) return err;
    const s = load();
    return HttpResponse.json({
      upcoming: scenario() === 'none' ? 0 : BASE.length,
      bookings: s.bookings.length,
      past: isNewLearner() ? 0 : 2,
      ...festGate(),
      city: 'Pune',
    });
  }),

  http.get('/api/fests', async ({ request }) => {
    await delay(400);
    const err = fail();
    if (err) return err;
    const s = load();
    if (scenario() === 'none') return HttpResponse.json([]);
    const filter = new URL(request.url).searchParams.get('filter') ?? 'all';
    const list = BASE.map((f) => fest(f, s)).filter((f) =>
      filter === 'free'
        ? f.free
        : filter === 'in-person'
          ? f.mode === 'in-person'
          : filter === 'online'
            ? f.mode === 'online'
            : filter === 'city'
              ? f.city === 'Pune'
              : true,
    );
    // Recommended order comes from the server (profile match, distance, date), as drawn in H1.
    return HttpResponse.json(list);
  }),

  http.get('/api/fests/bookings', async () => {
    await delay(300);
    const err = fail();
    if (err) return err;
    const s = load();
    return HttpResponse.json(s.bookings.map((b) => booking(b, s)));
  }),

  http.get('/api/fests/bookings/:id', async ({ params }) => {
    await delay(250);
    const s = load();
    const b = s.bookings.find((x) => x.id === params['id']);
    return b ? HttpResponse.json(booking(b, s)) : new HttpResponse(null, { status: 404 });
  }),

  http.post('/api/fests/bookings/:id/cancel', async ({ params, request }) => {
    await delay(500);
    const { employerId } = (await request.json()) as { employerId: string | null };
    const s = load();
    const b = s.bookings.find((x) => x.id === params['id']);
    if (!b) return new HttpResponse(null, { status: 404 });
    if (employerId) b.picks = b.picks.filter((p) => p.employerId !== employerId);
    if (!employerId || !b.picks.length) s.bookings = s.bookings.filter((x) => x.id !== b.id);
    save(s);
    const left = s.bookings.find((x) => x.id === b.id);
    return HttpResponse.json(left ? booking(left, s) : null);
  }),

  http.get('/api/fests/past', async () => {
    await delay(300);
    const err = fail();
    if (err) return err;
    return HttpResponse.json(past(load()));
  }),

  http.put('/api/fests/past/:id/outcome', async ({ params, request }) => {
    await delay(250);
    const { employerId, outcome } = (await request.json()) as {
      employerId: string;
      outcome: Outcome;
    };
    const s = load();
    s.outcomes[`${String(params['id'])}:${employerId}`] = outcome;
    save(s);
    const p = past(s).find((x) => x.id === params['id']);
    const row = p?.interviews.find((i) => i.employerId === employerId);
    if (outcome === 'offer' && row) recordFestOffer(row.company, row.role);
    return p ? HttpResponse.json(p) : new HttpResponse(null, { status: 404 });
  }),

  http.put('/api/fests/past/:id/rating', async ({ params, request }) => {
    await delay(200);
    const { stars } = (await request.json()) as { stars: number };
    const s = load();
    s.ratings[String(params['id'])] = stars;
    save(s);
    return HttpResponse.json(past(s).find((x) => x.id === params['id']));
  }),

  http.get('/api/fests/alerts', async () => {
    await delay(150);
    return HttpResponse.json(load().alerts);
  }),

  http.put('/api/fests/alerts', async ({ request }) => {
    await delay(200);
    const s = load();
    s.alerts = (await request.json()) as FestAlerts;
    save(s);
    return HttpResponse.json(s.alerts);
  }),

  http.get('/api/fests/:id', async ({ params }) => {
    await delay(250);
    const f = BASE.find((x) => x.id === params['id']);
    return f ? HttpResponse.json(fest(f, load())) : new HttpResponse(null, { status: 404 });
  }),

  http.put('/api/fests/:id/saved', async ({ params, request }) => {
    await delay(150);
    const id = String(params['id']);
    const { saved } = (await request.json()) as { saved: boolean };
    const s = load();
    s.saved = saved ? [...new Set([...s.saved, id])] : s.saved.filter((x) => x !== id);
    save(s);
    const f = BASE.find((x) => x.id === id);
    return f ? HttpResponse.json(fest(f, s)) : new HttpResponse(null, { status: 404 });
  }),

  http.get('/api/fests/:id/slots', async ({ params, request }) => {
    await delay(350);
    const f = BASE.find((x) => x.id === params['id']);
    if (!f) return new HttpResponse(null, { status: 404 });
    const ids = (new URL(request.url).searchParams.get('employers') ?? '')
      .split(',')
      .filter(Boolean);
    const ds = dates(f);
    const slots: SlotGrid['slots'] = Object.fromEntries(
      ids.map((e) => [e, Object.fromEntries(ds.map((d) => [d, slotsFor(f.id, e, d)]))]),
    );
    const days = ds.map((d) => {
      const total = ids.reduce(
        (t, e) => t + (slots[e]?.[d] ?? []).reduce((n, x) => n + x.left, 0),
        0,
      );
      return { date: d, label: dayLabel(d), fewLeft: total < 12 };
    });
    const grid: SlotGrid = {
      days,
      slots,
      minutes: MINUTES,
      buffer: BUFFER,
      maxEmployers: MAX_EMPLOYERS,
    };
    return HttpResponse.json(grid);
  }),

  http.post('/api/fests/:id/book', async ({ params, request }) => {
    await delay(800);
    if (typeof navigator !== 'undefined' && !navigator.onLine) return HttpResponse.error();
    const id = String(params['id']);
    const body = (await request.json()) as BookRequest;
    const s = load();
    const existing = s.bookings.find((b) => b.festId === id);
    if (existing) {
      // Rescheduling or adding: replace the picks for those employers.
      const others = existing.picks.filter(
        (p) => !body.picks.some((n) => n.employerId === p.employerId),
      );
      existing.picks = [...others, ...body.picks];
      existing.reminders = body.reminders;
    } else {
      s.bookings.unshift({
        id: `bk-${id}`,
        code: id === 'tech-bpo-pune' ? 'HF-7Q4X-1201' : code(),
        festId: id,
        picks: [...body.picks],
        reminders: body.reminders,
        cv: `Yash_Pohare_CV.pdf · ${body.cvTemplate}`,
      });
    }
    save(s);
    const b = s.bookings.find((x) => x.festId === id);
    return b ? HttpResponse.json(booking(b, s)) : new HttpResponse(null, { status: 500 });
  }),

  http.get('/api/fests/:id/waitlist', async ({ params, request }) => {
    await delay(200);
    const emp = new URL(request.url).searchParams.get('employerId') ?? '';
    const s = load();
    const pos = s.waitlist[`${String(params['id'])}:${emp}`] ?? 4;
    return HttpResponse.json({
      position: pos,
      odds: 'Usually 1 in 3 waitlisted learners get a slot',
    });
  }),

  http.post('/api/fests/:id/waitlist', async ({ params, request }) => {
    await delay(400);
    const { employerId } = (await request.json()) as { employerId: string };
    const s = load();
    s.waitlist[`${String(params['id'])}:${employerId}`] = 4;
    save(s);
    return HttpResponse.json({
      position: 4,
      odds: 'Usually 1 in 3 waitlisted learners get a slot',
    });
  }),
];
