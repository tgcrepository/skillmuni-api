import { HttpResponse, delay, http } from 'msw';
import { creditXp } from './xp-ledger';
import { sceneOr } from './persona';
import type {
  Answer,
  AssessmentResult,
  AssessmentState,
  DriverScores,
} from '../app/core/assessment/assessment.api';
import {
  isAnswered,
  matchArchetype,
  rankDrivers,
  scoreDrivers,
} from '../app/core/assessment/scoring';
import { ARCHETYPES, DRIVERS, ISLANDS, PAIRS } from './assessment.data';

/**
 * Career Assessment v2 · Muni's Balance (Figma 259:19781). Scoring runs "on the server" with the
 * same pure functions the tests cover. State lives in sessionStorage so a reload resumes.
 * Page URL scenarios (`?ca=`): new · resume (13 answered) · final (34/36, 2 skipped) · done
 * (3 attempts, S1) · error. Submitting while the browser is offline fails like a real network (S3).
 */

const KEY = 'sm_mock_assessment';
const XP_ISLAND = 25;
/** A-309: 25 XP per island, 100 in all; the last island's 25 is paid on submit. */
const XP_DONE = XP_ISLAND;

interface Attempt {
  n: number;
  date: string;
  scores: DriverScores;
  xp: number;
}

interface State {
  seed: string;
  answers: Answer[];
  current: number;
  xp: number;
  earnsXp: boolean;
  islandsPaid: number[];
  remind: boolean;
  history: Attempt[];
}

const empty = (): Answer[] => PAIRS.map(() => null);

function scenario(): string {
  return sceneOr('ca', 'new');
}

/** The Figma S1 example and the two attempts before it (compare view). */
const HISTORY: Attempt[] = [
  {
    n: 1,
    date: '2026-04-12',
    xp: 100,
    scores: { A: 10, B: 10, C: 12, D: 9, E: 14, F: 12, G: 14, H: 13, I: 14 },
  },
  {
    n: 2,
    date: '2026-07-20',
    xp: 0,
    scores: { A: 12, B: 9, C: 10, D: 9, E: 16, F: 9, G: 16, H: 13, I: 14 },
  },
  {
    n: 3,
    date: '2026-10-01',
    xp: 0,
    scores: { A: 11, B: 9, C: 10, D: 8, E: 18, F: 9, G: 17, H: 12, I: 14 },
  },
];

/** Answers that lean toward the Figma example for seeded scenarios. */
function seeded(count: number, skip: number[] = []): Answer[] {
  return PAIRS.map((p, i) => {
    if (skip.includes(i)) return 'skip';
    if (i >= count) return null;
    const lean = ['E', 'G', 'I'];
    return lean.includes(p.this.driver)
      ? 0
      : lean.includes(p.that.driver)
        ? 3
        : (((i % 2) + 1) as 1 | 2);
  });
}

function fresh(seed: string): State {
  const base: State = {
    seed,
    answers: empty(),
    current: 0,
    xp: 0,
    earnsXp: true,
    islandsPaid: [],
    remind: true,
    history: [],
  };
  switch (seed) {
    case 'resume':
      return { ...base, answers: seeded(13), current: 13, xp: 25, islandsPaid: [1] };
    case 'final':
      return {
        ...base,
        answers: seeded(36, [11, 26]),
        current: 35,
        xp: 75,
        islandsPaid: [1, 2, 3],
      };
    case 'done':
      return { ...base, history: HISTORY, earnsXp: false };
    default:
      return base;
  }
}

function load(): State {
  const sc = scenario();
  try {
    const raw = sessionStorage.getItem(KEY);
    const s = raw ? (JSON.parse(raw) as State) : null;
    if (s && (!sc || s.seed === sc)) return s;
  } catch {
    /* private mode */
  }
  const s = fresh(sc);
  save(s);
  return s;
}

function save(s: State): void {
  try {
    sessionStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* private mode */
  }
}

function status(s: State): AssessmentState['status'] {
  if (s.answers.some((a) => a !== null)) return 'in-progress';
  return s.history.length ? 'done' : 'new';
}

function view(s: State): AssessmentState {
  return {
    status: status(s),
    pairs: PAIRS,
    islands: ISLANDS,
    answers: s.answers,
    current: s.current,
    xp: s.xp,
    earnsXp: s.earnsXp,
    remind: s.remind,
    attempts: s.history.length,
  };
}

function result(s: State, n?: number): AssessmentResult | null {
  const a = s.history.find((h) => h.n === n) ?? s.history.at(-1);
  if (!a) return null;
  const prev = s.history.find((h) => h.n === a.n - 1) ?? null;
  return {
    attempt: a.n,
    date: a.date,
    scores: a.scores,
    ranking: rankDrivers(a.scores),
    archetype: matchArchetype(a.scores, ARCHETYPES),
    drivers: DRIVERS,
    previous: prev?.scores ?? null,
    attempts: s.history
      .map((h) => ({ n: h.n, date: h.date, archetype: matchArchetype(h.scores, ARCHETYPES).name }))
      .reverse(),
    xpEarned: a.xp,
    mandatoryCourses: 2,
  };
}

const offline = () => typeof navigator !== 'undefined' && !navigator.onLine;

/** Read by the Launchpad mock so its assessment card follows real progress. */
export function assessmentSnapshot(): {
  answered: number;
  done: boolean;
  archetype: { name: string; emoji: string; traits: string[]; summary: string } | null;
} | null {
  try {
    const raw = sessionStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as State;
    const last = s.history.at(-1);
    const answered = s.answers.filter(isAnswered).length;
    if (!last) return { answered, done: false, archetype: null };
    const arch = matchArchetype(last.scores, ARCHETYPES);
    return {
      answered,
      done: true,
      archetype: {
        name: arch.name,
        emoji: arch.emoji,
        summary: arch.summary,
        traits: rankDrivers(last.scores)
          .slice(0, 3)
          .map((d) => DRIVERS.find((x) => x.id === d)?.name ?? d),
      },
    };
  } catch {
    return null;
  }
}

export const assessmentHandlers = [
  http.get('/api/assessments/career', async () => {
    await delay(400);
    if (scenario() === 'error') return new HttpResponse(null, { status: 503 });
    return HttpResponse.json(view(load()));
  }),

  http.put('/api/assessments/career/answers', async ({ request }) => {
    await delay(150);
    if (offline()) return HttpResponse.error();
    const body = (await request.json()) as { answers: Answer[]; current: number };
    const s = load();
    s.answers = body.answers;
    s.current = body.current;
    let earned = 0;
    for (const i of ISLANDS) {
      if (i.n === ISLANDS.length || s.islandsPaid.includes(i.n)) continue;
      const done = s.answers.slice(i.from - 1, i.to).every(isAnswered);
      if (done) {
        s.islandsPaid.push(i.n);
        if (s.earnsXp) earned += XP_ISLAND;
      }
    }
    s.xp += earned;
    creditXp(earned);
    save(s);
    return HttpResponse.json({ xp: s.xp, xpEarned: earned });
  }),

  http.post('/api/assessments/career/submit', async ({ request }) => {
    await delay(900);
    if (offline()) return HttpResponse.error();
    const { answers } = (await request.json()) as { answers: Answer[] };
    if (answers.length !== PAIRS.length || !answers.every(isAnswered))
      return HttpResponse.json({ code: 'incomplete' }, { status: 422 });
    const s = load();
    const xp = s.earnsXp ? XP_DONE : 0;
    creditXp(xp);
    s.history.push({
      n: s.history.length + 1,
      date: new Date().toISOString().slice(0, 10),
      scores: scoreDrivers(PAIRS, answers),
      xp: s.xp + xp,
    });
    s.answers = empty();
    s.current = 0;
    s.xp = 0;
    s.islandsPaid = [];
    s.earnsXp = false;
    save(s);
    return HttpResponse.json(result(s));
  }),

  http.get('/api/assessments/career/result', async ({ request }) => {
    await delay(350);
    const n = Number(new URL(request.url).searchParams.get('attempt')) || undefined;
    const r = result(load(), n);
    return r ? HttpResponse.json(r) : new HttpResponse(null, { status: 404 });
  }),

  http.post('/api/assessments/career/restart', async () => {
    await delay(200);
    const s = load();
    s.answers = empty();
    s.current = 0;
    save(s);
    return HttpResponse.json(view(s));
  }),

  http.post('/api/assessments/career/retake', async () => {
    await delay(250);
    const s = load();
    s.answers = empty();
    s.current = 0;
    s.xp = 0;
    s.islandsPaid = [];
    s.earnsXp = false;
    save(s);
    return HttpResponse.json(view(s));
  }),

  http.put('/api/assessments/career/remind', async ({ request }) => {
    await delay(150);
    const { remind } = (await request.json()) as { remind: boolean };
    const s = load();
    s.remind = remind;
    save(s);
    return HttpResponse.json({ remind });
  }),
];
