import { HttpResponse, delay, http } from 'msw';
import { totalXp } from './xp-ledger';
import { isNewLearner, learnerName, sceneOr } from './persona';
import { levelFor } from '../app/core/quests/levels';
import { badgeList, earnedBadges, setShowcase, showcase, upNext } from './badges.data';

/**
 * My Stats (Figma Dashboard v2 161:4277). Sample data from the design.
 * `?stats=error` fails every slide; `?stats=empty` shows the Assessments empty state (161:4514) and
 * a learner with no courses started.
 */

function scenario(): string {
  return sceneOr('stats', 'empty');
}

function nextMidnight(): string {
  const d = new Date();
  d.setHours(24, 0, 0, 0);
  return d.toISOString();
}

function catalogue() {
  const pinned = showcase();
  return {
    earned: earnedBadges().length,
    total: badgeList().length,
    badges: badgeList().map((x) => ({ ...x, pinned: pinned.includes(x.id) })),
  };
}

function rewards() {
  const pinned = showcase()
    .map((id) => badgeList().find((x) => x.id === id && x.state === 'earned'))
    .filter((x) => !!x)
    .map((x) => ({
      id: x.id,
      name: x.name,
      icon: x.icon,
      image: x.image ?? null,
      rarity: x.rarity,
    }));
  const slots = [...pinned, null, null, null].slice(0, 3);
  // A new learner (A-232): only the registration-quest XP, day 1 of a streak, nothing earned yet.
  const fresh = isNewLearner();
  const me = learnerName();
  const xp = totalXp();
  return {
    player: {
      name: me.full,
      initials: me.initials,
      title: levelFor(xp).rank,
      photoUrl: null,
      level: levelFor(xp).level,
      xp,
      nextLevelXp: levelFor(xp).target,
      batchRank: fresh ? null : 12,
    },
    streak: {
      days: fresh ? 1 : 2,
      week: fresh
        ? ['upcoming', 'upcoming', 'today', 'upcoming', 'upcoming', 'upcoming', 'upcoming']
        : ['done', 'done', 'today', 'upcoming', 'upcoming', 'upcoming', 'upcoming'],
    },
    wallet: { xp, coins: 0, coinsEarned: 0, coinsSpent: 0, credits: 0 },
    quests: {
      resetsAt: nextMidnight(),
      items: [
        {
          id: 'finish-bv',
          icon: 'play',
          title: 'Finish Brain-Vita',
          progressLabel: fresh ? '0% done' : '98.86% done',
          percent: fresh ? 0 : 98.86,
          xp: 10,
          done: false,
          link: '/learn/brain-vita',
        },
        {
          id: 'learn-15',
          icon: 'clock',
          title: 'Learn for 15 minutes',
          progressLabel: fresh ? '0 / 15 min' : '6 / 15 min',
          percent: fresh ? 0 : 40,
          xp: 5,
          done: false,
          link: '/home',
        },
        {
          id: 'quiz-80',
          icon: 'lightbulb',
          title: 'Score 80%+ on any quiz',
          progressLabel: '0 / 1',
          percent: 0,
          xp: 5,
          done: false,
          link: '/learn/brain-vita/non-verbal-reasoning/quiz',
        },
      ],
    },
    badges: {
      earned: earnedBadges().length,
      total: badgeList().length,
      showcase: slots,
      upNext: upNext(3).map((x) => ({
        id: x.id,
        name: x.name,
        icon: x.icon,
        image: x.image ?? null,
        progressLabel: x.progressLabel ?? '',
        percent: x.percent,
      })),
    },
    rank: fresh
      ? { rank: 48, gapXp: 15, nextName: 'Riya' }
      : { rank: 12, gapXp: 48, nextName: 'Aarav' },
    learningHours: fresh ? 0 : 285.2,
  };
}

const C = (
  id: string,
  title: string,
  tone: string,
  percent: number,
  status: string,
  link: string,
  summary: string,
  deadlineDays: number | null = null,
) => ({
  id,
  title,
  tone,
  percent,
  status,
  kind: 'Standard',
  xpOnFinish: 50,
  deadlineDays,
  timeEstHours: null,
  cpdHours: null,
  summary,
  link,
});

const NOT_STARTED = [
  'Retail Basics',
  'Healthcare Support',
  'Logistics 101',
  'Customer Service Pro',
  'Spoken English',
  'Financial Literacy',
  'Digital Marketing',
  'Workplace Safety',
  'Excel Essentials',
  'Teamwork at Work',
  'Interview Ready',
  'Time Management',
  'Sales Starter',
  'Data Entry',
  'Electrician Basics',
  'Hospitality Advanced',
  'Tally for Beginners',
];

function learning() {
  if (scenario() === 'empty') {
    return {
      courses: NOT_STARTED.slice(0, 5).map((t, i) =>
        C(
          `ns-${i}`,
          t,
          'blue',
          0,
          'not-started',
          '/home',
          `Start ${t} to earn XP and a certificate.`,
        ),
      ),
      currentId: null,
      nudge: null,
    };
  }
  const tones = ['arcane', 'ember', 'green', 'amber', 'pink', 'blue'];
  return {
    courses: [
      C(
        'brain-vita',
        'Brain-Vita',
        'arcane',
        98.86,
        'in-progress',
        '/learn/brain-vita',
        'Sharpen verbal, non-verbal, arithmetic and data reasoning.',
        6,
      ),
      C(
        'hospitality',
        'Hospitality',
        'ember',
        56.67,
        'in-progress',
        '/home',
        'Front desk, guest care and service skills for hotels and restaurants.',
        14,
      ),
      C(
        'it-gyan',
        'IT Gyan',
        'green',
        37.78,
        'in-progress',
        '/home',
        'Computer basics, the internet and staying safe online.',
        21,
      ),
      C(
        'banking',
        'Banking',
        'amber',
        8.7,
        'in-progress',
        '/home',
        'Accounts, payments and the jobs that keep a bank running.',
        30,
      ),
      C(
        'intl-opps',
        'International Opportunities',
        'arcane',
        0.25,
        'in-progress',
        '/home',
        'Discover global career opportunities for India’s aspiring blue-collar workforce: plan your skill development, navigate overseas employment and build a sustainable future.',
        0,
      ),
      C(
        'auto-components',
        'Auto Components',
        'pink',
        0.25,
        'in-progress',
        '/home',
        'How vehicle parts are made, checked and fitted.',
        45,
      ),
      ...NOT_STARTED.map((t, i) =>
        C(
          `ns-${i}`,
          t,
          tones[i % tones.length] ?? 'blue',
          0,
          'not-started',
          '/home',
          `Start ${t} to earn XP and a certificate.`,
        ),
      ),
      C('first-steps', 'Skillmuni Basics', 'green', 100, 'done', '/home', 'How Skillmuni works.'),
    ],
    currentId: 'intl-opps',
    nudge: 'Brain-Vita is 98.86% done. One more push for the badge!',
  };
}

const A = (
  id: string,
  title: string,
  tier: string,
  score: number,
  correct: number,
  completed: string,
) => ({
  id,
  title,
  subtitle: `${title} Mastery`,
  tier,
  score,
  correct,
  total: 20,
  completed,
  retakeUrl: `/assessments/${id}`,
});

function assessments() {
  const recommended = {
    title: 'Digital Skills',
    url: '/assessments/digital-skills',
    why: 'Start with Digital Skills. Most of your batch unlocks it first.',
  };
  if (scenario() === 'empty') return { results: [], available: 20, firstCardXp: 20, recommended };
  return {
    results: [
      A('digital-skills', 'Digital Skills', 'expert', 95, 18, '2026-06-07'),
      A('leadership', 'Leadership & Ownership', 'expert', 94, 18, '2026-06-02'),
      A('risk', 'Risk & Adaptability', 'advanced', 86, 17, '2026-05-28'),
      A('ai', 'AI & Emerging Technologies', 'advanced', 81, 16, '2026-05-20'),
      A('tech-innovation', 'Technology Innovation', 'intermediate', 75, 15, '2026-05-14'),
      A('data-analytics', 'Data Analytics', 'intermediate', 71, 14, '2026-05-09'),
      A('entrepreneurial', 'Entrepreneurial Mindset', 'beginner', 59, 12, '2026-05-02'),
      A('sales', 'Sales & Growth', 'beginner', 58, 12, '2026-04-25'),
      A('cyber', 'Cyber Awareness', 'beginner', 57, 11, '2026-04-18'),
      A('startup', 'Startup Readiness', 'beginner', 42, 8, '2026-04-11'),
      A('communication', 'Communication', 'beginner', 3, 1, '2026-04-04'),
    ],
    available: 20,
    firstCardXp: 20,
    recommended,
  };
}

const fail = () => scenario() === 'error';

export const statsHandlers = [
  http.get('/api/stats/rewards', async () => {
    await delay(400);
    return fail() ? new HttpResponse(null, { status: 503 }) : HttpResponse.json(rewards());
  }),
  http.get('/api/stats/learning', async () => {
    await delay(400);
    return fail() ? new HttpResponse(null, { status: 503 }) : HttpResponse.json(learning());
  }),
  http.get('/api/stats/assessments', async () => {
    await delay(400);
    return fail() ? new HttpResponse(null, { status: 503 }) : HttpResponse.json(assessments());
  }),
  http.get('/api/badges', async () => {
    await delay(400);
    return fail() ? new HttpResponse(null, { status: 503 }) : HttpResponse.json(catalogue());
  }),
  http.put('/api/badges/showcase', async ({ request }) => {
    await delay(300);
    const { ids } = (await request.json()) as { ids: string[] };
    const earned = new Set(earnedBadges().map((x) => x.id));
    setShowcase(ids.filter((id) => earned.has(id)).slice(0, 3));
    return HttpResponse.json(catalogue());
  }),
];
