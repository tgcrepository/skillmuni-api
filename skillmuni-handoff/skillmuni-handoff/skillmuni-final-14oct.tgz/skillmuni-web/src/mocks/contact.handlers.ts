import { HttpResponse, delay, http } from 'msw';
import { rememberLogin } from './persona';

/** Phone code: 123456 works. PINs 560038 / 400001 (IN) and postal codes 2194 / 2001 (ZA) are known. */
const POSTAL: Record<string, { region: string; district: string; city: string; areas: string[] }> =
  {
    'IN/560038': {
      region: 'Karnataka',
      district: 'Bengaluru Urban',
      city: 'Bengaluru',
      areas: [
        'Indiranagar',
        'HAL II Stage',
        'Doopanahalli',
        'Jeevan Bima Nagar',
        'New Thippasandra',
        'Domlur',
        'Kodihalli',
      ],
    },
    'IN/400001': {
      region: 'Maharashtra',
      district: 'Mumbai',
      city: 'Mumbai',
      areas: ['Fort', 'Colaba Causeway', 'Ballard Estate'],
    },
    'ZA/2194': {
      region: 'Gauteng',
      district: 'City of Johannesburg',
      city: 'Johannesburg',
      areas: [
        'Randburg (Ferndale)',
        'Randburg Central',
        'Blairgowrie',
        'Bordeaux',
        'Fontainebleau',
      ],
    },
    'ZA/2001': {
      region: 'Gauteng',
      district: 'City of Johannesburg',
      city: 'Johannesburg',
      areas: ['Braamfontein', 'Marshalltown'],
    },
  };

const REGIONS: Record<string, string[]> = {
  IN: [
    'Andhra Pradesh',
    'Arunachal Pradesh',
    'Assam',
    'Bihar',
    'Chhattisgarh',
    'Delhi',
    'Goa',
    'Gujarat',
    'Haryana',
    'Himachal Pradesh',
    'Jammu and Kashmir',
    'Jharkhand',
    'Karnataka',
    'Kerala',
    'Madhya Pradesh',
    'Maharashtra',
    'Manipur',
    'Meghalaya',
    'Mizoram',
    'Nagaland',
    'Odisha',
    'Puducherry',
    'Punjab',
    'Rajasthan',
    'Sikkim',
    'Tamil Nadu',
    'Telangana',
    'Tripura',
    'Uttar Pradesh',
    'Uttarakhand',
    'West Bengal',
  ],
  ZA: [
    'Eastern Cape',
    'Free State',
    'Gauteng',
    'KwaZulu-Natal',
    'Limpopo',
    'Mpumalanga',
    'North West',
    'Northern Cape',
    'Western Cape',
  ],
};

export const contactHandlers = [
  http.post('/api/me/phone/code', async ({ request }) => {
    await delay(400);
    const { phone } = (await request.json()) as { phone: string };
    const d = phone.replace(/\D/g, '');
    return HttpResponse.json({
      sentTo: `+${d.slice(0, d.length - 10)} ${d.slice(-10, -5)} ${d.slice(-5)}`,
      resendIn: 30,
      triesLeft: 5,
    });
  }),

  http.post('/api/me/phone/verify', async ({ request }) => {
    await delay(400);
    const { phone, code } = (await request.json()) as { phone: string; code: string };
    if (code === '123456') {
      rememberLogin(phone); // A-308: a verified mobile can log in next time.
      return new HttpResponse(null, { status: 204 });
    }
    if (code === '000000') {
      return HttpResponse.json(
        { message: 'Expired', errors: { code: ['code-expired'] } },
        { status: 410 },
      );
    }
    return HttpResponse.json(
      { message: 'Wrong', errors: { code: ['invalid-code'], triesLeft: ['4'] } },
      { status: 422 },
    );
  }),

  http.get('/api/geo/:market/postal/:code', async ({ params }) => {
    await delay(350);
    const hit = POSTAL[`${params['market']}/${params['code']}`];
    if (!hit) return HttpResponse.json({ message: 'Not found' }, { status: 404 });
    return HttpResponse.json({
      ...hit,
      areas: hit.areas.map((name) => ({ name, sub: hit.district })),
    });
  }),

  http.get('/api/geo/:market/regions', ({ params }) =>
    HttpResponse.json(REGIONS[String(params['market'])] ?? []),
  ),
];
