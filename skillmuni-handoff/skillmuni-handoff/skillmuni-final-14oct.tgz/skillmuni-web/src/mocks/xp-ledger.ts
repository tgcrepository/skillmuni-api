import { isNewLearner } from './persona';
import { mockProgress, syncLevel } from './quest.handlers';

/**
 * One XP total for the whole mock (mirrors the backend's single XP ledger, MISS-01).
 * Every screen — quest HUD, Profile, My Stats, Arena, Muni — reads `totalXp()`, and every reward
 * goes through `creditXp()`, so the learner never sees two different totals or rank names.
 *   - New account: the quest progress XP is the ledger.
 *   - The sample returning learner: 529 XP of history, plus anything earned in this tab.
 */
export const SAMPLE_XP = 529;
const EXTRA = 'sm_mock_xp_extra';

function extra(): number {
  try {
    return Number(sessionStorage.getItem(EXTRA) ?? 0) || 0;
  } catch {
    return 0;
  }
}

export function totalXp(): number {
  return isNewLearner() ? mockProgress.xp : SAMPLE_XP + extra();
}

export function creditXp(amount: number): void {
  if (amount <= 0) return;
  if (isNewLearner()) {
    mockProgress.xp += amount;
    syncLevel();
    return;
  }
  try {
    sessionStorage.setItem(EXTRA, String(extra() + amount));
  } catch {
    /* private mode */
  }
}
