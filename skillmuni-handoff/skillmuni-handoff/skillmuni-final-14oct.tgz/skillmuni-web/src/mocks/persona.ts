/**
 * Who the mock backend is serving (A-232). A real backend knows this from the account; the mock
 * decides at sign-in:
 *   - "Join the squad" (register → verify email) → a brand-new learner. Every feature starts
 *     empty: no assessment, no applications, no bookings, no badges, no streak.
 *   - Logging in with mobile or email → a returning learner with history (the Figma sample data).
 * Deep links without signing in (dev, e2e, Storybook) keep the returning learner.
 * A `?<feature>=` scenario param in the page URL still wins over the persona.
 */
export type Persona = 'new' | 'existing';

const KEY = 'sm_mock_persona';
const PREFIX = 'sm_mock_';
const NAME = 'sm_persona_name';
const listeners: ((p: Persona) => void)[] = [];

export function persona(): Persona {
  try {
    return sessionStorage.getItem(KEY) === 'new' ? 'new' : 'existing';
  } catch {
    return 'existing';
  }
}

export const isNewLearner = (): boolean => persona() === 'new';

/** Switch persona. A new learner wipes every mock store so nothing from a previous account leaks in. */
export function setPersona(p: Persona): void {
  try {
    if (p === 'new') {
      for (const k of Object.keys(sessionStorage))
        if (k.startsWith(PREFIX)) sessionStorage.removeItem(k);
    }
    sessionStorage.setItem(KEY, p);
  } catch {
    /* private mode */
  }
  for (const fn of listeners) fn(p);
}

/** The registered learner's name (new persona) or the Figma sample learner. */
export function learnerName(): {
  first: string;
  last: string;
  full: string;
  initials: string;
  email: string | null;
} {
  let first = 'Yash';
  let last = 'Pohare';
  let email: string | null = null;
  try {
    const raw = isNewLearner() ? sessionStorage.getItem(NAME) : null;
    if (raw)
      ({
        first,
        last,
        email = null,
      } = JSON.parse(raw) as { first: string; last: string; email?: string });
  } catch {
    /* private mode */
  }
  const full = `${first} ${last}`.trim();
  const initials = full
    .split(/\s+/)
    .map((w) => w[0] ?? '')
    .join('')
    .slice(0, 2)
    .toUpperCase();
  return { first, last, full, initials, email };
}

export function rememberName(first: string, last: string, email: string): void {
  try {
    sessionStorage.setItem(NAME, JSON.stringify({ first, last, email }));
  } catch {
    /* private mode */
  }
}

/** Mocks that keep in-memory state reset themselves here. */
export function onPersona(fn: (p: Persona) => void): void {
  listeners.push(fn);
}

/** `?param=` from the page URL, else the persona's default scenario. */
export function sceneOr(param: string, forNew: string): string {
  if (typeof location === 'undefined') return '';
  const v = new URLSearchParams(location.search).get(param);
  if (v !== null) return v;
  return isNewLearner() ? forNew : '';
}

/**
 * A-308: logins that exist beyond the sample learner — emails that signed up or used Google, and
 * mobiles verified in quest 1 or the profile. Kept outside the `sm_mock_` prefix so a new persona's
 * wipe doesn't forget them. Phones are stored as their last 10 digits.
 */
const ACCOUNTS = 'sm_accounts';

export function knownLogins(): string[] {
  try {
    return JSON.parse(sessionStorage.getItem(ACCOUNTS) ?? '[]') as string[];
  } catch {
    return [];
  }
}

export function rememberLogin(value: string): void {
  const v = value.includes('@') ? value.trim().toLowerCase() : value.replace(/\D/g, '').slice(-10);
  try {
    sessionStorage.setItem(ACCOUNTS, JSON.stringify([...new Set([...knownLogins(), v])]));
  } catch {
    /* private mode */
  }
}
