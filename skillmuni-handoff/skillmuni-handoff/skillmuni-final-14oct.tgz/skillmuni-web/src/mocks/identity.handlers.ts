import { HttpResponse, delay, http } from 'msw';
import { isNewLearner, learnerName } from './persona';

/**
 * DigiLocker link (A-272). The mock returns what a real DigiLocker pull gives Skillmuni after
 * masking: never the full number. Kept in sessionStorage like the other mock stores.
 */
const KEY = 'sm_mock_identity';

const MASKS: Record<string, { masked: string; last4: string }> = {
  aadhaar: { masked: 'XXXX XXXX 4821', last4: '4821' },
  pan: { masked: 'XXXXXX234F', last4: '234F' },
  'driving-licence': { masked: 'XXXX XXXXXXX7731', last4: '7731' },
};

function read(): Record<string, string> | null {
  try {
    return JSON.parse(sessionStorage.getItem(KEY) ?? 'null') as Record<string, string> | null;
  } catch {
    return null;
  }
}

export const identityHandlers = [
  http.get('/api/me/identity', async () => {
    await delay(150);
    return HttpResponse.json(read());
  }),

  http.post('/api/me/identity/digilocker/start', async () => {
    await delay(150);
    return HttpResponse.json({ authorizeUrl: '/quests/who-dis?part=2&digilocker=sandbox' });
  }),

  http.post('/api/me/identity/digilocker/link', async ({ request }) => {
    await delay(600);
    const { doc, code } = (await request.json()) as { doc: string; code: string };
    const mask = MASKS[doc];
    if (!mask || !code) return new HttpResponse(null, { status: 400 });
    const record = {
      doc,
      ...mask,
      name: learnerName().full,
      birthday: isNewLearner() ? '2004-08-21' : '2003-05-14',
      verifiedAt: new Date().toISOString(),
    };
    try {
      sessionStorage.setItem(KEY, JSON.stringify(record));
    } catch {
      /* private mode */
    }
    return HttpResponse.json(record);
  }),

  http.delete('/api/me/identity', async () => {
    await delay(150);
    try {
      sessionStorage.removeItem(KEY);
    } catch {
      /* private mode */
    }
    return new HttpResponse(null, { status: 204 });
  }),
];
