import { HttpResponse, delay, http } from 'msw';
import { answer, fallback, greeting, me } from './muni-knowledge';
import { learnerName } from './persona';

/**
 * Muni chat mocks (Figma Muni Chat v2 179:5915). Keyword intents stand in for the real backend
 * (handoff "to confirm": which intents exist). Replies are rich cards + short bubbles + ≤ 3 chips.
 * `?muni=error` in the page URL fails replies.
 */

const PROFILE = {
  email: 'yash.pohare@thegamification.com',
  mobile: '+91 98765 40697',
};

const mask = {
  email: (e: string) => `${e[0] ?? ''}••••@${e.split('@')[1] ?? ''}`,
  mobile: (m: string) => `••••••${m.replace(/\D/g, '').slice(-4)}`,
};

const text = (t: string) => ({ kind: 'text', text: t });

const TOPIC_CHIPS: Record<string, { intro: string; chips: string[] }> = {
  jobs: {
    intro: 'Jobs it is 💼 What do you want to do?',
    chips: ['Jobs for me', 'Applications', 'Career Compass'],
  },
  learn: {
    intro: 'Let’s learn something 📚 Pick one:',
    chips: ['Continue my quest', 'Quick quiz', 'Browse modules'],
  },
  assess: {
    intro: 'Time to flex 🎯 Which one?',
    chips: ['Career assessment', 'Skill check'],
  },
  me: {
    intro: 'All about you ✨',
    chips: ['Show my profile', 'My XP & rank', 'My career archetype'],
  },
};

function reply(input: { text: string; intent?: string }) {
  const q = (input.intent ?? input.text).toLowerCase().trim();
  const topic = TOPIC_CHIPS[q];
  if (topic) return { blocks: [text(topic.intro)], chips: topic.chips };
  // A-282: greetings and platform questions are answered for this learner.
  if (/^(hi|hey|hello|yo|hii+|namaste)\b/.test(q) && q.split(' ').length <= 3) return greeting();
  const isChip =
    /^(show my profile|my xp & rank|jobs for me|continue my quest|my career archetype|quick quiz|browse modules|applications|career compass|take the career assessment|why do i match\?)$/.test(
      q,
    );
  if (!isChip) return answer(q) ?? fallback();

  if (/profile|about me|my details/.test(q)) {
    return {
      blocks: [
        text('Here’s you on Skillmuni 👇 Private bits stay masked. Tap the eye to peek.'),
        {
          kind: 'profile',
          initials: learnerName().initials,
          name: learnerName().full,
          subtitle: `${me().rank} · Lvl ${me().level}`,
          fields: [
            { key: 'email', label: 'Email', value: mask.email(PROFILE.email), masked: true },
            { key: 'mobile', label: 'Mobile', value: mask.mobile(PROFILE.mobile), masked: true },
            { key: 'since', label: 'Member since', value: 'Apr 2025', masked: false },
          ],
          completeness: me().profilePct,
          nextStep: me().gaps[0]
            ? `Next: ${me().gaps[0]?.quest} · ${me().gaps[0]?.left}`
            : 'All done. Nice!',
        },
        text('Want the tea on your XP, rank or career archetype? 👀'),
      ],
      chips: ['My XP & rank', 'My career archetype', 'Jobs for me'],
    };
  }
  if (/xp|rank|leaderboard|arena/.test(q)) {
    return {
      blocks: [
        text(`You’re cooking, ${me().first} 🔥 Here’s where you stand:`),
        {
          kind: 'stats',
          items: [
            { label: 'Total XP', value: String(me().xp), icon: 'zap' },
            { label: 'Level', value: `${me().level} · ${me().rank}`, icon: 'trophy' },
            { label: 'To next level', value: String(me().toNext), icon: 'trend-up' },
          ],
          link: { label: 'Open the Arena', url: '/arena' },
        },
        text('One module and a quiz gets you a good chunk of the way. Want me to pick one?'),
      ],
      chips: ['Continue my quest', 'Quick quiz', 'Jobs for me'],
    };
  }
  if (/job|match|work|hire|application/.test(q)) {
    return {
      blocks: [
        text('2 jobs match your profile right now 👀'),
        {
          kind: 'list',
          items: [
            {
              title: 'Customer Support Executive',
              detail: 'Teleperformance · Mumbai · ₹22k/mo',
              tag: '92% match',
              url: '/matches',
            },
            {
              title: 'Retail Associate',
              detail: 'Reliance Trends · Pune · ₹18k/mo',
              tag: '86% match',
              url: '/matches',
            },
          ],
        },
      ],
      chips: ['Why do I match?', 'Applications', 'Career Compass'],
    };
  }
  if (/archetype|compass|career/.test(q)) {
    return {
      blocks: [
        text(
          me().archetype
            ? `Your archetype is ${me().archetype} 🤝 It’s what drives you at work, and it shapes your job matches.`
            : 'You haven’t taken Career Drivers yet. 36 quick picks (6 min) and I’ll tell you your archetype 🎯',
        ),
      ],
      chips: ['Jobs for me', 'Take the Career assessment', 'My XP & rank'],
    };
  }
  if (/quest|continue|module|learn|brain|quiz|brief/.test(q)) {
    return {
      blocks: [
        text('Brain Vita is 98.86% done. One quiz gets you the badge 🧠'),
        {
          kind: 'list',
          items: [
            {
              title: 'Non-Verbal Reasoning',
              detail: 'Brief 11 of 11 · 3 questions',
              tag: '+1 XP each',
              url: '/learn/brain-vita/non-verbal-reasoning/quiz',
            },
          ],
        },
      ],
      chips: ['Browse modules', 'My XP & rank', 'Jobs for me'],
    };
  }
  if (/streak/.test(q)) {
    return {
      blocks: [text('2-day streak and counting 🔥 One brief’s quiz today keeps it alive.')],
      chips: ['Quick quiz', 'Continue my quest'],
    };
  }
  if (/cv|resume|attach/.test(q)) {
    return {
      blocks: [
        text(
          'Got your CV 📄 I’ll compare it with your profile and show you what’s new before anything changes.',
        ),
      ],
      chips: ['Show my profile', 'Jobs for me'],
    };
  }
  if (/hi|hey|hello|yo\b/.test(q)) {
    return {
      blocks: [text('Heyyy 👋 Ask me about jobs, learning, your rank or your profile.')],
      chips: ['Jobs for me', 'Continue my quest', 'My XP & rank'],
    };
  }
  return {
    blocks: [
      text(
        'Hmm, I’m not sure about that one yet 🤔 I’m best with jobs, learning, assessments and your profile.',
      ),
    ],
    chips: ['Jobs for me', 'Continue my quest', 'Show my profile'],
  };
}

function scenario(): string {
  return typeof location === 'undefined'
    ? ''
    : (new URLSearchParams(location.search).get('muni') ?? '');
}

export const muniHandlers = [
  http.get('/api/muni/welcome', async () => {
    await delay(300);
    const m = me();
    return HttpResponse.json({
      firstName: m.first,
      intro: `Level ${m.level} · ${m.rank}, ${m.xp} XP. Ask me anything about Skillmuni, or start with what I’d do right now:`,
      suggestions: m.fresh
        ? [
            {
              id: 'drivers',
              icon: 'compass',
              tone: 'accent',
              title: 'Discover your Career Drivers',
              detail: '36 quick picks · 6 min',
              cta: 'Start',
              link: '/assessments/career',
            },
            {
              id: 'learn',
              icon: 'play',
              tone: 'success',
              title: 'Start your first learning module',
              detail: '2-minute brief, then a quick quiz',
              cta: 'Let’s go',
              link: '/learn/brain-vita',
            },
            {
              id: 'jobs',
              icon: 'briefcase',
              tone: 'brand',
              title: 'See jobs that fit you',
              detail: 'Matched to your quests',
              cta: 'See jobs',
              intent: 'Jobs for me',
            },
          ]
        : [
            {
              id: 'finish',
              icon: 'play',
              tone: 'success',
              title: 'Finish Brain-Vita',
              detail: '98.86% done · 1 module to the badge',
              cta: 'Let’s go',
              link: '/learn/brain-vita/non-verbal-reasoning/quiz',
            },
            {
              id: 'jobs',
              icon: 'briefcase',
              tone: 'accent',
              title: '2 jobs match your profile',
              detail: 'Customer Support Exec · Retail Associate',
              cta: 'See jobs',
              intent: 'Jobs for me',
            },
            {
              id: 'streak',
              icon: 'flame',
              tone: 'brand',
              title: 'Keep your 2-day streak',
              detail: '5 min today keeps it alive',
              cta: 'Quick quiz',
              link: '/learn/brain-vita/non-verbal-reasoning/quiz',
            },
          ],
      topics: [
        { id: 'jobs', icon: 'briefcase', label: 'Jobs', options: 5 },
        { id: 'learn', icon: 'play', label: 'Learn', options: 4 },
        { id: 'assess', icon: 'target', label: 'Assess', options: 2 },
        { id: 'me', icon: 'user', label: 'Me', options: 4 },
      ],
      unread: 2,
      nudge: { title: '2 new jobs match you 👀', body: 'Tap Muni to see them' },
    });
  }),

  http.post('/api/muni/messages', async ({ request }) => {
    await delay(900);
    if (scenario() === 'error') return new HttpResponse(null, { status: 503 });
    const body = (await request.json()) as { text: string; intent?: string };
    return HttpResponse.json(reply(body));
  }),

  http.post('/api/muni/reveal', async ({ request }) => {
    await delay(300);
    const { field } = (await request.json()) as { field: 'email' | 'mobile' };
    return HttpResponse.json({ value: PROFILE[field] });
  }),

  http.put('/api/muni/messages/:id/rating', () => new HttpResponse(null, { status: 204 })),

  http.get('/api/muni/history', async () => {
    await delay(300);
    return HttpResponse.json([
      {
        id: 'h1',
        title: 'Jobs for me',
        when: 'Yesterday',
        messages: [
          { from: 'me', text: 'Jobs for me' },
          { from: 'muni', text: '2 jobs match your profile right now 👀' },
        ],
      },
      {
        id: 'h2',
        title: 'My XP & rank',
        when: 'Mon',
        messages: [
          { from: 'me', text: 'My XP & rank' },
          { from: 'muni', text: 'You’re #3 this week with 41 XP. Keep going!' },
        ],
      },
    ]);
  }),
];
