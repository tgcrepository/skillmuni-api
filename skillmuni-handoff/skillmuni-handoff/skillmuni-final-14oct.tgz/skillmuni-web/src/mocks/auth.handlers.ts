import { mockPhoto } from './profile.handlers';
import { HttpResponse, delay, http } from 'msw';
import {
  isNewLearner,
  knownLogins,
  learnerName,
  persona,
  rememberLogin,
  rememberName,
  setPersona,
} from './persona';
import { mockProgress } from './quest.handlers';

/**
 * Mock auth. Codes: 123456 is right; anything else is wrong (5 tries); "000000" = expired.
 * Phones ending 0000 are locked. Password "letmein123" works for any email; "locked@…" is locked.
 *
 * A-308: log in only works for a registered mobile or email. Registered = the sample learner
 * (+91 98765 43210, yash.p@gmail.com), yash.verma@gmail.com, locked accounts, and any email that
 * signed up or used Google in this tab. Anything else → 404 account-not-found → sign-up.
 */
const tries = new Map<string, number>();
/** Corrections #7: unlimited tries for people; 20 wrong codes in a row is the hidden anti-bot limit. */
const MAX_TRIES = 20;

const user = { id: 'u-1', firstName: 'Yash', email: 'yash.p@gmail.com', phone: '+91 98765 43210' };

/** The mock backend runs inside the page (A-157), so it sets the session cookie itself. */
export function mockSession(on: boolean): void {
  document.cookie = on ? 'sm_mock_session=1; Path=/' : 'sm_mock_session=; Max-Age=0; Path=/';
}
const hasSession = () => document.cookie.split('; ').includes('sm_mock_session=1');
/** Logging in with mobile or email = a returning learner (A-232). */
const signedIn = (body: object) => {
  mockSession(true);
  // A new learner who saved & exited mid-registration is the same learner logging back in (A-252).
  if (!(persona() === 'new' && mockProgress.completed < 8)) setPersona('existing');
  return HttpResponse.json(body);
};

function fail(status: number, code: string, message: string) {
  return HttpResponse.json({ message, errors: { code: [code] } }, { status });
}

function formatPhone(phone: string): string {
  const d = phone.replace(/\D/g, '');
  const local = d.slice(-10);
  return `+91 ${local.slice(0, 5)} ${local.slice(5)}`;
}

const emailTries = new Map<string, number>();
const SAMPLE_PHONE = '9876543210';
const SAMPLE_EMAILS = ['yash.p@gmail.com', 'yash.verma@gmail.com'];
const isRegisteredEmail = (email: string) => {
  const e = email.trim().toLowerCase();
  return e.startsWith('locked@') || SAMPLE_EMAILS.includes(e) || knownLogins().includes(e);
};
const isRegisteredPhone = (phone: string) => {
  const local = phone.replace(/\D/g, '').slice(-10);
  return local === SAMPLE_PHONE || local.endsWith('0000') || knownLogins().includes(local);
};
const notFound = () => fail(404, 'account-not-found', 'No account for that login');
const pending = new Map<string, { firstName: string; lastName: string }>();

function emailChallenge(email: string) {
  emailTries.set(email, MAX_TRIES);
  return { email, resendIn: 42, validFor: 10, triesLeft: MAX_TRIES };
}

export const authHandlers = [
  http.post('/api/auth/register', async ({ request }) => {
    await delay(600);
    const body = (await request.json()) as { email: string; firstName: string; lastName?: string };
    if (isRegisteredEmail(body.email)) {
      return HttpResponse.json(
        {
          message: 'Email taken',
          errors: { code: ['email-taken'], email: ['Already in the squad.'] },
        },
        { status: 409 },
      );
    }
    pending.set(body.email, { firstName: body.firstName, lastName: body.lastName ?? '' });
    return HttpResponse.json(emailChallenge(body.email));
  }),

  http.post('/api/auth/email/resend', async ({ request }) => {
    await delay(400);
    const { email } = (await request.json()) as { email: string };
    return HttpResponse.json(emailChallenge(email));
  }),

  http.post('/api/auth/email/verify', async ({ request }) => {
    await delay(500);
    const { email, code } = (await request.json()) as { email: string; code: string };
    if (code === '000000') return fail(410, 'code-expired', 'Code expired');
    if (code === '123456') {
      // A-232: a brand-new account → every feature starts in its first-time state.
      setPersona('new');
      mockSession(true);
      rememberLogin(email);
      rememberName(
        pending.get(email)?.firstName ?? 'there',
        pending.get(email)?.lastName ?? '',
        email,
      );
      return HttpResponse.json({
        id: 'u-new',
        firstName: pending.get(email)?.firstName ?? 'there',
        email,
      });
    }
    const left = (emailTries.get(email) ?? MAX_TRIES) - 1;
    emailTries.set(email, left);
    if (left <= 0) return fail(429, 'too-many-tries', 'Too many tries');
    return HttpResponse.json(
      { message: 'Wrong code', errors: { code: ['invalid-code'], triesLeft: [String(left)] } },
      { status: 422 },
    );
  }),

  http.post('/api/auth/otp', async ({ request }) => {
    await delay(500);
    const { phone } = (await request.json()) as { phone: string };
    if (!isRegisteredPhone(phone)) return notFound();
    if (phone.endsWith('0000')) return fail(423, 'account-locked', 'Account locked');
    tries.set(phone, MAX_TRIES);
    return HttpResponse.json({ sentTo: formatPhone(phone), resendIn: 30, triesLeft: MAX_TRIES });
  }),

  http.post('/api/auth/otp/verify', async ({ request }) => {
    await delay(500);
    const { phone, code } = (await request.json()) as { phone: string; code: string };
    if (code === '000000') return fail(410, 'code-expired', 'Code expired');
    if (code === '123456') return signedIn({ ...user, phone: formatPhone(phone) });
    const left = (tries.get(phone) ?? MAX_TRIES) - 1;
    tries.set(phone, left);
    if (left <= 0) return fail(429, 'too-many-tries', 'Too many tries');
    return HttpResponse.json(
      { message: 'Wrong code', errors: { code: ['invalid-code'], triesLeft: [String(left)] } },
      { status: 422 },
    );
  }),

  http.post('/api/auth/email/login-code', async ({ request }) => {
    await delay(500);
    const { email } = (await request.json()) as { email: string };
    if (!isRegisteredEmail(email)) return notFound();
    if (email.startsWith('locked@')) return fail(423, 'account-locked', 'Account locked');
    tries.set(email, MAX_TRIES);
    const [name = '', domain = ''] = email.split('@');
    return HttpResponse.json({
      sentTo: `${name.slice(0, 2)}•••@${domain}`,
      resendIn: 30,
      triesLeft: MAX_TRIES,
    });
  }),

  http.post('/api/auth/email/login-verify', async ({ request }) => {
    await delay(500);
    const { email, code } = (await request.json()) as { email: string; code: string };
    if (code === '000000') return fail(410, 'code-expired', 'Code expired');
    if (code === '123456') return signedIn({ ...user, email });
    const left = (tries.get(email) ?? MAX_TRIES) - 1;
    tries.set(email, left);
    if (left <= 0) return fail(429, 'too-many-tries', 'Too many tries');
    return HttpResponse.json(
      { message: 'Wrong code', errors: { code: ['invalid-code'], triesLeft: [String(left)] } },
      { status: 422 },
    );
  }),

  /** A-253: `mock:existing` → the sample learner; `mock:new:First:Last` → a brand-new account. */
  http.post('/api/auth/google', async ({ request }) => {
    await delay(500);
    const { credential } = (await request.json()) as { credential: string };
    if (credential.startsWith('mock:new:')) {
      const [, , first = 'there', last = ''] = credential.split(':');
      const email = `${first}.${last}@gmail.com`.toLowerCase();
      setPersona('new');
      rememberName(first, last, email);
      rememberLogin(email);
      mockSession(true);
      return HttpResponse.json({
        user: { id: 'u-google-new', firstName: first, email },
        isNew: true,
      });
    }
    if (credential === 'mock:existing') {
      mockSession(true);
      setPersona('existing');
      return HttpResponse.json({ user: { ...user, email: 'yash.p@gmail.com' }, isNew: false });
    }
    return fail(401, 'google-invalid', 'Google token rejected');
  }),

  http.post('/api/auth/login', async ({ request }) => {
    await delay(500);
    const { email, password } = (await request.json()) as { email: string; password: string };
    if (email.startsWith('locked@')) return fail(423, 'account-locked', 'Account locked');
    if (password !== 'letmein123') return fail(401, 'wrong-credentials', 'Wrong email or password');
    return signedIn({ ...user, email });
  }),

  http.post('/api/auth/password-reset', async () => {
    await delay(400);
    return HttpResponse.json({ resendIn: 45, validFor: 30 });
  }),

  http.post('/api/auth/logout', () => {
    mockSession(false);
    return new HttpResponse(null, { status: 204 });
  }),

  http.get('/api/session', () =>
    hasSession()
      ? HttpResponse.json(
          {
            ...(isNewLearner() ? { ...user, id: 'u-new', firstName: learnerName().first } : user),
            photoUrl: mockPhoto(),
          },
        )
      : HttpResponse.json({ message: 'No session' }, { status: 401 }),
  ),
];
