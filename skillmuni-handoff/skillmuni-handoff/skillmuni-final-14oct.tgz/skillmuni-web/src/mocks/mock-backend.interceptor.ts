import {
  HttpErrorResponse,
  HttpEvent,
  HttpHeaders,
  HttpInterceptorFn,
  HttpRequest,
  HttpResponse,
} from '@angular/common/http';
import { Observable, from, switchMap } from 'rxjs';
import { getResponse } from 'msw';
import { handlers } from './handlers';

/**
 * Dev-only mock backend (A-157). Runs the MSW handlers inside the page instead of a service worker, so
 * Chrome stopping an idle worker (or a hard reload) can never make a save fall through to the dev server.
 * Requests no handler claims go on to the network as usual.
 */
export const mockBackendInterceptor: HttpInterceptorFn = (req, next) =>
  from(resolve(req)).pipe(
    switchMap((res): Observable<HttpEvent<unknown>> => (res ? from(toHttp(req, res)) : next(req))),
  );

async function resolve(req: HttpRequest<unknown>): Promise<Response | undefined> {
  const url = new URL(req.urlWithParams, location.href);
  const headers = new Headers();
  for (const key of req.headers.keys()) headers.set(key, req.headers.get(key) ?? '');
  let body: BodyInit | undefined;
  if (req.method !== 'GET' && req.method !== 'HEAD' && req.body !== null) {
    if (req.body instanceof FormData || req.body instanceof Blob || typeof req.body === 'string') {
      body = req.body;
    } else {
      body = JSON.stringify(req.body);
      if (!headers.has('content-type')) headers.set('content-type', 'application/json');
    }
  }
  const request = new Request(url, { method: req.method, headers, body, referrer: location.href });
  return getResponse(handlers, request);
}

async function toHttp(req: HttpRequest<unknown>, res: Response): Promise<HttpEvent<unknown>> {
  const text = await res.text();
  let body: unknown = text || null;
  if (text && (res.headers.get('content-type') ?? '').includes('json')) {
    try {
      body = JSON.parse(text);
    } catch {
      /* leave as text */
    }
  }
  const headers = new HttpHeaders(Object.fromEntries(res.headers.entries()));
  const init = { headers, status: res.status, statusText: res.statusText, url: req.urlWithParams };
  if (res.ok) return new HttpResponse({ ...init, body });
  throw new HttpErrorResponse({ ...init, error: body });
}
