import { HttpResponse, delay, http } from 'msw';
import { creditXp, totalXp } from './xp-ledger';
import { levelFor } from '../app/core/quests/levels';
import { isNewLearner, learnerName, rememberLogin, sceneOr } from './persona';
import { assessmentSnapshot } from './assessment.handlers';
import { badgeList, earnedBadges, showcase, upNext } from './badges.data';

/**
 * Profile v2 · Player ID (Figma 186:6669, note 187:8642). Sample data from the design.
 * Strength weights: contact 30 · name 30 · photo 10 · skills 15 · Career Drivers 15 (60% in the design).
 * `?profile=error` in the page URL fails the load; `?profile=new` starts from a fresh learner.
 * Edits live in sessionStorage; an uploaded photo lives in memory only (gone on reload).
 */

type Gender = 'female' | 'male' | 'non-binary' | 'rather-not';

interface State {
  skills: string[];
  gender: Gender;
  dob: string;
  /** A-273: set once a new mobile / email is verified with a code. */
  mobile?: string;
  email?: string;
}

function currentMobile(s: State): string {
  return s.mobile ?? (isNewLearner() ? '' : MOBILE);
}
function currentEmail(s: State): string {
  return s.email ?? learnerName().email ?? EMAIL;
}
function maskMobile(m: string): string {
  return m ? `•••••• ${m.replace(/\D/g, '').slice(-4)}` : 'Not added';
}
/** A-272: the DigiLocker link holds only the masked number. */
function linkedId(): { doc: string; masked: string } | null {
  try {
    return JSON.parse(sessionStorage.getItem('sm_mock_identity') ?? 'null') as {
      doc: string;
      masked: string;
    } | null;
  } catch {
    return null;
  }
}
const DOC_LABEL: Record<string, string> = {
  aadhaar: 'Aadhaar',
  pan: 'PAN',
  'driving-licence': 'Driving licence',
};
const pending: Record<string, string> = {};

const KEY = 'sm_mock_profile';
const WEIGHTS = { contact: 30, name: 30, photo: 10, skills: 15, drivers: 15 } as const;
/** Career Drivers pays its own 100 XP (A-309), so the strength task carries no extra XP. */
const XP = { photo: 5, skills: 10, drivers: 0 } as const;

const SKILL_OPTIONS = [
  'Customer service',
  'Communication',
  'MS Excel',
  'Teamwork',
  'Problem solving',
  'Sales',
  'Hindi',
  'English',
  'Data entry',
  'Social media',
  'Time management',
  'Leadership',
];

const MOBILE = '+91 98765 40697';
const EMAIL = 'yash.pohare@thegamification.com';
const GENDER_LABEL: Record<Gender, string> = {
  female: 'Female',
  male: 'Male',
  'non-binary': 'Non-binary',
  'rather-not': 'Rather not say',
};

/** Kept for the tab like other mock stores, so the top bar shows it after a reload (A-277). */
const PHOTO_KEY = 'sm_mock_photo';
let photoUrl: string | null = (() => {
  try {
    return sessionStorage.getItem(PHOTO_KEY);
  } catch {
    return null;
  }
})();
export function mockPhoto(): string | null {
  return photoUrl;
}

function scenario(): string {
  return sceneOr('profile', 'new');
}

function initial(): State {
  return { skills: [], gender: 'rather-not', dob: '2000-08-14' };
}

function load(): State {
  try {
    const raw = sessionStorage.getItem(KEY);
    return raw ? { ...initial(), ...(JSON.parse(raw) as Partial<State>) } : initial();
  } catch {
    return initial();
  }
}

function persist(s: State): void {
  try {
    sessionStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* private mode */
  }
}

function formatDob(iso: string): string {
  const d = new Date(`${iso}T00:00:00`);
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

function maskEmail(email: string | null): string | null {
  if (!email) return null;
  const [name = '', domain = ''] = email.split('@');
  return `${name.slice(0, 1)}••••@${domain}`;
}

function build(s: State, fresh: boolean) {
  const photo = photoUrl !== null;
  // One ledger everywhere (corrections #13 bugs): the profile shows the same total as every screen.
  const xp = fresh && !isNewLearner() ? 15 : totalXp();
  const lvl = levelFor(xp); // A-249: one ladder everywhere
  const level = lvl.level;
  const ca = assessmentSnapshot();
  const tasks = [
    { id: 'contact', label: 'Contact details', xp: 0, done: true },
    { id: 'name', label: 'Name & joining date', xp: 0, done: true },
    { id: 'photo', label: 'Add a profile photo', xp: XP.photo, done: photo },
    { id: 'skills', label: 'Add your top skills', xp: XP.skills, done: s.skills.length > 0 },
    { id: 'drivers', label: 'Take Career Drivers', xp: XP.drivers, done: !!ca?.done },
  ] as const;
  const percent = tasks.reduce((sum, t) => sum + (t.done ? WEIGHTS[t.id] : 0), 0);
  const year = s.dob.slice(0, 4);
  return {
    playerId: 'SM-00412',
    name: learnerName().full,
    initials: learnerName().initials,
    title: lvl.rank,
    joined: fresh ? '2026-10-05' : '2025-04-01',
    photoUrl,
    level,
    xp,
    levelStartXp: lvl.start,
    nextLevelXp: lvl.target,
    batchRank: fresh ? null : 12,
    bestSkill: fresh ? null : 'Digital Skills',
    // A-306: the archetype from the learner's own Career Drivers result.
    archetype: ca?.archetype
      ? {
          name: ca.archetype.name,
          blurb: ca.archetype.summary,
          emoji: ca.archetype.emoji,
          traits: ca.archetype.traits,
        }
      : null,
    // Corrections #24: quest badges count from day one.
    stats: fresh
      ? { streakDays: 0, badges: earnedBadges().length, learningHours: 0 }
      : { streakDays: 2, badges: earnedBadges().length, learningHours: 285.2 },
    strength: { percent, tasks },
    showcase:
      fresh && !earnedBadges().length
        ? { pinned: [], next: { name: 'First Steps', icon: 'star', percent: 40 } }
        : {
            pinned: showcase()
              .map((id) => badgeList().find((x) => x.id === id && x.state === 'earned'))
              .filter((x) => !!x)
              .map((x) => ({
                id: x.id,
                name: x.name,
                icon: x.icon,
                image: x.image ?? null,
                rarity: x.rarity,
              })),
            next:
              upNext(1).map((x) => ({
                name: x.name,
                icon: x.icon,
                image: x.image ?? null,
                percent: x.percent,
              }))[0] ?? null,
          },
    privateFields: [
      {
        key: 'mobile',
        label: 'Mobile number',
        masked: maskMobile(currentMobile(s)),
        empty: !currentMobile(s),
      },
      {
        key: 'email',
        label: 'Email',
        masked: maskEmail(currentEmail(s)) ?? 'y••••@thegamification.com',
        empty: false,
      },
      { key: 'gender', label: 'Gender', masked: 'Hidden', empty: false },
      {
        key: 'dob',
        label: 'Date of birth',
        masked: s.dob ? `•• ••• ${year}` : 'Not added',
        empty: !s.dob,
      },
    ],
    skills: s.skills,
  };
}

/** Private fields plus the DigiLocker-linked ID (masked, never revealable), A-272. */
function withId<T extends { privateFields: unknown[] }>(p: T): T {
  const id = linkedId();
  if (!id) return p;
  return {
    ...p,
    privateFields: [
      ...p.privateFields,
      {
        key: 'id',
        label: 'Government ID',
        masked: `${DOC_LABEL[id.doc] ?? 'ID'} ${id.masked}`,
        empty: true,
      },
    ],
  } as T;
}

export const profileHandlers = [
  http.get('/api/profile', async () => {
    await delay(400);
    if (scenario() === 'error') return new HttpResponse(null, { status: 503 });
    return HttpResponse.json(withId(build(load(), scenario() === 'new')));
  }),

  http.post('/api/profile/reveal', async ({ request }) => {
    await delay(250);
    const { field } = (await request.json()) as { field: string };
    const s = load();
    const value =
      field === 'mobile'
        ? currentMobile(s)
        : field === 'email'
          ? currentEmail(s)
          : field === 'gender'
            ? GENDER_LABEL[s.gender]
            : s.dob
              ? formatDob(s.dob)
              : '';
    return HttpResponse.json({ value });
  }),

  http.get('/api/profile/edit', async () => {
    await delay(300);
    const s = load();
    return HttpResponse.json({
      skills: s.skills,
      gender: s.gender,
      dob: s.dob,
      mobile: currentMobile(s),
      email: currentEmail(s),
      skillOptions: SKILL_OPTIONS,
    });
  }),

  // A-273: a new mobile or email needs a code sent to it (test code 123456).
  http.post('/api/profile/contact/code', async ({ request }) => {
    await delay(500);
    const { kind, value } = (await request.json()) as { kind: 'mobile' | 'email'; value: string };
    const ok =
      kind === 'mobile'
        ? /^\d{10}$/.test(value.replace(/\D/g, '').slice(-10))
        : /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(value);
    if (!ok) return HttpResponse.json({ message: 'invalid' }, { status: 422 });
    pending[kind] = value;
    return HttpResponse.json({
      sentTo: kind === 'mobile' ? maskMobile(value) : (maskEmail(value) ?? value),
    });
  }),

  http.post('/api/profile/contact/verify', async ({ request }) => {
    await delay(500);
    const { kind, value, code } = (await request.json()) as {
      kind: 'mobile' | 'email';
      value: string;
      code: string;
    };
    if (pending[kind] !== value || code !== '123456')
      return HttpResponse.json({ message: 'wrong code' }, { status: 422 });
    Reflect.deleteProperty(pending, kind);
    persist({ ...load(), [kind]: value });
    rememberLogin(value);
    return new HttpResponse(null, { status: 204 });
  }),

  http.put('/api/profile', async ({ request }) => {
    await delay(600);
    const edit = (await request.json()) as { skills: string[]; gender: Gender; dob: string };
    const s = load();
    const firstSkills = !s.skills.length && edit.skills.length > 0;
    const next: State = {
      ...s,
      skills: edit.skills.slice(0, 5),
      gender: edit.gender,
      dob: edit.dob,
    };
    persist(next);
    if (firstSkills) creditXp(XP.skills);
    return HttpResponse.json({
      profile: withId(build(next, scenario() === 'new')),
      xpEarned: firstSkills ? XP.skills : 0,
    });
  }),

  http.post('/api/profile/photo', async ({ request }) => {
    await delay(900);
    const data = await request.formData();
    const file = data.get('photo');
    if (!(file instanceof File)) return new HttpResponse(null, { status: 400 });
    const first = photoUrl === null;
    photoUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
    try {
      sessionStorage.setItem(PHOTO_KEY, photoUrl);
    } catch {
      /* too big or private mode: this page only */
    }
    if (first) creditXp(XP.photo);
    return HttpResponse.json({
      profile: withId(build(load(), scenario() === 'new')),
      xpEarned: first ? XP.photo : 0,
    });
  }),
];
