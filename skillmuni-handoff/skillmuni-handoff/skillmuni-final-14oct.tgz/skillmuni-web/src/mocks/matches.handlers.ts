import { HttpResponse, delay, http } from 'msw';
import { environment } from '../environments/environment';
import type { IndustryFit, MatchJob, MatchStatus } from '../app/core/matches/matches.api';

/**
 * My Matches mocks (Figma 200:38000 + MM1–MM6). Jobs appear once the profile is published (Q8 "Send it").
 * Add `?matches=empty` or `?matches=error` to the page URL to see MM2 / MM3.
 */
const KEY = 'sm_mock_published';
let published = (() => {
  try {
    return sessionStorage.getItem(KEY) === '1';
  } catch {
    return false;
  }
})();
const status = new Map<string, MatchStatus>();
/** A confirmed institute claim (V4) shows matches before Vibe Check publishes the profile. */
let claimed = false;
export function markClaimed(): void {
  claimed = true;
}

type Seed = Omit<MatchJob, 'status'> & { readonly start: MatchStatus };

const ZA: readonly Seed[] = [
  {
    id: 'm1',
    title: 'Contact Centre Agent — Learnership',
    employer: 'Ubuntu CX (Pty) Ltd',
    kind: 'learnership',
    location: 'Randburg',
    distanceKm: 4,
    match: 92,
    pay: 'R 6,500 / month stipend · 12 months',
    start: 'invited',
    interviewAt: '2026-10-09T10:00:00',
    industry: 'bpo',
    tipKind: 'boost',
    tip: 'Add Call centre systems proof → +3%',
    skills: [
      { name: 'Customer service', evidence: 'assessed' },
      { name: 'Active listening', evidence: 'declared' },
      { name: 'isiZulu + English', evidence: 'level', note: 'C2 / C1' },
    ],
  },
  {
    id: 'm2',
    title: 'Back Office Assistant',
    employer: 'Sizwe Financial Services',
    kind: 'job',
    location: 'Sandton',
    distanceKm: 11,
    match: 88,
    pay: 'R 8,000 – 9,500 / month',
    start: 'shortlisted',
    interviewAt: null,
    industry: 'finance',
    tipKind: 'boost',
    tip: 'Typing test (5 min) would make Excel Assessed',
    skills: [
      { name: 'Data capturing', evidence: 'verified' },
      { name: 'MS Excel', evidence: 'declared' },
      { name: 'Matric (NSC)', evidence: 'verified' },
    ],
  },
  {
    id: 'm3',
    title: 'Retail Sales Assistant',
    employer: 'Kasi Retail Group',
    kind: 'job',
    location: 'Soweto',
    distanceKm: 18,
    match: 81,
    pay: 'R 5,800 – 6,800 / month',
    start: 'recommended',
    interviewAt: null,
    industry: 'retail',
    tipKind: 'gap',
    tip: 'Weekend shifts required — you said Weekends: no',
    skills: [
      { name: 'Customer service', evidence: 'assessed' },
      { name: 'Conflict resolution', evidence: 'declared' },
    ],
  },
  {
    id: 'm4',
    title: 'Front Desk Trainee (Hospitality)',
    employer: 'Jozi Hotels',
    kind: 'learnership',
    location: 'Rosebank',
    distanceKm: 9,
    match: 76,
    pay: 'R 6,000 / month · learnership',
    start: 'saved',
    interviewAt: null,
    industry: 'hospitality',
    tipKind: 'gap',
    tip: 'Missing: Hospitality NQF 2 (can be done on the job)',
    skills: [
      { name: 'Active listening', evidence: 'declared' },
      { name: 'isiZulu + English', evidence: 'level', note: 'C2 / C1' },
    ],
  },
  {
    id: 'm5',
    title: 'Chat Support Agent',
    employer: 'Ubuntu CX (Pty) Ltd',
    kind: 'job',
    location: 'Remote',
    distanceKm: null,
    match: 74,
    pay: 'R 7,200 / month',
    start: 'recommended',
    interviewAt: null,
    industry: 'bpo',
    tipKind: 'boost',
    tip: 'A typing test would lift this to Strong',
    skills: [{ name: 'Customer service', evidence: 'assessed' }],
  },
  {
    id: 'm6',
    title: 'Stock Controller Assistant',
    employer: 'Mzansi Logistics',
    kind: 'job',
    location: 'Midrand',
    distanceKm: 22,
    match: 64,
    pay: 'R 6,800 / month',
    start: 'recommended',
    interviewAt: null,
    industry: 'logistics',
    tipKind: 'gap',
    tip: 'Missing: Warehousing basics (short course)',
    skills: [{ name: 'Data capturing', evidence: 'verified' }],
  },
];

const IN: readonly Seed[] = [
  {
    id: 'm1',
    title: 'Customer Support Executive — Voice',
    employer: 'Swiggy',
    kind: 'job',
    location: 'Andheri, Mumbai',
    distanceKm: 6,
    match: 92,
    pay: '₹3.2 – 4 LPA',
    start: 'invited',
    interviewAt: '2026-10-09T10:00:00',
    industry: 'bpo',
    tipKind: 'boost',
    tip: 'Add a call-centre certificate → +3%',
    skills: [
      { name: 'Customer service', evidence: 'assessed' },
      { name: 'Communication', evidence: 'declared' },
      { name: 'Hindi + English', evidence: 'level', note: 'C2 / C1' },
    ],
  },
  {
    id: 'm2',
    title: 'Back Office Executive',
    employer: 'HDFC Bank',
    kind: 'job',
    location: 'Powai, Mumbai',
    distanceKm: 11,
    match: 88,
    pay: '₹2.8 – 3.6 LPA',
    start: 'shortlisted',
    interviewAt: null,
    industry: 'finance',
    tipKind: 'boost',
    tip: 'Typing test (5 min) would make Excel Assessed',
    skills: [
      { name: 'Data capturing', evidence: 'verified' },
      { name: 'MS Excel', evidence: 'declared' },
    ],
  },
  {
    id: 'm3',
    title: 'Retail Sales Associate',
    employer: 'Reliance Retail',
    kind: 'job',
    location: 'Malad, Mumbai',
    distanceKm: 14,
    match: 81,
    pay: '₹2.4 – 3 LPA',
    start: 'recommended',
    interviewAt: null,
    industry: 'retail',
    tipKind: 'gap',
    tip: 'Weekend shifts required — you said Weekends: no',
    skills: [{ name: 'Customer service', evidence: 'assessed' }],
  },
  {
    id: 'm4',
    title: 'Hotel Front Office Trainee (NAPS)',
    employer: 'Taj Hotels',
    kind: 'apprenticeship',
    location: 'Colaba, Mumbai',
    distanceKm: 19,
    match: 76,
    pay: '₹15,000 / month stipend',
    start: 'saved',
    interviewAt: null,
    industry: 'hospitality',
    tipKind: 'gap',
    tip: 'Missing: Front office basics (done on the job)',
    skills: [{ name: 'Hindi + English', evidence: 'level', note: 'C2 / C1' }],
  },
  {
    id: 'm5',
    title: 'Chat Support Associate',
    employer: 'Teleperformance',
    kind: 'job',
    location: 'Remote',
    distanceKm: null,
    match: 74,
    pay: '₹2.6 LPA',
    start: 'recommended',
    interviewAt: null,
    industry: 'bpo',
    tipKind: 'boost',
    tip: 'A typing test would lift this to Strong',
    skills: [{ name: 'Customer service', evidence: 'assessed' }],
  },
];

const INDUSTRIES: readonly IndustryFit[] = [
  {
    id: 'bpo',
    name: 'Contact centre & BPO',
    fit: 92,
    why: 'Social + Enterprising interests · strong communication & patience',
    roles: 'Contact centre agent, Chat support',
    path: 'Your contact centre certificate fits',
    pathDone: true,
    jobs: 38,
  },
  {
    id: 'retail',
    name: 'Retail & e-commerce',
    fit: 84,
    why: 'Enjoys helping people, works well under pressure',
    roles: 'Sales assistant, Cashier, Store ops',
    path: 'Short course: Retail basics (8 weeks)',
    pathDone: false,
    jobs: 21,
  },
  {
    id: 'finance',
    name: 'Financial services — operations',
    fit: 78,
    why: 'Detail-focused, good with numbers',
    roles: 'Back office, Data capturer, KYC',
    path: 'Learning path: Banking basics (4 h)',
    pathDone: false,
    jobs: 12,
  },
  {
    id: 'hospitality',
    name: 'Hospitality & tourism',
    fit: 71,
    why: 'Social interests, multilingual',
    roles: 'Front desk, Guest services',
    path: 'Learnership: Hospitality level 2',
    pathDone: false,
    jobs: 9,
  },
  {
    id: 'logistics',
    name: 'Logistics & supply chain admin',
    fit: 64,
    why: 'Organised, reliable',
    roles: 'Stock controller, Dispatch clerk',
    path: 'Short course: Warehousing basics',
    pathDone: false,
    jobs: 6,
  },
];

function force(request: Request): string | null {
  return new URL(request.referrer || 'http://x/').searchParams.get('matches');
}

function jobs(): MatchJob[] {
  const seeds = environment.market === 'ZA' ? ZA : IN;
  return seeds.map(({ start, ...j }) => ({ ...j, status: status.get(j.id) ?? start }));
}

export const matchesHandlers = [
  http.get('/api/me/matches/preview', async () => {
    await delay(500);
    const list = jobs();
    return HttpResponse.json({
      count: 14,
      radiusKm: 25,
      top: list.slice(0, 2).map(({ id, title, kind, match }) => ({ id, title, kind, match })),
    });
  }),

  http.post('/api/me/profile/publish', async () => {
    await delay(900);
    published = true;
    try {
      sessionStorage.setItem(KEY, '1');
    } catch {
      /* private mode: published for this page only */
    }
    return new HttpResponse(null, { status: 204 });
  }),

  http.get('/api/me/matches', async ({ request }) => {
    await delay(700);
    const mode = force(request);
    if (mode === 'error') return new HttpResponse(null, { status: 500 });
    const empty = mode === 'empty' || !(published || claimed);
    const list = empty ? [] : jobs();
    return HttpResponse.json({
      total: empty ? 0 : claimed && !published ? 9 : 14,
      shortlisted: list.filter((j) => j.status === 'shortlisted').length + (empty ? 0 : 1),
      invites: list.filter((j) => j.status === 'invited').length,
      profileComplete: 100,
      visible: published,
      jobs: list,
      industries: INDUSTRIES,
      compass: {
        takenOn: '2026-09-12',
        summary:
          'Top interests: Social, Enterprising · Strengths: communication, patience, reliability. Industry fit = interests + strengths + your skills + local demand.',
      },
    });
  }),

  http.post('/api/me/matches/:id/apply', async ({ params }) => {
    await delay(600);
    status.set(String(params['id']), 'applied');
    return new HttpResponse(null, { status: 204 });
  }),

  http.post('/api/me/matches/:id/save', async ({ params, request }) => {
    await delay(300);
    const { saved } = (await request.json()) as { saved: boolean };
    status.set(String(params['id']), saved ? 'saved' : 'recommended');
    return new HttpResponse(null, { status: 204 });
  }),

  http.post('/api/me/matches/:id/accept', async ({ params }) => {
    await delay(600);
    status.set(String(params['id']), 'accepted');
    return new HttpResponse(null, { status: 204 });
  }),
];
