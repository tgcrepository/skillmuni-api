import { levelFor, LADDER, QUEST_XP, STEP_XP } from '../app/core/quests/levels';
import { totalXp } from './xp-ledger';
import { assessmentSnapshot } from './assessment.handlers';
import { isNewLearner, learnerName } from './persona';
import { profileProgress } from './profile-progress';
import { mockProgress } from './quest.handlers';

/**
 * Muni's platform knowledge (A-282). Stands in for the real assistant: every answer is about the
 * signed-in learner (their name, XP, level, quests, profile gaps) and explains a feature in plain
 * steps with links to the right screen. Keyword-scored, so "how do i get xp" and "earn points"
 * land on the same answer. Swap for the backend when it lands; the reply shape stays the same.
 */

type Block =
  | { kind: 'text'; text: string }
  | { kind: 'list'; items: { title: string; detail: string; tag?: string; url: string }[] }
  | {
      kind: 'stats';
      items: { label: string; value: string; icon: string }[];
      link: { label: string; url: string };
    };

export interface Reply {
  blocks: Block[];
  chips: string[];
}

export interface Me {
  first: string;
  fresh: boolean;
  xp: number;
  level: number;
  rank: string;
  toNext: number;
  questsDone: number;
  profilePct: number;
  gaps: { quest: string; left: string; url: string }[];
  archetype: string | null;
}

export function me(): Me {
  const fresh = isNewLearner();
  const xp = totalXp();
  const l = levelFor(xp);
  const p = profileProgress();
  return {
    first: learnerName().first,
    fresh,
    xp,
    level: l.level,
    rank: l.rank,
    toNext: Math.max(0, l.target - xp),
    questsDone: fresh ? mockProgress.completed : 8,
    profilePct: p.percent,
    gaps: p.quests
      .filter((q) => q.left.length)
      .map((q) => ({
        quest: q.name,
        left: q.left.map((x) => x.label).join(', '),
        url: `/quests/${q.slug}?part=${q.left[0]?.part ?? 1}`,
      })),
    archetype: assessmentSnapshot()?.archetype?.name ?? (fresh ? null : 'The Connector'),
  };
}

const t = (text: string): Block => ({ kind: 'text', text });
const link = (title: string, detail: string, url: string, tag?: string) => ({
  title,
  detail,
  url,
  ...(tag ? { tag } : {}),
});

interface Topic {
  id: string;
  /** Words that point here; longer phrases score higher. */
  keys: string[];
  answer: (m: Me) => Reply;
}

const TOPICS: Topic[] = [
  {
    id: 'xp',
    keys: ['xp', 'points', 'earn', 'experience', 'how do i get', 'level up', 'score'],
    answer: (m) => ({
      blocks: [
        t(
          `XP is how Skillmuni keeps score, ${m.first} ⚡ You’ve got ${m.xp} XP right now, Level ${m.level} · ${m.rank}${m.toNext ? `, ${m.toNext} XP to the next level` : ''}.`,
        ),
        t(
          `Ways to earn it:\n• Quests: +${STEP_XP} XP for every step, +${QUEST_XP} XP when a quest is done (an all-optional step pays once you add something to it)\n• Learning: +1 XP for every right answer in a brief’s quiz\n• Career Drivers assessment: +25 XP per island, 100 XP in all (first time)\n• Your first moves on the Lobby: +50 XP bonus\n• Launchpad missions (once each): finish your job profile +50, first job application +100, first Hire Fest slot +100\n• Today’s quests: the XP shown on each, when you clear it\n• Profile: +5 XP for your first photo, +10 XP for your top skills\n• Programme bonus quest: +100 XP\n• Monthly feedback: +5 XP\nXP never expires, and it’s what ranks you in the Arena.`,
        ),
        {
          kind: 'list',
          items: [
            link('Keep learning', 'Short briefs + quick quizzes', '/home', '+1 XP each'),
            link('See your XP and badges', 'My Stats · Rewards dashboard', '/stats'),
          ],
        },
      ],
      chips: ['How do levels work?', 'XP vs credits', 'How does the Arena work?'],
    }),
  },
  {
    id: 'levels',
    keys: ['level', 'levels', 'rank', 'rookie', 'pathfinder', 'trailblazer', 'legend', 'icon'],
    answer: (m) => ({
      blocks: [
        t(
          `Levels go up as your XP grows. You’re Level ${m.level} · ${m.rank}.\n${LADDER.map((l) => `• Level ${l.level} ${l.rank}: from ${l.min} XP`).join('\n')}`,
        ),
        t(
          m.toNext
            ? `${m.toNext} XP to go. A couple of quizzes and a quest step get you most of the way 💪`
            : 'You’re at the top of the ladder. Legend behaviour 👑',
        ),
      ],
      chips: ['How do I earn XP?', 'How does the Arena work?'],
    }),
  },
  {
    id: 'currency',
    keys: ['coin', 'coins', 'credit', 'credits', 'wallet', 'currency', 'money', 'spend'],
    answer: () => ({
      blocks: [
        t(
          'Three things to collect, each with its own job:\n• ⚡ XP: your score. Levels you up and ranks you in the Arena. Never spent.\n• Coins and the rewards store are coming later. For now, everything you do pays XP.\n• 🎓 Credits: earned by finishing courses and certificates. They show your learning on your CV.',
        ),
        {
          kind: 'list',
          items: [link('Your wallet', 'XP and credits in one place', '/stats')],
        },
      ],
      chips: ['How do I earn XP?', 'What are daily quests?'],
    }),
  },
  {
    id: 'quests',
    keys: ['quest', 'quests', 'registration', 'register', 'onboarding', 'who dis', 'steps', 'skip'],
    answer: (m) => ({
      blocks: [
        t(
          `The 8 quests are how you register and build your job profile 🗺️ You’ve finished ${m.questsDone} of 8.\n• Each quest has 1–3 short steps (+${STEP_XP} XP each) and a badge at the end (+${QUEST_XP} XP)\n• Everything autosaves; “Save & exit” picks up exactly where you left\n• Optional steps can be skipped and filled later from My Job Profile`,
        ),
        {
          kind: 'list',
          items: [link('Open your quests', 'See which ones are done', '/welcome-back')],
        },
      ],
      chips: ['What’s left in my profile?', 'How do I earn XP?'],
    }),
  },
  {
    id: 'profile',
    keys: ['job profile', 'profile', 'cv', 'resume', 'left', 'missing', 'complete', 'fill', 'gaps'],
    answer: (m) => ({
      blocks: [
        t(
          m.gaps.length
            ? `Your job profile is ${m.profilePct}% done, ${m.first}. It’s built from your quests, so filling a gap is one tap away:`
            : `Your job profile is 100% done, ${m.first} 🎉 Recruiters see everything you shared, and your CV updates itself.`,
        ),
        ...(m.gaps.length
          ? [
              {
                kind: 'list' as const,
                items: m.gaps.map((g) => link(g.quest, `Left: ${g.left}`, g.url, 'Fill')),
              },
            ]
          : []),
        t(
          'Tip: on My Job Profile, “Edit” on any section opens just that section, already filled in, with Save to bring you straight back.',
        ),
      ],
      chips: ['How does job matching work?', 'Is my ID safe?'],
    }),
  },
  {
    id: 'jobs',
    keys: ['job', 'jobs', 'match', 'matching', 'apply', 'application', 'hire', 'hiring', 'work'],
    answer: (m) => ({
      blocks: [
        t(
          `My Jobs has four tabs: Available, Matching, Invitations and Applied.\n• Matching ranks jobs by your skills, education, languages, where you want to work and your Career Drivers\n• It’s never locked; the fuller your profile (yours is ${m.profilePct}%), the sharper the matches\n• Apply in two taps with your Skillmuni CV, then track it in Applied`,
        ),
        {
          kind: 'list',
          items: [
            link(
              'Customer Support Executive',
              'Teleperformance · Mumbai',
              '/jobs/matching',
              '92% match',
            ),
            link('Retail Associate', 'Reliance Trends · Pune', '/jobs/matching', '86% match'),
          ],
        },
      ],
      chips: ['What’s Hire Fest?', 'What’s left in my profile?'],
    }),
  },
  {
    id: 'fest',
    keys: ['hire fest', 'fest', 'career fest', 'recruiter', 'interview', 'slot', 'book', 'ticket'],
    answer: () => ({
      blocks: [
        t(
          'Hire Fest is a recruitment day: meet employers, interview on the spot 🎪\n• Pick a fest, choose employers and time slots, and get one ticket for the day\n• You need a job profile at least 60% done to book\n• Reschedule or cancel anytime from My bookings',
        ),
        { kind: 'list', items: [link('Upcoming fests', 'Book a slot', '/hire-fest')] },
      ],
      chips: ['How does job matching work?', 'What’s left in my profile?'],
    }),
  },
  {
    id: 'assessment',
    keys: ['assessment', 'career drivers', 'archetype', 'personality', 'test', 'compass'],
    answer: (m) => ({
      blocks: [
        t(
          m.archetype
            ? `Your archetype is ${m.archetype}. It’s the mix of what drives you at work, and it powers your job matches.`
            : 'Career Drivers is 36 quick this-or-that picks (about 12 minutes). No right answers, just you.',
        ),
        t(
          '• Lean left or right on each pair; you can undo\n• At the end you get your archetype, your top drivers and where you’ll thrive\n• It’s saved as you go, so you can pause anytime',
        ),
        {
          kind: 'list',
          items: [
            link(
              m.archetype ? 'See your full results' : 'Start Career Drivers',
              m.archetype ? 'Drivers, thrive zones, courses' : '36 picks · 6 min',
              m.archetype ? '/assessments/career/report' : '/assessments/career',
            ),
          ],
        },
      ],
      chips: ['How does job matching work?', 'How do I earn XP?'],
    }),
  },
  {
    id: 'arena',
    keys: ['arena', 'leaderboard', 'top', 'crown', 'batch', 'league', 'compete', 'friends'],
    answer: (m) => ({
      blocks: [
        t(
          `The Arena ranks learners by XP 🏆\n• Switch between Everyone, My batch and Friends, and This week, This month or All time\n• The weekly board resets every Monday at midnight\n• Top 3 each week move up a league\nYou have ${m.xp} XP in total.`,
        ),
        {
          kind: 'stats',
          items: [
            { label: 'Total XP', value: String(m.xp), icon: 'zap' },
            { label: 'Level', value: String(m.level), icon: 'trophy' },
          ],
          link: { label: 'Open the Arena', url: '/arena' },
        },
      ],
      chips: ['How do I earn XP?', 'How do streaks work?'],
    }),
  },
  {
    id: 'streak',
    keys: ['streak', 'daily', 'every day', 'fire', 'flame'],
    answer: () => ({
      blocks: [
        t(
          'A streak counts the days in a row you learn 🔥\n• Finish at least one brief’s quiz a day to keep it alive\n• Streaks unlock streak badges\n• Miss a day and it goes back to 0, so pick a time that works for you',
        ),
      ],
      chips: ['What are daily quests?', 'How do badges work?'],
    }),
  },
  {
    id: 'daily',
    keys: ['daily quest', 'today', 'mystery chest', 'challenge'],
    answer: () => ({
      blocks: [
        t(
          'Today’s quests are three small goals that reset every night: finish a module, learn for 15 minutes, score 80%+ on a quiz. Each pays the XP shown when you clear it that day. Chest rewards are coming soon 🎁',
        ),
        { kind: 'list', items: [link('Today’s quests', 'My Stats · Rewards', '/stats')] },
      ],
      chips: ['XP vs credits', 'How do streaks work?'],
    }),
  },
  {
    id: 'badges',
    keys: ['badge', 'badges', 'showcase', 'pin', 'achievement', 'unlock'],
    answer: () => ({
      blocks: [
        t(
          'Badges mark milestones: quests, learning, quizzes, streaks and more 🏅\n• Each quest gives one when you finish it\n• “Closest to unlock” on My Stats shows what you’re near\n• Pin up to 3 to your showcase so they show on your Player ID',
        ),
        { kind: 'list', items: [link('My badges', 'All 48, with progress', '/stats/badges')] },
      ],
      chips: ['How do I earn XP?', 'How do streaks work?'],
    }),
  },
  {
    id: 'learn',
    keys: [
      'learn',
      'learning',
      'module',
      'modules',
      'knook',
      'brief',
      'briefs',
      'quiz',
      'course',
      'brain vita',
    ],
    answer: () => ({
      blocks: [
        t(
          'Learning lives in Knooks (shelves of modules) on the Lobby 📚\n• Each module has short briefs (about 2 minutes each)\n• Each brief ends with a quick quiz: +1 XP per right answer\n• Retrying a passed quiz is practice: no XP, but it locks the learning in',
        ),
        {
          kind: 'list',
          items: [
            link('Brain Vita', 'Pick up where you left off', '/learn/brain-vita'),
            link('All Skill Knook modules', 'Browse everything', '/knooks/skill-knook'),
          ],
        },
      ],
      chips: ['How do I earn XP?', 'How do streaks work?'],
    }),
  },
  {
    id: 'id',
    keys: ['aadhaar', 'digilocker', 'id', 'pan', 'passport', 'privacy', 'safe', 'data', 'secure'],
    answer: () => ({
      blocks: [
        t(
          'Your ID is safe 🔒\n• We never store your Aadhaar, PAN or licence number, or a copy of the document\n• You link it through DigiLocker (Government of India), and only the last 4 characters stay with us\n• Mobile and email stay masked until you tap the eye, and employers never see your ID',
        ),
        { kind: 'list', items: [link('Private details', 'Profile · Edit profile', '/profile')] },
      ],
      chips: ['How do I change my mobile?', 'What’s left in my profile?'],
    }),
  },
  {
    id: 'account',
    keys: [
      'change',
      'mobile',
      'email',
      'phone',
      'number',
      'photo',
      'picture',
      'edit',
      'gender',
      'birthday',
      'dob',
    ],
    answer: () => ({
      blocks: [
        t(
          'All in Profile → Edit profile ✏️\n• Mobile or email: type the new one, we send a 6-digit code to it, and it saves once the code matches\n• Gender and date of birth: pick and save\n• Photo: tap the camera on your Player ID card; it shows in the top bar right away',
        ),
        { kind: 'list', items: [link('Edit profile', 'Private details', '/profile')] },
      ],
      chips: ['Is my ID safe?', 'How do I earn XP?'],
    }),
  },
  {
    id: 'sound',
    keys: ['sound', 'voice', 'mute', 'audio', 'speak', 'talk', 'quiet'],
    answer: () => ({
      blocks: [
        t(
          'Sound effects can be turned on or off in Profile → Settings 🔊 It remembers your choice on this device.',
        ),
      ],
      chips: ['What can you do?'],
    }),
  },
  {
    id: 'muni',
    keys: [
      'what can you do',
      'help',
      'who are you',
      'muni',
      'features',
      'how does this work',
      'guide',
    ],
    answer: (m) => ({
      blocks: [
        t(
          `I’m Muni, your Skillmuni buddy 🤙 Ask me anything about the platform, ${m.first}. I’m best at:\n• Your progress: XP, level, rank, badges\n• Your job profile and what’s left to fill\n• Jobs, matching and Hire Fest\n• Learning, quizzes and streaks\n• Privacy, your ID and account settings`,
        ),
      ],
      chips: ['How do I earn XP?', 'What’s left in my profile?', 'How does job matching work?'],
    }),
  },
];

const words = (s: string) => s.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, ' ');

/** Best topic for a question, or null when nothing fits well enough. */
export function answer(question: string): Reply | null {
  const q = ` ${words(question).replace(/\s+/g, ' ').trim()} `;
  let best: { topic: Topic; score: number } | null = null;
  for (const topic of TOPICS) {
    let score = 0;
    for (const k of topic.keys)
      if (q.includes(` ${k} `) || (k.includes(' ') && q.includes(k)))
        score += k.split(' ').length * 2;
    // Plurals and stems: "badges" vs "badge", "matching" vs "match".
    for (const k of topic.keys) if (!k.includes(' ') && k.length > 3 && q.includes(k)) score += 1;
    if (score && (!best || score > best.score)) best = { topic, score };
  }
  return best ? best.topic.answer(me()) : null;
}

export function greeting(): Reply {
  const m = me();
  return {
    blocks: [
      t(
        `Heyyy ${m.first} 👋 You’re Level ${m.level} · ${m.rank} with ${m.xp} XP. Ask me anything about Skillmuni: XP, jobs, your profile, Hire Fest, the Arena…`,
      ),
    ],
    chips: ['What can you do?', 'How do I earn XP?', 'What’s left in my profile?'],
  };
}

export function fallback(): Reply {
  const m = me();
  return {
    blocks: [
      t(
        `Hmm, I don’t have that one yet, ${m.first} 🤔 Try asking it another way, or pick one of these. I know the platform inside out.`,
      ),
    ],
    chips: ['What can you do?', 'How do I earn XP?', 'How does job matching work?'],
  };
}
