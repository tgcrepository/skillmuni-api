import { HttpResponse, delay, http } from 'msw';
import { environment } from '../environments/environment';
import { mockSession } from './auth.handlers';
import { markClaimed } from './matches.handlers';
import { mockProgress, persistQuests, seedAnswers, syncLevel } from './quest.handlers';
import { QUESTS, questXp } from '../app/core/quests/quest-catalog';

/** A claimed account arrives with quests 1–5 done (A-321: their real XP, 550); 6–8 are left. */
const CLAIMED_XP = QUESTS.slice(0, 5).reduce((n, q) => n + questXp(q), 0);
const xpOf = (id: number): number => {
  const q = QUESTS[id - 1];
  return q ? questXp(q) : 0;
};

/**
 * Institute claim mocks. Links: /claim/psa-15-aarav works; /claim/claimed and /claim/expired are used up;
 * anything else is not found. Code 123456 is right, 000000 is expired, others are wrong (5 tries).
 */
/** Corrections #7: unlimited tries for people; 20 wrong codes in a row is the hidden anti-bot limit. */
const MAX_TRIES = 20;
let tries = MAX_TRIES;
const rejected = new Set<string>();

/** Claim progress survives a full reload (learner reopens the SMS link after editing a quest). */
const KEY = 'sm_mock_claim';
interface Progress {
  verified: boolean;
  consented: boolean;
  confirmed: string[];
  result: object | null;
}
function load(): Progress {
  try {
    return {
      verified: false,
      consented: false,
      confirmed: [],
      result: null,
      ...JSON.parse(sessionStorage.getItem(KEY) ?? '{}'),
    };
  } catch {
    return { verified: false, consented: false, confirmed: [], result: null };
  }
}
const state = load();
const confirmed = new Set<string>(state.confirmed);
function save(): void {
  state.confirmed = [...confirmed];
  try {
    sessionStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* private mode: this page only */
  }
}
const market = () => (environment.market === 'ZA' ? 'ZA' : 'IN');

const INVITE = {
  IN: {
    institute: 'Pune Skills Academy',
    name: 'Aarav Mehta',
    programme: 'Customer Care Executive (Domestic Voice) · NSQF L4',
    batch: 'Pune batch 15 · completed 30 Sep 2026',
    fromCv: 'Contact, education, 8 skills, 2 languages, 1 job',
    sentTo: '+91 98•••• 4521',
    certificate: 'NSQF L4 certificate',
  },
  ZA: {
    institute: 'Ubuntu Skills Academy',
    name: 'Nkosazana Dlamini',
    programme: 'Contact Centre Support · NQF 4 learnership',
    batch: 'Randburg cohort 7 · completed 30 Sep 2026',
    fromCv: 'Contact, education, 8 skills, 2 languages, 1 job',
    sentTo: '+27 82••• 4521',
    certificate: 'NQF 4 certificate',
  },
};

const row = (label: string, value: string, source: string | null, issue?: string) => ({
  label,
  value,
  source,
  ...(issue ? { issue } : {}),
});

const SECTIONS = {
  IN: [
    {
      slug: 'who-dis',
      quest: 1,
      title: 'Who Dis?',
      summary: 'Aarav Mehta · date of birth added by you',
      rows: [row('Name', 'Aarav Mehta', 'institute'), row('Date of birth', '14 Mar 2005', 'you')],
    },
    {
      slug: 'hit-me-up',
      quest: 2,
      title: 'Hit Me Up',
      summary: '+91 98•••• 4521 verified · Kothrud, Pune 411038',
      rows: [
        row('Mobile', '+91 98•••• 4521', 'verified'),
        row('Address', 'Kothrud, Pune 411038', 'institute'),
      ],
    },
    {
      slug: 'big-brain-stuff',
      quest: 3,
      title: 'Big Brain Stuff',
      summary: '12th (HSC) · NSQF L4 certificate',
      rows: [
        row('Highest level', '12th (HSC) · Maharashtra State Board · 2023', 'institute'),
        row('Certificate', 'Customer Care Executive (Domestic Voice) · NSQF L4 · 2026', 'verified'),
        row('Marks', '72% · optional', null),
      ],
    },
    {
      slug: 'your-flex-era',
      quest: 4,
      title: 'Your Flex Era',
      summary: '8 skills · Hindi (Native), English (Fluent), Marathi (Conversational)',
      rows: [
        row('Skills', 'Customer service, Active listening, MS Excel, Data entry +4', 'institute'),
        row('Languages', 'Hindi (Native), English (Fluent), Marathi (Conversational)', 'institute'),
      ],
    },
    {
      slug: 'work-lore',
      quest: 5,
      title: 'Work Lore',
      summary: 'Customer support intern · Concentrix · end date missing',
      rows: [
        row(
          'Customer support intern',
          'Concentrix · Jun 2025 – ?',
          'institute',
          'End date missing. Still there? Add it or tap Looks right.',
        ),
      ],
    },
  ],
  ZA: [
    {
      slug: 'who-dis',
      quest: 1,
      title: 'Who Dis?',
      summary: 'Nkosazana Dlamini · date of birth added by you',
      rows: [
        row('Name', 'Nkosazana Dlamini', 'institute'),
        row('Date of birth', '2 Aug 2004', 'you'),
      ],
    },
    {
      slug: 'hit-me-up',
      quest: 2,
      title: 'Hit Me Up',
      summary: '+27 82••• 4521 verified · Randburg 2194',
      rows: [
        row('Mobile', '+27 82••• 4521', 'verified'),
        row('Address', 'Randburg, Johannesburg 2194', 'institute'),
      ],
    },
    {
      slug: 'big-brain-stuff',
      quest: 3,
      title: 'Big Brain Stuff',
      summary: 'Matric (NSC) · NQF 4 certificate',
      rows: [
        row('Highest level', 'Matric (NSC) · 2022', 'institute'),
        row('Certificate', 'Contact Centre Support · NQF 4 · 2026', 'verified'),
        row('Marks', '68% · optional', null),
      ],
    },
    {
      slug: 'your-flex-era',
      quest: 4,
      title: 'Your Flex Era',
      summary: '8 skills · isiZulu (Native), English (Fluent), Sesotho (Conversational)',
      rows: [
        row('Skills', 'Customer service, Active listening, Data capturing +5', 'institute'),
        row(
          'Languages',
          'isiZulu (Native), English (Fluent), Sesotho (Conversational)',
          'institute',
        ),
      ],
    },
    {
      slug: 'work-lore',
      quest: 5,
      title: 'Work Lore',
      summary: 'Call centre intern · Ubuntu CX · end date missing',
      rows: [
        row(
          'Call centre intern',
          'Ubuntu CX · Jun 2025 – ?',
          'institute',
          'End date missing. Still there? Add it or tap Looks right.',
        ),
      ],
    },
  ],
};

function sections() {
  return SECTIONS[market()].map((sec) => ({
    ...sec,
    status: confirmed.has(sec.slug) ? 'confirmed' : sec.slug === 'work-lore' ? 'fix' : 'review',
  }));
}

// Re-apply a claim made earlier in this tab after a full reload.
if (state.consented) mockProgress.completed = Math.max(mockProgress.completed, 5);
if (state.result) {
  mockProgress.xp = Math.max(mockProgress.xp, CLAIMED_XP);
  mockProgress.badges = Math.max(mockProgress.badges, 5);
  syncLevel();
  markClaimed();
}

const gone = (code: string) =>
  HttpResponse.json({ message: code, errors: { code: [code] } }, { status: 410 });

export const claimHandlers = [
  http.get('/api/claims/:token', async ({ params }) => {
    await delay(600);
    const token = String(params['token']);
    if (token === 'claimed' || token === 'expired') return gone(token);
    if (rejected.has(token)) return gone('deleted');
    if (token !== 'psa-15-aarav') return new HttpResponse(null, { status: 404 });
    tries = MAX_TRIES;
    const resume = state.verified
      ? {
          stage: state.result ? 'confirmed' : state.consented ? 'validate' : 'consent',
          sections: state.consented ? sections() : [],
          result: state.result,
        }
      : undefined;
    return HttpResponse.json({
      ...INVITE[environment.market === 'ZA' ? 'ZA' : 'IN'],
      resendIn: 24,
      triesLeft: MAX_TRIES,
      deleteBy: '2026-10-30',
      ...(resume ? { resume } : {}),
    });
  }),

  http.post('/api/claims/:token/otp', async () => {
    await delay(400);
    tries = MAX_TRIES;
    const invite = INVITE[environment.market === 'ZA' ? 'ZA' : 'IN'];
    return HttpResponse.json({ sentTo: invite.sentTo, resendIn: 30, triesLeft: MAX_TRIES });
  }),

  http.post('/api/claims/:token/verify', async ({ request }) => {
    await delay(500);
    const { code } = (await request.json()) as { code: string };
    if (code === '000000')
      return HttpResponse.json({ errors: { code: ['code-expired'] } }, { status: 410 });
    if (code === '123456') {
      state.verified = true;
      save();
      const invite = INVITE[environment.market === 'ZA' ? 'ZA' : 'IN'];
      mockSession(true);
      return HttpResponse.json({
        id: 'u-claim',
        firstName: invite.name.split(' ')[0],
        phone: invite.sentTo,
      });
    }
    tries -= 1;
    if (tries <= 0)
      return HttpResponse.json({ errors: { code: ['too-many-tries'] } }, { status: 429 });
    return HttpResponse.json(
      { errors: { code: ['invalid-code'], triesLeft: [String(tries)] } },
      { status: 422 },
    );
  }),

  http.post('/api/claims/:token/consent', async () => {
    await delay(700);
    state.consented = true;
    save();
    // Pre-filled quests 1–5 open for editing from V3 (XP is granted when the profile is confirmed).
    mockProgress.completed = Math.max(mockProgress.completed, 5);
    persistQuests();
    return HttpResponse.json(sections());
  }),

  http.post('/api/claims/:token/sections/:slug/confirm', async ({ params }) => {
    await delay(300);
    confirmed.add(String(params['slug']));
    save();
    return new HttpResponse(null, { status: 204 });
  }),

  http.post('/api/claims/:token/finish', async () => {
    await delay(800);
    const [first = '', last = ''] = INVITE[market()].name.split(' ');
    seedAnswers('who-dis', { firstName: first, lastName: last });
    Object.assign(mockProgress, { completed: Math.max(mockProgress.completed, 5), partsDone: 0 });
    mockProgress.xp = Math.max(mockProgress.xp, CLAIMED_XP);
    mockProgress.badges = Math.max(mockProgress.badges, 5);
    syncLevel();
    markClaimed();
    state.result = {
      profilePercent: 80,
      verifiedItems: 2,
      jobs: 9,
      xpLeft: xpOf(6) + xpOf(7) + xpOf(8),
      minutesLeft: 6,
      left: [
        {
          quest: 6,
          slug: 'pick-your-arc',
          name: 'Pick Your Arc',
          blurb: 'Jobs you want, where, when you can start',
          xp: xpOf(6),
        },
        {
          quest: 7,
          slug: 'drop-the-receipts',
          name: 'Drop the Receipts',
          blurb: `Your ${INVITE[market()].certificate} is already verified ✓`,
          xp: xpOf(7),
        },
        {
          quest: 8,
          slug: 'vibe-check',
          name: 'Vibe Check',
          blurb: 'Review and choose who can see you',
          xp: xpOf(8),
        },
      ],
    };
    save();
    return HttpResponse.json(state.result);
  }),

  http.post('/api/claims/:token/decline', async ({ params }) => {
    await delay(600);
    rejected.add(String(params['token']));
    Object.assign(state, { verified: false, consented: false, result: null });
    confirmed.clear();
    save();
    return new HttpResponse(null, { status: 204 });
  }),
];
