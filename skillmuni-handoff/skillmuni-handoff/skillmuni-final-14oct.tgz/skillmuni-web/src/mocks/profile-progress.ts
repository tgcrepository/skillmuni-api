import { QUESTS } from '../app/core/quests/quest-catalog';
import { QUEST_SCREENS } from '../app/features/quests/quest-defs';
import { isNewLearner } from './persona';
import { mockProgress, questAnswers } from './quest.handlers';

/**
 * A-262: the job profile is built from the 8 registration quests, so its completeness is read quest
 * by quest: every step counts, and a step the learner skipped (optional ones) is what's "left".
 */
export interface QuestStep {
  readonly key: string;
  readonly label: string;
  /** 1-based step, for `?part=` deep links into the quest. */
  readonly part: number;
}

export interface QuestStatus {
  readonly id: number;
  readonly slug: string;
  readonly name: string;
  readonly filled: number;
  readonly total: number;
  readonly left: readonly QuestStep[];
}

export interface ProfileProgress {
  readonly percent: number;
  readonly filled: number;
  readonly total: number;
  readonly quests: readonly QuestStatus[];
}

/** The sample returning learner finished every quest but skipped three optional steps. */
const SAMPLE_SKIPPED: Readonly<Record<string, readonly string[]>> = {
  'hit-me-up': ['backup'],
  'big-brain-stuff': ['timeline'],
  'your-flex-era': ['trophies'],
};

const clean = (label: string) => label.replace(/\s*(·\s*optional|\(optional\))\s*$/i, '').trim();

export function profileProgress(): ProfileProgress {
  const fresh = isNewLearner();
  const quests = QUESTS.map((q, i): QuestStatus => {
    const parts = QUEST_SCREENS[q.slug]?.parts ?? [];
    const answers = questAnswers(q.slug);
    const left = parts
      .map((p, j) => ({ key: p.key, label: clean(p.label), part: j + 1 }))
      .filter((p) => {
        if (!fresh) return SAMPLE_SKIPPED[q.slug]?.includes(p.key) ?? false;
        if (i + 1 > mockProgress.completed) {
          // Quest in progress: steps past the last one saved; later quests: everything.
          return i === mockProgress.completed ? p.part > mockProgress.partsDone : true;
        }
        return answers[`${p.key}Skipped`] === true;
      });
    return {
      id: q.id,
      slug: q.slug,
      name: q.name,
      filled: parts.length - left.length,
      total: parts.length,
      left,
    };
  });
  const total = quests.reduce((n, q) => n + q.total, 0);
  const filled = quests.reduce((n, q) => n + q.filled, 0);
  return { percent: total ? Math.round((filled / total) * 100) : 0, filled, total, quests };
}

/** Quest names that still have gaps, for chips ("Hit Me Up", "Your Flex Era"…). */
export function questsWithGaps(p = profileProgress()): string[] {
  return p.quests.filter((q) => q.left.length).map((q) => q.name);
}
