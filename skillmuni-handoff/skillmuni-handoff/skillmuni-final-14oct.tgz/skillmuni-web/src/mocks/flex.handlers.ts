import { HttpResponse, delay, http } from 'msw';
import { escoSearch } from './esco.data';

/**
 * Q4 trophy mocks. Link check: URLs containing "verify" or "credential" match the learner's name
 * (→ Verified); "fail" times out. Upload: any file. DigiLocker returns two Skill India / NPTEL certificates.
 */
export const flexHandlers = [
  /** ESCO skill search proxy (A-245). `?q=esco-down` fails so the offline fallback can be seen. */
  http.get('/api/skills/esco', async ({ request }) => {
    const url = new URL(request.url);
    const q = url.searchParams.get('q') ?? '';
    await delay(220);
    if (q.includes('esco-down')) return new HttpResponse(null, { status: 503 });
    return HttpResponse.json(escoSearch(q, Number(url.searchParams.get('limit')) || 24));
  }),

  http.post('/api/me/trophies/check-link', async ({ request }) => {
    const { url } = (await request.json()) as { url: string };
    await delay(url.includes('fail') ? 5200 : 900);
    if (url.includes('fail')) return new HttpResponse(null, { status: 504 });
    return HttpResponse.json({ verified: /verify|credential/i.test(url) });
  }),

  http.post('/api/me/trophies/files', async () => {
    await delay(800);
    return HttpResponse.json({ fileId: `f_${Date.now().toString(36)}` });
  }),

  http.post('/api/me/trophies/digilocker', async () => {
    await delay(1200);
    return HttpResponse.json([
      {
        name: 'NPTEL Programming in Java',
        issuer: 'NPTEL · IIT Kharagpur',
        issuedOn: '2023-10',
        credentialId: 'NPTEL23CS74S4',
      },
      {
        name: 'Skill India: Customer Care Executive',
        issuer: 'NSDC · Skill India',
        issuedOn: '2024-03',
        credentialId: 'SI-CCE-88213',
      },
    ]);
  }),
];
