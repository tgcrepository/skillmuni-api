import { profileProgress } from './profile-progress';
import { HttpResponse, delay, http } from 'msw';

/**
 * My Job Profile v2 (Figma 308:43436). Sample record from the design. In the real app the server
 * builds this from the 8 registration quests (one record, no second form).
 * Page URL scenarios (`?jp=`): fresher (P7) · finish (P6, sections to finish) · error.
 * Accepted CV changes (P5) and a rewritten "About me" live in sessionStorage.
 */

const KEY = 'sm_mock_job_profile';

interface State {
  about: string | null;
  added: string[];
  hideContact: boolean;
  expiresDays: number;
}

function scenario(): string {
  return typeof location === 'undefined'
    ? ''
    : (new URLSearchParams(location.search).get('jp') ?? '');
}

function load(): State {
  const base: State = { about: null, added: [], hideContact: true, expiresDays: 30 };
  try {
    const raw = sessionStorage.getItem(KEY);
    return raw ? { ...base, ...(JSON.parse(raw) as Partial<State>) } : base;
  } catch {
    return base;
  }
}

function save(s: State): void {
  try {
    sessionStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* private mode */
  }
}

const MUNI_ABOUT =
  'Customer-first B.Com graduate with 6 months of voice support at Teleperformance and a year of retail sales. Calm on tough calls, quick on Excel, fluent in English, Hindi and Marathi. Looking for a full-time customer support or BPO voice role in Pune.';

const SOURCES = {
  about: { slug: 'who-dis', part: 1, name: 'Who Dis?' },
  contact: { slug: 'hit-me-up', part: 1, name: 'Hit Me Up' },
  work: { slug: 'work-lore', part: 1, name: 'Work Lore' },
  education: { slug: 'big-brain-stuff', part: 1, name: 'Big Brain Stuff' },
  languages: { slug: 'your-flex-era', part: 2, name: 'Your Flex Era' },
  skills: { slug: 'your-flex-era', part: 1, name: 'Your Flex Era' },
  certificates: { slug: 'drop-the-receipts', part: 1, name: 'Drop the Receipts' },
  lookingFor: { slug: 'pick-your-arc', part: 1, name: 'Pick Your Arc' },
};

const CHANGES = [
  {
    id: 'job-concentrix',
    kind: 'job',
    title: 'Customer Support Executive · Concentrix',
    detail: 'New job · Jul 2025 – now',
    suggest: 'add',
  },
  { id: 'skill-freshdesk', kind: 'skill', title: 'Freshdesk', detail: 'New skill', suggest: 'add' },
  {
    id: 'cert-udemy',
    kind: 'certificate',
    title: 'Customer Service Excellence · Udemy',
    detail: 'New certificate · needs proof to verify',
    suggest: 'add',
  },
  {
    id: 'email-outlook',
    kind: 'contact',
    title: 'Email: yash.p@outlook.com',
    detail: 'Different from your verified email',
    suggest: 'keep',
  },
];

function build(s: State) {
  const sc = scenario();
  const fresher = sc === 'fresher';
  const has = (id: string) => s.added.includes(id);
  const work = fresher
    ? []
    : [
        ...(has('job-concentrix')
          ? [
              {
                id: 'concentrix',
                initials: 'CX',
                role: 'Customer Support Executive',
                employer: 'Concentrix',
                city: 'Pune',
                period: 'Jul 2025 – now',
                bullets: [],
                proof: 'none',
              },
            ]
          : []),
        {
          id: 'tp',
          initials: 'TP',
          role: 'Customer Service Intern',
          employer: 'Teleperformance',
          city: 'Pune',
          period: 'Jan 2025 – Jun 2025 · 6 mos',
          bullets: ['Handled 60+ inbound calls a day for a telecom client · 92% CSAT'],
          proof: 'none',
        },
        {
          id: 'rt',
          initials: 'RT',
          role: 'Sales Associate (part-time)',
          employer: 'Reliance Trends',
          city: 'Pune',
          period: 'Mar 2023 – Apr 2024 · 1 yr 2 mos',
          bullets: ['Top seller 3 months running · handled billing and stock entry'],
          proof: 'verified',
        },
      ];
  const skills = [
    { name: 'Customer handling', power: 3, signature: true },
    { name: 'MS Excel', power: 3, signature: true },
    { name: 'Communication', power: 3, signature: true },
    { name: 'Data entry', power: 3, signature: false },
    { name: 'Zoho CRM', power: 2, signature: false },
    { name: 'Sales calls', power: 2, signature: false },
    { name: 'Problem solving', power: 2, signature: false },
    { name: 'Hindi typing', power: 2, signature: false },
    ...(has('skill-freshdesk') ? [{ name: 'Freshdesk', power: 2, signature: false }] : []),
    { name: 'Tally basics', power: null, signature: false },
  ];
  const certificates = [
    {
      id: 'nsdc',
      title: 'Data capturing certificate',
      issuer: 'NSDC · 2024',
      status: 'verified',
      eta: null,
    },
    {
      id: 'google',
      title: 'Fundamentals of Digital Marketing',
      issuer: 'Google · 2025',
      status: 'checking',
      eta: '48 h',
    },
    ...(has('cert-udemy')
      ? [
          {
            id: 'udemy',
            title: 'Customer Service Excellence',
            issuer: 'Udemy · 2025',
            status: 'none',
            eta: null,
          },
        ]
      : []),
    ...(fresher
      ? []
      : [
          {
            id: 'tp-letter',
            title: 'Teleperformance internship letter',
            issuer: 'Work proof',
            status: 'none',
            eta: null,
          },
        ]),
  ];
  const quickWins = [
    {
      id: 'tally',
      title: 'Set your level for Tally basics',
      impact: '+3 job matches',
      link: '/quests/your-flex-era',
      query: { part: 1, edit: 1 },
    },
    ...(fresher
      ? [
          {
            id: 'project',
            title: 'Add a college project or volunteering',
            impact: 'Freshers with one get 2× more invites',
            link: '/quests/work-lore',
            query: { part: 1, edit: 1 },
          },
        ]
      : [
          {
            id: 'tp-proof',
            title: 'Add proof for your Teleperformance internship',
            impact: 'Gets a ✓ Verified badge',
            link: '/quests/drop-the-receipts',
            query: { part: 1, edit: 1 },
          },
        ]),
  ];
  const progress = profileProgress();
  return {
    byQuest: progress.quests,
    name: 'Yash Pohare',
    initials: 'Y',
    headline: 'Customer Support · BPO Voice',
    archetype: { name: 'People Pro', strongest: 'People' },
    radar: { people: 92, business: 74, data: 52, creative: 38, tech: 46 },
    signature: [
      { name: 'Customer handling', power: 3 },
      { name: 'MS Excel', power: 2 },
      { name: 'Communication', power: 2 },
    ],
    counts: { skills: skills.length, languages: 3, trophies: 2 },
    strength: {
      percent: progress.percent,
      label: fresher ? 'Good start' : 'Strong profile',
      jobMatches: fresher ? 8 : 12,
      quickWins,
    },
    contact: {
      mobile: '+91 98••• ••210',
      mobileVerified: true,
      email: 'yash••••@gmail.com',
      location: 'Kothrud, Pune 411038',
      city: 'Pune',
      discoverable: true,
      invitesBy: 'Email · WhatsApp',
      neverShown: 'ID number, full address',
    },
    about: {
      text:
        s.about ??
        (fresher
          ? 'B.Com graduate from Savitribai Phule Pune University, quick on Excel and fluent in English, Hindi and Marathi. Looking for my first full-time customer support or BPO voice role in Pune.'
          : MUNI_ABOUT),
      byMuni: s.about === null,
      tags: fresher
        ? ['People Pro', 'Fresher', 'Immediate joiner']
        : ['People Pro', '2 yrs 2 mos experience', 'Immediate joiner'],
    },
    work,
    education: [
      {
        id: 'bcom',
        initials: 'SP',
        title: 'B.Com',
        school: 'Savitribai Phule Pune University',
        detail: '2021 – 2024 · CGPA 7.4',
        proof: 'verified',
      },
      {
        id: 'hsc',
        initials: '12',
        title: '12th · Commerce (HSC)',
        school: 'Maharashtra State Board',
        detail: '2021 · 78%',
        proof: 'verified',
      },
    ],
    languages: [
      { name: 'English', skills: 'Speak · Read · Write', level: 'Fluent' },
      { name: 'Hindi', skills: 'Speak · Read · Write', level: 'Native' },
      { name: 'Marathi', skills: 'Speak · Read', level: 'Native' },
    ],
    skills,
    certificates,
    lookingFor: [
      { label: 'Looking for', value: 'Full-time · Internship' },
      { label: 'Roles', value: 'Customer support · BPO voice · Data entry' },
      { label: 'Where', value: 'Pune + 25 km · open to remote' },
      { label: 'Shifts', value: 'Day · Rotational' },
      { label: 'Can join', value: 'Immediately', good: true },
      { label: 'Expected pay', value: '₹3 – 4.5 LPA', private: true },
    ],
    verifyCode: 'YP7Q4',
    verifiedCount: fresher ? 3 : 4,
    updatedAt: new Date().toISOString(),
    pending:
      sc === 'finish'
        ? [
            {
              slug: 'your-flex-era',
              title: 'Your Flex Era · skills',
              detail: 'About 3 min · pre-filled from your CV',
              xp: 20,
            },
            { slug: 'your-flex-era', title: 'Language passport', detail: 'About 1 min', xp: 20 },
          ]
        : [],
    sources: SOURCES,
  };
}

export const jobProfileHandlers = [
  http.get('/api/job-profile', async () => {
    await delay(450);
    if (scenario() === 'error') return new HttpResponse(null, { status: 503 });
    return HttpResponse.json(build(load()));
  }),
  http.get('/api/job-profile/cv-contact', async () => {
    await delay(250);
    return HttpResponse.json({
      phone: '+91 98765 43210',
      email: 'yash.pohare@gmail.com',
      location: 'Kothrud, Pune',
      linkedin: 'linkedin.com/in/yashpohare',
      expectedPay: '₹3 – 4.5 LPA',
    });
  }),
  http.put('/api/job-profile/about', async ({ request }) => {
    await delay(400);
    const { text } = (await request.json()) as { text: string };
    const s = load();
    s.about = text.trim() || null;
    save(s);
    return HttpResponse.json(build(s));
  }),
  http.post('/api/job-profile/cv', async () => {
    await delay(1200);
    const s = load();
    return HttpResponse.json(CHANGES.filter((c) => !s.added.includes(c.id)));
  }),
  http.post('/api/job-profile/cv/apply', async ({ request }) => {
    await delay(500);
    const { ids } = (await request.json()) as { ids: string[] };
    const s = load();
    s.added = [...new Set([...s.added, ...ids.filter((id) => id !== 'email-outlook')])];
    save(s);
    return HttpResponse.json(build(s));
  }),
  http.get('/api/job-profile/share', async () => {
    await delay(250);
    const s = load();
    return HttpResponse.json({
      url: 'https://skillmuni.app/cv/yash-7q4',
      hideContact: s.hideContact,
      expiresDays: s.expiresDays,
      viewsThisWeek: 3,
    });
  }),
  http.put('/api/job-profile/share', async ({ request }) => {
    await delay(250);
    const body = (await request.json()) as { hideContact: boolean; expiresDays: number };
    const s = { ...load(), ...body };
    save(s);
    return HttpResponse.json({
      url: 'https://skillmuni.app/cv/yash-7q4',
      hideContact: s.hideContact,
      expiresDays: s.expiresDays,
      viewsThisWeek: 3,
    });
  }),
];
