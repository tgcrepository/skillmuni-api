import { assessmentSnapshot } from './assessment.handlers';
import { festActivity } from './fest.handlers';
import { jobsActivity } from './jobs.handlers';
import { HttpResponse, delay, http } from 'msw';
import { isNewLearner, onPersona, sceneOr } from './persona';
import { creditXp } from './xp-ledger';
import { syncLevel } from './quest.handlers';
import { profileProgress, questsWithGaps } from './profile-progress';

/**
 * Career Launchpad v2 (Figma 241:18014). Each card has its own endpoint so one slow or failing
 * service never blocks the page (L6, L7). Page URL scenarios (`?launch=`):
 *   new (L2) · paused (L3) · done (L4) · nofest (L5) · jobs-error (L6) · loading (L7, slow) · error
 * Default is L1 (returning learner).
 */

type Scenario = '' | 'new' | 'paused' | 'done' | 'nofest' | 'jobs-error' | 'loading' | 'error';

function scenario(): Scenario {
  return sceneOr('launch', 'new') as Scenario;
}

let alertsOn = false;

async function wait(base = 350): Promise<void> {
  await delay(scenario() === 'loading' ? 60_000 : base);
}

const MISSIONS = [
  { id: 'assessment', label: 'Take assessment', xp: 100 },
  { id: 'profile', label: 'Finish job profile', xp: 50 },
  { id: 'apply', label: 'Apply to a job', xp: 100 },
  { id: 'fest', label: 'Book a Hire Fest slot', xp: 100 },
];

/** A scenario forced from the page URL (`?launch=`) wins; otherwise the launchpad follows real state. */
const forced = () =>
  typeof location !== 'undefined' && new URLSearchParams(location.search).has('launch');

const LEVEL_NAMES = ['On the launchpad', 'Engines warming up', 'Lift-off', 'Almost in orbit', 'Launched!'];

/**
 * A-306: each mission ticks off from what the learner actually did (assessment played, Job Profile
 * complete, an application sent, a fest slot booked), and the readiness level follows the missions.
 */
function readiness() {
  const s = scenario();
  let done: Record<string, boolean>;
  if (forced() && s === 'done') done = { assessment: true, profile: true, apply: true, fest: true };
  else if (forced() && (s === 'new' || s === 'paused')) done = {};
  else {
    const ca = assessment();
    done = {
      assessment: ca.status === 'done',
      profile: profileProgress().percent === 100,
      apply: jobsActivity().applied > 0,
      fest: festActivity().booked,
    };
  }
  if (!forced()) payMissions(done);
  const missions = MISSIONS.map((m) => ({ ...m, done: !!done[m.id] }));
  const count = missions.filter((m) => m.done).length;
  const total = MISSIONS.reduce((n, m) => n + m.xp, 0);
  const percent = Math.round((missions.reduce((n, m) => n + (m.done ? m.xp : 0), 0) / total) * 100);
  return { level: count, levelName: LEVEL_NAMES[count] ?? LEVEL_NAMES[0], percent, missions };
}

/**
 * A-321: each mission pays its XP once, the first time it is done. The assessment mission is the
 * assessment's own 100 XP (paid per island), so it is never paid twice.
 */
const PAID = 'sm_mock_missions_paid';
function paid(): string[] {
  try {
    return JSON.parse(sessionStorage.getItem(PAID) ?? '[]') as string[];
  } catch {
    return [];
  }
}
function payMissions(done: Record<string, boolean>): void {
  // The sample returning learner's history is already in their 529 XP: start the record from today.
  let stored: string | null = null;
  try {
    stored = sessionStorage.getItem(PAID);
  } catch {
    /* private mode */
  }
  if (stored === null && !isNewLearner()) {
    try {
      sessionStorage.setItem(PAID, JSON.stringify(MISSIONS.filter((m) => done[m.id]).map((m) => m.id)));
    } catch {
      /* private mode */
    }
    return;
  }
  const already = paid();
  const due = MISSIONS.filter((m) => m.id !== 'assessment' && done[m.id] && !already.includes(m.id));
  if (!due.length) return;
  for (const m of due) creditXp(m.xp);
  syncLevel();
  try {
    sessionStorage.setItem(PAID, JSON.stringify([...already, ...due.map((m) => m.id)]));
  } catch {
    /* private mode */
  }
}
onPersona((p) => {
  try {
    if (p === 'new') sessionStorage.setItem(PAID, '[]');
    else sessionStorage.removeItem(PAID);
  } catch {
    /* private mode */
  }
});

/** A-262: the job profile comes from the 8 quests, so its status is read quest by quest. */
function profile() {
  const s = scenario();
  if (s === 'done') return { percent: 100, sectionsLeft: 0, sectionsTotal: 8, stepsLeft: 0, missing: [] };
  const p = profileProgress();
  const missing = questsWithGaps(p);
  return {
    percent: p.percent,
    sectionsLeft: missing.length,
    sectionsTotal: p.quests.length,
    stepsLeft: p.total - p.filled,
    missing,
  };
}

function assessment() {
  const s = scenario();
  // Once the learner has played the real assessment (mock state exists), follow it (A-306).
  const live = forced() ? null : assessmentSnapshot();
  if (live?.done)
    return {
      status: 'done',
      answered: 36,
      total: 36,
      minutes: 0,
      archetype: live.archetype
        ? { name: live.archetype.name, emoji: live.archetype.emoji, traits: live.archetype.traits }
        : null,
      mandatoryCourses: 2,
    };
  if (live && live.answered > 0)
    return {
      status: 'paused',
      answered: live.answered,
      total: 36,
      minutes: Math.max(1, Math.ceil(((36 - live.answered) * 10) / 60)),
      archetype: null,
      mandatoryCourses: 0,
    };
  const archetype = {
    name: 'The Connector',
    emoji: '🤝',
    traits: ['People', 'Helping', 'Structure'],
  };
  if (s === 'new')
    return {
      status: 'not-started',
      answered: 0,
      total: 36,
      minutes: 8,
      archetype: null,
      mandatoryCourses: 0,
    };
  if (s === 'paused')
    return {
      status: 'paused',
      answered: 14,
      total: 36,
      minutes: 5,
      archetype: null,
      mandatoryCourses: 0,
    };
  return { status: 'done', answered: 36, total: 36, minutes: 0, archetype, mandatoryCourses: 2 };
}

function jobs() {
  const s = scenario();
  const act = jobsActivity();
  const top = {
    title: 'Customer Service Agent',
    employer: 'Teleperformance',
    city: 'Pune',
    match: 92,
  };
  // A-261: My Jobs is never locked; a new learner sees their first matches straight away.
  if (s === 'new')
    return {
      locked: false,
      unlockAt: 0,
      matched: 6,
      applied: act.applied,
      saved: act.saved,
      newMatches: act.seen ? 0 : 6,
      interviews: 0,
      top,
    };
  return {
    locked: false,
    unlockAt: 60,
    matched: 12,
    applied: s === 'done' ? 5 : act.applied,
    saved: act.saved || 4,
    newMatches: act.seen ? 0 : 5,
    interviews: s === 'done' ? 2 : 0,
    top,
  };
}

function fest() {
  const s = scenario();
  if (s === 'nofest') return { fest: null, alertsOn };
  return {
    fest: {
      id: 'pune-oct',
      name: 'Pune Hire Fest',
      date: '2026-10-14',
      daysAway: 13,
      recruiters: 40,
      free: true,
      mode: 'Hybrid',
      slotsLeft: 32,
      slotsTotal: 100,
      bookedSlot: s === 'done' || festActivity().booked ? '11:30 AM' : null,
    },
    alertsOn,
  };
}

const S = (
  id: string,
  name: string,
  emoji: string,
  jobs: number,
  newJobs: number,
  fit: number,
) => ({
  id,
  name,
  emoji,
  jobs,
  newJobs,
  fit,
});

const SECTORS = [
  S('bpo', 'BPO', '🎧', 24, 3, 94),
  S('insurance', 'Insurance', '🛡️', 12, 1, 88),
  S('it', 'IT', '💻', 31, 4, 84),
  S('hospitality', 'Hospitality', '🏨', 9, 0, 81),
  S('retail', 'Retail', '🛍️', 18, 2, 79),
  S('banking', 'Banking', '🏦', 15, 1, 76),
  S('healthcare', 'Healthcare', '🏥', 7, 0, 71),
  S('telecom', 'Telecom', '📡', 8, 1, 68),
  S('marketing', 'Marketing', '📣', 10, 0, 64),
  S('manufacturing', 'Manufacturing', '🏭', 13, 2, 58),
  S('engineering', 'Engineering', '⚙️', 11, 0, 52),
  S('pharma', 'Pharmaceutical', '💊', 6, 0, 47),
  S('fashion', 'Fashion Retail', '👗', 5, 1, 44),
  S('ngo', 'NGO', '🌱', 4, 0, 40),
];

function sectors() {
  const noFit = scenario() === 'new' || scenario() === 'paused';
  return SECTORS.map((x) => (noFit ? { ...x, fit: null } : x));
}

const fail = () => scenario() === 'error';

export const launchpadHandlers = [
  http.get('/api/launchpad/readiness', async () => {
    await wait(300);
    return fail() ? new HttpResponse(null, { status: 503 }) : HttpResponse.json(readiness());
  }),
  http.get('/api/launchpad/profile', async () => {
    await wait(350);
    return fail() ? new HttpResponse(null, { status: 503 }) : HttpResponse.json(profile());
  }),
  http.get('/api/launchpad/assessment', async () => {
    await wait(450);
    return fail() ? new HttpResponse(null, { status: 503 }) : HttpResponse.json(assessment());
  }),
  http.get('/api/launchpad/jobs', async () => {
    await wait(600);
    return fail() || scenario() === 'jobs-error'
      ? new HttpResponse(null, { status: 503 })
      : HttpResponse.json(jobs());
  }),
  http.get('/api/launchpad/fest', async () => {
    await wait(500);
    return fail() ? new HttpResponse(null, { status: 503 }) : HttpResponse.json(fest());
  }),
  http.get('/api/launchpad/sectors', async () => {
    await wait(400);
    return fail() ? new HttpResponse(null, { status: 503 }) : HttpResponse.json(sectors());
  }),
  http.put('/api/launchpad/fest/alerts', async ({ request }) => {
    await delay(300);
    alertsOn = ((await request.json()) as { on: boolean }).on;
    return HttpResponse.json(fest());
  }),
];
