import { HttpResponse, delay, http } from 'msw';
import { creditXp } from './xp-ledger';
import { mockProgress, syncLevel } from './quest.handlers';

/**
 * Programme code mocks. Valid codes: SKM-MUM-26-0417 (India) and SKM-JHB-26-0102 (South Africa).
 * 5 wrong tries → 429 (cool-down). IFSC HDFC0000240 → HDFC Bank · Andheri West; other well-formed codes
 * resolve to a generic branch; "XXXX0000000" → not found.
 */
let wrong = 0;

const PROGRAMMES: Record<string, object> = {
  'SKM-MUM-26-0417': {
    code: 'SKM-MUM-26-0417',
    name: 'Customer Support Associate',
    partner: 'NSQF Level 4 · Aarambh Foundation × Skill India',
    centre: 'Andheri West, Mumbai',
    batchStarts: '2026-10-12',
    duration: '3 months · 240 hrs',
    stipend: '₹5,000 / month',
    marksFrom: '12',
    minEnglish: 50,
    minMaths: 50,
    eligibility: 'Class 12 · 50%+ Eng & Maths',
  },
  'SKM-JHB-26-0102': {
    code: 'SKM-JHB-26-0102',
    name: 'Contact Centre Learnership',
    partner: 'NQF 4 · Ubuntu CX × Services SETA',
    centre: 'Randburg, Johannesburg',
    batchStarts: '2026-10-12',
    duration: '12 months',
    stipend: 'R6,500 / month',
    marksFrom: '12',
    minEnglish: 50,
    minMaths: 40,
    eligibility: 'Matric · 50%+ English, 40%+ Maths',
  },
};

export const programmeHandlers = [
  http.get('/api/programmes/:code', async ({ params }) => {
    await delay(700);
    if (wrong >= 5) return new HttpResponse(null, { status: 429 });
    const p = PROGRAMMES[String(params['code']).toUpperCase()];
    if (!p) {
      wrong += 1;
      return new HttpResponse(null, { status: 404 });
    }
    wrong = 0;
    return HttpResponse.json(p);
  }),

  http.get('/api/banks/ifsc/:code', async ({ params }) => {
    await delay(400);
    const code = String(params['code']).toUpperCase();
    if (code === 'HDFC0000240')
      return HttpResponse.json({ bank: 'HDFC Bank', branch: 'Andheri West, Mumbai' });
    if (code.startsWith('XXXX')) return new HttpResponse(null, { status: 404 });
    return HttpResponse.json({ bank: `${code.slice(0, 4)} Bank`, branch: 'Main branch' });
  }),

  http.post('/api/me/programme', async ({ request }) => {
    await delay(900);
    const body = (await request.json()) as { bank: { account: string } | null };
    creditXp(100);
    syncLevel();
    return HttpResponse.json({
      xpEarned: 100,
      progress: mockProgress,
      accountTail: body.bank?.account.slice(-2) ?? '',
    });
  }),
];
