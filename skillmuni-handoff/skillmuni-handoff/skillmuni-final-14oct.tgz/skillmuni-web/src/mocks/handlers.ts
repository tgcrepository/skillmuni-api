import type { RequestHandler } from 'msw';
import { authHandlers } from './auth.handlers';
import { coreHandlers } from './core.handlers';
import { cvHandlers } from './cv.handlers';
import { questHandlers } from './quest.handlers';
import { contactHandlers } from './contact.handlers';
import { flexHandlers } from './flex.handlers';
import { matchesHandlers } from './matches.handlers';
import { programmeHandlers } from './programme.handlers';
import { claimHandlers } from './claim.handlers';
import { homeHandlers } from './home.handlers';
import { arenaHandlers } from './arena.handlers';
import { learnHandlers } from './learn.handlers';
import { muniHandlers } from './muni.handlers';
import { profileHandlers } from './profile.handlers';
import { statsHandlers } from './stats.handlers';
import { launchpadHandlers } from './launchpad.handlers';
import { jobProfileHandlers } from './job-profile.handlers';
import { assessmentHandlers } from './assessment.handlers';
import { jobsHandlers } from './jobs.handlers';
import { festHandlers } from './fest.handlers';
import { identityHandlers } from './identity.handlers';
import { feedbackHandlers } from './feedback.handlers';

/**
 * Mock API handlers, one file per feature (added with each slice), e.g. `./auth.handlers`.
 * The UI talks to typed API clients behind interfaces, so swapping to the real API needs no UI change.
 */
export const handlers: RequestHandler[] = [
  ...coreHandlers,
  ...authHandlers,
  ...cvHandlers,
  ...questHandlers,
  ...contactHandlers,
  ...flexHandlers,
  ...matchesHandlers,
  ...programmeHandlers,
  ...claimHandlers,
  ...homeHandlers,
  ...arenaHandlers,
  ...learnHandlers,
  ...muniHandlers,
  ...profileHandlers,
  ...statsHandlers,
  ...launchpadHandlers,
  ...jobProfileHandlers,
  ...assessmentHandlers,
  ...jobsHandlers,
  ...festHandlers,
  ...identityHandlers,
  ...feedbackHandlers,
];
