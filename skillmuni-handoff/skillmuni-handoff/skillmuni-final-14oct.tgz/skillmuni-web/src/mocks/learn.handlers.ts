import { HttpResponse, delay, http } from 'msw';
import { creditXp } from './xp-ledger';
import { isNewLearner } from './persona';

/**
 * Learning content mocks: modules (Figma Brain Vita 67:1228), topics with briefs (78:2520) and quizzes
 * (132:2709). Brain Vita and Digital Basics carry the design copy; other modules get generic content.
 * Progress (passed quizzes, bookmarks, feedback, quiz drafts) survives a refresh in the same tab.
 * `?learn=error` in the page URL fails every learn call.
 */

const A = 'assets/learn/';
const ART = ['verbal', 'non-verbal', 'arithmetic', 'data'].map((a) => `${A}topic-${a}.svg`);

interface Q {
  id: string;
  prompt: string;
  options: string[];
  answer: number;
  why: string;
  /** Per wrong option: why that pick is wrong. */
  notes?: Record<number, string>;
  /** Muni's line when this one is missed. */
  muni?: string;
}

interface BriefSeed {
  title: string;
  body: string;
  example?: string;
  keyTerm?: string;
  videoUrl?: string;
  media?: { kind: 'image' | 'video'; src: string; alt: string; duration?: string; poster?: string };
}

interface TopicSeed {
  slug: string;
  title: string;
  art: string;
  briefs: BriefSeed[];
  /** Briefs already passed when the mock starts, with XP each earned. */
  done: number[];
  questions: Q[];
  quizTitle?: string;
  course?: string;
}

interface ModuleSeed {
  slug: string;
  title: string;
  tagline: string;
  knook: { slug: string; title: string };
  topics: TopicSeed[];
}

const generic = (n: number, topic: string): BriefSeed[] =>
  Array.from({ length: n }, (_, i) => ({
    title: `${topic} · Brief ${i + 1}`,
    body: `Short, focused reading for ${topic.toLowerCase()}. Read it once, then take the one-question quiz to lock it in.`,
  }));

const MIRROR: BriefSeed = {
  title: 'Mirror and Water Images',
  body: 'A mirror image is how a figure looks when a mirror is placed beside it: left and right swap, while top and bottom stay the same. A water image is the reflection you see in still water below a figure: top and bottom swap, while left and right stay the same. In these questions you pick the correct reflection from four options. Check one feature at a time, such as a corner, a dot or a letter, and track where it lands after the flip. Rule out any option that breaks even one rule.',
  example:
    'Hold the word “CAB” up to a mirror on its right and you read BAC, with every letter flipped sideways. Reflect the same word in water and the order stays C-A-B, but every letter turns upside down. An option that keeps the right order but does not flip the letters is wrong.',
  keyTerm: 'Lateral inversion',
  videoUrl: 'https://www.youtube.com/results?search_query=mirror+and+water+images+reasoning',
  media: {
    kind: 'image',
    src: `${A}brief-mirror.svg`,
    alt: 'An orange triangle and its mirror image in violet on the other side of a vertical mirror line; the dot moves from the bottom-left corner to the bottom-right.',
  },
};

const EMBEDDED: BriefSeed = {
  title: 'Embedded Figures',
  body: 'An embedded figure is a simple shape hidden inside a more complex one. Look for the shape’s most distinctive edge or angle first, then check that every other line of it is present in the same size and orientation.',
  keyTerm: 'Lateral inversion',
  media: {
    kind: 'image',
    src: `${A}brief-mirror.svg`,
    alt: 'Two triangles either side of a line.',
  },
};

const NON_VERBAL_TITLES = [
  'Series Completion',
  'Analogy',
  'Classification',
  'Odd One Out',
  'Pattern Completion',
  'Figure Matrix',
  'Rule Detection',
  'Dot Situation',
  'Cubes and Dice',
];

const MIRROR_QUIZ: Q[] = [
  {
    id: 'nv-q1',
    prompt: 'A mirror is placed to the right of a figure. What changes in its mirror image?',
    options: [
      'Top and bottom swap',
      'Left and right swap',
      'Nothing changes',
      'The figure turns 90°',
    ],
    answer: 1,
    why: 'A side mirror flips the figure sideways: left and right swap, top and bottom stay where they are.',
    notes: { 0: 'Top and bottom swap in a water image, not a mirror image.' },
    muni: 'So close! A side mirror flips left and right.',
  },
  {
    id: 'nv-q2',
    prompt: 'What does a water image do to a figure?',
    options: [
      'Left and right swap',
      'Top and bottom swap, left and right stay',
      'The figure shrinks',
      'Both directions swap',
    ],
    answer: 1,
    why: 'Still water sits below the figure, so the reflection turns it upside down while keeping left and right.',
    notes: { 0: 'That’s a mirror image. Water reflects from below.' },
    muni: 'Nearly! Water flips it upside down.',
  },
  {
    id: 'nv-q3',
    prompt: 'You hold the word “CAB” up to a mirror on its right. What do you read?',
    options: [
      'CAB, upside down',
      'BAC, with every letter flipped sideways',
      'CAB, unchanged',
      'BAC, upside down',
    ],
    answer: 1,
    why: 'The order reverses and each letter is laterally inverted, which is why it reads BAC with flipped letters.',
    notes: { 0: 'Upside down is the water image of CAB.' },
    muni: 'Almost! Order and letters both flip in a mirror.',
  },
];

const WORKPLACE_QUIZ: Q[] = [
  {
    id: 'dw-q1',
    prompt: 'Which tool is best suited for formal correspondence in a digital workplace?',
    options: ['Social media posts', 'Instant messaging', 'Video conferencing', 'Email'],
    answer: 3,
    why: 'Email is the standard for formal messages: it keeps a written record, can carry attachments and is easy to refer back to later.',
    notes: {
      1: 'Instant messaging is great for quick, casual chats, but it’s informal and messages get buried fast.',
      0: 'Social media is public and informal, so it isn’t the place for formal work messages.',
      2: 'Video calls are for live conversations, not written correspondence.',
    },
    muni: 'So close! Email’s the formal one.',
  },
  {
    id: 'dw-q2',
    prompt: 'What is a key benefit of using instant messaging in a work setting?',
    options: [
      'It allows for quick queries and immediate responses',
      'It requires significant setup time',
      'It is ideal for sending very long documents',
      'It replaces all other communication methods',
    ],
    answer: 0,
    why: 'Instant messaging is built for short questions that need a fast reply, without waiting for an email or booking a meeting.',
    muni: 'Nearly! IM is all about speed.',
  },
  {
    id: 'dw-q3',
    prompt: 'Video conferencing is primarily used for:',
    options: [
      'Sending physical mail',
      'Virtual meetings and face-to-face discussions',
      'Creating spreadsheets',
      'Storing files offline',
    ],
    answer: 1,
    why: 'Video calls let teams in different places meet face to face in real time, share screens and talk things through.',
    muni: 'Close one! Video calls are for meetings.',
  },
];

const genericQuiz = (topic: string): Q[] => [
  {
    id: `${topic}-q1`,
    prompt: 'What’s the best way to lock in what you just read?',
    options: [
      'Skip to the next module',
      'Try the quiz straight away',
      'Read it ten times',
      'Wait a week',
    ],
    answer: 1,
    why: 'Answering right after reading (retrieval practice) is what makes it stick.',
  },
];

const MODULES: ModuleSeed[] = [
  {
    slug: 'brain-vita',
    title: 'Brain Vita',
    tagline: 'Sharpen your reasoning, one quiz at a time.',
    knook: { slug: 'skill', title: 'Skill Knook' },
    topics: [
      {
        slug: 'verbal-reasoning',
        title: 'Verbal Reasoning',
        art: ART[0] ?? '',
        briefs: generic(51, 'Verbal Reasoning'),
        done: Array.from({ length: 51 }, (_, i) => (i % 3 === 2 ? 2 : 1)),
        questions: genericQuiz('verbal'),
      },
      {
        slug: 'non-verbal-reasoning',
        title: 'Non-Verbal Reasoning',
        art: ART[1] ?? '',
        briefs: [
          ...NON_VERBAL_TITLES.map((t) => ({
            title: t,
            body: `${t}: spot the rule that links the figures, then apply it to find the missing one. Work feature by feature and rule options out.`,
          })),
          EMBEDDED,
          MIRROR,
        ],
        done: [1, 1, 0, 1, 1, 1, 1, 1, 1, 1],
        questions: MIRROR_QUIZ,
        course: 'Non-Verbal Reasoning: Full course + certificate',
      },
      {
        slug: 'arithmetical-ability',
        title: 'Arithmetical Ability',
        art: ART[2] ?? '',
        briefs: generic(37, 'Arithmetical Ability'),
        done: Array.from({ length: 37 }, (_, i) => (i < 10 ? 2 : 1)),
        questions: genericQuiz('arith'),
      },
      {
        slug: 'data-interpretation',
        title: 'Data Interpretation',
        art: ART[3] ?? '',
        briefs: generic(6, 'Data Interpretation'),
        done: [1, 1, 0, 1, 0, 1],
        questions: genericQuiz('data'),
      },
    ],
  },
  {
    slug: 'digital-basics',
    title: 'Digital Basics',
    tagline: 'Tools and habits for the modern workplace.',
    knook: { slug: 'course', title: 'Digital Foundations Knook' },
    topics: [
      {
        slug: 'digital-workplace-essentials',
        title: 'Digital Workplace Essentials',
        art: ART[3] ?? '',
        briefs: generic(10, 'Digital Workplace'),
        done: [1, 1, 0, 1],
        questions: WORKPLACE_QUIZ,
        quizTitle: 'Digital Workplace Essentials',
      },
    ],
  },
];

const titleCase = (slug: string) =>
  slug
    .split('-')
    .map((w) => (w[0] ?? '').toUpperCase() + w.slice(1))
    .join(' ');

function moduleSeed(slug: string): ModuleSeed {
  const known = MODULES.find((m) => m.slug === slug);
  if (known) return known;
  const title = titleCase(slug);
  return {
    slug,
    title,
    tagline: `Short briefs and quick quizzes on ${title}.`,
    knook: { slug: 'skill', title: 'Skill Knook' },
    topics: ['Getting Started', 'Going Deeper'].map((t, i) => ({
      slug: t.toLowerCase().replace(/\s+/g, '-'),
      title: t,
      art: ART[i] ?? '',
      briefs: generic(3, t),
      done: i === 0 ? [1] : [],
      questions: genericQuiz(`${slug}-${i}`),
    })),
  };
}

/* ---------- Session state ---------- */

interface LearnState {
  /** `${module}/${topic}` → XP per passed brief (index-aligned). */
  passed: Record<string, number[]>;
  results: Record<string, { correct: number; total: number }>;
  bookmarks: string[];
  helpful: Record<string, boolean | null>;
  drafts: Record<string, Record<string, string>>;
}

const KEY = 'sm_mock_learn';

function load(): LearnState {
  try {
    const raw = sessionStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as LearnState;
  } catch {
    /* fresh state */
  }
  return { passed: {}, results: {}, bookmarks: [], helpful: {}, drafts: {} };
}

function save(s: LearnState): void {
  try {
    sessionStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* private mode — keep in memory only */
  }
}

const passedOf = (s: LearnState, m: string, t: TopicSeed) =>
  s.passed[`${m}/${t.slug}`] ?? (isNewLearner() ? [] : t.done);

function topicSummary(s: LearnState, m: string, t: TopicSeed) {
  const p = passedOf(s, m, t);
  return {
    slug: t.slug,
    title: t.title,
    art: t.art,
    quizzesDone: p.length,
    quizzesTotal: t.briefs.length,
    xp: p.reduce((a, b) => a + b, 0),
  };
}

function scenario(): string {
  return typeof location === 'undefined'
    ? ''
    : (new URLSearchParams(location.search).get('learn') ?? '');
}

const fail = () => new HttpResponse(null, { status: 503 });
const notFound = () => new HttpResponse(null, { status: 404 });

function findTopic(m: string, t: string) {
  const mod = moduleSeed(m);
  const topic = mod.topics.find((x) => x.slug === t);
  return topic ? { mod, topic } : null;
}

const quizId = (m: string, t: string, brief: number) => `${m}~${t}~${brief}`;

function questionsFor(topic: TopicSeed, briefIndex: number): Q[] {
  // The design quiz belongs to the topic's last brief; earlier briefs get a single question.
  return briefIndex === topic.briefs.length - 1 || topic.questions.length > 1
    ? topic.questions
    : topic.questions.slice(0, 1);
}

/** The brief whose quiz is up next (first not passed), or the last one when all are done. */
function quizBrief(passed: number[], topic: TopicSeed): number {
  return Math.min(passed.length, topic.briefs.length - 1);
}

export const learnHandlers = [
  http.get('/api/learn/modules/:module', async ({ params }) => {
    await delay(400);
    if (scenario() === 'error') return fail();
    const s = load();
    const mod = moduleSeed(String(params['module']));
    const topics = mod.topics.map((t) => topicSummary(s, mod.slug, t));
    return HttpResponse.json({
      slug: mod.slug,
      title: mod.title,
      tagline: mod.tagline,
      knook: mod.knook,
      quizzesDone: topics.reduce((a, t) => a + t.quizzesDone, 0),
      quizzesTotal: topics.reduce((a, t) => a + t.quizzesTotal, 0),
      xp: topics.reduce((a, t) => a + t.xp, 0),
      topics,
    });
  }),

  http.get('/api/learn/modules/:module/topics/:topic', async ({ params }) => {
    await delay(400);
    if (scenario() === 'error') return fail();
    const found = findTopic(String(params['module']), String(params['topic']));
    if (!found) return notFound();
    const { mod, topic } = found;
    const s = load();
    const passed = passedOf(s, mod.slug, topic);
    const sum = topicSummary(s, mod.slug, topic);
    const briefs = topic.briefs.map((b, i) => {
      const id = `${mod.slug}~${topic.slug}~${i}`;
      const qid = quizId(mod.slug, topic.slug, i);
      const status = i < passed.length ? 'done' : i === passed.length ? 'current' : 'locked';
      return {
        id,
        index: i + 1,
        title: b.title,
        status,
        body: b.body,
        ...(b.example ? { example: b.example } : {}),
        ...(b.keyTerm ? { keyTerm: b.keyTerm } : {}),
        ...(b.videoUrl ? { videoUrl: b.videoUrl } : {}),
        ...(b.media ? { media: b.media } : {}),
        bookmarked: s.bookmarks.includes(id),
        helpful: s.helpful[id] ?? null,
        xp: passed[i] ?? 0,
        quiz: {
          id: qid,
          questions: questionsFor(topic, i).length,
          result:
            s.results[qid] ?? (i < passed.length ? { correct: passed[i] ?? 0, total: 1 } : null),
        },
      };
    });
    return HttpResponse.json({
      slug: topic.slug,
      title: topic.title,
      module: { slug: mod.slug, title: mod.title },
      knook: { title: mod.knook.title },
      quizzesDone: sum.quizzesDone,
      quizzesTotal: sum.quizzesTotal,
      xp: sum.xp,
      briefs,
      course: topic.course
        ? {
            title: topic.course,
            unlocked: passed.length >= topic.briefs.length,
            link: `/learn/${mod.slug}/${topic.slug}/course`,
          }
        : null,
    });
  }),

  http.put('/api/learn/briefs/:id/bookmark', async ({ params, request }) => {
    await delay(200);
    const id = String(params['id']);
    const { on } = (await request.json()) as { on: boolean };
    const s = load();
    s.bookmarks = on ? [...new Set([...s.bookmarks, id])] : s.bookmarks.filter((b) => b !== id);
    save(s);
    return new HttpResponse(null, { status: 204 });
  }),

  http.put('/api/learn/briefs/:id/feedback', async ({ params, request }) => {
    await delay(200);
    const { helpful } = (await request.json()) as { helpful: boolean | null };
    const s = load();
    s.helpful[String(params['id'])] = helpful;
    save(s);
    return new HttpResponse(null, { status: 204 });
  }),

  http.get('/api/learn/modules/:module/topics/:topic/quiz', async ({ params }) => {
    await delay(400);
    if (scenario() === 'error') return fail();
    const found = findTopic(String(params['module']), String(params['topic']));
    if (!found) return notFound();
    const { mod, topic } = found;
    const s = load();
    const passed = passedOf(s, mod.slug, topic);
    const sum = topicSummary(s, mod.slug, topic);
    const brief = quizBrief(passed, topic);
    const id = quizId(mod.slug, topic.slug, brief);
    return HttpResponse.json({
      id,
      title: topic.quizTitle ?? topic.briefs[brief]?.title ?? topic.title,
      module: { slug: mod.slug, title: mod.title },
      topic: { slug: topic.slug, title: topic.title },
      knook: { title: mod.knook.title },
      quizzesDone: sum.quizzesDone,
      quizzesTotal: sum.quizzesTotal,
      xp: sum.xp,
      questions: questionsFor(topic, brief).map((q) => ({
        id: q.id,
        prompt: q.prompt,
        options: q.options.map((text, i) => ({ id: `${q.id}-o${i}`, text })),
      })),
      draft: s.drafts[id] ?? {},
      alreadyPassed: brief < passed.length,
    });
  }),

  http.put('/api/learn/quizzes/:id/draft', async ({ params, request }) => {
    const { answers } = (await request.json()) as { answers: Record<string, string> };
    const s = load();
    s.drafts[String(params['id'])] = answers;
    save(s);
    return new HttpResponse(null, { status: 204 });
  }),

  http.post('/api/learn/quizzes/:id/submit', async ({ params, request }) => {
    await delay(600);
    if (scenario() === 'error') return fail();
    const id = String(params['id']);
    const [m = '', t = '', b = '0'] = id.split('~');
    const found = findTopic(m, t);
    if (!found) return notFound();
    const { mod, topic } = found;
    const brief = Number(b);
    const { answers } = (await request.json()) as { answers: Record<string, string> };
    const qs = questionsFor(topic, brief);
    const results = qs.map((q) => {
      const correctOptionId = `${q.id}-o${q.answer}`;
      const pickedOptionId = answers[q.id] ?? '';
      const picked = Number(pickedOptionId.split('-o').pop());
      const correct = pickedOptionId === correctOptionId;
      const note = correct ? undefined : q.notes?.[picked];
      return {
        questionId: q.id,
        correctOptionId,
        pickedOptionId,
        correct,
        explanation: q.why,
        ...(note ? { pickNote: note } : {}),
      };
    });
    const correct = results.filter((r) => r.correct).length;
    const s = load();
    const key = `${mod.slug}/${topic.slug}`;
    const passed = [...passedOf(s, mod.slug, topic)];
    // XP only the first time a brief's quiz is checked (+1 per correct, no bonus).
    const first = brief >= passed.length;
    const xp = first ? correct : 0;
    if (first) passed[brief] = xp;
    creditXp(xp);
    s.passed[key] = passed;
    s.results[id] = { correct, total: qs.length };
    s.drafts = Object.fromEntries(Object.entries(s.drafts).filter(([k]) => k !== id));
    save(s);
    const missed = qs.find((q, i) => !results[i]?.correct);
    return HttpResponse.json({
      correct,
      total: qs.length,
      xp,
      results,
      muni:
        correct === qs.length
          ? 'Brain on fire today!'
          : correct === 0
            ? 'Shake it off. Read the why, then go again.'
            : (missed?.muni ?? 'So close! Check the one you missed.'),
    });
  }),
];
