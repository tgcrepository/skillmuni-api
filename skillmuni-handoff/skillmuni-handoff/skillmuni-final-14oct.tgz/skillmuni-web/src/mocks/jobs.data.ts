/**
 * My Jobs v2 mock catalogue (Figma 272:22353). The first six jobs are the ones drawn in Figma;
 * the rest are generated deterministically so filters have real counts (128 open jobs).
 */
import type { Job, JobType, MatchInfo, WorkMode } from '../app/core/jobs/jobs.api';

export const SECTORS: Record<string, readonly string[]> = {
  'BPO / Contact centre': ['Customer service', 'Technical support', 'Collections', 'Chat support'],
  Insurance: ['Customer service', 'Claims processing', 'Sales'],
  'IT & Tech support': ['Technical support', 'Desktop support', 'QA tester'],
  Retail: ['Store associate', 'Cashier', 'Visual merchandiser'],
  Hospitality: ['Front desk', 'Guest relations', 'F&B service'],
  'Banking & Finance': ['Relationship officer', 'Back office', 'Sales'],
  'E-commerce & Logistics': ['Delivery associate', 'Warehouse associate', 'Customer service'],
  Education: ['Teaching assistant', 'Counsellor', 'Admissions'],
  Healthcare: ['Patient care', 'Front desk', 'Pharmacy assistant'],
  Telecom: ['Sales', 'Customer service', 'Field technician'],
  Manufacturing: ['Machine operator', 'Quality inspector', 'Store keeper'],
  'Media & Marketing': ['Content writer', 'Social media assistant', 'Graphic designer'],
  'Real estate': ['Sales', 'Site coordinator'],
  'Data & Admin': ['Data entry', 'Office assistant', 'Back office'],
};

export const STATES: Record<string, readonly string[]> = {
  Maharashtra: ['Pune', 'Mumbai', 'Nagpur', 'Nashik'],
  Karnataka: ['Bengaluru', 'Mysuru'],
  Telangana: ['Hyderabad'],
  'Tamil Nadu': ['Chennai'],
  Delhi: ['New Delhi'],
  Goa: ['Goa'],
};

const COMPANIES: readonly [string, string, string][] = [
  ['Teleperformance', 'TP', 'BPO / Contact centre'],
  ['HDFC Life', 'HL', 'Insurance'],
  ['Concentrix', 'CX', 'BPO / Contact centre'],
  ['Reliance Trends', 'RT', 'Retail'],
  ['Tata AIG', 'TA', 'Insurance'],
  ['Taj Hotels', 'TH', 'Hospitality'],
  ['ICICI Lombard', 'IL', 'Insurance'],
  ['Infosys BPM', 'IB', 'IT & Tech support'],
  ['Amazon', 'AZ', 'E-commerce & Logistics'],
  ['Axis Bank', 'AX', 'Banking & Finance'],
  ['Apollo Hospitals', 'AH', 'Healthcare'],
  ['Airtel', 'AT', 'Telecom'],
  ['Tata Motors', 'TM', 'Manufacturing'],
  ['upGrad', 'UG', 'Education'],
  ['Zomato', 'ZO', 'E-commerce & Logistics'],
  ['Wipro', 'WI', 'IT & Tech support'],
  ['Lodha Group', 'LG', 'Real estate'],
  ['Ogilvy', 'OG', 'Media & Marketing'],
  ['Quess Corp', 'QC', 'Data & Admin'],
];

const TITLES: Record<string, string> = {
  'Customer service': 'Customer Service Associate',
  'Technical support': 'Technical Support Associate',
  Collections: 'Collections Executive',
  'Chat support': 'Chat Support Executive',
  'Claims processing': 'Claims Processing Associate',
  Sales: 'Sales Executive',
  'Desktop support': 'Desktop Support Engineer',
  'QA tester': 'Junior QA Tester',
  'Store associate': 'Retail Store Associate',
  Cashier: 'Cashier',
  'Visual merchandiser': 'Visual Merchandiser',
  'Front desk': 'Front Desk Associate',
  'Guest relations': 'Guest Relations Executive',
  'F&B service': 'F&B Service Associate',
  'Relationship officer': 'Relationship Officer',
  'Back office': 'Back Office Executive',
  'Delivery associate': 'Delivery Associate',
  'Warehouse associate': 'Warehouse Associate',
  'Teaching assistant': 'Teaching Assistant',
  Counsellor: 'Career Counsellor',
  Admissions: 'Admissions Executive',
  'Patient care': 'Patient Care Assistant',
  'Pharmacy assistant': 'Pharmacy Assistant',
  'Field technician': 'Field Technician',
  'Machine operator': 'Machine Operator',
  'Quality inspector': 'Quality Inspector',
  'Store keeper': 'Store Keeper',
  'Content writer': 'Junior Content Writer',
  'Social media assistant': 'Social Media Assistant',
  'Graphic designer': 'Junior Graphic Designer',
  'Site coordinator': 'Site Coordinator',
  'Data entry': 'Data Entry Operator',
  'Office assistant': 'Office Assistant',
};

const MODES: readonly WorkMode[] = ['onsite', 'onsite', 'onsite', 'hybrid', 'remote'];
const TYPES: readonly JobType[] = [
  'full-time',
  'full-time',
  'full-time',
  'learnership',
  'part-time',
  'contract',
];

const ABOUT_CS =
  'Be the first voice customers hear. You’ll help customers of a leading telecom brand over calls and chat, solve their questions and make sure they leave happy. Full training is provided in your first 4 weeks.';

/** Small deterministic PRNG so the catalogue is the same on every load. */
function rng(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

export function payLabel(type: JobType, min: number, max: number): string {
  if (type === 'learnership') return `₹${(min * 1000).toLocaleString('en-IN')} / month stipend`;
  return min === max ? `₹${min.toFixed(1)} LPA` : `₹${min.toFixed(1)}–${max.toFixed(1)} LPA`;
}

/** Annual pay in lakh for the pay filter; stipends count as monthly × 12. */
export const payIndex = new Map<string, number>();

function match(percent: number, skills: string[], city: string, gap: boolean): MatchInfo {
  return {
    percent,
    skills,
    reasons: [
      {
        ok: true,
        text: `Skills: ${Math.min(5, skills.length + 1)} of 5 match (${skills.map((s) => s.toLowerCase()).join(', ')})`,
      },
      {
        ok: true,
        text:
          city === 'Pune'
            ? 'Location: Pune, where you live'
            : `Location: ${city}, you said you’d relocate`,
      },
      { ok: true, text: 'Your assessment: People-First Service Builder fits people-facing roles' },
      ...(gap ? [{ ok: false, text: 'Missing: basic MS Excel' }] : []),
    ],
    gap: gap ? { label: 'Close the gap: Excel basics · 20 min course', link: '/learn' } : null,
  };
}

interface Seed {
  title: string;
  company: string;
  initials: string;
  city: string;
  state: string;
  sector: string;
  role: string;
  workMode: WorkMode;
  jobType: JobType;
  months?: number;
  pay: [number, number];
  postedDays: number;
  closingInDays?: number;
  saved?: boolean;
  match?: MatchInfo;
}

function make(id: string, s: Seed, r: () => number): Job {
  const remote = s.workMode === 'remote';
  payIndex.set(id, s.jobType === 'learnership' ? (s.pay[0] * 12) / 100 : s.pay[0]);
  const typeLabel =
    s.jobType === 'contract'
      ? `Contract · ${s.months ?? 6} months`
      : s.jobType === 'learnership'
        ? 'Learnership'
        : s.jobType === 'part-time'
          ? 'Part-time'
          : 'Full-time';
  return {
    id,
    title: s.title,
    company: s.company,
    initials: s.initials,
    city: remote ? 'Remote' : s.city,
    state: remote ? '' : s.state,
    place: remote ? 'Remote · India' : s.city === s.state ? s.city : `${s.city}, ${s.state}`,
    sector: s.sector,
    role: s.role,
    workMode: s.workMode,
    jobType: s.jobType,
    jobTypeLabel: typeLabel,
    pay: payLabel(s.jobType, s.pay[0], s.pay[1]),
    postedDays: s.postedDays,
    applicants: 12 + Math.floor(r() * 80),
    applyBy: '15 Oct',
    closingInDays: s.closingInDays ?? null,
    closed: false,
    isNew: s.postedDays <= 2,
    saved: s.saved ?? false,
    savedDays: s.saved ? 2 : null,
    appliedOn: null,
    experience: '0–1 years (freshers welcome)',
    openings: 2 + Math.floor(r() * 14),
    shift: s.sector === 'BPO / Contact centre' ? 'Rotational · 5 days/week' : 'Day · 6 days/week',
    about:
      s.role === 'Customer service'
        ? ABOUT_CS
        : `Join ${s.company} as ${/^[AEIOU]/.test(s.title) ? 'an' : 'a'} ${s.title}. You’ll learn on the job with a buddy for your first month and grow into a full role.`,
    duties:
      s.role === 'Customer service'
        ? [
            'Handle 40–60 customer calls and chats a day',
            'Log every interaction in the CRM',
            'Escalate complex issues to the right team',
          ]
        : [
            'Learn the team’s tools in your first two weeks',
            'Own a daily set of tasks and targets',
            'Share updates with your team lead',
          ],
    requirements: [
      '12th pass or graduate',
      'Good spoken English and Hindi',
      ...(s.sector === 'BPO / Contact centre' ? ['Comfortable with rotational shifts'] : []),
      'Basic computer skills (MS Office)',
    ],
    skills:
      s.role === 'Customer service'
        ? ['Communication', 'Customer service', 'English', 'Hindi', 'CRM', 'MS Office']
        : ['Communication', 'Teamwork', 'MS Office'],
    companyAbout: `${s.company} is a leading employer in ${s.sector.toLowerCase()} with teams across India. Benefits: health insurance, performance bonus${
      s.sector === 'BPO / Contact centre' ? ', cab facility for night shifts' : ''
    }.`,
    match: s.match ?? null,
  };
}

function build(): Job[] {
  const r = rng(42);
  const fixed: Seed[] = [
    {
      title: 'Customer Service Associate',
      company: 'Teleperformance',
      initials: 'TP',
      city: 'Pune',
      state: 'Maharashtra',
      sector: 'BPO / Contact centre',
      role: 'Customer service',
      workMode: 'onsite',
      jobType: 'full-time',
      pay: [2.4, 3.0],
      postedDays: 2,
      match: match(92, ['Communication', 'English', 'Customer service'], 'Pune', true),
    },
    {
      title: 'Inbound Sales Executive',
      company: 'HDFC Life',
      initials: 'HL',
      city: 'Mumbai',
      state: 'Maharashtra',
      sector: 'Insurance',
      role: 'Sales',
      workMode: 'hybrid',
      jobType: 'full-time',
      pay: [3.0, 4.0],
      postedDays: 5,
      closingInDays: 3,
      saved: true,
      match: match(84, ['Communication', 'Sales', 'Hindi'], 'Mumbai', true),
    },
    {
      title: 'Technical Support Trainee',
      company: 'Concentrix',
      initials: 'CX',
      city: 'Bengaluru',
      state: 'Karnataka',
      sector: 'BPO / Contact centre',
      role: 'Technical support',
      workMode: 'onsite',
      jobType: 'learnership',
      pay: [15, 15],
      postedDays: 1,
      saved: true,
      match: match(78, ['Tech support', 'English'], 'Bengaluru', false),
    },
    {
      title: 'Retail Store Associate',
      company: 'Reliance Trends',
      initials: 'RT',
      city: 'Pune',
      state: 'Maharashtra',
      sector: 'Retail',
      role: 'Store associate',
      workMode: 'onsite',
      jobType: 'part-time',
      pay: [1.8, 1.8],
      postedDays: 7,
      match: match(66, ['Communication', 'Retail'], 'Pune', false),
    },
    {
      title: 'Data Entry Operator',
      company: 'Tata AIG',
      initials: 'TA',
      city: 'Remote',
      state: '',
      sector: 'Data & Admin',
      role: 'Data entry',
      workMode: 'remote',
      jobType: 'contract',
      months: 6,
      pay: [2.2, 2.2],
      postedDays: 3,
      match: match(61, ['Typing', 'MS Office'], 'Remote', false),
    },
    {
      title: 'Front Desk Associate',
      company: 'Taj Hotels',
      initials: 'TH',
      city: 'Goa',
      state: 'Goa',
      sector: 'Hospitality',
      role: 'Front desk',
      workMode: 'onsite',
      jobType: 'full-time',
      pay: [2.6, 2.6],
      postedDays: 14,
      saved: true,
    },
    {
      title: 'Claims Processing Associate',
      company: 'ICICI Lombard',
      initials: 'IL',
      city: 'Pune',
      state: 'Maharashtra',
      sector: 'Insurance',
      role: 'Claims processing',
      workMode: 'onsite',
      jobType: 'full-time',
      pay: [2.8, 2.8],
      postedDays: 4,
    },
  ];
  const out = fixed.map((s, i) => make(`job-${i + 1}`, s, r));
  const stateNames = Object.keys(STATES);
  // Most generated jobs sit in Maharashtra so the Pune defaults have depth.
  for (let i = out.length; i < 128; i++) {
    const [company, initials, home] = COMPANIES[Math.floor(r() * COMPANIES.length)] ?? [
      'Teleperformance',
      'TP',
      'BPO / Contact centre',
    ];
    const sector = r() < 0.7 ? home : (Object.keys(SECTORS)[Math.floor(r() * 14)] ?? home);
    const roles = SECTORS[sector] ?? ['Customer service'];
    const role = roles[Math.floor(r() * roles.length)] ?? 'Customer service';
    const state =
      r() < 0.6
        ? 'Maharashtra'
        : (stateNames[Math.floor(r() * stateNames.length)] ?? 'Maharashtra');
    const cities = STATES[state] ?? ['Pune'];
    const city =
      state === 'Maharashtra' && r() < 0.55
        ? 'Pune'
        : (cities[Math.floor(r() * cities.length)] ?? 'Pune');
    const workMode = MODES[Math.floor(r() * MODES.length)] ?? 'onsite';
    const jobType = TYPES[Math.floor(r() * TYPES.length)] ?? 'full-time';
    const base = 1.6 + Math.round(r() * 30) / 10;
    const pay: [number, number] =
      jobType === 'learnership'
        ? [10 + Math.floor(r() * 8), 0]
        : [base, base + Math.round(r() * 10) / 10];
    if (jobType === 'learnership') pay[1] = pay[0];
    out.push(
      make(
        `job-${i + 1}`,
        {
          title: TITLES[role] ?? role,
          company,
          initials,
          city,
          state,
          sector,
          role,
          workMode,
          jobType,
          months: 6,
          pay,
          postedDays: 1 + Math.floor(r() * 40),
          closingInDays: r() < 0.08 ? 2 + Math.floor(r() * 4) : undefined,
          // A few people-facing roles match the sample profile too (Matching Jobs has 12).
          match:
            out.length < 60 &&
            ['Customer service', 'Sales', 'Chat support', 'Store associate'].includes(role)
              ? match(60 + Math.floor(r() * 18), ['Communication', 'English'], city, r() < 0.5)
              : undefined,
        },
        r,
      ),
    );
  }
  return out;
}

export const JOBS: readonly Job[] = build();
