import { HttpResponse, delay, http } from 'msw';
import { creditXp } from './xp-ledger';
import { assessmentSnapshot } from './assessment.handlers';
import { isNewLearner, onPersona, sceneOr } from './persona';
import { syncLevel } from './quest.handlers';

/**
 * Lobby feed (Figma Home v2 185:8307). Static content from the design; art and copy will come from the CMS.
 * `?home=empty` in the page URL hides "Pick up where you left off" (new learner); `?home=error` fails the call.
 */
const A = 'assets/home/';

const tile = (slug: string, title: string) => ({
  slug,
  title,
  art: `${A}tile-${slug}.png`,
  link: `/learn/${slug}`,
});

function daypart(): 'morning' | 'afternoon' | 'evening' {
  const h = new Date().getHours();
  return h < 12 ? 'morning' : h < 17 ? 'afternoon' : 'evening';
}

function scenario(): string {
  return sceneOr('home', 'empty');
}

/** A-266: first moves done by visiting them, and whether the +50 bonus was collected. */
const FIRST_KEY = 'sm_mock_first_moves';
const FIRST_MOVES_XP = 50;
function firstState(): { visited: string[]; claimed: boolean } {
  try {
    return { visited: [], claimed: false, ...JSON.parse(sessionStorage.getItem(FIRST_KEY) ?? '{}') };
  } catch {
    return { visited: [], claimed: false };
  }
}
function saveFirst(state: { visited: string[]; claimed: boolean }): void {
  try {
    sessionStorage.setItem(FIRST_KEY, JSON.stringify(state));
  } catch {
    /* private mode */
  }
}
onPersona((p) => {
  if (p === 'new') saveFirst({ visited: [], claimed: false });
});

/** A-233: the three guided first moves for a brand-new learner. */
function firstSteps() {
  let learned = false;
  try {
    const raw = sessionStorage.getItem('sm_mock_learn');
    learned =
      !!raw &&
      Object.values((JSON.parse(raw) as { passed: Record<string, number[]> }).passed).some(
        (p) => p.length,
      );
  } catch {
    /* private mode */
  }
  const ca = assessmentSnapshot();
  // `?first=done` in the page URL: every move done (demos and tests of the bonus, A-266).
  const all = new URLSearchParams(location.search).get('first') === 'done';
  return [
    {
      id: 'assessment',
      title: 'Discover your Career Drivers',
      meta:
        ca && ca.answered && !ca.done
          ? `${ca.answered} of 36 picked · pick up where you left off`
          : '36 quick this-or-that picks · 6 min',
      xp: 100,
      link: '/assessments/career',
      done: all || !!ca?.done,
    },
    {
      id: 'learn',
      title: 'Start your first learning module',
      meta: 'A 2-minute brief, then a quick quiz · XP for every right answer',
      xp: null,
      link: '/learn/brain-vita',
      done: all || learned,
    },
    {
      id: 'jobs',
      title: 'See jobs that fit you',
      meta: 'Matched to what you told us in your quests',
      xp: null,
      link: '/jobs/matching',
      done: all || firstState().visited.includes('jobs'),
    },
  ];
}

function firstMoves() {
  if (!isNewLearner()) return { firstSteps: null, firstMovesBonus: null };
  const state = firstState();
  // Once the bonus is collected the card has done its job and makes way for the usual Lobby.
  if (state.claimed) return { firstSteps: null, firstMovesBonus: null };
  return { firstSteps: firstSteps(), firstMovesBonus: { xp: FIRST_MOVES_XP, claimed: false } };
}

export const homeHandlers = [
  http.post('/api/home/first-steps/:id', async ({ params }) => {
    await delay(120);
    const state = firstState();
    const id = String(params['id']);
    if (!state.visited.includes(id)) saveFirst({ ...state, visited: [...state.visited, id] });
    return new HttpResponse(null, { status: 204 });
  }),

  http.post('/api/home/first-moves/claim', async () => {
    await delay(300);
    const state = firstState();
    const steps = firstSteps();
    if (state.claimed || steps.some((s) => !s.done))
      return HttpResponse.json({ xp: 0 }, { status: state.claimed ? 200 : 409 });
    saveFirst({ ...state, claimed: true });
    creditXp(FIRST_MOVES_XP);
    syncLevel();
    return HttpResponse.json({ xp: FIRST_MOVES_XP });
  }),

  http.get('/api/home', async () => {
    await delay(500);
    const mode = scenario();
    if (mode === 'error') return new HttpResponse(null, { status: 503 });
    return HttpResponse.json({
      daypart: daypart(),
      ...firstMoves(),
      resume:
        mode === 'empty'
          ? null
          : {
              module: 'Brain Vita',
              topic: 'Non-Verbal Reasoning',
              brief: 11,
              briefs: 11,
              note: '1 quiz away from 100% mastery',
              percent: 99,
              xp: 1,
              art: `${A}tile-brain-vita.png`,
              link: '/learn/brain-vita/non-verbal-reasoning',
            },
      pathways: [
        {
          slug: 'career-launchpad',
          title: 'Career Launchpad',
          blurb:
            'Take assessments to match jobs with your skills and needs. Opportunities are waiting!',
          tone: 'arcane',
          art: `${A}pathway-career.png`,
          link: '/launchpad',
        },
        {
          slug: 'grad-gateway',
          title: 'Grad Gateway',
          blurb:
            'Compare countries, find top institutes and register your interest. We’ll guide you all the way!',
          tone: 'ember',
          art: `${A}pathway-grad.png`,
          link: null,
        },
        {
          slug: 'startup-street',
          title: 'Startup Street',
          blurb:
            'Test your Entrepreneurial Quotient, share ideas, find collaborators and explore new paths!',
          tone: 'success',
          art: `${A}pathway-startup.png`,
          link: null,
        },
      ],
      knooks: [
        {
          slug: 'skill',
          title: 'Skill Knook',
          icon: `${A}knook-skill.png`,
          expanded: true,
          modules: [
            tile('brain-vita', 'Brain Vita'),
            tile('english-vinglish', 'English Vinglish'),
            tile('its-my-style', 'It’s My Style'),
            tile('happiness-barometer', 'Happiness Barometer'),
            tile('sharp-shooter', 'Sharp Shooter'),
            tile('surgical-strike', 'Surgical Strike'),
            // A-255: more than six, so "Show more" has something to show.
            { ...tile('banking', 'Money Smart'), slug: 'money-smart', link: '/learn/money-smart' },
            { ...tile('english-vinglish', 'Speak Up'), slug: 'speak-up', link: '/learn/speak-up' },
            {
              ...tile('happiness-barometer', 'Time Boss'),
              slug: 'time-boss',
              link: '/learn/time-boss',
            },
            {
              ...tile('it-gyan', 'Digital Detox'),
              slug: 'digital-detox',
              link: '/learn/digital-detox',
            },
          ],
        },
        {
          slug: 'industry',
          title: 'Industry Knook',
          icon: `${A}knook-industry.png`,
          expanded: true,
          modules: [
            tile('insurance', 'Insurance'),
            tile('banking', 'Banking'),
            tile('hospitality', 'Hospitality'),
            tile('it-gyan', 'IT Gyan'),
          ],
        },
        {
          slug: 'blue-collar',
          title: 'Blue Collar Knook',
          icon: `${A}knook-blue-collar.png`,
          expanded: false,
          modules: [
            tile('surgical-strike', 'Electrician Basics'),
            tile('sharp-shooter', 'Safety First'),
            tile('it-gyan', 'Plumbing 101'),
            tile('banking', 'Retail Floor'),
            tile('hospitality', 'Delivery Pro'),
            tile('insurance', 'Security Guard'),
          ].map((m, i) => ({
            ...m,
            slug: `blue-collar-${i + 1}`,
            link: `/learn/blue-collar-${i + 1}`,
          })),
        },
        {
          slug: 'practice',
          title: 'Practice Knook',
          icon: `${A}knook-practice.png`,
          expanded: false,
          modules: [
            {
              ...tile('sharp-shooter', 'Mock Interviews'),
              slug: 'mock-interviews',
              link: '/learn/mock-interviews',
            },
          ],
        },
        {
          slug: 'course',
          title: 'Course Knook',
          icon: `${A}knook-course.png`,
          expanded: false,
          modules: [
            {
              ...tile('it-gyan', 'Digital Basics'),
              slug: 'digital-basics',
              link: '/learn/digital-basics',
            },
          ],
        },
      ],
      rewardsReady: 2,
      unreadNotifications: 1,
    });
  }),
];
