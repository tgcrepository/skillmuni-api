# Skillmuni Registration — Phase 1 Audit (pre-build)

**Figma:** `Skillmuni-India` · page **Screens – Reviewed** (`200:8004`) · audited 4 Oct 2026
**Method:** Plugin-API inventory of every page, variable collection, style and component set; frame names, spec boards and prototype reactions on the reviewed page. Coverage cells come from frame names + on-canvas spec boards — I did not open all ~330 frames one by one, so ⚠️ means "needs a look", not "absent".

**Status: awaiting your approval. No Angular code written.**

---

## 0. Headline findings

1. **The design system is real and good** — 4 variable collections (413 vars), 28 text styles, 16 effect styles, 12 gradient styles, 31 component sets. Tokens can be generated straight from Figma.
2. **The screens barely use it.** On the reviewed page only **9 % of fills, 16 % of text and ~1 % of radii are bound** to variables/styles. Most buttons, fields and pills are hand-drawn frames (≈2,500 frames named like components; only 35 real `Button` instances). Build will map these back to components — every mapping is a potential visual diff.
3. **No light theme, no motion tokens, no keyframe animation.** Theme has a single `Dark` mode. Motion exists only as prototype transitions.
4. **States are well covered for Entry, CV, Quests 2–5, Matches and Programme code**; weak for **Quests 1, 6, 7, 8**, the **institute claim** flow, every **loading** state except parsing/matches/submit, and **long-content overflow everywhere**.
5. **Scope question:** the file's first page (`Screens`) holds a much larger v2 product (Dashboard, Settings, My Jobs, Rewards, Career Assessment, Hire Fest… ≈900 frames). I've treated it as **out of scope**; the reviewed page = registration + matches + programme code.

---

## 1. Inventory

### 1.1 Pages

| Group       | Pages                                                                                                                                                             |
| ----------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Screens     | `Screens` (v2 product explorations, out of scope) · **`Screens – Reviewed`** (in scope)                                                                           |
| Docs        | Cover · Getting Started (empty)                                                                                                                                   |
| Foundations | Color · Typography · Spacing & Layout · Radius, Stroke & Elevation · Icons                                                                                        |
| Components  | Buttons · Tags & Pills · Selection Controls · Inputs & Fields · Select & Menu · Feedback · Progress & Game HUD · Navigation · Muni · Cards & Overlays · App Shell |
| Patterns    | Patterns & Templates (1 example set only)                                                                                                                         |

### 1.2 Flows and screens (Screens – Reviewed)

D = Desktop 1728 · T = Tablet 834 · M = Mobile 390

| #        | Section                   | Screens                                                                                                                    |       D       |  T  |  M  |
| -------- | ------------------------- | -------------------------------------------------------------------------------------------------------------------------- | :-----------: | :-: | :-: |
| 01       | Entry                     | E0 Login (mobile OTP)                                                                                                      |      ✅       | ✅  | ✅  |
|          |                           | E1 Intro — Meet Muni                                                                                                       |      ✅       | ✅  | ✅  |
|          |                           | E2 CV or manual — consent + upload                                                                                         |      ✅       | ✅  | ✅  |
|          |                           | E2b.1–.6 Country picker (open, search, no results, changed, not detected, error)                                           |      ✅       | ✅  | ✅  |
|          |                           | E3 Parsing                                                                                                                 |      ✅       | ✅  | ✅  |
|          |                           | E4 CV summary                                                                                                              |      ✅       | ✅  | ✅  |
| 01+      | Login extras (review)     | E0b Email & password · L1 Enter code (modal / sheet) · FP1–FP2 Forgot password · R1 Welcome back / resume                  |      ✅       | ✅  | ✅  |
| 01b      | Sign up                   | SU1–SU4 (empty, filled, email taken, validation) · VE1–VE4 (sent, wrong, expired, verified)                                |      ✅       | ✅  | ✅  |
|          |                           | Q1 / Q2 pre-filled from sign-up                                                                                            |      ✅       | ❌  | ❌  |
| 02       | Quest 1 Who Dis?          | Parts 1–3 + Complete                                                                                                       |      ✅       | ✅  | ✅  |
| 03       | Quest 2 Hit Me Up         | Spec + states board · mobile, OTP, verified, backup contact, address (PIN auto-fill, PIN not found, SA) · Complete         |      ✅       | ✅  | ✅  |
| 04       | Quest 3 Big Brain Stuff   | Spec + states board · level, degree, college+CGPA, still studying, SA, timeline · Complete                                 |      ✅       | ✅  | ✅  |
| 05       | Quest 4 Your Flex Era     | Spec + states board · skill deck (CV, search+power, deck full), language passport, trophy shelf + add · Player Card reveal |      ✅       | ✅  | ✅  |
| 06       | Quest 5 Work Lore         | Spec + states board · work types, fresher path, role search, filled, timeline · Level up                                   |      ✅       | ✅  | ✅  |
| 07       | Quest 6 Pick Your Arc     | Single screen                                                                                                              |      ✅       | ✅  | ✅  |
| 08       | Quest 7 Drop the Receipts | Single screen                                                                                                              |      ✅       | ✅  | ✅  |
| 09       | Quest 8 Vibe Check        | Single screen                                                                                                              |      ✅       | ✅  | ✅  |
| 10       | States & mobile extras    | CV states board (D) · S1–S12 file/parse states · camera capture, compact summary                                           | ⚠️ board only | ✅  | ✅  |
| 10+      | Global states (review)    | PM1 Camera primer · PM2 Notifications primer · SE1 Session expired · OF1 Offline · SB1 Submit loading                      |    PM1 ❌     | ✅  | ✅  |
| 11       | Institute-added profile   | V1 Claim · V2 Consent · V3 Validate · V4 Confirmed · V5 Decline/delete                                                     |      ✅       | ✅  | ✅  |
| 12 / 12+ | My Matches                | M1–M4 · MM1 Loading · MM2 Empty · MM3 Error · MM4–MM6 Accept / toasts                                                      |      ✅       | ✅  | ✅  |
| 13       | Programme & bank (India)  | P1–P5 · RG Registered                                                                                                      |      ✅       | ✅  | ✅  |

**Totals:** 17 sections · ≈330 screen frames · 552 prototype reactions.

### 1.3 Components (library pages)

| Page             | Component (variants)                                                                                                                                                                                                   | Variant axes / props                                                                                                                                           |
| ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Buttons          | **Button** (24)                                                                                                                                                                                                        | Style = Primary · Accent · Secondary · Outline Brand · State = Default · Hover · Pressed · Focus · Disabled · Loading · props: Label, XP reward, trailing icon |
|                  | **Icon Button** (20)                                                                                                                                                                                                   | Tone = Neutral · Ghost · State ×5 · Size = 44 · 36                                                                                                             |
|                  | **Text Link** (6)                                                                                                                                                                                                      | Tone = Brand · Accent · State = Default · Hover · Focus                                                                                                        |
| Tags & Pills     | **Tag** (7)                                                                                                                                                                                                            | Tone = Neutral · Brand · Accent · Danger · Success · Warning · Info                                                                                            |
|                  | **Pill** (10)                                                                                                                                                                                                          | Tone = Accent · Brand · Inset · Success · Neutral · Size = M · S · dot / icon                                                                                  |
| Selection        | **Chip** (6)                                                                                                                                                                                                           | State = Default · Hover · Focus · Selected · Disabled · Add more                                                                                               |
|                  | **Option Card** (7)                                                                                                                                                                                                    | Kind = Standard · Opt-out · State ×5                                                                                                                           |
|                  | **Checkbox** (9) · **Radio** (6) · **Switch** (6)                                                                                                                                                                      | checked/selected/on × Default · Focus · Disabled                                                                                                               |
| Inputs           | **Field** (6)                                                                                                                                                                                                          | State = Default · Focus · Valid · Error · Disabled · Read-only                                                                                                 |
|                  | **Input** (9)                                                                                                                                                                                                          | + Hover · Filled · Warning; leading/trailing icon                                                                                                              |
|                  | **OTP Digit** (6)                                                                                                                                                                                                      | Empty · Focus · Filled · Error · Success · Disabled                                                                                                            |
|                  | **Status Icon** (8)                                                                                                                                                                                                    | Tone ×4 · Size M · L                                                                                                                                           |
| Select & Menu    | **Select** (8) · **Menu** (4: List · Searchable · No results · Loading) · **Menu Option** (5)                                                                                                                          |                                                                                                                                                                |
| Feedback         | **Banner** (4 tones) · **Toast** (Reward · Success · Error)                                                                                                                                                            |                                                                                                                                                                |
| Progress & HUD   | **XP HUD** (Full · Compact) · **Section Step** · **Section Stepper** · **Progress Bar** (M/S × 0–100) · **Level Orb** (L/M/S) · **Step Status** · **Skill Chip** (Default · Signature · Unset) · **Power Meter** (0–3) |                                                                                                                                                                |
| Navigation       | **Quest Item** (Active · Next · Locked · Done · Hover · Focus) · **Quest Illustration** (1–8) · **Quest Map** · **Tab** · **Segment** · **Segmented Control**                                                          |                                                                                                                                                                |
| Muni             | **Speech Bubble** (Tail Bottom/Left/None × Mood Default/Celebrate) · Muni Character · Muni Tip · Muni Avatar                                                                                                           |                                                                                                                                                                |
| Cards & Overlays | **Quest Footer** (Inline · Bottom Bar) · **Loot Drop Card** · **Badge Ring** · **Panel** (Glass · Glass Muted · Raised · Inset) · Quest Card · Quest Complete Modal · Bottom Sheet · Scrim · Slot                      |                                                                                                                                                                |
| App Shell        | **App Header** (Desktop · Mobile) · Page Background · Logo · Brand Tagline                                                                                                                                             |                                                                                                                                                                |
| Icons            | 24 icons: check, chevron ×4, arrow-right, x, plus, search, lock, calendar, eye, alert, info, edit, upload, mail, phone, map-pin, star, grip, spinner, shield, sparkle                                                  |                                                                                                                                                                |
| Local (review)   | Country Field · Country Row · Decision Sheet · Quest / Save & exit button · Review / Changes card                                                                                                                      |                                                                                                                                                                |

**Code Connect:** not available on your Figma seat (needs Dev/Full seat on Org/Enterprise). Mapping will live in code only.

---

## 2. Token table

All from Figma variables/styles unless marked **[proposed]**.

### 2.1 Colour — primitives (`Primitives`, 1 mode)

| Ramp                               | Steps          | Range                                                            |
| ---------------------------------- | -------------- | ---------------------------------------------------------------- |
| `ink` (neutral)                    | 50 → 1000 (18) | `#f5f7ff` → `#050914`                                            |
| `ember` (brand orange)             | 50 → 900 (14)  | `#ffe0c2` → `#8e3413`                                            |
| `arcane` (accent violet)           | 50 → 900 (13)  | `#e4dfff` → `#1b2150`                                            |
| `green` · `red` · `amber` · `blue` | 3–4 each       | success / error / warning / info                                 |
| `pink`, `plum`, `dusk`, `base`     | 1–2 each       | decorative / white / black                                       |
| `alpha/*`                          | 60             | white 3–30 %, black 22–60 %, tinted brand/accent/feedback alphas |

### 2.2 Colour — semantic (`Theme`, **Dark only**)

| Group          | Tokens (→ primitive)                                                                                                                                                                          |
| -------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| bg             | canvas → ink/950 · scrim → ink-1000 @78 %                                                                                                                                                     |
| surface        | panel · panel-muted · header · raised (ink/800) · field (ink-900 @85 %) · subtle / muted / hover / pressed / disabled (white 4/6/8/12/3 %) · inset · inset-strong · inverse · track · grabber |
| text           | heading (white) · primary (ink/50) · body · subtle · secondary · tertiary · disabled · on-accent · inverse · brand · brand-strong · accent · highlight · xp · link · button-secondary         |
| border         | default · subtle · strong · disabled · focus (arcane/200) · brand · brand-subtle · accent · accent-strong · inverse · button-primary · button-accent                                          |
| brand / accent | solid · subtle · selected · tag · dot-bg / solid · subtle · tag · focus-bg · hover · icon-bg · ring                                                                                           |
| feedback       | success · error · warning · info × solid · subtle · muted · border · text (+ icon, field, tag)                                                                                                |
| icon           | default · muted · disabled · on-accent                                                                                                                                                        |
| effect         | shadow · shadow-strong · shadow-soft · glow-brand(+hover, soft) · glow-accent(+soft) · focus-ring · glow-success · glow-reward                                                                |
| rank           | gold · silver · bronze (+deep) · up · down — **raw hex, not aliased**                                                                                                                         |
| **Light mode** | **❌ none — [proposed] ship dark-only, keep token layer mode-ready**                                                                                                                          |

### 2.3 Dimension (`Dimension`)

| Token        | Values                                                                                                                                                                                     |
| ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| space        | 0 · 50 (2) · 100 (4) · 150 (6) · 200 (8) · 250 (10) · 300 (12) · 350 (14) · 400 (16) · 450 (18) · 500 (20) · 600 (24) · 700 (28) · 800 (32) · 900 (36) · 1000 (40) · 1200 (48) · 1600 (64) |
| radius       | none 0 · xs 4 · sm 6 · md 10 · lg 12 · xl 14 · 2xl 16 · 3xl 18 · 4xl 22 · 5xl 24 · 6xl 28 · 7xl 32 · full 999                                                                              |
| size/control | sm 36 · md 44 · lg 52 · xl 56 · **touch-min 44**                                                                                                                                           |
| size/icon    | xs 12 · sm 16 · md 20 · lg 24                                                                                                                                                              |
| size/avatar  | sm 28 · md 36 · lg 48 · badge/lg 128                                                                                                                                                       |
| stroke       | sm 1 · md 1.5 · lg 2 · xl 3                                                                                                                                                                |
| opacity      | disabled 45 %                                                                                                                                                                              |

### 2.4 Responsive (`Responsive`: Desktop · Tablet · Mobile)

| Token                                        | D / T / M                                                                                                                                                |
| -------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| display-lg                                   | 44/52 · 36/44 · 32/40                                                                                                                                    |
| display                                      | 32/38 · 26/31 · 24/30                                                                                                                                    |
| heading-lg / heading                         | 24/30 · 22/28 · 21/26 — 20/28 · 20/28 · 18/26                                                                                                            |
| title / lead / body / body-sm                | 16/24 → 15/22 · 16/24 → 14/21 · 15/22 → 14/20 · 14/20 → 13/19                                                                                            |
| label / button / input                       | 17/26 · 17→16/26→24 · 16/24 all                                                                                                                          |
| chip / caption / tag / eyebrow / overline    | 15→14 · 13→12 · 12 · 13→11 · 11→10                                                                                                                       |
| speech / script (Caveat)                     | 15→14 · 34/42 · 28/36 · 24/30                                                                                                                            |
| layout/panel                                 | padding-x 40·28·18 · padding-y 32·24·22 · gap 20·18·18 · radius 28·28·24                                                                                 |
| layout/control/height                        | 56 · 56 · 52                                                                                                                                             |
| layout/page                                  | margin 40·24·16 · column-gap 30·20·16                                                                                                                    |
| **Breakpoints** (from Spacing & Layout page) | Desktop ≥1280 · Tablet 768–1279 · Mobile <768. Desktop shell: Quest map 330 · Quest card fluid max 910 · Reward rail 348; header 104 tall, 20 from edges |

### 2.5 Typography (text styles)

Fonts: **Poppins** 400/500/600/700, **Caveat** Bold (Muni's handwriting).
28 styles: Display L/M · Heading L/M · Subheading · Title SemiBold/Medium · Lead · Body Regular/Medium · Body Small Regular/Medium/SemiBold · Label · Button · Input Value/Placeholder · Chip Default/Selected · Caption Medium/SemiBold/Bold · Tag SemiBold/Medium · Eyebrow (UPPER +12 %) · Overline (UPPER +8 %) · Speech · Script.

### 2.6 Elevation, glow, blur, gradients

| Style                                                 | Value                                                                                                                                           |
| ----------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| Elevation/Panel                                       | 0 20 50 black 45 % + bg blur 30                                                                                                                 |
| Elevation/Header                                      | 0 14 40 black 45 % + bg blur 24                                                                                                                 |
| Elevation/Popover · Bubble · Sheet · Modal            | 0 16 40 /60 · 0 10 24 /35 · 0 −10 40 /60 · 0 30 80 /60 + violet 0 0 60 /25                                                                      |
| Glow/Brand · Hover · Soft · Accent · Success · Reward | ember 35/55/25 % · violet 50 % · green 50 % · ember 12 %                                                                                        |
| Focus/Ring · Ring Offset                              | 4 px violet 45 % · 3 px canvas + 5 px arcane/200                                                                                                |
| Blur/Glass · Ambient                                  | bg blur 30 · layer blur 200                                                                                                                     |
| Gradients (12)                                        | Brand Ember · Ember→Arcane · Button Primary / Hover / Pressed · Button Accent · Game Level · Glass Sheen · Reward · Modal · Canvas · Decor Wave |

### 2.7 Motion — **none in Figma → [proposed]**

| Token                         | Value                             | Source                                     |
| ----------------------------- | --------------------------------- | ------------------------------------------ |
| `--motion-duration-micro`     | 120 ms                            | your spec (press, hover, focus)            |
| `--motion-duration-fast`      | 200 ms                            | Figma: Dissolve 200 ms on login tabs/links |
| `--motion-duration-standard`  | 250 ms                            | Figma: Smart Animate 250 ms on every CTA   |
| `--motion-duration-slow`      | 300 ms                            | Figma: Back, logo, parsing auto-advance    |
| `--motion-duration-page`      | 400 ms                            | your spec (route transitions)              |
| `--motion-duration-celebrate` | 800 ms                            | Figma: E0 800 ms ease-in-out               |
| `--motion-ease-out`           | cubic-bezier(0, 0, 0.58, 1)       | Figma "Ease out"                           |
| `--motion-ease-in-out`        | cubic-bezier(0.42, 0, 0.58, 1)    | Figma "Ease in and out"                    |
| `--motion-ease-emphasized`    | cubic-bezier(0.2, 0, 0, 1)        | proposed — reveals, sheets                 |
| `--motion-ease-spring`        | cubic-bezier(0.34, 1.56, 0.64, 1) | proposed — badge pop only                  |

---

## 3. Screen × state coverage

✅ designed · ❌ missing · ⚠️ ambiguous / partial · **G** = covered by the global pattern (OF1 offline, SE1 session expired) · — not applicable

| Flow                    | Default | Loading               | Empty                        | Error                                  | Offline        | No-perm                       | Validation           | Overflow          | First-run               | Session exp.      |
| ----------------------- | ------- | --------------------- | ---------------------------- | -------------------------------------- | -------------- | ----------------------------- | -------------------- | ----------------- | ----------------------- | ----------------- |
| Login (E0, E0b, L1, FP) | ✅      | ❌ send code / log in | —                            | ⚠️ wrong code / password not confirmed | G              | ❌ locked / suspended account | ⚠️ bad phone format  | ❌                | ✅ via "Join the squad" | ✅ SE1 lands here |
| Welcome back R1         | ✅      | ❌                    | —                            | ❌                                     | G              | —                             | —                    | ❌                | —                       | G                 |
| Sign up SU              | ✅      | ❌                    | —                            | ✅ SU3                                 | G              | —                             | ✅ SU4               | ❌                | ✅                      | —                 |
| Verify email VE         | ✅      | ❌ resend             | —                            | ✅ VE2, VE3                            | G              | —                             | ✅                   | —                 | —                       | —                 |
| Intro E1                | ✅      | —                     | —                            | —                                      | G              | —                             | —                    | ❌                | ✅                      | G                 |
| CV / manual E2, E2b     | ✅      | ⚠️ upload progress    | ✅ E2b.3                     | ✅ S1–S4                               | G              | ⚠️ PM1 camera (T/M only)      | ✅ E2b.5–6, S12      | ❌ long file name | ✅                      | G                 |
| Parsing E3              | ✅      | ✅                    | ✅ S8                        | ✅ S6                                  | ⚠️ mid-parse   | —                             | —                    | ❌                | —                       | ⚠️ mid-parse      |
| CV summary E4           | ✅      | —                     | ⚠️ S8 path                   | —                                      | G              | —                             | ✅ amber "check"     | ❌                | —                       | G                 |
| Quest 1                 | ✅      | ❌                    | —                            | ❌                                     | G              | —                             | ❌ no states board   | ❌                | ✅ pre-filled (D only)  | G                 |
| Quest 2                 | ✅      | ⚠️ board (D)          | —                            | ✅ PIN not found                       | G              | —                             | ✅ board (D)         | ❌                | ✅ pre-filled (D only)  | G                 |
| Quest 3                 | ✅      | ⚠️ board (D)          | ⚠️ college search no results | ⚠️ board (D)                           | G              | —                             | ✅ board (D)         | ❌                | ✅ SA from CV           | G                 |
| Quest 4                 | ✅      | ⚠️ board (D)          | ✅ trophy shelf              | ⚠️ board (D)                           | G              | —                             | ✅ deck full         | ❌                | ✅ from CV              | G                 |
| Quest 5                 | ✅      | ⚠️ board (D)          | ✅ fresher path              | ⚠️ board (D)                           | G              | —                             | ✅ board (D)         | ❌                | ✅ from CV              | G                 |
| Quest 6 Pick Your Arc   | ✅      | ❌                    | ❌                           | ❌                                     | G              | —                             | ❌                   | ❌                | ❌                      | G                 |
| Quest 7 Receipts        | ✅      | ❌ upload             | ❌                           | ⚠️ reuse S1–S4?                        | G              | ⚠️ camera                     | ❌                   | ❌                | ❌                      | G                 |
| Quest 8 Vibe Check      | ✅      | ✅ SB1                | —                            | ❌ submit failed                       | ✅ OF1 queued  | —                             | ❌ incomplete quests | ❌                | —                       | G                 |
| Institute claim V1–V5   | ✅      | ❌                    | —                            | ❌ wrong code                          | G              | ⚠️ V5 decline                 | ❌                   | ❌                | ✅                      | G                 |
| My Matches              | ✅      | ✅ MM1                | ✅ MM2                       | ✅ MM3                                 | G              | ✅ M4 assessment not taken    | —                    | ❌                | —                       | G                 |
| Programme & bank P/RG   | ✅      | ❌ verifying code     | ✅ P1                        | ✅ P4                                  | G              | —                             | ✅ P3                | ❌                | —                       | G                 |
| **Global**              |         |                       |                              |                                        | ✅ OF1 (D/T/M) | ✅ PM2 · PM1 (T/M)            |                      |                   |                         | ✅ SE1 (D/T/M)    |

**Pattern:** overflow is missing in every flow; loading is missing everywhere except parsing, matches and final submit; quest states boards exist only at desktop.

---

## 4. Gaps, unclear interactions, inconsistencies

### 4.1 Missing screens

- Login: loading on **Send me the code** / **Log in**; locked or suspended account; invalid phone format.
- **Q1 states board** (validation, error) — Q2–Q5 have one, Q1 does not.
- **Q6, Q7, Q8**: only the default screen exists (no validation, error, empty, partial).
- Q8 submit **failed** (SB1 shows sending only).
- Institute claim: wrong / expired verification code, loading.
- Programme code: verifying-code loading.
- Upload progress between "file picked" and "parsing".
- Desktop versions of **S1–S12** (only a combined board) and of **PM1** camera primer.
- Tablet/mobile of **Q1/Q2 pre-filled from sign-up**.
- Overflow / long-content variants anywhere (long names, long college names, 15 skills on mobile, long file names, German-length strings for i18n).

### 4.2 Unclear interactions

- **E0 whole frame has a click reaction** (Smart Animate 800 ms) — is there a splash/intro before login?
- **Parsing auto-advances after a timeout** in the prototype; real app should advance on API completion. Copy says "about 10 seconds", the Figma note says "under 20 s" — which is the timeout before we show a slow-parse message?
- "You can keep going — we'll ping you" on parsing: keep going **where**? Background parse + notification is not designed.
- Country pill: when the country changes after a CV was parsed, are prefilled fields cleared?
- Save & exit (120 instances): what happens on exit — draft saved server-side, then where does the learner land?
- Segmented control: does switching OTP ↔ email keep the typed value?
- Mobile OTP on Q2 is a bottom sheet; tablet/desktop are inline — confirm the breakpoint rule.

### 4.3 Inconsistencies

| Issue                                                                                                                                                                           | Where               | Impact                                                                |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | --------------------------------------------------------------------- |
| **Detached / hand-drawn components** — ≈2,500 frames named Button, Primary, Pill, Input… vs 35 Button instances                                                                 | all sections        | Each needs mapping to the real component; small visual diffs expected |
| **Off-token colours**: `#7b6cff` (segment thumb; nearest arcane/500 `#7b61ff`), `#10152e` (field bg), `#1c2347` (Google button), `#2b3152`, `#222227`, `#fefefe`                | E0 login and others | Snap to nearest token, log each                                       |
| **Unbound values**: fills 9 % bound, text styles 16 %, radii ~1 %                                                                                                               | whole page          | Tokens chosen by value-match, not binding                             |
| Login CTA text 15 px vs **Button/Label** style 17 px (16 on mobile)                                                                                                             | E0                  | Follow component or screen?                                           |
| Primary CTA gradient `#c64b1c → #a83e17` = ember/700→800, but **Gradient/Button/Primary** style may differ                                                                      | E0                  | Use paint style                                                       |
| `rank/*` colours are raw hex, not aliased to primitives                                                                                                                         | Theme               | Alias in code                                                         |
| **Mixed market data**: India login (+91) but E3/E4 show a South African CV (+27, isiZulu, Randburg); E2 picked file "Aryan_sharma_CV.pdf" vs parsing "Nkosazana_Dlamini_CV.pdf" | Entry               | Need a market config (IN / ZA)                                        |
| Consent copy says **POPIA** on the India flow (India = **DPDP**)                                                                                                                | E2                  | Legal copy per market                                                 |
| E3 note says **4** parse steps; frame shows **6**                                                                                                                               | E3                  | Pick one                                                              |
| E1 note "desktop missing Quest 6" — a Pick-your-Arc node now exists on desktop                                                                                                  | E1                  | Stale note?                                                           |
| Phone **status bars** on desktop and mobile frames                                                                                                                              | many                | Device chrome — will not be built                                     |
| Hidden layers: "Old login box", "Dev note (moved…)"                                                                                                                             | E0, E2, E3          | Ignore                                                                |
| `Review / Changes card` (258 instances)                                                                                                                                         | review annotations  | Not product UI — will not be built                                    |
| Desktop frames are 1728 wide; `Screens` page v2 uses 1536                                                                                                                       | —                   | Build fluid, max-width per shell spec                                 |

---

## 5. Animations

### 5.1 Found (prototype only — no keyframe/motion data on sampled frames)

| Trigger →                     | Transition                       | Used on                                                                                     |
| ----------------------------- | -------------------------------- | ------------------------------------------------------------------------------------------- |
| Click primary / secondary CTA | Smart Animate 250 ms ease-out    | Let's gooo, Upload & let's go, Start typing, Looks right, Upload a different CV, quest CTAs |
| Click tab / text link         | Dissolve 200 ms ease-out         | Login segmented tabs, Send me the code, Join the squad                                      |
| Click logo                    | Smart Animate 300 ms ease-out    | headers                                                                                     |
| Back                          | system back                      | mobile headers                                                                              |
| After timeout                 | Dissolve 300 ms ease-out         | E3 parsing → E4                                                                             |
| Click frame                   | Smart Animate 800 ms ease-in-out | E0 login frame                                                                              |

### 5.2 Needs definition

| Moment                                                             | Proposal                                                                              |
| ------------------------------------------------------------------ | ------------------------------------------------------------------------------------- |
| Press / hover / focus                                              | scale 0.97 + glow swap, `micro`                                                       |
| Segmented control thumb                                            | translateX, `fast`, ease-out                                                          |
| Field focus / error                                                | ring fade `micro`; error = 3-step shake (translateX, 240 ms), reduced-motion → none   |
| OTP digit fill / error / success                                   | per-digit pop `micro`; row shake on error; green sweep on success                     |
| Dropdown / menu open                                               | fade + translateY 4 px, `fast`                                                        |
| Bottom sheet / modal / scrim                                       | sheet translateY 100 %→0 `standard` emphasized; modal scale 0.96→1 + fade; scrim fade |
| Toast enter / leave                                                | translateY + fade, auto-dismiss 4 s                                                   |
| Skeleton → content                                                 | shimmer loop; crossfade `fast`                                                        |
| List enter / leave / reorder                                       | stagger 30 ms fade+translate; FLIP reorder (skills, chapters)                         |
| Parsing checklist                                                  | tick pop per step, progress bar width via transform scaleX                            |
| Muni bubble entrance                                               | fade + scale from tail, `standard`                                                    |
| Quest map step advance                                             | step fills, next unlocks — `standard`                                                 |
| XP gain / progress bar fill                                        | count-up + scaleX, `slow`                                                             |
| Badge unlock / Loot drop / Quest complete modal                    | badge pop (spring) + glow pulse, `celebrate`                                          |
| Player Card reveal (Q4) · Level up (Q5) · Registered "Yippee" (RG) | card flip / burst, `celebrate`; confetti optional                                     |
| Route transitions                                                  | View Transitions API crossfade + 8 px slide, `page`                                   |
| All                                                                | transform/opacity only; `prefers-reduced-motion` → instant or opacity-only            |

---

## 6. Proposed build order

| Phase                 | Deliverable                                                                                                                                                                                                     | Done when                                              |
| --------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------ |
| **0 · Foundation**    | Angular workspace (standalone, zoneless, strict), ESLint/Prettier, Storybook, Playwright, MSW, i18n, `core/shared/features`                                                                                     | lint + type-check + empty test suite green             |
| **1 · Tokens**        | Script: Figma variables → `tokens.css` (primitives → semantic → responsive via media queries) + motion tokens + gradients/effects                                                                               | snapshot test of generated CSS                         |
| **2 · Primitives**    | Icon set · Button · Icon Button · Text Link · Tag · Pill · Chip · Checkbox · Radio · Switch · Field · Input · OTP · Select/Menu · Segmented Control · Tab · Banner · Toast · Progress Bar · Status Icon         | each: all variants in Storybook, axe clean, unit tests |
| **3 · Composites**    | Panel · Bottom Sheet · Modal + Scrim · Speech Bubble · Muni Avatar/Character/Tip · Option Card · Skill Chip · Power Meter · Level Orb · Badge Ring · Loot Drop Card · Quest Item · Quest Illustration           | same                                                   |
| **4 · Shell**         | Page Background · App Header · Quest shell (map 330 · card · reward rail 348) · Quest Footer · XP HUD · Save & exit · route transitions                                                                         | responsive at 3 breakpoints                            |
| **5 · Cross-cutting** | Auth/session (SE1), offline queue (OF1), error boundary, permission primers (PM1/PM2), skeleton pattern, market config (IN/ZA)                                                                                  | Playwright: offline + expiry flows                     |
| **6 · Slices**        | 6a Auth: E0, E0b, L1, FP, R1 → 6b Sign up + verify → 6c Entry: E1, E2/E2b, E3, E4, S1–S12 → 6d Q1 → Q2 → Q3 → Q4 → Q5 → Q6 → Q7 → Q8 + SB1 → 6e RG + Programme P1–P5 → 6f Institute claim V1–V5 → 6g My Matches | per-slice Definition of Done                           |

---

## 7. Decisions I need from you (only the irreversible / truly ambiguous ones)

1. **Scope** — build only `Screens – Reviewed`? (Recommended: yes; v2 product page later.)
2. **Theme** — dark-only for v1 since Figma has no light mode? (Recommended: yes, mode-ready tokens.)
3. **Market** — launch India first, with South Africa as a config switch (phone format, consent law, PIN vs postal code, CV languages)?
4. **White-label** — SkillMuni is sold white-labelled: do tenants need their own brand colours/logo at runtime? (Changes how the token layer is built — irreversible-ish.)
5. **Off-design states** — OK for me to design the ❌ cells from existing components (logged in ASSUMPTIONS.md), or will you add them in Figma first?
6. **Motion durations** — use Figma's 250 ms for standard (vs your ~240 ms)? (Recommended: Figma's.)

Everything else follows the defaults in `ASSUMPTIONS.md`.
