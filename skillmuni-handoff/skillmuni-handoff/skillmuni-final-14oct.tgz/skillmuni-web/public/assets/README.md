# Raster assets (exported from Figma, PNG @2x)

These files come from Figma and must not be redrawn. Paths are referenced from `src/app/shared/assets.ts`.

| File | Figma source |
|---|---|
| `muni/muni-character.png` | Muni page → Muni Character (28:2) |
| `muni/muni-avatar.png` | Muni page → Muni Avatar (28:4) |
| `quests/quest-1.png` … `quest-8.png` | Navigation → Quest Illustration (26:448), one per variant |
| `brand/logo.png` | App Shell → Logo (32:27) |
| `brand/login-bg.png` | E0 Login Desktop → background image (200:8010) |
