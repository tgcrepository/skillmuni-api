#!/usr/bin/env node
/**
 * Figma → CSS custom properties.
 *
 * Inputs  (tokens/source): primitives.json, semantic.json, styles.json, extensions.json
 * Outputs (src/styles/tokens):
 *   tokens.generated.css      every --sm-* custom property (the only place literal colours/px/ms may live)
 *   typography.generated.css  .sm-text-<style> utility classes for Figma text styles
 *   _breakpoints.generated.scss  SCSS breakpoints (media queries can't read custom properties)
 *   tokens.manifest.json      list of every token name, used by tests and lint
 *
 * Naming
 *   --sm-ref-*   reference (primitive) tokens. Components must NOT use these directly.
 *   --sm-*       semantic / component-facing tokens (match Figma's own code syntax, e.g. --sm-color-text-primary).
 *
 * White-label: alpha primitives are built with color-mix() from their base ramp step, so a tenant
 * that overrides --sm-ref-color-ember-* or --sm-ref-color-arcane-* gets consistent tints everywhere.
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const read = (f) => JSON.parse(readFileSync(resolve(root, 'tokens/source', f), 'utf8'));
const strip = (o) => Object.fromEntries(Object.entries(o).filter(([k]) => !k.startsWith('$')));

const primitives = strip(read('primitives.json'));
const semantic = read('semantic.json');
const styles = read('styles.json');
const ext = read('extensions.json');

const slug = (path) => path.replace(/\//g, '-').replace(/_/g, '-').toLowerCase();
const refVar = (path) => `--sm-ref-${slug(path)}`;
const semVar = (path) => `--sm-${slug(path)}`;
const px = (n) => (n === 0 ? '0' : `${n}px`);
/**
 * Lengths are rem (Figma px / 16) so the whole UI scales with the root font size: laptop-fit
 * scaling on short/narrow desktops (styles.scss, A-239) and the learner's own font-size setting.
 * Strokes, shadows and blurs stay px so hairlines stay crisp.
 */
const rem = (n) => (n === 0 ? '0' : `${Number((n / 16).toFixed(4))}rem`);

const FONT_STACK = {
  Poppins: "'Poppins', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
  Caveat: "'Caveat', 'Comic Neue', cursive",
};

/* ---------- 1. Reference tokens ---------- */
const ref = new Map(); // css var name -> value
const hexToRef = new Map(); // lowercase hex -> css var name (for gradients/effects)

const alphaBase = (base) => {
  if (base === 'white') return 'color/base/white';
  if (base === 'black') return 'color/base/black';
  const [ramp, step] = base.split('-');
  return `color/${ramp}/${step}`;
};

for (const [path, value] of Object.entries(primitives)) {
  const name = refVar(path);
  if (path.startsWith('color/alpha/')) {
    const [, , base, pct] = path.split('/');
    ref.set(name, `color-mix(in srgb, var(${refVar(alphaBase(base))}) ${pct}%, transparent)`);
    hexToRef.set(String(value).toLowerCase(), name);
  } else if (path.startsWith('color/')) {
    ref.set(name, value);
    if (!hexToRef.has(value.toLowerCase())) hexToRef.set(value.toLowerCase(), name);
  } else if (path.startsWith('opacity/')) {
    ref.set(name, String(value / 100));
  } else if (path.startsWith('font/family/')) {
    ref.set(name, FONT_STACK[value] ?? `'${value}', sans-serif`);
  } else if (path.startsWith('font/weight/')) {
    ref.set(name, String(value));
  } else {
    ref.set(name, path.startsWith('stroke/') ? px(value) : rem(value)); // space, radius, size, font/size
  }
}

/* Theme raw hex (rank/*) becomes reference tokens too (A-05). */
for (const [path, value] of Object.entries(semantic.Theme)) {
  if (typeof value === 'string' && value.startsWith('#')) {
    const name = refVar(path);
    ref.set(name, value);
    if (!hexToRef.has(value.toLowerCase())) hexToRef.set(value.toLowerCase(), name);
  }
}

const resolveAlias = (value) => {
  if (typeof value === 'string' && value.startsWith('{')) {
    const path = value.slice(1, -1);
    const name = refVar(path);
    if (!ref.has(name)) throw new Error(`Unresolved alias ${value}`);
    return `var(${name})`;
  }
  return null;
};

/* ---------- 2. Semantic tokens ---------- */
const sem = new Map();
for (const [path, value] of Object.entries(semantic.Theme)) {
  sem.set(semVar(path), resolveAlias(value) ?? `var(${refVar(path)})`);
}
for (const [path, value] of Object.entries(strip(semantic.Dimension))) {
  const v = resolveAlias(value);
  if (!v) throw new Error(`Dimension ${path} is not an alias`);
  sem.set(semVar(path), v);
}

/* ---------- 3. Responsive (mobile-first) ---------- */
const responsive = strip(semantic.Responsive);
const [DESKTOP, TABLET, MOBILE] = [0, 1, 2];
const respValue = (v) => resolveAlias(v) ?? rem(v);
const mobile = new Map();
const tablet = new Map();
const desktop = new Map();
for (const [path, modes] of Object.entries(responsive)) {
  const name = semVar(path);
  const [d, t, m] = [respValue(modes[DESKTOP]), respValue(modes[TABLET]), respValue(modes[MOBILE])];
  mobile.set(name, m);
  if (t !== m) tablet.set(name, t);
  if (d !== t) desktop.set(name, d);
}

/* ---------- 3b. Type scale review overrides (extensions.json → type-scale, A-161) ---------- */
const typeScale = ext['type-scale'] ?? {};
for (const [mode, map] of [['tablet', tablet], ['desktop', desktop]]) {
  for (const [scale, [size, lh]] of Object.entries(typeScale[mode] ?? {})) {
    map.set(semVar(`type/${scale}/size`), rem(size));
    map.set(semVar(`type/${scale}/line-height`), rem(lh));
  }
}

/* ---------- 4. Typography composites ---------- */
const typeVars = new Map();
const typeClasses = [];
for (const [key, s] of Object.entries(styles.text)) {
  const family = `var(${refVar(`font/family/${s.family}`)})`;
  const weight = `var(${refVar(`font/weight/${s.weight}`)})`;
  const size = `var(${semVar(`type/${s.scale}/size`)})`;
  const lh = `var(${semVar(`type/${s.scale}/line-height`)})`;
  typeVars.set(`--sm-font-${key}`, `${weight} ${size}/${lh} ${family}`);
  const extra = [
    s.letterSpacing ? `  letter-spacing: ${s.letterSpacing};` : '',
    s.textTransform ? `  text-transform: ${s.textTransform};` : '',
  ].filter(Boolean);
  typeClasses.push(
    `/* Figma: ${s.figma} */\n.sm-text-${key} {\n  font: var(--sm-font-${key});\n${extra.join('\n')}${extra.length ? '\n' : ''}}`,
  );
  if (s.letterSpacing) typeVars.set(`--sm-letter-spacing-${key}`, s.letterSpacing);
}

/* ---------- 5. Gradients and effects ---------- */
const colorRef = (hex) => {
  const name = hexToRef.get(hex.toLowerCase());
  return name ? `var(${name})` : hex; // literal only when no primitive matches (logged in ASSUMPTIONS A-39)
};
const literalStops = [];
const fx = new Map();
for (const [key, g] of Object.entries(styles.gradients)) {
  const stops = g.stops.map((s) => {
    const [hex, pos] = s.split(' ');
    const c = colorRef(hex);
    if (c === hex) literalStops.push(`${key}: ${hex}`);
    return `${c} ${pos}`;
  });
  fx.set(`--sm-gradient-${key}`, `linear-gradient(${g.angle}deg, ${stops.join(', ')})`);
  // Individual stops, for SVG <stop> elements that can't use a CSS gradient.
  stops.forEach((stop, i) =>
    fx.set(`--sm-gradient-${key}-stop-${i + 1}`, stop.split(' ').slice(0, -1).join(' ')),
  );
}
for (const [key, e] of Object.entries(styles.effects)) {
  if (e.shadows) {
    fx.set(
      `--sm-shadow-${key}`,
      e.shadows
        .map(([x, y, b, s, c]) => `${px(x)} ${px(y)} ${px(b)} ${px(s)} ${colorRef(c)}`)
        .join(', '),
    );
  }
  if (e.backdropBlur) fx.set(`--sm-backdrop-${key}`, `blur(${e.backdropBlur}px)`);
  if (e.layerBlur) fx.set(`--sm-filter-${key}`, `blur(${e.layerBlur}px)`);
}

/* ---------- 6. Extensions: layout, motion, z-index ---------- */
const extVars = new Map();
for (const [path, v] of Object.entries(strip(ext.layout)))
  extVars.set(`--sm-layout-${slug(path)}`, rem(v));
const motion = strip(ext.motion);
for (const [path, v] of Object.entries(motion)) {
  const name = `--sm-motion-${slug(path)}`;
  if (path.startsWith('duration/') || path.startsWith('loop/') || path === 'stagger')
    extVars.set(name, `${v}ms`);
  else if (path.startsWith('distance/') || path === 'shake') extVars.set(name, rem(v));
  else extVars.set(name, v);
}
for (const [path, v] of Object.entries(strip(ext.z)))
  extVars.set(`--sm-z-${slug(path)}`, String(v));
for (const [name, [ref, pct]] of Object.entries(strip(ext.decor ?? {})))
  extVars.set(
    `--sm-color-decor-${name}`,
    pct >= 100
      ? `var(${refVar(ref)})`
      : `color-mix(in srgb, var(${refVar(ref)}) ${pct}%, transparent)`,
  );
for (const [path, v] of Object.entries(strip(ext.size ?? {})))
  extVars.set(`--sm-size-${slug(path)}`, rem(v));

/* ---------- 7. Write files ---------- */
const block = (selector, map, indent = '  ') =>
  `${selector} {\n${[...map].map(([k, v]) => `${indent}${k}: ${v};`).join('\n')}\n}`;

const { tablet: bpTablet, desktop: bpDesktop } = styles.breakpoints;
const reducedMotion = new Map(
  Object.keys(motion)
    .filter(
      (p) =>
        p.startsWith('duration/') || p.startsWith('distance/') || p === 'stagger' || p === 'shake',
    )
    .map((p) => [
      `--sm-motion-${slug(p)}`,
      p.startsWith('duration/') || p === 'stagger' ? '1ms' : '0',
    ]),
);

const header = `/* AUTO-GENERATED by tools/tokens/build-tokens.mjs — do not edit. Source: tokens/source/*.json */`;
const css = [
  header,
  '',
  '/* 1. Reference tokens (primitives). Do not use in components. */',
  block(':root', ref),
  '',
  '/* 2. Semantic tokens — Theme (Dark) + Dimension */',
  block(':root', sem),
  '',
  `/* 3. Responsive — Mobile (<${bpTablet}px) is the base */`,
  block(':root', mobile),
  '',
  `@media (min-width: ${bpTablet}px) {\n${block('  :root', tablet, '    ')}\n}`,
  '',
  `@media (min-width: ${bpDesktop}px) {\n${block('  :root', desktop, '    ')}\n}`,
  '',
  '/* 4. Typography composites (use with `font:`) */',
  block(':root', typeVars),
  '',
  '/* 5. Gradients, shadows, blurs */',
  block(':root', fx),
  '',
  '/* 6. Layout shell, motion, z-index (extensions.json) */',
  block(':root', extVars),
  '',
  '/* Reduced motion: movement collapses to ~instant; opacity fades may still use --sm-motion-duration-fast via --sm-motion-fade */',
  `:root {\n  --sm-motion-fade: var(--sm-motion-duration-fast);\n}`,
  `@media (prefers-reduced-motion: reduce) {\n${block('  :root', reducedMotion, '    ')}\n}`,
  '',
].join('\n');

const outDir = resolve(root, 'src/styles/tokens');
mkdirSync(outDir, { recursive: true });
writeFileSync(resolve(outDir, 'tokens.generated.css'), css);
writeFileSync(
  resolve(outDir, 'typography.generated.css'),
  [header, '', ...typeClasses, ''].join('\n'),
);
writeFileSync(
  resolve(outDir, '_breakpoints.generated.scss'),
  `// ${header.slice(3, -3)}\n$sm-bp-tablet: ${bpTablet}px;\n$sm-bp-desktop: ${bpDesktop}px;\n`,
);

const all = [
  ...ref.keys(),
  ...sem.keys(),
  ...mobile.keys(),
  ...typeVars.keys(),
  ...fx.keys(),
  ...extVars.keys(),
  '--sm-motion-fade',
];
writeFileSync(
  resolve(outDir, 'tokens.manifest.json'),
  JSON.stringify(
    { count: all.length, literalGradientStops: literalStops, tokens: all.sort() },
    null,
    2,
  ) + '\n',
);
console.log(
  `tokens: ${all.length} custom properties · literal gradient stops: ${literalStops.length}`,
);
