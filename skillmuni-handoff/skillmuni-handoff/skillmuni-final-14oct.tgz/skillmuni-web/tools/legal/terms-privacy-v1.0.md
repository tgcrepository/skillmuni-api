**Terms of Use**

**Introduction:**

These terms and conditions govern your use of this App; by using this
App, you accept these terms and conditions and Privacy Policy in full.
If you disagree with these terms and conditions or any part of these
terms and conditions, you must not use this App. \[You must be at least
\[18\] years of age to use this App.

**Content**

The copyright in all material contained on, in, or available through the
App including all information, data, text, music, sound, photographs,
graphics and video messages, the selection and arrangement thereof, and
all source code, software compilations and other material ("Material")
is owned by or licensed or free to use by TGC Technologies Pvt. Ltd.
("TGC") or its group companies. All rights are reserved. You cannot
otherwise copy, edit, vary, reproduce, publish, display, distribute,
store, transmit, commercially exploit, disseminate in any form
whatsoever or use the Material without TGC's express permission.

The trademarks, service marks, and logos ("Trade Marks") contained on or
in the App are owned by TGC or its group companies or third party
resources. You cannot use, copy, edit, vary, reproduce, publish,
display, distribute, store, transmit, commercially exploit or
disseminate the Trade Marks without the prior written consent of TGC or
the relevant group company or the relevant third party.

**License to use App**

Unless otherwise stated, TGC and/or its licensors own the intellectual
property rights of the App. Subject to the license below, all these
intellectual property rights are reserved. You may view, download for
caching purposes only, and print pages \[or \[OTHER CONTENT\]\] from the
App for your own use, subject to the restrictions set out below and
elsewhere in these terms and conditions.

**Acceptable use:**

You must not use this App in any way that causes, or may cause, damage
to the App or impairment of the availability or accessibility of the
App; or in any way which is unlawful, illegal, fraudulent or harmful, or
in connection with any unlawful, illegal, fraudulent or harmful purpose
or activity. You must not use this App to copy, store, host, transmit,
send, use, publish or distribute any material which consists of (or is
linked to) any spyware, computer virus, Trojan horse, worm, keystroke
logger, rootkit or other malicious software. You must use this App; the
content herein only for your respective teams. Restricted access
\[Access to certain areas of this App is restricted.\] TGC reserves the
right to restrict access to \[other\] areas of this App, or indeed this
entire App, at TGC & discretion. If TGC provides you with a user ID and
password to enable you to access restricted areas of this App or other
content or services, you must ensure that the user ID and password are
kept confidential. \[TGC may disable your user ID and password in, sole
discretion without notice or explanation.\]

**Limitations of liability:**

TGC will not be liable to you (whether under the law of contact, the law
of torts or otherwise) in relation to the contents of, or use of, or
otherwise in connection with, this App: to the extent that the App is
provided free-of-charge, for any direct loss; for paid subscriptions,
for any direct loss; for any indirect, special or consequential loss; or
for any business losses, loss of revenue, income, profits or anticipated
savings, loss of contracts or business relationships, loss of reputation
or goodwill, or loss or corruption of information or data. These
limitations of liability apply even if TGC has been expressly advised of
the potential loss. Breaches of these terms and conditions Without
prejudice to TGC other rights under these terms and conditions, if you
breach these terms and conditions in any way, TGC may take such action
as TGC deems appropriate to deal with the breach, including suspending
your access to the App, prohibiting you from accessing the App,
contacting your internet service provider to request that they block
your access to the App and/or bringing court proceedings against you.

**Competitions**

If you take part in any competition which is run in or through the App
("Competition"), you agree to be bound by the rules of that competition
and any other rules specified by TGC from time to time ("Competition
Rules") and by the decisions of TGC, which are final in all matters
relating to the Competition. TGC reserves the right to disqualify any
entrant and/or winner in its absolute discretion without notice in
accordance with the Competition Rules.

**Variation:**

TGC may revise these terms and conditions from time-to-time. Revised
terms and conditions will apply to the use of this App from the date of
the publication of the revised terms and conditions on this App. Please
check this page regularly to ensure you are familiar with the current
version.

**Privacy Policy**

We value your trust. In order to honour that trust, TGC\'S adheres to
ethical standards in gathering, using, and safeguarding any information
you provide. This privacy policy governs your use of the application
\'Skillmuni' (\'Application\') and the other associated applications,
products, websites and services managed by TGC. Please read this privacy
policy (\'Policy\') carefully before using the Application, Website, our
services and products, along with the Terms and Conditions (\'T&C's\')
provided on the Application. Your use of the Application, or services in
connection with the Application or products (\'Services\'), or
registrations with us through any modes or usage of any products
including through SD cards, tablets or other storage/transmitting device
shall signify your acceptance of this Policy and your agreement to be
legally bound by the same. If you do not agree with the terms of this
Policy, do not use the Application our products or avail any of our
Services.

**User Provided Information**

The Application/ Services/products obtains the information you provide
when you download and register for the Application or Services or
products. When you register with us, you generally provide (a) your
name, age, email address, location, phone number, password and
educational interests; (b) transaction-related information, such as when
you make purchases, respond to any offers, or download or use
applications from us; (c) information you provide us when you contact us
for help; (d) information you enter into our system when using the
Application/Services/products, such as while asking doubts,
participating in discussions and taking tests. The said information
collected from the users could be categorized as "Personal Information",
"Sensitive Personal Information" and "Associated Information". Personal
Information, Sensitive Personal Information and Associated Information
(each as individually defined under this Information Technology
(Reasonable security practices and procedures and sensitive personal
data or information) Rules, 2011 (the "Data Protection Rules")) shall
collectively be referred to as \'Information\' in this Policy. We may
use the Information to contact you from time to time, to provide you
with the Services, important information, required notices and marketing
promotions. We will ask you when we need more information that
personally identifies you (personal information) or allows us to contact
you. We will not differentiate between who is using the device to access
the Application or Services or products, so long as the log in/access
credentials match with yours. In order to make the best use of the
Application/Services/products and enable your Information to be captured
accurately on the Application/Services/products, it is essential that
you have logged in using your own credentials. We will, at all times,
provide the option to you to not provide the Personal Information or
Sensitive Personal Information, which we seek from you. Further, you
shall, at any time while using the Application/Services/products, also
have an option to withdraw your consent given earlier to us to use such
Personal Information or Sensitive Personal Information. Such withdrawal
of the consent is required to be sent in writing to us at the contact
details provided in this Policy below. In such event, however, TGC fully
reserves the right not to allow further usage of the Application or
provide any Services/products thereunder to you.

**Automatically Collected Information**

In addition, the Application/products/Services may collect certain
information automatically, including, but not limited to, the type of
mobile device you use, your mobile devices unique device ID, the IP
address of your mobile device, your mobile operating system, the type of
mobile Internet browsers you use, and information about the way you use
the Application/Services/products. As is true of most Mobile
applications, we also collect other relevant information as per the
permissions that you provide. We use an outside credit card processing
company to bill you for goods and services. These companies do not
retain, share, store or use personally identifiable information for any
other purpose.

**Use of your Personal Information**

We use the collected Information to analyse trends, to conduct research,
to administer the Application/Services and products, to learn about each
user\'s learning patterns and movements around the Application/Services
and products and to gather demographic information and usage behaviour
about our user base as a whole. Aggregated and individual, anonymized
and non-anonymized data may periodically be transmitted to external
service providers to help us improve the Application, products and our
Services. We will share your information with third parties only in the
ways that are described below in this Policy. We may use the individual
data and behavior patterns combined with personal information to provide
you with personalized content, and better your learning objectives.
Third parties provide certain services which we may use to analyze the
data and information to personalize, drive insights and help us better
your experience or reach out to you with more value added applications,
products, information and services. However, these third party companies
do not have any independent right to share this information. We do not
sell, trade or rent your Information to any third party unless, we have
been expressly authorized by you either in writing or electronically to
do so. We may at times provide aggregate statistics about our customers,
traffic patterns, and related site information to reputable third
parties, however this information when disclosed will be in an aggregate
form and does not contain any of your Personally Identifiable
Information. TGC will occasionally send email notices or contact you to
communicate about our Services, products and benefits, as they are
considered an essential part of the Services/products you have chosen.
We may disclose Information:

-   as required by law, such as to comply with a subpoena, or similar
    legal process;

-   to enforce applicable T&C's, including investigation of potential
    violations thereof;

-   when we believe in good faith that disclosure is necessary to
    protect our rights, protect your safety or the safety of others,
    investigate fraud, address security or technical issues or respond
    to a government request;

-   with our trusted services providers who work on our behalf, do not
    have an independent use of the information we disclose to them, and
    have agreed to adhere to the rules set forth in this Policy;

-   to protect against imminent harm to the rights, property or safety
    of the Application/Website/ Think and Learn Private Limited or its
    users or the public as required or permitted by law;

-   with third party service providers in order to personalize the
    Application/Website/Services/products for a better user experience
    and to perform behavioural analysis;

**Access to your Personal Information**

We will provide you with the means to ensure that your Personal
Information is correct and current. If you have filled out a user
profile, we will provide an obvious way for you to access and change
your profile from our Application/Services/Website/products. We adopt
reasonable security measures to protect your password from being exposed
or disclosed to anyone.

1.  **Changes in Privacy Policy**

> TGC may, from time to time, make changes to this Privacy Policy, the
> social terms or the cookies. Such revisions shall take effect
> immediately, please refer our [[privacy
> policy]{.underline}](https://www.flinnt.com/app/static/privacy/) from
> time to time

2.  **Advertisements of \"Third Party\" on Skillmuni**

> We use third-party advertising content provider/ course creator to
> serve ads when you visit Skillmuni. These content provider/ course
> creator may use information about your visits to this and other
> websites in order to provide advertisements about new courses, new
> products and services of interest to you.

3.  **Your Consent about personal information**

> By using our services or by providing your information, you give your
> consent to the collection and use of the information you disclose on
> Skillmuni in accordance with this Privacy Policy, including but not
> limited to your consent for sharing your information as per this
> privacy policy. If we decide to change our privacy policy, we will
> post those changes on this page so that you are always aware of what
> information we collect, how we use it, and where we disclose it.

4.  **Governing Law and Jurisdiction**

> Any action at law, suit in equity or judicial proceeding arising
> directly, indirectly, or otherwise in connection with, out of, related
> to or from this Agreement shall be litigated only in the court having
> jurisdiction in Pune, in the state of Maharashtra, India.

5.  **Feed back**

> Any feedback You provide with respect to the Application shall be
> deemed to be non-confidential. The Application shall be free to use
> such information on an unrestricted basis. Further, by submitting the
> feedback, You represent and warrant that (i) Your feedback does not
> contain confidential or proprietary information of You or of third
> parties; (ii) TGC is not under any obligation of confidentiality,
> express or implied, with respect to the feedback; (iii) the
> Application may have something similar to the feedback already under
> consideration or in development; and (iv) You are not entitled to any
> compensation or reimbursement of any kind from TGC for the feedback
> under any circumstances, unless specified.
>
> **Contact us**
>
> If you have any questions or queries about this Privacy policy, please
> contact us at: \
> <Skillmuni@thegamificationcompany.com>
